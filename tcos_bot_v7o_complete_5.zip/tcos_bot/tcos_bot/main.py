"""
TCOS-L Bot — Entry Point
========================
Run from the openalgo\ folder:
    py -m tcos_bot.main

Or from inside tcos_bot\ folder:
    py main.py
"""
from __future__ import annotations

from dotenv import load_dotenv
load_dotenv()

import argparse
import glob
import logging
import os
import shutil
import signal
import sqlite3
import sys
from pathlib import Path

# ── Path bootstrap ────────────────────────────────────────────────────────────
_HERE   = Path(__file__).resolve().parent
_PARENT = _HERE.parent
if str(_PARENT) not in sys.path:
    sys.path.insert(0, str(_PARENT))
# ─────────────────────────────────────────────────────────────────────────────

import pandas as pd

from tcos_bot.monitoring.logger import setup_logging

log = logging.getLogger(__name__)

# ── Instrument catalogue ──────────────────────────────────────────────────────
ALL_INSTRUMENTS = {
    "1": ("NIFTY",       "NSE_INDEX"),
    "2": ("BANKNIFTY",   "NSE_INDEX"),
    "3": ("SENSEX",      "BSE_INDEX"),
    "4": ("BANKEX",      "BSE_INDEX"),
    "5": ("CRUDEOIL",    "MCX"),
    # "6": ("GOLDM",   "MCX"),   # DISABLED: illiquid options, stale WS data causes ₹1L+ losses
    # "7": ("SILVERM", "MCX"),   # DISABLED: illiquid options, stale WS data causes ₹1L+ losses
    "8": ("NATURALGAS",  "MCX"),
}
SHORTCUTS = {
    "A":  ["1","2","3","4","5","8"],  # GOLDM(6) and SILVERM(7) disabled
    "N":  ["1","2"],
    "B":  ["3","4"],
    "M":  ["5","8"],    # GOLDM(6) and SILVERM(7) disabled — illiquid WS
    "NB": ["1","2","3","4"],
}

# Default brick sizes per symbol
BRICK_SIZES = {
    "NIFTY":       12,
    "BANKNIFTY":   40,
    "SENSEX":      50,
    "BANKEX":      50,
    "CRUDEOIL":     8,
    "GOLDM":       150,
    "SILVERM":     500,
    "NATURALGAS":    4,
}


# ── Lot size from openalgo.db ─────────────────────────────────────────────────
_HARDCODED_LOT_SIZES = {
    # Fallbacks if DB lookup fails — verify these against your broker
    "NIFTY":       65,
    "BANKNIFTY":   30,
    "SENSEX":      20,
    "BANKEX":      20,
    "CRUDEOIL":   100,
    "GOLDM":       10,
    "SILVERM":      5,
    "NATURALGAS": 1250,
}

def _get_lot_size_from_db(symbol: str, exchange: str) -> int:
    """
    Read lot size directly from openalgo.db symtoken table.
    Falls back to hardcoded value if DB unavailable.
    """
    deriv_map = {
        "NSE_INDEX": "NFO", "BSE_INDEX": "BFO",
        "NSE": "NFO", "BSE": "BFO", "MCX": "MCX",
    }
    deriv_ex = deriv_map.get(exchange.upper(), "NFO")
    root = symbol.upper()

    db_path = os.path.join(os.getcwd(), "db", "openalgo.db")
    if os.path.exists(db_path):
        try:
            con = sqlite3.connect(db_path)
            row = con.execute(
                "SELECT lotsize FROM symtoken "
                "WHERE exchange=? AND UPPER(symbol) LIKE ? "
                "AND lotsize > 0 LIMIT 1",
                (deriv_ex, root + "%"),
            ).fetchone()
            con.close()
            if row and row[0]:
                return int(row[0])
        except Exception as e:
            print(f"  ⚠️ DB lot size lookup failed for {symbol}: {e}")

    fallback = _HARDCODED_LOT_SIZES.get(root, 1)
    print(f"  ℹ️ Using hardcoded lot size for {symbol}: {fallback}")
    return fallback


# ── Interactive menus ─────────────────────────────────────────────────────────

def _menu_instruments() -> list[tuple[str, str, float]]:
    """Returns list of (symbol, exchange, brick_size)."""
    print()
    print("=" * 60)
    print("📋  SELECT INSTRUMENTS TO TRADE")
    print("=" * 60)
    print()
    print("  NSE / BSE:")
    print("    1. NIFTY         (brick=12)    2. BANKNIFTY   (brick=40)")
    print("    3. SENSEX        (brick=50)    4. BANKEX      (brick=50)")
    print()
    print("  MCX:")
    print("    5. CRUDEOIL      (brick=8)     6. GOLDM       (brick=150)")
    print("    7. SILVERM       (brick=500)   8. NATURALGAS  (brick=4)")
    print()
    print("  Shortcuts:")
    print("    A  → All    N  → NSE (1+2)    B  → BSE (3+4)")
    print("    M  → MCX    NB → NSE+BSE (1+2+3+4)")
    print()

    raw = input("  👉 Enter choice (e.g. 1,2 or A/N/B/M/NB) [default: NB]: ").strip().upper()
    if not raw:
        raw = "NB"

    keys = SHORTCUTS.get(raw, None)
    if keys is None:
        keys = []
        for token in raw.replace(" ", "").split(","):
            if token in ALL_INSTRUMENTS:
                keys.append(token)
            else:
                print(f"  ⚠️ Unknown: '{token}' — skipped")

    if not keys:
        print("  ⚠️ No valid selection — defaulting to NB (NSE+BSE)")
        keys = SHORTCUTS["NB"]

    result = []
    for k in keys:
        sym, ex = ALL_INSTRUMENTS[k]
        bs = BRICK_SIZES.get(sym, 50)
        result.append((sym, ex, float(bs)))

    print()
    print(f"  ✅ Trading: {', '.join(s for s,_,_ in result)}")
    print("=" * 60)
    return result


def _menu_lots(instruments: list[tuple[str, str, float]]) -> int:
    """Returns number of lots (same for all instruments, grade multiplier applied later)."""
    print()
    print("=" * 60)
    print("📦  SELECT NUMBER OF LOTS PER TRADE")
    print("=" * 60)
    print()
    print("  This is the MAXIMUM lots for a Grade A signal.")
    print("  Grade B signals automatically use 50% (minimum 1 lot).")
    print()

    # Show lot sizes for selected instruments
    print("  Lot sizes for your selection:")
    for sym, ex, _ in instruments:
        ls = _get_lot_size_from_db(sym, ex)
        print(f"    {sym:<12} = {ls} units per lot")
    print()
    print("  Enter any number 1–100  [default: 1]")
    print()

    raw = input("  👉 Lots per trade: ").strip()
    if not raw:
        lots = 1
    else:
        try:
            lots = int(raw)
            if lots < 1:
                print("  ⚠️ Must be ≥ 1 — defaulting to 1")
                lots = 1
            elif lots > 10:
                confirm = input(f"  ⚠️ {lots} lots is high. Type YES to confirm: ").strip().upper()
                if confirm != "YES":
                    lots = 1
                    print("  ℹ️ Defaulted to 1 lot")
        except ValueError:
            print(f"  ⚠️ '{raw}' is not valid — defaulting to 1")
            lots = 1

    print()
    print(f"  ✅ Lots per trade: {lots}  (Grade A={lots} lots, Grade B={max(1, lots//2)} lots)")
    print("=" * 60)
    return lots


def _menu_cleanup() -> None:
    """Interactive DB / file cleanup menu."""
    print()
    print("=" * 60)
    print("🗑️   DATA CLEANUP OPTIONS")
    print("=" * 60)
    print()
    print("    1. Fresh start  — Delete OHLC + Renko data (keep trades)")
    print("    2. Clear trades — Drop trade_manager table (reset positions)")
    print("    3. Full cleanup — Delete everything (fresh session)")
    print("    4. No cleanup   — Resume previous session  [default]")
    print()

    raw = input("  👉 Enter choice (1/2/3/4) [default: 4]: ").strip()

    from sqlalchemy import create_engine
    from sqlalchemy.pool import NullPool
    db_url = os.environ.get("TRADE_DB_URL", "sqlite:///db/tradebook.db")
    engine = create_engine(db_url, future=True, poolclass=NullPool,
                           connect_args={"check_same_thread": False})

    def _drop_tradebook_tables(*patterns):
        try:
            from sqlalchemy import inspect as sa_inspect
            with engine.begin() as conn:
                all_tables = sa_inspect(engine).get_table_names()
                for t in all_tables:
                    if any(t.startswith(p) for p in patterns):
                        conn.exec_driver_sql(f"DROP TABLE IF EXISTS [{t}];")
                        print(f"  🗑️  Dropped table: {t}")
        except Exception as e:
            print(f"  ⚠️ DB cleanup error: {e}")

    def _clean_ohlc_files():
        deleted = 0
        for entry in glob.glob("ohlcdata/*"):
            # Preserve symbols_to_trade.csv so instrument config survives
            if "symbols_to_trade" in entry:
                continue
            try:
                if os.path.isfile(entry):
                    os.remove(entry)
                    deleted += 1
                elif os.path.isdir(entry):
                    shutil.rmtree(entry)
                    deleted += 1
            except (PermissionError, OSError) as e:
                print(f"  ⚠️ Could not delete {entry}: {e}")
        if deleted:
            print(f"  🗑️  Deleted {deleted} OHLC file(s)")

    if raw == "1":
        print("\n  🗑️  Deleting OHLC + Renko tables and files...")
        _drop_tradebook_tables("ohlc", "renko")
        _clean_ohlc_files()
        print("  ✅ OHLC data cleared.\n")

    elif raw == "2":
        print("\n  🗑️  Clearing trade_manager...")
        _drop_tradebook_tables("trade_manager")
        print("  ✅ Trade history cleared.\n")

    elif raw == "3":
        print("\n  🗑️  Full cleanup — deleting all data...")
        _drop_tradebook_tables("ohlc", "renko", "trade_manager")
        _clean_ohlc_files()
        # Also delete tradebook.db so schema is recreated fresh
        db_file = db_url.replace("sqlite:///", "").replace("sqlite://", "")
        if os.path.exists(db_file):
            try:
                engine.dispose()
                os.remove(db_file)
                print(f"  🗑️  Deleted {db_file}")
            except OSError as e:
                print(f"  ⚠️ Could not delete {db_file}: {e}")
        print("  ✅ Full cleanup done.\n")

    else:
        print("\n  ✅ No cleanup — resuming previous session.\n")

    engine.dispose()
    print("=" * 60)


# ── Startup banner ────────────────────────────────────────────────────────────

def _print_banner():
    print("""
╔══════════════════════════════════════════════════════════════╗
║                                                              ║
║          📈   T C O S - L   T R A D I N G   B O T   📉      ║
║                                                              ║
║    NIFTY ▲12   BANKNIFTY ▲40   SENSEX ▲50   BANKEX ▲50      ║
║    CRUDE ▲8    GOLDM ▲150      SILVERM ▲500  NATGAS ▲4       ║
║                                                              ║
║    Strategy: RENKO + TCOS-L 3-Layer Filter + Smart TSL      ║
║    Mode: LONG OPTIONS ONLY   Execution: AUTO                 ║
╚══════════════════════════════════════════════════════════════╝
""")


# ── Broker client ─────────────────────────────────────────────────────────────

def _build_client():
    try:
        from openalgo import api
        client = api(
            api_key = os.environ["OPENALGO_API_KEY"],
            host    = os.environ.get("OPENALGO_HOST", "http://localhost:5000"),
        )
        log.info("Broker client initialised: %s", os.environ.get("OPENALGO_HOST"))
        return client
    except ImportError:
        log.critical("openalgo package not found.  pip install openalgo")
        sys.exit(1)
    except KeyError as e:
        log.critical("Missing environment variable: %s", e)
        sys.exit(1)


# ── Symbol loader ─────────────────────────────────────────────────────────────

def _build_symbols_df(
    instruments: list[tuple[str, str, float]],
    lots: int,
) -> pd.DataFrame:
    """
    Build the symbols DataFrame and upsert into DB.
    Also patches MAX_LOTS in settings so qty is correct.
    """
    from tcos_bot.data.trade_store import symbol_store
    import tcos_bot.config.settings as _s

    rows = []
    for sym, ex, bs in instruments:
        symbol_store.upsert(exchange=ex, symbol=sym, brick_size=bs)
        rows.append({"symbol": sym, "exchange": ex, "brick_size": bs})

    # Patch MAX_LOTS at runtime so all selected instruments use the chosen lot count
    for sym, _, _ in instruments:
        _s.MAX_LOTS[sym] = lots

    df = pd.DataFrame(rows)
    df["exchange"]   = df["exchange"].str.upper()
    df["brick_size"] = pd.to_numeric(df["brick_size"], errors="coerce").fillna(50.0)
    return df


# ── Argument parser ───────────────────────────────────────────────────────────

def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="TCOS-L Nifty Options Bot")
    parser.add_argument("--log-dir",   default="log")
    parser.add_argument("--log-level", default="INFO",
                        choices=["DEBUG", "INFO", "WARNING"])
    parser.add_argument("--dry-run",   action="store_true",
                        help="Skip actual order placement")
    # Legacy --symbols flag kept for compatibility but ignored (interactive menu used instead)
    parser.add_argument("--symbols",   default="ohlcdata/symbols_to_trade.csv",
                        help="(legacy) CSV seed path — ignored when running interactively")
    return parser.parse_args()


# ── Main ──────────────────────────────────────────────────────────────────────

def main() -> None:
    args = _parse_args()

    setup_logging(
        log_dir       = args.log_dir,
        script_name   = "tcos_bot",
        console_level = getattr(logging, args.log_level),
    )

    _print_banner()

    # ── Interactive startup menus ──────────────────────────────────────────
    instruments = _menu_instruments()
    lots        = _menu_lots(instruments)
    _menu_cleanup()

    print()
    print("=" * 60)
    print("🚀  Starting TCOS-L engine...")
    print("=" * 60)
    print()

    log.info("=" * 60)
    log.info("TCOS-L Starting — instruments=%s lots=%d",
             [s for s,_,_ in instruments], lots)
    log.info("=" * 60)

    client   = _build_client()
    if client is None:
        log.critical(
            "💀 Broker client is None — cannot start engine. "
            "Check OPENALGO_API_KEY and OPENALGO_HOST environment variables, "
            "and ensure the OpenAlgo server is running at %s.",
            os.environ.get("OPENALGO_HOST", "http://localhost:5000"),
        )
        sys.exit(1)

    strategy = os.environ.get("OPENALGO_STRATEGY", "TCOS_L")
    product  = os.environ.get("OPENALGO_PRODUCT", "MIS")

    symbols_df = _build_symbols_df(instruments, lots)

    from tcos_bot.core.engine import TradingEngine
    engine = TradingEngine(client, strategy=strategy, product=product)

    def _shutdown(sig, _frame):
        log.info("Shutdown signal received (%s)", sig)
        engine.stop()
        sys.exit(0)

    signal.signal(signal.SIGINT,  _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    engine.run(symbols_df)


if __name__ == "__main__":
    main()
