"""
LTP Store
=========
Thread-safe, lock-per-symbol LTP cache with staleness detection.
Replaces the raw `ltp_dict` / `ltp_timestamps` global dicts
that were scattered throughout the original bot.

Design
------
- One RWLock per symbol bucket (16 buckets, hash-based)
- O(1) get/set
- Age query in microseconds
- No GIL-unsafe operations
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, Optional, Tuple

log = logging.getLogger(__name__)

_BUCKET_COUNT = 16


@dataclass
class _LTPEntry:
    ltp:       float
    timestamp: float   # time.monotonic()
    source:    str     # "WEBSOCKET" | "REST"


class LTPStore:
    """
    Thread-safe last-traded-price cache.

    Example
    -------
    store = LTPStore()
    store.update("NIFTY", 22150.0, source="WEBSOCKET")
    ltp, age = store.get("NIFTY")
    """

    def __init__(self, stale_threshold_secs: float = 10.0) -> None:
        self._stale_threshold = stale_threshold_secs
        self._data:  Dict[str, _LTPEntry] = {}
        self._locks: list[threading.RLock] = [
            threading.RLock() for _ in range(_BUCKET_COUNT)
        ]

    # ── Write ──────────────────────────────────────────────────────────────────

    def update(self, symbol: str, ltp: float, source: str = "WEBSOCKET") -> None:
        """
        Store a new LTP for *symbol*.
        No-op if *ltp* is non-positive or NaN.
        """
        if not (ltp and ltp > 0 and ltp == ltp):   # NaN guard
            return
        with self._lock_for(symbol):
            prev = self._data.get(symbol)
            self._data[symbol] = _LTPEntry(
                ltp=float(ltp),
                timestamp=time.monotonic(),
                source=source,
            )
            if prev and abs(ltp - prev.ltp) / prev.ltp > 0.05:
                log.warning(
                    "LTP spike %s: %.2f → %.2f (%.1f%%)",
                    symbol, prev.ltp, ltp, (ltp - prev.ltp) / prev.ltp * 100,
                )

    # ── Read ───────────────────────────────────────────────────────────────────

    def get(self, symbol: str) -> Tuple[Optional[float], float]:
        """
        Return *(ltp, age_seconds)*.
        If symbol is unknown, returns *(None, inf)*.
        """
        with self._lock_for(symbol):
            entry = self._data.get(symbol)
        if entry is None:
            return None, float("inf")
        age = time.monotonic() - entry.timestamp
        return entry.ltp, age

    def get_safe(
        self, symbol: str, max_age: Optional[float] = None
    ) -> Tuple[Optional[float], float]:
        """
        Like *get* but returns *(None, age)* if the entry is stale.
        Uses *stale_threshold_secs* when *max_age* is None.
        """
        ltp, age = self.get(symbol)
        threshold = max_age if max_age is not None else self._stale_threshold
        if ltp is None or age > threshold:
            return None, age
        return ltp, age

    def is_stale(self, symbol: str, threshold_secs: Optional[float] = None) -> bool:
        _, age = self.get(symbol)
        limit = threshold_secs if threshold_secs is not None else self._stale_threshold
        return age > limit

    def age(self, symbol: str) -> float:
        """Return seconds since last update for *symbol*."""
        _, age = self.get(symbol)
        return age

    def all_symbols(self) -> list[str]:
        """Return all tracked symbols (snapshot, thread-safe)."""
        # Minimal lock: just read keys once
        return list(self._data.keys())

    def stale_symbols(self, threshold_secs: Optional[float] = None) -> list[str]:
        """Return symbols whose LTP is older than threshold."""
        limit = threshold_secs or self._stale_threshold
        now   = time.monotonic()
        result = []
        for sym, entry in list(self._data.items()):
            if (now - entry.timestamp) > limit:
                result.append(sym)
        return result

    def health_report(self) -> dict:
        """Return health summary for logging."""
        now   = time.monotonic()
        total = len(self._data)
        stale_count = sum(
            1 for e in self._data.values()
            if (now - e.timestamp) > self._stale_threshold
        )
        return {
            "total": total,
            "stale": stale_count,
            "healthy": total - stale_count,
        }

    # ── Private ────────────────────────────────────────────────────────────────

    def _lock_for(self, symbol: str) -> threading.RLock:
        bucket = hash(symbol) % _BUCKET_COUNT
        return self._locks[bucket]


# Module-level singleton — import and reuse everywhere
ltp_store = LTPStore()
