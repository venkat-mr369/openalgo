"""
Trade Store
===========
Thread-safe SQLite persistence for the trade_manager table.
Replaces the scattered read_csv / save_to_csv / SQLite hybrid.

Design
------
- Single write lock (no concurrent writes, SQLite WAL for reads)
- Schema auto-migration: new columns added without downtime
- Typed read returns list[TradeRow] not raw DataFrame
- Bulk upsert for batch signal inserts
- WAL + busy_timeout for max concurrency
"""

from __future__ import annotations

import logging
import threading
from contextlib import contextmanager
from datetime import datetime
from typing import Generator, List, Optional

import pandas as pd

# SQLAlchemy is a required runtime dependency but an optional import-time one.
# Guarding it here means tests that mock trade_store (and therefore never call
# any DB method) can import this module cleanly without sqlalchemy installed.
# Any code path that actually touches the database will hit the clear error below.
try:
    from sqlalchemy import create_engine, event, text
    from sqlalchemy.pool import NullPool
    _SQLALCHEMY_AVAILABLE = True
except ImportError:  # pragma: no cover
    _SQLALCHEMY_AVAILABLE = False
    create_engine = None  # type: ignore[assignment]
    event       = None    # type: ignore[assignment]
    text        = None    # type: ignore[assignment]
    NullPool    = None    # type: ignore[assignment]

from tcos_bot.config.settings import cfg
from tcos_bot.models.types import OrderStatus, TradeRow

log = logging.getLogger(__name__)

# ── SQLite engine ─────────────────────────────────────────────────────────────

# Bug D fix: lazy engine initialization.
# The module-level create_engine() call used to run at import time, which crashed
# if TRADE_DB_URL hadn't been set yet (e.g. pytest conftest order).
# _get_engine() initializes the engine on first use so callers control timing.
_engine = None
_engine_lock = threading.Lock()


def _set_pragmas(dbapi_conn, _record) -> None:
    cur = dbapi_conn.cursor()
    cur.execute("PRAGMA journal_mode=WAL;")
    cur.execute("PRAGMA synchronous=NORMAL;")
    cur.execute("PRAGMA busy_timeout=10000;")
    cur.execute("PRAGMA wal_autocheckpoint=1000;")
    cur.close()


def _get_engine():
    """Return (and lazily create) the SQLAlchemy engine. Thread-safe."""
    if not _SQLALCHEMY_AVAILABLE:
        raise ImportError(
            "sqlalchemy is required for database persistence. "
            "Install it with: pip install sqlalchemy"
        )
    global _engine
    if _engine is not None:
        return _engine
    with _engine_lock:
        if _engine is not None:         # double-checked locking
            return _engine
        eng = create_engine(
            cfg.persistence.db_url,
            future=True,
            poolclass=NullPool,
            pool_pre_ping=True,
            connect_args={"check_same_thread": False},
        )
        event.listen(eng, "connect", _set_pragmas)
        _engine = eng
    return _engine



def get_engine():
    """Public accessor for the SQLAlchemy engine. Use in tests instead of importing _engine."""
    return _get_engine()


# ── Trade Store ───────────────────────────────────────────────────────────────

class TradeStore:
    """
    Manages trade_manager persistence.

    All public methods are thread-safe.
    Use read_df() when the caller needs a full DataFrame
    (e.g., the order execution loop).
    """

    # Columns in schema order — used for CREATE TABLE
    _COLUMNS = {
        "id":                       "INTEGER PRIMARY KEY AUTOINCREMENT",
        "exchange":                 "TEXT",
        "timestamp":                "TEXT",
        "renko_signal":             "TEXT",
        "symbol":                   "TEXT",
        "entry_price":              "REAL",
        "limit_entry_price":        "REAL",
        "exec_price":               "REAL",
        "quantity":                 "REAL",
        "order_status":             "TEXT",
        "orderid":                  "TEXT",
        "close_reason":             "TEXT",
        "close_price":              "REAL",
        "gap_minutes":              "REAL",
        "signal_source":            "TEXT",
        "col_value":                "REAL",
        "peak_brick_since_entry":   "REAL",
        "peak_ltp_since_entry":     "REAL",
        "nft_validated":            "INTEGER DEFAULT 0",
        "nft_target":               "REAL",
        "nft_rev_count":            "INTEGER DEFAULT 0",
        "nft_last_dir":             "TEXT",
        "option_symbol":            "TEXT",
        "entry_mode":               "TEXT",
        "chop_reversals":           "INTEGER DEFAULT 0",
        "chop_last_dir":            "TEXT",
        "chop_last_ltp":            "REAL",
        "index_ltp":                "REAL",
        "fill_timestamp":           "TEXT",
        # Quality metadata (new)
        "signal_grade":             "TEXT",
        "quality_score":            "INTEGER",
        "day_regime":               "TEXT",
        "brick_size_hint":          "REAL",
        # Reconciliation fields
        "position_key":             "TEXT",    # deterministic dedup key for RECONCILE_IMPORT
        "close_timestamp":          "TEXT",    # when the row was closed
        # Structural stop levels — written by signal_generator._create_entry(),
        # read by position_tracker._on_entry_fill() and _reseed_trailing_stops().
        # Must be in schema so they survive save_df / read_df round-trips.
        "struct_high":              "REAL",
        "struct_low":               "REAL",
        # NFT per-position LTP tracking (C-12 / BUG-3 fix: separate from chop_last_ltp)
        "nft_last_ltp":             "REAL",
    }

    def __init__(self) -> None:
        self._write_lock = threading.Lock()
        self._schema_ready = False
        # Schema is initialised lazily on first use so that importing
        # trade_store without TRADE_DB_URL set does not crash at import time.
        # Tests set TRADE_DB_URL in conftest before any import; production
        # code sets it via environment before main() runs.
        try:
            self._ensure_schema()
            self._schema_ready = True
        except Exception:
            log.warning(
                "TradeStore: schema init deferred — DB not accessible yet. "
                "Will retry on first read/write."
            )

    def _ensure_schema_if_needed(self) -> None:
        """Retry schema init on first operation if it was deferred at startup."""
        if not self._schema_ready:
            self._ensure_schema()
            self._schema_ready = True

    # ── Public API ─────────────────────────────────────────────────────────────

    def read_df(self) -> pd.DataFrame:
        """Return the full trade_manager as a DataFrame."""
        self._ensure_schema_if_needed()
        try:
            # Recovery guard: handle every possible crash point in save_df's
            # DROP-RENAME-RENAME-DROP sequence.
            #
            # Crash between RENAME-1 and RENAME-2:
            #   trade_manager      → gone (now trade_manager_old)
            #   trade_manager_tmp  → exists (new data, not yet renamed)
            #   Action: promote _tmp (new write) → trade_manager
            #
            # Crash between DROP-1 and RENAME-1 (trade_manager_old was dropped,
            # trade_manager is now trade_manager_old, _tmp exists):
            #   trade_manager      → gone
            #   trade_manager_tmp  → exists (may be the only surviving copy)
            #   Action: same — promote _tmp
            #
            # Crash at any other point leaves trade_manager intact; no action.
            #
            # Additionally: if trade_manager is still missing and only
            # trade_manager_old exists (rare double-crash), recover from _old.
            with _get_engine().begin() as cn:
                tables = {r[0] for r in cn.exec_driver_sql(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                ).fetchall()}
                if "trade_manager" not in tables:
                    if "trade_manager_tmp" in tables:
                        log.warning(
                            "⚠️ trade_manager missing but _tmp exists — recovering from _tmp"
                        )
                        cn.exec_driver_sql(
                            "ALTER TABLE trade_manager_tmp RENAME TO trade_manager;"
                        )
                    elif "trade_manager_old" in tables:
                        # Double-crash safety net: promote _old as last resort
                        log.warning(
                            "⚠️ trade_manager missing, _tmp missing, _old exists — "
                            "recovering from trade_manager_old (C-5 blind-spot fix)"
                        )
                        cn.exec_driver_sql(
                            "ALTER TABLE trade_manager_old RENAME TO trade_manager;"
                        )
            with _get_engine().connect() as cn:
                df = pd.read_sql("SELECT * FROM trade_manager", cn)
            return df
        except Exception:
            log.exception("TradeStore.read_df failed")
            return pd.DataFrame()

    def save_df(self, df: pd.DataFrame) -> None:
        """
        Replace the full trade_manager contents atomically.
        Used by the order loop after each cycle.
        """
        if df is None or df.empty:
            return
        df = df.copy()
        if "timestamp" in df.columns:
            df["timestamp"] = (
                pd.to_datetime(df["timestamp"], errors="coerce")
                .dt.strftime("%Y-%m-%d %H:%M:%S")
            )
        with self._write_lock:
            try:
                with _get_engine().begin() as cn:
                    self._ensure_schema_conn(cn)
                    self._sync_columns(cn, df)
                    # Fast replace via temp table + rename
                    df.to_sql(
                        "trade_manager_tmp", con=cn,
                        if_exists="replace", index=False,
                    )
                    cn.execute(text("DROP TABLE IF EXISTS trade_manager_old;"))
                    cn.execute(text("ALTER TABLE trade_manager RENAME TO trade_manager_old;"))
                    cn.execute(text("ALTER TABLE trade_manager_tmp RENAME TO trade_manager;"))
                    cn.execute(text("DROP TABLE IF EXISTS trade_manager_old;"))
            except Exception:
                log.exception("TradeStore.save_df failed")

    def append_rows(self, rows: List[dict]) -> None:
        """Append one or more rows without replacing existing data."""
        if not rows:
            return
        df = pd.DataFrame(rows)
        if "timestamp" in df.columns:
            df["timestamp"] = (
                pd.to_datetime(df["timestamp"], errors="coerce")
                .dt.strftime("%Y-%m-%d %H:%M:%S")
            )
        with self._write_lock:
            try:
                with _get_engine().begin() as cn:
                    self._ensure_schema_conn(cn)
                    self._sync_columns(cn, df)
                    df.to_sql("trade_manager", con=cn, if_exists="append", index=False)
                    log.debug("TradeStore: appended %d rows", len(df))
            except Exception:
                log.exception("TradeStore.append_rows failed")

    def update_row(self, orderid: str, **fields) -> None:
        """Update specific fields for a row identified by orderid."""
        if not orderid or not fields:
            return
        sets   = ", ".join(f"{k} = :{k}" for k in fields)
        params = {**fields, "orderid": orderid}
        with self._write_lock:
            try:
                with _get_engine().begin() as cn:
                    cn.execute(
                        text(f"UPDATE trade_manager SET {sets} WHERE orderid = :orderid"),
                        params,
                    )
            except Exception:
                log.exception("TradeStore.update_row failed for orderid=%s", orderid)

    def open_rows(
        self,
        symbol: Optional[str] = None,
        signal: Optional[str] = None,
    ) -> pd.DataFrame:
        """Return OPEN rows, optionally filtered by symbol and/or signal."""
        clauses = ["order_status = 'OPEN'"]
        params: dict = {}
        if symbol:
            clauses.append("symbol = :symbol")
            params["symbol"] = symbol
        if signal:
            clauses.append("renko_signal = :signal")
            params["signal"] = signal
        where = " AND ".join(clauses)
        try:
            with _get_engine().connect() as cn:
                return pd.read_sql(f"SELECT * FROM trade_manager WHERE {where}", cn, params=params)
        except Exception:
            log.exception("TradeStore.open_rows failed")
            return pd.DataFrame()

    def inposition_rows(self, symbol: Optional[str] = None) -> pd.DataFrame:
        """Return INPOSITION rows for tracking active trades."""
        clause = "order_status = 'INPOSITION'"
        params: dict = {}
        if symbol:
            clause += " AND symbol = :symbol"
            params["symbol"] = symbol
        try:
            with _get_engine().connect() as cn:
                return pd.read_sql(f"SELECT * FROM trade_manager WHERE {clause}", cn, params=params)
        except Exception:
            log.exception("TradeStore.inposition_rows failed")
            return pd.DataFrame()

    def import_position(self, row: dict) -> bool:
        """
        Idempotently insert a reconciled broker position.

        Returns True if a new row was inserted, False if already present.
        Dedup logic:
          1. If row has a position_key → check for existing INPOSITION row
             with the same key.
          2. Else fall back to (symbol, option_symbol, order_status=INPOSITION).
        """
        pkey = row.get("position_key")
        with self._write_lock:
            try:
                with _get_engine().begin() as cn:
                    self._ensure_schema_conn(cn)
                    # Dedup check — use SELECT 1 (not SELECT id) so this works even
                    # on tables created by test helpers that omit the id column.
                    if pkey:
                        existing = cn.execute(
                            text(
                                "SELECT 1 FROM trade_manager "
                                "WHERE position_key = :pk "
                                "AND order_status IN ('INPOSITION', 'OPEN') LIMIT 1"
                            ),
                            {"pk": pkey},
                        ).fetchone()
                    else:
                        sym     = row.get("symbol", "")
                        opt_sym = row.get("option_symbol", "")
                        existing = cn.execute(
                            text(
                                "SELECT 1 FROM trade_manager "
                                "WHERE symbol = :sym "
                                "AND option_symbol = :opt "
                                "AND order_status = 'INPOSITION' LIMIT 1"
                            ),
                            {"sym": sym, "opt": opt_sym},
                        ).fetchone()
                    if existing:
                        log.debug("import_position: already tracked (pkey=%s) — skipping", pkey)
                        return False
                    df = pd.DataFrame([row])
                    self._sync_columns(cn, df)
                    df.to_sql("trade_manager", con=cn, if_exists="append", index=False)
                    log.debug("import_position: inserted row pkey=%s sym=%s",
                              pkey, row.get("symbol"))
                    return True
            except Exception:
                log.exception("TradeStore.import_position failed")
                return False

    def mark_closed_row(self, row_id: int, reason: str, close_price: Optional[float],
                        close_timestamp: Optional[str] = None) -> None:
        """
        Mark a single trade_manager row as CLOSED by primary key id.
        Safe to call multiple times — no-op if already CLOSED.
        """
        ts = close_timestamp or datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
        with self._write_lock:
            try:
                with _get_engine().begin() as cn:
                    cn.execute(
                        text(
                            "UPDATE trade_manager "
                            "SET order_status='CLOSED', close_reason=:reason, "
                            "close_price=:cp, close_timestamp=:ts "
                            "WHERE id=:id AND order_status != 'CLOSED'"
                        ),
                        {"reason": reason, "cp": close_price, "ts": ts, "id": row_id},
                    )
            except Exception:
                log.exception("TradeStore.mark_closed_row failed for id=%s", row_id)

    # ── Schema management ──────────────────────────────────────────────────────

    def _ensure_schema(self) -> None:
        with _get_engine().begin() as cn:
            self._ensure_schema_conn(cn)

    def _ensure_schema_conn(self, cn) -> None:
        cols_ddl = ",\n    ".join(f"{c} {t}" for c, t in self._COLUMNS.items())
        cn.exec_driver_sql(f"""
            CREATE TABLE IF NOT EXISTS trade_manager (
                {cols_ddl}
            );
        """)
        # ── Column migration first — indexes are created AFTER so they never
        # reference a column that does not yet exist in an older schema.
        # (Pre-existing bug: index creation preceded migration, crashing when
        # an old table was missing 'orderid'.)
        existing = {
            r[1] for r in
            cn.exec_driver_sql("PRAGMA table_info(trade_manager)").fetchall()
        }
        for col, typedef in self._COLUMNS.items():
            if col == "id":
                continue
            if col not in existing:
                base_type = typedef.split()[0]
                cn.exec_driver_sql(
                    f"ALTER TABLE trade_manager ADD COLUMN {col} {base_type};"
                )
                log.info("TradeStore: migrated column %s (%s)", col, base_type)

        # ── Indexes — safe to create now that all columns exist
        cn.exec_driver_sql("""
            CREATE UNIQUE INDEX IF NOT EXISTS ux_tm_orderid
            ON trade_manager(orderid) WHERE orderid IS NOT NULL AND orderid <> '';
        """)
        cn.exec_driver_sql(
            "CREATE INDEX IF NOT EXISTS ix_tm_ts ON trade_manager(timestamp);"
        )

    def _sync_columns(self, cn, df: pd.DataFrame) -> None:
        """Add any DataFrame columns not yet in the DB table."""
        existing = {
            r[1] for r in
            cn.exec_driver_sql("PRAGMA table_info(trade_manager)").fetchall()
        }
        for col in df.columns:
            if col not in existing and col != "id":
                dtype = df[col].dtype
                sql_type = (
                    "REAL"    if str(dtype).startswith("float") else
                    "INTEGER" if str(dtype).startswith("int") else
                    "TEXT"
                )
                try:
                    cn.exec_driver_sql(
                        f"ALTER TABLE trade_manager ADD COLUMN {col} {sql_type};"
                    )
                    log.info("TradeStore: dynamically added column %s %s", col, sql_type)
                except Exception:
                    pass   # Column may already exist in a concurrent session



# ── Fallback TradeStore (no SQLAlchemy) ──────────────────────────────────────

class _FallbackTradeStore:
    """
    Pure-Python TradeStore used when SQLAlchemy is not installed.

    Stores data in a thread-safe in-memory DataFrame that is optionally
    persisted to a JSON file (path from TRADE_DB_URL env var, or a temp file).
    Provides the same public interface as TradeStore so the rest of the bot
    is unaffected by the absence of SQLAlchemy.

    This is NOT a production persistence solution — install sqlalchemy for
    production use.  It is intentionally lightweight so that:
      1. Tests run without any DB dependency.
      2. The bot can start and run in degraded-persistence mode.
    """

    def __init__(self) -> None:
        import os, tempfile
        self._lock = threading.Lock()
        self._df   = pd.DataFrame()

        # Derive a file path from TRADE_DB_URL or use a temp file
        db_url = os.environ.get("TRADE_DB_URL", "")
        if db_url.startswith("sqlite:///"):
            path = db_url[len("sqlite:///"):]
            self._path = path.replace(".db", "_fallback.json")
        else:
            fd, self._path = tempfile.mkstemp(suffix="_fallback.json", prefix="tcos_")
            os.close(fd)

        self._load()
        log.warning(
            "⚠️  TradeStore: SQLAlchemy not available — using JSON fallback at %s. "
            "Install sqlalchemy for production use.",
            self._path,
        )

    def _load(self) -> None:
        import os
        try:
            if os.path.exists(self._path) and os.path.getsize(self._path) > 0:
                self._df = pd.read_json(self._path, orient="records")
        except Exception:
            self._df = pd.DataFrame()

    def _save(self) -> None:
        try:
            self._df.to_json(self._path, orient="records", indent=2)
        except Exception:
            log.exception("FallbackTradeStore._save failed")

    # ── Public API (mirrors TradeStore) ───────────────────────────────────────

    def read_df(self) -> pd.DataFrame:
        with self._lock:
            return self._df.copy()

    def save_df(self, df: pd.DataFrame) -> None:
        if df is None or df.empty:
            return
        with self._lock:
            self._df = df.copy()
            self._save()

    def append_rows(self, rows: list) -> None:
        if not rows:
            return
        new_df = pd.DataFrame(rows)
        with self._lock:
            self._df = pd.concat([self._df, new_df], ignore_index=True)
            self._save()

    def open_rows(self, symbol=None, signal=None) -> pd.DataFrame:
        with self._lock:
            df = self._df.copy()
        if df.empty:
            return df
        mask = df.get("order_status", pd.Series(dtype=str)) == "OPEN"
        if symbol:
            mask = mask & (df.get("symbol", pd.Series(dtype=str)) == symbol)
        if signal:
            mask = mask & (df.get("renko_signal", pd.Series(dtype=str)) == signal)
        return df[mask]

    def inposition_rows(self, symbol=None) -> pd.DataFrame:
        with self._lock:
            df = self._df.copy()
        if df.empty:
            return df
        mask = df.get("order_status", pd.Series(dtype=str)) == "INPOSITION"
        if symbol:
            mask = mask & (df.get("symbol", pd.Series(dtype=str)) == symbol)
        return df[mask]

    def import_position(self, row: dict) -> bool:
        pkey = row.get("position_key")
        with self._lock:
            if not self._df.empty and pkey:
                existing = self._df[
                    (self._df.get("position_key", pd.Series(dtype=str)) == pkey) &
                    (self._df.get("order_status", pd.Series(dtype=str)).isin(["INPOSITION", "OPEN"]))
                ]
                if not existing.empty:
                    return False
            self._df = pd.concat([self._df, pd.DataFrame([row])], ignore_index=True)
            self._save()
        return True

    def update_row(self, orderid: str, **fields) -> None:
        with self._lock:
            if self._df.empty or "orderid" not in self._df.columns:
                return
            mask = self._df["orderid"] == orderid
            for k, v in fields.items():
                self._df.loc[mask, k] = v
            self._save()

    def mark_closed_row(self, row_id: int, reason: str, close_price=None,
                        close_timestamp=None) -> None:
        with self._lock:
            if self._df.empty or "id" not in self._df.columns:
                return
            mask = (self._df["id"] == row_id) & (self._df["order_status"] != "CLOSED")
            self._df.loc[mask, "order_status"]  = "CLOSED"
            self._df.loc[mask, "close_reason"]  = reason
            self._df.loc[mask, "close_price"]   = close_price
            self._df.loc[mask, "close_timestamp"] = (
                close_timestamp or datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S")
            )
            self._save()


class _FallbackSymbolStore:
    """Lightweight in-memory SymbolStore for no-SQLAlchemy environments."""

    def __init__(self) -> None:
        self._lock  = threading.Lock()
        self._rows: list = []
        self._brick_cache: dict = {}
        log.warning("⚠️  SymbolStore: SQLAlchemy not available — using in-memory fallback.")

    def load_df(self) -> pd.DataFrame:
        with self._lock:
            return pd.DataFrame(self._rows) if self._rows else pd.DataFrame(
                columns=["exchange", "symbol", "brick_size"]
            )

    def upsert(self, exchange: str, symbol: str, brick_size: float) -> None:
        with self._lock:
            for r in self._rows:
                if r["exchange"] == exchange and r["symbol"] == symbol:
                    r["brick_size"] = brick_size
                    self._brick_cache.pop(symbol.upper(), None)
                    return
            self._rows.append({"exchange": exchange, "symbol": symbol, "brick_size": brick_size})
            self._brick_cache.pop(symbol.upper(), None)

    def get_brick_size(self, symbol: str, default: float = 50.0) -> float:
        cached = self._brick_cache.get(symbol.upper())
        if cached:
            return cached
        with self._lock:
            for r in self._rows:
                if r["symbol"].upper() == symbol.upper():
                    return float(r["brick_size"])
        return default

    def invalidate_cache(self, symbol=None) -> None:
        if symbol:
            self._brick_cache.pop(symbol.upper(), None)
        else:
            self._brick_cache.clear()

    def all_symbols(self) -> list:
        with self._lock:
            return [r["symbol"].upper() for r in self._rows]


# Module-level singleton
trade_store = TradeStore() if _SQLALCHEMY_AVAILABLE else _FallbackTradeStore()


# ── Symbol Store ──────────────────────────────────────────────────────────────

class SymbolStore:
    """
    Manages the `symbols_to_trade` table — the canonical list of
    instruments the bot monitors.

    Schema (mirrors original bot exactly)
    --------------------------------------
    exchange   TEXT
    symbol     TEXT
    brick_size REAL
    UNIQUE (exchange, symbol)

    Startup flow
    ------------
    1. load_df()           — load all rows into DataFrame
    2. upsert(symbol, ...) — auto-register new symbols on first trade
    3. get_brick_size()    — per-symbol brick lookup with 5-min cache
    """

    _BRICK_CACHE_TTL = 300   # seconds (match original _BRICK_CACHE_TTL)

    def __init__(self) -> None:
        self._write_lock  = threading.Lock()
        self._brick_cache: dict[str, tuple[float, float]] = {}   # {symbol: (size, ts)}
        self._schema_ready = False
        try:
            self._ensure_schema()
            self._schema_ready = True
        except Exception:
            log.warning("SymbolStore: schema init deferred — DB not accessible yet.")

    # ── Public API ──────────────────────────────────────────────────────────

    def load_df(self) -> pd.DataFrame:
        """
        Return all rows as a DataFrame with columns
        [exchange, symbol, brick_size].

        Returns empty DataFrame (not None) on any error so callers
        can always do `for _, row in df.iterrows()` safely.
        """
        try:
            with _get_engine().connect() as cn:
                return pd.read_sql("SELECT * FROM symbols_to_trade", cn)
        except Exception:
            log.exception("SymbolStore.load_df failed")
            return pd.DataFrame(columns=["exchange", "symbol", "brick_size"])

    def upsert(self, exchange: str, symbol: str, brick_size: float) -> None:
        """
        Insert or update one symbol row.
        Called automatically after every successful trade fill.
        Uses INSERT OR REPLACE which works with the UNIQUE PRIMARY KEY constraint.
        """
        with self._write_lock:
            try:
                with _get_engine().begin() as cn:
                    cn.exec_driver_sql(
                        "INSERT OR REPLACE INTO symbols_to_trade "
                        "(exchange, symbol, brick_size) VALUES (?, ?, ?)",
                        (exchange.upper(), symbol.upper(), float(brick_size)),
                    )
                self._brick_cache.pop(symbol.upper(), None)
                log.debug("SymbolStore: upserted %s %s bs=%.1f", exchange, symbol, brick_size)
            except Exception:
                log.exception("SymbolStore.upsert failed for %s %s", exchange, symbol)

    def get_brick_size(self, symbol: str, default: float = 50.0) -> float:
        """
        Return brick size for *symbol*.

        Priority
        --------
        1. In-memory cache (5-min TTL)
        2. symbols_to_trade DB table
        3. *default*

        This is called on every signal cycle — the cache keeps it fast.
        """
        import time as _time
        clean = symbol.upper().strip()

        cached = self._brick_cache.get(clean)
        if cached and (_time.time() - cached[1]) < self._BRICK_CACHE_TTL:
            return cached[0]

        try:
            with _get_engine().connect() as cn:
                row = cn.execute(
                    text("SELECT brick_size FROM symbols_to_trade "
                         "WHERE UPPER(symbol) = :sym LIMIT 1"),
                    {"sym": clean},
                ).fetchone()
            if row and row[0] and float(row[0]) > 0:
                bs = float(row[0])
                self._brick_cache[clean] = (bs, _time.time())
                return bs
        except Exception:
            log.debug("SymbolStore.get_brick_size DB miss for %s", clean)

        self._brick_cache[clean] = (default, _time.time())
        return default

    def invalidate_cache(self, symbol: str | None = None) -> None:
        """Flush brick-size cache. Pass None to flush all symbols."""
        if symbol:
            self._brick_cache.pop(symbol.upper(), None)
        else:
            self._brick_cache.clear()
            log.info("SymbolStore: brick cache fully invalidated")

    def all_symbols(self) -> list[str]:
        """Return list of all tracked symbol names."""
        df = self.load_df()
        return df["symbol"].str.upper().tolist() if not df.empty else []

    # ── Schema ──────────────────────────────────────────────────────────────

    def _ensure_schema(self) -> None:
        with _get_engine().begin() as cn:
            # PRIMARY KEY on (exchange, symbol) enables INSERT OR REPLACE upsert
            cn.exec_driver_sql("""
                CREATE TABLE IF NOT EXISTS symbols_to_trade (
                    exchange   TEXT NOT NULL,
                    symbol     TEXT NOT NULL,
                    brick_size REAL NOT NULL DEFAULT 50.0,
                    PRIMARY KEY (exchange, symbol)
                );
            """)


# Module-level singleton
symbol_store = SymbolStore() if _SQLALCHEMY_AVAILABLE else _FallbackSymbolStore()
