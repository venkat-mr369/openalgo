"""
Logging Infrastructure
======================
Structured logging with IST timestamps, emoji-prefixed levels,
file rotation, and console output. Replaces all print() calls.
"""

from __future__ import annotations

import logging
import os
import sys
import traceback
import threading
from datetime import datetime
from logging.handlers import RotatingFileHandler
from typing import Optional
from zoneinfo import ZoneInfo

_IST = ZoneInfo("Asia/Kolkata")
_LOCK = threading.Lock()


# ── IST-aware log formatter ───────────────────────────────────────────────────

class ISTFormatter(logging.Formatter):
    """Formats log records with IST timestamp and structured fields."""

    LEVEL_EMOJI = {
        logging.DEBUG:    "🔍",
        logging.INFO:     "ℹ️ ",
        logging.WARNING:  "⚠️ ",
        logging.ERROR:    "❌",
        logging.CRITICAL: "🚨",
    }

    def formatTime(self, record: logging.LogRecord, datefmt: Optional[str] = None) -> str:  # noqa: N802
        dt = datetime.fromtimestamp(record.created, tz=_IST)
        return dt.strftime("%Y-%m-%d %H:%M:%S")

    def format(self, record: logging.LogRecord) -> str:
        emoji = self.LEVEL_EMOJI.get(record.levelno, "  ")
        ts    = self.formatTime(record)
        base  = f"{ts} {emoji} [{record.name}] {record.getMessage()}"

        # ── Append traceback if present ───────────────────────────────────
        # The original implementation dropped exc_info entirely because it
        # never called formatException(). This meant log.exception() showed
        # only the one-liner message with no traceback — making every crash
        # completely invisible and impossible to debug.
        if record.exc_info:
            # formatException returns the full "Traceback (most recent call last):..." block
            tb = self.formatException(record.exc_info)
            base = f"{base}\n{tb}"
        if record.exc_text:
            base = f"{base}\n{record.exc_text}"
        if record.stack_info:
            base = f"{base}\n{self.formatStack(record.stack_info)}"

        return base


# ── Console filter: suppress noisy repetitive lines ──────────────────────────

class NoiseFilter(logging.Filter):
    """Drops high-frequency diagnostic lines from console (still written to file)."""

    _NOISE_PREFIXES = (
        "LTP NSE_INDEX",
        "LTP MCX",
        "Next data fetch",
        "Next OHLC monitor",
        "Updated brick_size",
        "ATR-based brick",
        "[normalize",
        "Correcting DB lot",
        "Positions book is empty",
        "Empty or None positions_book_df",
        "[lotsize]",
    )

    def filter(self, record: logging.LogRecord) -> bool:
        msg = record.getMessage()
        return not any(msg.startswith(p) for p in self._NOISE_PREFIXES)


# ── Public API ────────────────────────────────────────────────────────────────

def setup_logging(
    log_dir: str = "log",
    script_name: str = "tcos_bot",
    console_level: int = logging.INFO,
    file_level: int = logging.DEBUG,
    max_bytes: int = 50 * 1024 * 1024,   # 50 MB
    backup_count: int = 5,
) -> None:
    """
    Configure root logger with:
    - IST-formatted rotating file handler (full DEBUG output)
    - Console handler (INFO with noise suppressed)

    Call once at startup before any loggers are created.
    """
    os.makedirs(log_dir, exist_ok=True)
    ts = datetime.now(tz=_IST).strftime("%Y-%m-%d_%H-%M-%S")
    log_file = os.path.join(log_dir, f"{script_name}_{ts}.log")

    fmt = ISTFormatter()

    # ── File handler ──────────────────────────────────────────
    fh = RotatingFileHandler(
        log_file,
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8",
    )
    fh.setLevel(file_level)
    fh.setFormatter(fmt)

    # ── Console handler ───────────────────────────────────────
    ch = logging.StreamHandler(sys.stdout)
    ch.setLevel(console_level)
    ch.setFormatter(fmt)
    ch.addFilter(NoiseFilter())

    # ── Root logger ───────────────────────────────────────────
    root = logging.getLogger()
    root.setLevel(logging.DEBUG)
    root.addHandler(fh)
    root.addHandler(ch)

    # Silence noisy third-party loggers
    for lib in ("urllib3", "requests", "websocket", "sqlalchemy.engine"):
        logging.getLogger(lib).setLevel(logging.WARNING)

    root.info("Logging initialised → %s", log_file)


def get_logger(name: str) -> logging.Logger:
    """Return a named logger. Use module __name__ as convention."""
    return logging.getLogger(name)


# ── Trade-event helpers: structured log lines for P&L tracking ───────────────

class TradeLogger:
    """
    Emits structured log lines for every trade lifecycle event.
    All trade events go to a dedicated 'trade_events' logger so
    they can be streamed to a separate file / monitoring system.
    """

    _log = logging.getLogger("trade_events")

    @classmethod
    def entry(
        cls,
        symbol: str,
        action: str,
        option_symbol: str,
        entry_price: float,
        exec_price: float,
        quantity: int,
        mode: str,
        grade: str,
        regime: str,
    ) -> None:
        cls._log.info(
            "ENTRY | sym=%s | action=%s | opt=%s | entry=%.2f | exec=%.2f "
            "| qty=%d | mode=%s | grade=%s | regime=%s",
            symbol, action, option_symbol, entry_price,
            exec_price, quantity, mode, grade, regime,
        )

    @classmethod
    def exit(
        cls,
        symbol: str,
        action: str,
        option_symbol: str,
        entry_price: float,
        close_price: float,
        pnl_pts: float,
        reason: str,
    ) -> None:
        cls._log.info(
            "EXIT  | sym=%s | action=%s | opt=%s | entry=%.2f | close=%.2f "
            "| pnl=%+.2f pts | reason=%s",
            symbol, action, option_symbol, entry_price,
            close_price, pnl_pts, reason,
        )

    @classmethod
    def filter_block(cls, symbol: str, action: str, reason: str) -> None:
        cls._log.info(
            "BLOCK | sym=%s | action=%s | reason=%s",
            symbol, action, reason,
        )

    @classmethod
    def stop_update(cls, symbol: str, old_stop: float, new_stop: float, reason: str) -> None:
        cls._log.info(
            "STOP  | sym=%s | %.2f → %.2f | %s",
            symbol, old_stop, new_stop, reason,
        )
