"""
Filter Pipeline
===============
Orchestrates the 3-layer pre-entry quality gate.

Layer 1: Day Regime     — is today a tradeable day?
Layer 2: Signal Quality — is this signal worth acting on?
Layer 3: Option Quality — is the option cost-effective right now?

Each layer is independent and short-circuits on block.
Final size_multiplier = min(all layers) so the tightest
constraint always wins.
"""

from __future__ import annotations

import logging
import threading
import time
from datetime import datetime, time as dtime
from typing import Optional

import pandas as pd

from tcos_bot.config.settings import cfg, IST
from tcos_bot.filters.base import FilterResult
from tcos_bot.filters.day_regime import DayRegimeClassifier
from tcos_bot.filters.directional_gate import DirectionalGate
from tcos_bot.filters.option_quality import OptionQualityGate
from tcos_bot.filters.signal_quality import SignalQualityScorer
from tcos_bot.models.types import QualityResult, SignalGrade
from tcos_bot.signals.trend_state import TrendState, detect_trend_state

log = logging.getLogger(__name__)


class FilterPipeline:
    """
    Composes all pre-entry filters into a single callable.

    Usage
    -----
    pipeline = FilterPipeline()
    # Once per day at 09:30:
    pipeline.classify_day(ohlc_df, vix=14.5, brick_size=50)
    # Per signal:
    result = pipeline.evaluate(symbol, signal, renko_df, ohlc_df=ohlc_df, brick_size=50)
    if result.blocked:
        return   # skip entry
    """

    def __init__(self) -> None:
        self._day_regime       = DayRegimeClassifier()
        self._sig_quality      = SignalQualityScorer()
        self._opt_quality      = OptionQualityGate()
        self._directional_gate = DirectionalGate()
        self._lock        = threading.Lock()
        self._classified_date: Optional[datetime.date] = None
        self._last_classified_at: float = 0.0   # monotonic time of last classify()

        # Intraday trend state — keyed by symbol to prevent cross-symbol leakage.
        # Bug fix: a single _last_trend caused BANKNIFTY to inherit NIFTY's
        # previous_state, which could misclassify directional trend.
        self._last_trend_by_symbol: dict[str, TrendState] = {}
        self._trend_lock = threading.Lock()

        # Opening range state per symbol
        self._opening_range_end: dict[str, dtime] = {}

        # Log expiry-day block status once when the pipeline is constructed.
        if cfg.option_quality.trade_on_expiry:
            log.info(
                "✅ Expiry-day trading ENABLED — expiry-day block is OFF "
                "(cfg.option_quality.trade_on_expiry=True)."
            )
        else:
            log.warning(
                "⚠️  Expiry-day trading DISABLED — Thursday entries will be BLOCKED "
                "(cfg.option_quality.trade_on_expiry=False).  "
                "Set trade_on_expiry=True to allow trading on expiry days."
            )

    # ── Day classification ──────────────────────────────────────────────────────

    def classify_day(
        self,
        ohlc_df: pd.DataFrame,
        vix: Optional[float],
        brick_size: float,
    ) -> None:
        """
        Run the day regime classifier and store result.
        Call once per trading day after 09:30 IST.
        """
        with self._lock:
            result = self._day_regime.classify(ohlc_df, vix, brick_size)
            self._classified_date   = datetime.now(tz=IST).date()
            self._last_classified_at = time.monotonic()
            log.info(
                "🌅 Day classified: %s | conf=%.0f%% | range_ratio=%.2f",
                result.regime.value,
                result.confidence * 100,
                result.range_ratio,
            )

    @property
    def current_trend(self) -> TrendState:
        """
        Legacy property — returns TrendState.NEUTRAL.

        Kept as a @property to preserve the original call contract
        (pipeline.current_trend, not pipeline.current_trend()).
        No external caller has symbol context here, so NEUTRAL is the
        only safe default — returning any single symbol's state would
        silently leak cross-symbol trend into callers that do not expect it.

        Use trend_for(symbol) for symbol-specific state.
        """
        return TrendState.NEUTRAL

    @property
    def current_regime(self):
        """
        BUG-FIX-2: Expose the day regime classifier's current_regime on the
        pipeline itself.  engine.py calls self._signal_gen.pipeline.current_regime
        (added in the I-10 fix to pass live regime to chop_checker).
        Previously FilterPipeline had no such attribute → AttributeError crash
        on first CRUDEOIL signal in MCX-only sessions.
        Returns the MarketRegime enum value or None if not yet classified.
        """
        return self._day_regime.current_regime

    def trend_for(self, symbol: str) -> TrendState:
        """
        Return the most recent intraday TrendState for *symbol*.

        Updated on every evaluate() call for that symbol.
        Returns TrendState.NEUTRAL if symbol has never been evaluated.
        """
        with self._trend_lock:
            return self._last_trend_by_symbol.get(symbol, TrendState.NEUTRAL)

    def should_classify_today(self) -> bool:
        """True if we haven't classified today, or if the intraday re-classify
        interval has elapsed (cfg.day_regime.reclassify_interval_min > 0)."""
        from tcos_bot.config.settings import cfg
        today = datetime.now(tz=IST).date()
        if self._classified_date != today:
            return True
        interval = cfg.day_regime.reclassify_interval_min
        if interval <= 0:
            return False
        elapsed_min = (time.monotonic() - self._last_classified_at) / 60.0
        return elapsed_min >= interval

    # ── Main gate ──────────────────────────────────────────────────────────────

    def evaluate(
        self,
        symbol: str,
        signal: str,
        renko_df: Optional[pd.DataFrame],
        **kwargs,
    ) -> QualityResult:
        """
        Run the full filter pipeline and return a QualityResult.

        Parameters
        ----------
        symbol:    instrument root (e.g. "NIFTY")
        signal:    "BUYEN" | "SELEX"
        renko_df:  latest Renko DataFrame
        kwargs:    ohlc_df, brick_size, ltp, signal_timestamp, exchange

        Returns
        -------
        QualityResult with allowed, grade, size_multiplier, reasons/blocks
        """
        reasons: list[str] = []
        blocks:  list[str] = []
        size = 1.0

        # ── Opening range check (fast path, no filter class needed) ──────────
        or_result = self._check_opening_range(signal, kwargs)
        if not or_result.allowed:
            return self._make_result(
                allowed=False, grade=SignalGrade.REJECT, score=0,
                size=0.0, reasons=[], blocks=[or_result.reason],
            )

        # ── Time filter ──────────────────────────────────────────────────────
        time_result = self._check_market_time(signal, kwargs)
        if not time_result.allowed:
            return self._make_result(
                allowed=False, grade=SignalGrade.REJECT, score=0,
                size=0.0, reasons=[], blocks=[time_result.reason],
            )

        # ── Layer 1: Day Regime ───────────────────────────────────────────────
        # GAP-C FIX: MCX instruments must always use UNKNOWN/half-size regime,
        # even in mixed NSE+MCX sessions.  The DayRegimeClassifier uses India
        # VIX and equity OHLC — both irrelevant to commodity volatility.
        # In a mixed session, a high-VIX volatile equity day would apply
        # VOLATILE regime to CRUDEOIL/GOLDM/SILVERM/NATURALGAS, blocking
        # entries or halving size for reasons unrelated to commodity markets.
        # Fix: MCX exchange always sees UNKNOWN (same as MCX-only session).
        # NSE/BSE instruments are completely unaffected.
        _exchange_for_regime = str(kwargs.get("exchange", "")).upper()
        _MCX_EXCHANGES = {"MCX", "MCX_FUT", "MCX_OPT"}
        if _exchange_for_regime in _MCX_EXCHANGES:
            # MCX: always half-size caution, never hard-blocked by equity regime
            from tcos_bot.filters.base import FilterResult as _FR
            regime_result = _FR.half(
                f"MCX_REGIME_ISOLATED: equity regime not applied to {symbol} "
                f"({_exchange_for_regime}) — using UNKNOWN/half-size caution"
            )
            log.debug(
                "🌐 GAP-C: %s %s on MCX — equity regime isolated, using UNKNOWN",
                symbol, signal,
            )
        else:
            regime_result = self._day_regime.check(symbol, signal, renko_df, **kwargs)

        if not regime_result.allowed:
            log.info("🌅 REGIME BLOCK %s %s: %s", symbol, signal, regime_result.reason)
            return self._make_result(
                allowed=False, grade=SignalGrade.REJECT, score=0,
                size=0.0, reasons=[], blocks=[regime_result.reason],
                regime=(self._day_regime.current_regime.value if self._day_regime.current_regime else "UNKNOWN"),
            )
        size = min(size, regime_result.size_multiplier)
        reasons.append(regime_result.reason)

        # ── Layer 1b: Directional Gate (trend-aware, regime-gated) ───────────
        # Compute intraday trend state from latest Renko row, then apply the
        # regime-aware directional filter.  Hard blocks only fire in TRENDING
        # regime; other regimes get a size penalty or pass through.
        if renko_df is not None and not renko_df.empty:
            with self._trend_lock:
                prev_trend = self._last_trend_by_symbol.get(symbol, TrendState.NEUTRAL)
            current_trend = detect_trend_state(renko_df.iloc[-1], previous_state=prev_trend)
            with self._trend_lock:
                self._last_trend_by_symbol[symbol] = current_trend

            current_regime_str = (
                self._day_regime.current_regime.value
                if self._day_regime.current_regime else "UNKNOWN"
            )
            dir_result = self._directional_gate.check(
                signal=signal,
                trend=current_trend,
                regime=current_regime_str,
                symbol=symbol,
            )
            if not dir_result.allowed:
                log.info(
                    "🧭 DIRECTIONAL BLOCK %s %s: %s (trend=%s)",
                    symbol, signal, dir_result.reason, current_trend.value,
                )
                return self._make_result(
                    allowed=False, grade=SignalGrade.REJECT, score=0,
                    size=0.0, reasons=reasons, blocks=[dir_result.reason],
                    regime=current_regime_str,
                )
            size = min(size, dir_result.size_multiplier)
            reasons.append(dir_result.reason)
        else:
            with self._trend_lock:
                current_trend = self._last_trend_by_symbol.get(symbol, TrendState.NEUTRAL)

        # ── Layer 2: Signal Quality ───────────────────────────────────────────
        if renko_df is not None and not renko_df.empty:
            quality_result = self._sig_quality.check(symbol, signal, renko_df, **kwargs)
            if not quality_result.allowed:
                log.info("📊 QUALITY BLOCK %s %s: %s", symbol, signal, quality_result.reason)
                return self._make_result(
                    allowed=False, grade=SignalGrade.REJECT, score=0,
                    size=0.0, reasons=reasons, blocks=[quality_result.reason],
                )
            size = min(size, quality_result.size_multiplier)
            score_info = self._sig_quality.score_only(renko_df, signal, symbol)
            grade_val  = score_info.get("grade", "B")
            score_num  = score_info.get("score", 0)
            reasons.append(quality_result.reason)

            # ── Confidence gate: tighten min_grade when regime is uncertain ──
            # When the day-regime classifier has low confidence (default < 50%),
            # a Grade-B signal is marginal — the market has no clear character
            # so even an aligned Renko brick carries higher false-breakout risk.
            # Require Grade A in these conditions.  Configurable via:
            #   cfg.signal_quality.low_conf_threshold  (default 0.50)
            #   cfg.signal_quality.low_conf_min_grade  (default "A")
            #
            # MCX-BUG-1 FIX: MCX instruments (GOLDM, SILVERM, NATURALGAS)
            # always have confidence=0.0 because equity regime classification
            # is intentionally skipped — not because the signal is weak.
            # Applying the CONF_GATE here permanently blocks all MCX non-Grade-A
            # signals, which in practice means GOLDM/SILVERM/NATURALGAS never
            # enter (coarse bricks take longer to accumulate to Grade A).
            # Exchanges listed in low_conf_exempt_exchanges bypass this gate.
            conf        = self._day_regime.current_confidence
            conf_thresh = cfg.signal_quality.low_conf_threshold
            lc_min      = cfg.signal_quality.low_conf_min_grade
            _exempt_exchanges = getattr(cfg.signal_quality, "low_conf_exempt_exchanges", ())
            _exchange_str     = str(kwargs.get("exchange", "")).upper()
            _conf_exempt      = _exchange_str in _exempt_exchanges
            grade_order = ["REJECT", "C", "B", "A"]
            if (
                not _conf_exempt
                and conf < conf_thresh
                and grade_order.index(grade_val) < grade_order.index(lc_min)
            ):
                block_reason = (
                    f"CONF_GATE: regime conf={conf:.0%} < {conf_thresh:.0%} "
                    f"— need grade≥{lc_min}, got {grade_val}"
                )
                log.info("🔒 CONF_GATE BLOCK %s %s: %s", symbol, signal, block_reason)
                return self._make_result(
                    allowed=False, grade=SignalGrade.REJECT, score=score_num,
                    size=0.0, reasons=reasons, blocks=[block_reason],
                    regime=(self._day_regime.current_regime.value if self._day_regime.current_regime else "UNKNOWN"),
                )
            if _conf_exempt and conf < conf_thresh:
                log.debug(
                    "🔓 CONF_GATE EXEMPT %s %s: exchange=%s skips confidence gate "
                    "(conf=%.0f%% < %.0f%% but MCX has no equity regime)",
                    symbol, signal, _exchange_str, conf * 100, conf_thresh * 100,
                )
        else:
            grade_val = "B"
            score_num = 0
            reasons.append("QUALITY: no renko (default B)")

        # ── Layer 2b: RR Gate ────────────────────────────────────────────────
        # Reward/Risk geometry check: is there enough room between entry and
        # the nearest structural obstacle to justify the fixed 3-brick stop?
        # Gate is transparent (allow) when disabled or insufficient history.
        # VOLATILE half-size is preserved in Phase 2 — removed in Phase 3
        # after RR gate is validated over 5+ live trading days.
        _bs_for_rr = float(kwargs.get("brick_size", 12.0))
        rr_result = self._check_rr_gate(symbol, signal, renko_df, _bs_for_rr)
        if not rr_result.allowed:
            return self._make_result(
                allowed=False, grade=SignalGrade.REJECT, score=score_num,
                size=0.0, reasons=reasons, blocks=[rr_result.reason],
                regime=(self._day_regime.current_regime.value
                        if self._day_regime.current_regime else "UNKNOWN"),
            )
        if rr_result.reason and not rr_result.reason.startswith("RR_GATE_DISABLED"):
            reasons.append(rr_result.reason)

        # ── Layer 3: Option Quality ───────────────────────────────────────────
        opt_result = self._opt_quality.check(symbol, signal, renko_df, **kwargs)
        if not opt_result.allowed:
            log.info("⚡ OPT BLOCK %s %s: %s", symbol, signal, opt_result.reason)
            return self._make_result(
                allowed=False, grade=SignalGrade.REJECT, score=score_num,
                size=0.0, reasons=reasons, blocks=[opt_result.reason],
            )
        size = min(size, opt_result.size_multiplier)
        reasons.append(opt_result.reason)

        # ── Combined size floor ───────────────────────────────────────────────
        # If regime × quality × direction multipliers compound to a very small
        # size, the position is meaningless — block outright rather than placing
        # a micro-lot.  Configurable via cfg.signal_quality.min_combined_size.
        # F-05 FIX: per-exchange override allows MCX Grade-B through (0.25),
        # while the global 0.40 floor still protects NSE/BSE instruments.
        _exc_for_sz   = str(kwargs.get("exchange", "")).upper()
        _sz_overrides = getattr(cfg.signal_quality, "min_combined_size_override", {})
        min_size = _sz_overrides.get(
            _exc_for_sz, getattr(cfg.signal_quality, "min_combined_size", 0.40)
        )
        if min_size > 0 and size < min_size:
            block_reason = (
                f"MIN_SIZE_BLOCK: combined size={size:.0%} < min={min_size:.0%} "
                f"(regime+quality+direction penalties compound — "
                f"market conditions insufficient for entry)"
            )
            log.info("🚫 MIN_SIZE_BLOCK %s %s: %s", symbol, signal, block_reason)
            return self._make_result(
                allowed=False, grade=SignalGrade.REJECT, score=0,
                size=0.0, reasons=reasons, blocks=[block_reason],
                regime=(self._day_regime.current_regime.value if self._day_regime.current_regime else "UNKNOWN"),
            )

        # ── All layers passed ─────────────────────────────────────────────────
        grade = SignalGrade(grade_val) if grade_val in SignalGrade.__members__ else SignalGrade.B

        log.info(
            "✅ PIPELINE PASS %s %s | grade=%s size=%.0f%% | %s",
            symbol, signal, grade.value, size * 100,
            " | ".join(reasons),
        )

        return QualityResult(
            allowed=True,
            grade=grade,
            score=score_num,
            size_multiplier=round(size, 2),
            reasons=reasons,
            blocks=blocks,
            regime=(self._day_regime.current_regime.value if self._day_regime.current_regime else "UNKNOWN"),
        )

    # ── Utility ────────────────────────────────────────────────────────────────

    def get_strike_recommendation(
        self,
        symbol: str,
        signal: str,
        spot: float,
        days_to_expiry: int,
    ) -> dict:
        """Delegate strike selection to the option quality gate."""
        return self._opt_quality.select_strike(
            spot=spot,
            signal=signal,
            symbol=symbol,
            days_to_expiry=days_to_expiry,
        )

    # ── Private helpers ─────────────────────────────────────────────────────────

    def _check_rr_gate(
        self,
        symbol: str,
        signal: str,
        renko_df,
        brick_size: float,
    ) -> FilterResult:
        """
        Reward/Risk Gate: block entry when nearest structural obstacle is
        too close to justify the fixed 3-brick stop.

        For a CALL (BUYEN): find the nearest Renko swing HIGH above the
        current brick price.  Room = (wall - entry) / brick_size.
        For a PUT  (SELEX): find the nearest Renko swing LOW below entry.
        Room = (entry - floor) / brick_size.

        If room < rr_min_room_bricks → block (geometry is broken).
        If no wall/floor exists (open sky/floor) → allow (trending market).

        Transparent (allow) when:
          - rr_gate_enabled = False (feature flag off)
          - renko_df is None or empty
          - HH/LH/HL/LL columns missing (old data format)
          - Fewer than rr_min_swing_points swing points (early session)

        Design decisions:
          - Uses Renko_Brick price as entry reference (same as stop calc)
          - Scans ALL swing highs/lows — finds NEAREST, not just Last_High
          - Works for all instruments (NIFTY, BANKNIFTY, SENSEX, MCX)
        """
        # ── Feature flag ──────────────────────────────────────────────────────
        if not getattr(cfg.signal_quality, "rr_gate_enabled", False):
            return FilterResult.allow("RR_GATE_DISABLED")

        # ── Data guards ───────────────────────────────────────────────────────
        if renko_df is None or renko_df.empty:
            return FilterResult.allow("RR_NO_RENKO")

        required_cols = {"HH", "LH", "HL", "LL", "Renko_Brick"}
        if not required_cols.issubset(renko_df.columns):
            return FilterResult.allow("RR_MISSING_COLS")

        # ── Minimum swing history guard ────────────────────────────────────────
        _min_swings = getattr(cfg.signal_quality, "rr_min_swing_points", 5)
        _swing_count = int(
            (renko_df["HH"] | renko_df["LH"] | renko_df["HL"] | renko_df["LL"]).sum()
        )
        if _swing_count < _min_swings:
            return FilterResult.allow(
                f"RR_WARMING_UP: only {_swing_count} swing points "
                f"(need {_min_swings})"
            )

        # ── Entry price = last completed brick ────────────────────────────────
        entry_price = float(renko_df.iloc[-1]["Renko_Brick"])
        _min_room   = getattr(cfg.signal_quality, "rr_min_room_bricks", 1.5)

        if signal == "BUYEN":
            # CALL: look for swing highs ABOVE entry
            walls = renko_df[
                (renko_df["HH"] | renko_df["LH"]) &
                (renko_df["Renko_Brick"] > entry_price)
            ]["Renko_Brick"]

            if walls.empty:
                # No resistance above entry — open sky, trending market
                log.info(
                    "🎯 RR_OK %s BUYEN: no wall above entry=%.2f — open sky",
                    symbol, entry_price,
                )
                return FilterResult.allow(
                    f"RR_OK: open sky above entry={entry_price:.0f}"
                )

            nearest_wall = float(walls.min())
            room_bricks  = (nearest_wall - entry_price) / brick_size

            if room_bricks < _min_room:
                log.info(
                    "🚫 RR_BLOCK %s BUYEN: room=%.1fb wall=%.0f entry=%.0f "
                    "(min=%.1fb) — wall too close",
                    symbol, room_bricks, nearest_wall, entry_price, _min_room,
                )
                return FilterResult.block(
                    f"RR_BLOCK: room={room_bricks:.1f}b < {_min_room}b "
                    f"(wall={nearest_wall:.0f} entry={entry_price:.0f})"
                )

            log.info(
                "🎯 RR_OK %s BUYEN: room=%.1fb wall=%.0f entry=%.0f",
                symbol, room_bricks, nearest_wall, entry_price,
            )
            return FilterResult.allow(
                f"RR_OK: room={room_bricks:.1f}b wall={nearest_wall:.0f}"
            )

        else:  # SELEX — PUT
            # PUT: look for swing lows BELOW entry
            floors = renko_df[
                (renko_df["LL"] | renko_df["HL"]) &
                (renko_df["Renko_Brick"] < entry_price)
            ]["Renko_Brick"]

            if floors.empty:
                # No support below entry — open floor, trending market
                log.info(
                    "🎯 RR_OK %s SELEX: no floor below entry=%.2f — open floor",
                    symbol, entry_price,
                )
                return FilterResult.allow(
                    f"RR_OK: open floor below entry={entry_price:.0f}"
                )

            nearest_floor = float(floors.max())
            room_bricks   = (entry_price - nearest_floor) / brick_size

            if room_bricks < _min_room:
                log.info(
                    "🚫 RR_BLOCK %s SELEX: room=%.1fb floor=%.0f entry=%.0f "
                    "(min=%.1fb) — floor too close",
                    symbol, room_bricks, nearest_floor, entry_price, _min_room,
                )
                return FilterResult.block(
                    f"RR_BLOCK: room={room_bricks:.1f}b < {_min_room}b "
                    f"(floor={nearest_floor:.0f} entry={entry_price:.0f})"
                )

            log.info(
                "🎯 RR_OK %s SELEX: room=%.1fb floor=%.0f entry=%.0f",
                symbol, room_bricks, nearest_floor, entry_price,
            )
            return FilterResult.allow(
                f"RR_OK: room={room_bricks:.1f}b floor={nearest_floor:.0f}"
            )

    def _check_opening_range(self, signal: str, ctx: dict) -> FilterResult:
        """Block entry signals generated during the opening range volatility window."""
        if not cfg.market_hours:
            return FilterResult.allow()
        if signal not in ("BUYEN", "SELEX"):
            return FilterResult.allow()
        exchange = str(ctx.get("exchange", "NSE_INDEX")).upper()
        sig_ts   = ctx.get("signal_timestamp")
        if sig_ts is None:
            return FilterResult.allow()
        try:
            sig_time = (
                pd.to_datetime(sig_ts).time()
                if not hasattr(sig_ts, "time")
                else sig_ts.time()
            )
        except Exception:
            return FilterResult.allow()

        cutoff_str = {
            "NSE_INDEX": cfg.market_hours.opening_filter_end_nse,
            "BSE_INDEX": cfg.market_hours.opening_filter_end_nse,
            "MCX":       cfg.market_hours.opening_filter_end_mcx,
        }.get(exchange, cfg.market_hours.opening_filter_end_nse)

        cutoff = dtime(*map(int, cutoff_str.split(":")))

        # Block any signal whose timestamp falls inside the opening-range window.
        # The previous check also required now_t < cutoff, which meant a signal
        # generated at 09:23 slipped through when evaluated at 09:30:35 (startup
        # delay), reaching the drift-cancel guard instead.  A signal born inside
        # the OR window is always stale once the window closes — block it
        # unconditionally regardless of when it is evaluated.
        if sig_time < cutoff:
            return FilterResult.block(
                f"OPENING_RANGE({sig_time}<cutoff={cutoff}, exchange={exchange})"
            )
        return FilterResult.allow()

    def _check_market_time(self, signal: str, ctx: dict) -> FilterResult:
        """Block new entry signals outside market hours or after no-new-trades cutoff.
        UPGRADE T2-5: Returns half-size during configured low-activity windows."""
        if signal not in ("BUYEN", "SELEX"):
            return FilterResult.allow()   # exits always pass
        exchange = str(ctx.get("exchange", "NSE_INDEX")).upper()
        now_t    = datetime.now(tz=IST).time()

        if exchange in ("NSE_INDEX", "BSE_INDEX", "NFO", "BFO"):
            open_t  = dtime(*map(int, cfg.market_hours.nse_open.split(":")))
            close_t = dtime(*map(int, cfg.market_hours.nse_close.split(":")))
            cutoff  = dtime(*map(int, cfg.market_hours.no_new_entries_nse.split(":")))
        else:  # MCX
            open_t  = dtime(*map(int, cfg.market_hours.mcx_open.split(":")))
            close_t = dtime(*map(int, cfg.market_hours.mcx_close.split(":")))
            cutoff  = dtime(*map(int, cfg.market_hours.no_new_entries_mcx.split(":")))

        if now_t < open_t or now_t > close_t:
            return FilterResult.block(f"MARKET_CLOSED({now_t})")
        if now_t > cutoff:
            return FilterResult.block(f"NO_NEW_ENTRIES_AFTER({cutoff})")

        # UPGRADE T2-5: Low-activity time-of-day window check.
        # Returns half-size during noisy/thin windows (lunch, MCX dead zone).
        # Does NOT block — just reduces size. Circuit breakers still active.
        _windows = getattr(cfg.market_hours, "low_activity_windows", ())
        _low_size = getattr(cfg.market_hours, "low_activity_size_multiplier", 0.5)
        # Map exchange to prefix for window matching
        _exc_pfx = (
            "NSE" if exchange in ("NSE_INDEX", "NFO") else
            "BSE" if exchange in ("BSE_INDEX", "BFO") else
            "MCX"
        )
        for win_start, win_end, win_exchange in _windows:
            if win_exchange and win_exchange.upper() != _exc_pfx:
                continue
            try:
                ws = dtime(*map(int, win_start.split(":")))
                we = dtime(*map(int, win_end.split(":")))
                if ws <= now_t <= we:
                    log.debug(
                        "⏰ LOW_ACTIVITY_WINDOW %s %s: %s %s–%s → size×%.1f",
                        signal, exchange, win_exchange, win_start, win_end, _low_size,
                    )
                    return FilterResult.half(
                        f"LOW_ACTIVITY_WINDOW({win_start}–{win_end})",
                        size=_low_size,
                    )
            except Exception:
                pass

        return FilterResult.allow()

    @staticmethod
    def _make_result(
        allowed: bool,
        grade: SignalGrade,
        score: int,
        size: float,
        reasons: list[str],
        blocks: list[str],
        regime: str = "UNKNOWN",
    ) -> QualityResult:
        return QualityResult(
            allowed=allowed,
            grade=grade,
            score=score,
            size_multiplier=size,
            reasons=reasons,
            blocks=blocks,
            regime=regime,
        )
