"""
Option Quality Gate
===================
Layer 3 pre-entry filter. Checks:
  1. Day-of-week gate
       • When cfg.option_quality.trade_on_expiry is True  (default): Thursday
         entries are allowed; the expiry-day block is OFF.
       • When cfg.option_quality.trade_on_expiry is False (legacy):  Thursday
         entries are blocked via dow_size_map[3] = 0.0.
  2. Dynamic strike selection based on DTE

All data comes from the existing OHLC pipeline.
"""

from __future__ import annotations

import logging
from datetime import datetime
from typing import Optional

import pandas as pd

from tcos_bot.config.settings import cfg, STRIKE_STEPS
from tcos_bot.filters.base import BaseFilter, FilterResult
from tcos_bot.models.types import OptionType

log = logging.getLogger(__name__)

_DOW_LABELS: dict[int, str] = {
    0: "Monday",
    1: "Tuesday",
    2: "Wednesday",
    3: "Thursday (EXPIRY)",
    4: "Friday",
    5: "Saturday",
    6: "Sunday",
}


class OptionQualityGate(BaseFilter):
    """
    Evaluates whether entering a long option is cost-effective today.

    Decision rules
    --------------
    trade_on_expiry=True  (default):
        Thursday — allowed, same size as the dow_size_map would give for
                   a "normal" day (1.0 full size unless overridden).
        Wednesday/Friday — allowed, half size (dow_size_map still applies).

    trade_on_expiry=False (legacy / safety rollback):
        Thursday — block all entries (dow_size_map[3]=0.0).
        Wednesday/Friday — half size.
    """

    def __init__(self) -> None:
        self._cfg = cfg.option_quality
        # Log once when the gate is first constructed (runtime, not import time).
        if self._cfg.trade_on_expiry:
            log.info(
                "✅ Expiry-day trading ENABLED — expiry-day block is OFF "
                "(trade_on_expiry=True)."
            )
        else:
            log.info(
                "⚠️  Expiry-day trading DISABLED — Thursday entries are BLOCKED "
                "(trade_on_expiry=False)."
            )

    # ── Public API ─────────────────────────────────────────────────────────────

    def check(
        self,
        symbol: str,
        signal: str,
        renko_df: Optional[pd.DataFrame] = None,
        **kwargs,
    ) -> FilterResult:
        """
        Gate check combining DoW + IV rank.

        kwargs expected
        ---------------
        ohlc_df:    pd.DataFrame  — OHLC data with 'atr' column
        brick_size: float
        exchange:   str           — used to skip NSE Thursday-expiry bypass for MCX
        """
        exchange = str(kwargs.get("exchange", "")).upper()
        # FIX-1: pass exchange so MCX instruments bypass the NSE Thursday expiry rule
        dow_result = self._check_dow(exchange=exchange)
        if not dow_result.allowed:
            return dow_result

        return FilterResult.allow(
            reason=f"OPT_OK: {dow_result.reason}",
            size=dow_result.size_multiplier,
        )

    def select_strike(
        self,
        spot: float,
        signal: str,
        symbol: str,
        days_to_expiry: int,
    ) -> dict:
        """
        Choose the option strike dynamically.

        Logic
        -----
        Near expiry (≤2 DTE) → ATM
        Normal conditions    → 1 strike ITM (better delta)
        """
        root = self._extract_root(symbol)
        step = STRIKE_STEPS.get(root, 100)
        atm  = round(spot / step) * step

        near_expiry = days_to_expiry <= 2
        opt_type = OptionType.CALL if signal == "BUYEN" else OptionType.PUT

        if near_expiry:
            strike = atm
            label  = "ATM (near_expiry)"
        else:
            if opt_type == OptionType.CALL:
                strike = atm - step
                label  = "1-ITM CALL (normal)"
            else:
                strike = atm + step
                label  = "1-ITM PUT (normal)"

        log.info(
            "🎯 STRIKE: %s %s | spot=%.0f ATM=%d → strike=%d | %s",
            symbol, signal, spot, atm, strike, label,
        )
        return {"strike": int(strike), "label": label, "step": step}

    # ── Private helpers ─────────────────────────────────────────────────────────

    # MCX exchanges that have independent expiry schedules from NSE Thursday
    _MCX_EXCHANGES = {"MCX", "MCX_FUT", "MCX_OPT"}

    def _check_dow(self, exchange: str = "") -> FilterResult:
        """
        Day-of-week gate.

        When trade_on_expiry=True (default):
          Thursday is treated as a normal trading day.  The dow_size_map
          entry for Thursday is intentionally skipped so that any 0.0
          legacy value there does not bleed through.

        When trade_on_expiry=False (legacy):
          Full dow_size_map lookup applies; Thursday stays blocked.

        FIX-1: MCX instruments are excluded from the NSE Thursday-expiry bypass.
          MCX CRUDEOIL, GOLDM, SILVERM, NATURALGAS have monthly expiry schedules
          that are completely independent of NSE weekly Thursday expiry.
          Treating Thursday as "NSE expiry day" for MCX options was triggering
          DOW_EXPIRY_BYPASS for April-expiry CRUDEOILM options, which is wrong.
          NSE/BSE instruments are completely unaffected.
        """
        dow   = datetime.now().weekday()   # 0=Mon … 6=Sun
        label = _DOW_LABELS.get(dow, f"DOW={dow}")

        # ── Expiry-day bypass (NSE/BSE only) ──────────────────────────────────
        _is_mcx = exchange.upper() in self._MCX_EXCHANGES
        if dow == 3 and self._cfg.trade_on_expiry and not _is_mcx:
            # Thursday + NSE/BSE instrument + expiry-day block OFF → full size.
            log.info(
                "📅 DOW EXPIRY-DAY BYPASS: %s — trade_on_expiry=True, proceeding at full size",
                label,
            )
            return FilterResult.allow(f"DOW_EXPIRY_BYPASS: {label}", size=1.0)

        if dow == 3 and _is_mcx:
            # MCX on Thursday — completely independent of NSE weekly expiry.
            # MCX commodities have monthly (or other) expiry schedules.
            # Always allow full-size entries; the NSE Thursday expiry concern
            # does NOT apply to CRUDEOIL, GOLDM, SILVERM, NATURALGAS options.
            log.debug(
                "📅 MCX Thursday: %s — NSE expiry not applicable, "
                "allowing full size (MCX has independent expiry schedule)",
                exchange,
            )
            return FilterResult.allow(
                f"DOW_OK: Thursday (MCX — independent expiry schedule)", size=1.0
            )

        # ── Standard dow_size_map lookup ──────────────────────────────────────
        size = self._cfg.dow_size_map.get(dow, 0.5)

        if size == 0.0:
            log.info("📅 DOW BLOCK: %s — no new entries", label)
            return FilterResult.block(f"DOW_BLOCK: {label}")

        if size < 1.0:
            log.info("📅 DOW HALF: %s — half size only", label)
            return FilterResult.half(f"DOW_HALF: {label}")

        log.debug("📅 DOW OK: %s", label)
        return FilterResult.allow(f"DOW_OK: {label}", size=1.0)

    @staticmethod
    def _extract_root(symbol: str) -> str:
        """Return root index name from any symbol variant."""
        import re
        m = re.match(r'^([A-Z]+)', symbol.upper())
        return m.group(1) if m else symbol

