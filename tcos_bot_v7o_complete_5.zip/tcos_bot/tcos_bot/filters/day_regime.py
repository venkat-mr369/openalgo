"""
Day Regime Classifier
=====================
Classifies each trading day as TRENDING / SIDEWAYS / VOLATILE
before any trades are placed. Runs once at 09:30 IST.

Uses only data already present in the OHLC pipeline:
  - Opening gap vs previous close
  - First 15-min range vs ATR
  - India VIX level
"""

from __future__ import annotations

import logging
import math
from datetime import datetime
from typing import Optional

import pandas as pd

from tcos_bot.config.settings import cfg
from tcos_bot.filters.base import BaseFilter, FilterResult
from tcos_bot.models.types import (
    DayRegimeResult,
    MarketRegime,
)

log = logging.getLogger(__name__)


class DayRegimeClassifier(BaseFilter):
    """
    Classifies the trading day regime from OHLC data.

    Decision matrix
    ---------------
    TRENDING  → full BUY_CALL / BUY_PUT allowed (directional gate enforces direction)
    SIDEWAYS  → half-size penalty; reversal entries preserved (directional gate applies penalty)
    VOLATILE  → half-size; debit spreads preferred
    UNKNOWN   → cautious half-size until classified
    """

    def __init__(self) -> None:
        self._result: Optional[DayRegimeResult] = None
        self._cfg = cfg.day_regime

    # ── Public API ─────────────────────────────────────────────────────────────

    def classify(
        self,
        ohlc_df: pd.DataFrame,
        vix: Optional[float],
        brick_size: float,
    ) -> DayRegimeResult:
        """
        Classify today's market regime.
        Call once at 09:30 IST with current OHLC data.

        Parameters
        ----------
        ohlc_df:    1-minute OHLC DataFrame (must have open, high, low, close, atr)
        vix:        India VIX last price (None = unknown)
        brick_size: Renko brick size for this instrument

        Returns
        -------
        DayRegimeResult — also stored in self._result for check() calls
        """
        if ohlc_df is None or len(ohlc_df) < 5:
            self._result = DayRegimeResult(
                regime=MarketRegime.UNKNOWN,
                confidence=0.0,
                vix=vix,
                range_ratio=0.0,
                classified_at=datetime.now(),
            )
            log.warning("DayRegime: insufficient OHLC data — UNKNOWN")
            return self._result

        range_ratio = self._compute_range_ratio(ohlc_df)
        scores      = self._score(range_ratio, vix)

        regime     = max(scores, key=scores.get)  # type: ignore[arg-type]
        total      = sum(scores.values()) or 1
        confidence = scores[regime] / total

        self._result = DayRegimeResult(
            regime=MarketRegime(regime),
            confidence=round(confidence, 3),
            vix=vix,
            range_ratio=round(range_ratio, 2),
            classified_at=datetime.now(),
        )

        allowed = self._allowed_strategies(self._result.regime)
        log.info(
            "🌅 DAY REGIME: %s | confidence=%.0f%% | "
            "range/ATR=%.2f | VIX=%s | allowed=%s",
            regime, confidence * 100,
            range_ratio,
            f"{vix:.1f}" if vix else "?",
            allowed,
        )
        return self._result

    def check(
        self,
        symbol: str,
        signal: str,
        renko_df=None,
        **kwargs,
    ) -> FilterResult:
        """
        Gate check: should this signal be allowed today?

        Parameters
        ----------
        symbol: instrument name (for logging)
        signal: "BUYEN" | "SELEX"
        """
        if self._result is None:
            return FilterResult.half("REGIME_UNCLASSIFIED — caution")

        regime     = self._result.regime
        confidence = self._result.confidence

        if regime == MarketRegime.UNKNOWN:
            return FilterResult.half("REGIME_UNKNOWN")

        if regime == MarketRegime.SIDEWAYS:
            # User requirement: "no trades in choppy/sideways markets."
            # sideways_hard_block=True (default) enforces this as a hard block.
            # Set sideways_hard_block=False to revert to the old half-size
            # behaviour if you want to preserve reversal entries on range days.
            if getattr(self._cfg, "sideways_hard_block", True):
                return FilterResult.block(
                    f"SIDEWAYS_DAY — entries blocked in sideways market "
                    f"(conf={confidence:.0%}, set sideways_hard_block=False to allow)"
                )
            return FilterResult.half(
                f"SIDEWAYS_DAY — half-size caution (conf={confidence:.0%})"
            )

        if regime == MarketRegime.VOLATILE:
            # Phase 3: VOLATILE no longer penalises size.
            # The RR gate (now active) handles geometry filtering — if there
            # is not enough room between entry and the nearest wall, the signal
            # is blocked regardless of VIX.  A high VIX on a clean breakout
            # with 10b of room should run at full lot, not half.
            # Whipsaw cooldown (2.0×), NFT timeout, and confirm_mins overrides
            # still apply — those use the regime STRING not the size, so they
            # are unchanged.
            return FilterResult.allow(
                f"VOLATILE_DAY — full-size, RR gate active (VIX={self._result.vix})"
            )

        # TRENDING but conf < 40% means market has no clear direction —
        # Renko bricks will form both ways → whipsaw trap.
        if regime == MarketRegime.TRENDING and confidence < self._cfg.chop_half_threshold:
            return FilterResult.half(
                f"CHOP_GUARD: TRENDING but low conf={confidence:.0%} "
                f"(< {self._cfg.chop_half_threshold:.0%}) — half size"
            )

        return FilterResult.allow(
            f"REGIME={regime.value} conf={confidence:.0%}"
        )

    @property
    def current_regime(self) -> Optional[MarketRegime]:
        return self._result.regime if self._result else None

    @property
    def current_confidence(self) -> float:
        """Regime classification confidence (0.0–1.0). 0.0 if unclassified."""
        return self._result.confidence if self._result else 0.0

    # ── Private helpers ─────────────────────────────────────────────────────────

    def _compute_range_ratio(self, df: pd.DataFrame) -> float:
        """Return today's first-15-min range / average ATR.

        Bug-fix (C-3): the original code used df.tail(15) which returns the
        LAST 15 rows of the 4-day OHLC window — i.e. yesterday's closing
        range, not today's opening range.  This replaces it with df rows
        whose date matches today, then takes the FIRST 15 of those.
        Falls back to the last 15 rows if no today-data exists yet
        (e.g. called before 09:30 with only prior-day data loaded).

        Fix (timezone): the engine strips tz from OHLC timestamps via
        tz_localize(None) before storing them, so they are naive but represent
        IST wall-clock time.  Using pd.Timestamp.now().normalize() (server
        local, often UTC) would pick the wrong date on UTC servers between
        18:30 UTC and 00:00 UTC (i.e. during IST trading hours).
        Fix: use IST now explicitly, then strip tz to match naive OHLC timestamps.

        Fix (ATR fallback): when the ATR column is missing, the old code silently
        returned 1.0 which falls into the ambiguous zone (0.5–1.2) where VIX
        alone determines regime.  With calm VIX (13-16) this always scores
        TRENDING at 100% confidence — misclassifying a genuinely quiet day.
        Now logs a WARNING so missing ATR is visible in production.
        """
        try:
            ts_col = pd.to_datetime(df["timestamp"])
            # Use IST-aware now, then strip tz to match engine's naive IST timestamps.
            today  = pd.Timestamp.now(tz=IST).normalize().tz_localize(None)
            today_mask = ts_col.dt.normalize() >= today
            today_rows = df[today_mask]
            recent = today_rows.head(15) if not today_rows.empty else df.tail(15)
        except Exception:
            recent = df.tail(15)

        if recent.empty:
            return 1.0
        day_range = float(recent["high"].max() - recent["low"].min())
        if "atr" not in df.columns or df["atr"].dropna().empty:
            log.warning(
                "DayRegime: ATR column missing or all-NaN in OHLC data — "
                "range_ratio defaulting to 1.0 (ambiguous zone). "
                "Ensure the OHLC pipeline computes ATR before classification."
            )
            return 1.0
        # The OHLC pipeline computes ATR on 1-minute bars.  The opening range
        # window is 15 minutes, so comparing its raw range to a 1-min ATR
        # produces ratios ~10-15x instead of 1-2x — always scoring TRENDING.
        # Scale to a 15-min equivalent using the square-root-of-time rule
        # (σ scales with √T) so the existing thresholds (1.2 / 0.5) remain
        # valid without any config changes.
        raw_atr      = float(df["atr"].dropna().mean())
        hist_atr_15m = raw_atr * math.sqrt(15)
        return (day_range / hist_atr_15m) if hist_atr_15m > 0 else 1.0

    def _score(
        self,
        range_ratio: float,
        vix: Optional[float],
    ) -> dict[str, int]:
        scores: dict[str, int] = {
            MarketRegime.TRENDING.value:  0,
            MarketRegime.SIDEWAYS.value:  0,
            MarketRegime.VOLATILE.value:  0,
        }
        c = self._cfg

        # Range contribution
        if range_ratio > c.range_trending_ratio:
            scores[MarketRegime.TRENDING.value] += 2
        elif range_ratio < c.range_sideways_ratio:
            scores[MarketRegime.SIDEWAYS.value] += 2
        else:
            scores[MarketRegime.TRENDING.value] += 1

        # VIX contribution
        # When range_ratio strongly suggests a trending day, cap the VOLATILE
        # contribution to 1 so VIX elevated by overnight IV cannot split the
        # vote and suppress confidence on a clearly directional session.
        vix_volatile_cap = (
            1
            if (c.vix_trend_override_ratio > 0 and range_ratio >= c.vix_trend_override_ratio)
            else 2
        )
        if vix is not None:
            if vix > c.vix_volatile_threshold:
                scores[MarketRegime.VOLATILE.value] += vix_volatile_cap
                scores[MarketRegime.SIDEWAYS.value]  += 1
            elif vix < c.vix_low_threshold:
                scores[MarketRegime.SIDEWAYS.value] += 1
            elif c.vix_low_threshold <= vix <= c.vix_ideal_max:
                scores[MarketRegime.TRENDING.value] += 1

        return scores

    @staticmethod
    def _allowed_strategies(regime: MarketRegime) -> list[str]:
        # Note: these strings appear only in log output — they are not used
        # to gate anything.  They must accurately reflect what check() allows
        # so logs are not misleading.
        # SIDEWAYS: check() issues half-size, NOT a block — both directions are
        # permitted (reversal opportunities preserved).  Old code had [] here
        # which contradicted the actual gate behaviour.
        mapping = {
            MarketRegime.TRENDING:  ["BUY_CALL", "BUY_PUT", "DEBIT_SPREAD"],
            MarketRegime.SIDEWAYS:  ["BUY_CALL(0.5x)", "BUY_PUT(0.5x)"],
            MarketRegime.VOLATILE:  ["DEBIT_SPREAD", "BUY_CALL(0.5x)", "BUY_PUT(0.5x)"],
            MarketRegime.UNKNOWN:   ["DEBIT_SPREAD", "BUY_CALL(0.5x)", "BUY_PUT(0.5x)"],
        }
        return mapping.get(regime, [])
