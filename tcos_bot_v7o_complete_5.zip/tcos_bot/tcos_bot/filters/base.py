"""
Filter Base
===========
Abstract contract for all pre-entry filters.
Every filter returns a (allowed, reason) pair — nothing else.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Optional

import pandas as pd


@dataclass(frozen=True)
class FilterResult:
    """Immutable result from any filter."""
    allowed:         bool
    reason:          str = ""
    size_multiplier: float = 1.0   # 0.0 = block, 0.5 = half, 1.0 = full

    @classmethod
    def allow(cls, reason: str = "", size: float = 1.0) -> "FilterResult":
        return cls(allowed=True, reason=reason, size_multiplier=size)

    @classmethod
    def block(cls, reason: str) -> "FilterResult":
        return cls(allowed=False, reason=reason, size_multiplier=0.0)

    @classmethod
    def half(cls, reason: str, size: float = 0.5) -> "FilterResult":
        return cls(allowed=True, reason=reason, size_multiplier=size)


class BaseFilter(ABC):
    """
    Every pre-entry filter must implement this interface.
    Filters are stateless where possible; state lives in subclasses.
    """

    @abstractmethod
    def check(
        self,
        symbol: str,
        signal: str,
        renko_df: Optional[pd.DataFrame],
        **kwargs,
    ) -> FilterResult:
        """
        Evaluate whether this signal should proceed.

        Parameters
        ----------
        symbol:   instrument root (e.g., "NIFTY")
        signal:   "BUYEN" or "SELEX"
        renko_df: latest Renko DataFrame for this symbol
        kwargs:   filter-specific context (ltp, vix, brick_size, ...)

        Returns
        -------
        FilterResult with allowed flag, reason string, and size multiplier
        """

    @property
    def name(self) -> str:
        return self.__class__.__name__
