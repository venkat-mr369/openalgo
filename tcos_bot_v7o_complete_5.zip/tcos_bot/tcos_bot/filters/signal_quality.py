"""
Signal Quality Scorer
=====================
Grades every Renko signal A/B/C/REJECT using columns
already computed in the Renko pipeline:

  - zlema9             (zero-lag EMA — trend alignment)
  - Colour_Brick_Count (consecutive same-direction bricks)
  - HH / LH / HL / LL (swing structure)
  - Last_High / Last_Low (nearest S/R levels)

This module NEVER generates its own indicators.
It only reads what's already in renko_df.
"""

from __future__ import annotations

import logging
from typing import Optional

import pandas as pd

from tcos_bot.config.settings import cfg
from tcos_bot.filters.base import BaseFilter, FilterResult
from tcos_bot.models.types import SignalGrade

log = logging.getLogger(__name__)


class SignalQualityScorer(BaseFilter):
    """
    Scores pre-entry signal quality from existing Renko columns.

    Scoring rubric
    --------------
    +2 / +3  ZLEMA alignment (price on correct side of ZLEMA9)
    +1 / +3  Consecutive brick count (momentum depth)
    +2       Confirmed swing structure (HH for BUYEN, LL for SELEX)
    +1       Room to run (S/R sufficiently distant)
    -1 / -2  Counter-signals (wrong side of ZLEMA, adverse structure)

    Grade mapping
    -------------
    A  (score ≥ 5)  → full position size
    B  (score ≥ 3)  → half size or debit spread
    C  (score ≥ 1)  → skip (long options absorb too much theta)
    REJECT (score ≤ 0 or hard block present) → cancel entry
    """

    def __init__(self) -> None:
        self._cfg = cfg.signal_quality

    # ── Public API ─────────────────────────────────────────────────────────────

    def check(
        self,
        symbol: str,
        signal: str,
        renko_df: Optional[pd.DataFrame],
        **kwargs,
    ) -> FilterResult:
        """
        Grade the signal and return a FilterResult.

        Parameters
        ----------
        symbol:   instrument root
        signal:   "BUYEN" or "SELEX"
        renko_df: Renko DataFrame with quality columns populated
        """
        if renko_df is None or renko_df.empty:
            return FilterResult.block("QUALITY: no renko data")

        grade, score, reasons, blocks = self._compute_grade(renko_df, signal, symbol)

        min_grade = self._cfg.min_grade
        grade_order = [SignalGrade.REJECT, SignalGrade.C, SignalGrade.B, SignalGrade.A]
        min_idx = next((i for i, g in enumerate(grade_order) if g.value == min_grade), 1)
        cur_idx = next((i for i, g in enumerate(grade_order) if g.value == grade.value), 0)

        log.info(
            "📊 QUALITY %s %s | grade=%s score=%d | bricks=%s | ZLEMA=%s",
            symbol, signal, grade.value, score,
            self._get_brick_count(renko_df),
            "✅" if self._zlema_aligned(renko_df, signal) else "❌",
        )
        for b in blocks:
            log.info("   %s", b)
        for r in reasons:
            log.debug("   %s", r)

        if grade == SignalGrade.REJECT:
            return FilterResult.block(f"QUALITY_REJECT: score={score} | {'; '.join(blocks)}")

        if cur_idx < min_idx:
            return FilterResult.block(
                f"QUALITY_BELOW_MIN: grade={grade.value} < min={min_grade}"
            )

        size = 1.0 if grade == SignalGrade.A else 0.5
        return FilterResult.allow(
            reason=f"QUALITY_{grade.value}: score={score}",
            size=size,
        )

    def score_only(
        self,
        renko_df: pd.DataFrame,
        signal: str,
        symbol: str = "",
    ) -> dict:
        """Return full scoring dict for inspection / testing."""
        grade, score, reasons, blocks = self._compute_grade(renko_df, signal, symbol)
        return {
            "grade":    grade.value,
            "score":    score,
            "reasons":  reasons,
            "blocks":   blocks,
            "c_count":  self._get_brick_count(renko_df),
            "zlema_ok": self._zlema_aligned(renko_df, signal),
        }

    # ── Scoring logic ───────────────────────────────────────────────────────────

    def _compute_grade(
        self,
        df: pd.DataFrame,
        signal: str,
        symbol: str,
    ) -> tuple[SignalGrade, int, list[str], list[str]]:
        last     = df.iloc[-1]
        score    = 0
        reasons: list[str] = []
        blocks:  list[str] = []

        brick  = self._safe_float(last.get("Renko_Brick"))
        zlema  = self._safe_float(last.get("zlema9"))
        c_count = int(self._safe_float(last.get("Colour_Brick_Count") or 0))

        # ── Rule 1: ZLEMA alignment ─────────────────────────────────────────
        if zlema and zlema > 0 and brick:
            if signal == "BUYEN":
                if brick > zlema:
                    score += self._cfg.zlema_weight
                    reasons.append(f"✅ Price {brick:.0f} > ZLEMA9 {zlema:.0f}")
                else:
                    score -= self._cfg.zlema_weight
                    blocks.append(f"❌ Price {brick:.0f} ≤ ZLEMA9 {zlema:.0f} — counter-trend CALL")
            elif signal == "SELEX":
                if brick < zlema:
                    score += self._cfg.zlema_weight
                    reasons.append(f"✅ Price {brick:.0f} < ZLEMA9 {zlema:.0f}")
                else:
                    score -= self._cfg.zlema_weight
                    blocks.append(f"❌ Price {brick:.0f} ≥ ZLEMA9 {zlema:.0f} — counter-trend PUT")

        # ── Rule 2: Consecutive brick momentum ─────────────────────────────
        min_bricks = self._cfg.min_consecutive_bricks
        if c_count >= min_bricks + 1:
            score += self._cfg.brick_momentum_weight
            reasons.append(f"✅ Strong momentum: {c_count} consecutive bricks")
        elif c_count >= min_bricks:
            score += self._cfg.brick_momentum_weight - 1
            reasons.append(f"✅ Good momentum: {c_count} consecutive bricks")
        elif c_count == min_bricks - 1:
            score += 1
            reasons.append(f"⚠️ Weak momentum: {c_count} bricks (min {min_bricks})")
        else:
            score -= 1
            blocks.append(f"❌ Only {c_count} brick(s) — no momentum (need {min_bricks})")

        # ── Rule 3: Swing structure ─────────────────────────────────────────
        score, reasons, blocks = self._check_swing_structure(
            last, signal, score, reasons, blocks
        )

        # ── Rule 4: Room to run ─────────────────────────────────────────────
        if brick:
            score, reasons, blocks = self._check_room_to_run(
                last, signal, brick, score, reasons, blocks
            )

        # ── Rule 5: Directional efficiency ─────────────────────────────────
        # Measures how efficiently price moves over the last N bricks.
        # A clean trend is high-efficiency; a chop is low-efficiency.
        # This is the primary chop filter for MCX instruments that run
        # under UNKNOWN regime (no equity VIX classification available).
        score, reasons, blocks = self._check_efficiency(
            df, signal, score, reasons, blocks
        )

        # ── Grade ────────────────────────────────────────────────────────────
        # Grade-A threshold = 5.
        # Calibrated for fine-grained brick sizes (NIFTY=12, BANKNIFTY=25).
        # At brick=12 a new brick forms every ~6 minutes — CBC=3+ is common,
        # making score=4 fire on 38% of all signals (no longer selective).
        # Score=5 requires: ZLEMA(+2) + CBC_strong(+3) — genuinely strong
        # sustained momentum, not just 2 bricks in a row.
        # At coarser bricks (50+) score=4 is rarer and grade-A could be ≥4.
        if blocks and score <= 0:
            grade = SignalGrade.REJECT
        elif score >= 5:
            grade = SignalGrade.A
        elif score >= 3:
            grade = SignalGrade.B
        elif score >= 1:
            grade = SignalGrade.C
        else:
            grade = SignalGrade.REJECT

        return grade, score, reasons, blocks

    def _check_swing_structure(
        self,
        row: pd.Series,
        signal: str,
        score: int,
        reasons: list[str],
        blocks: list[str],
    ) -> tuple[int, list[str], list[str]]:
        hh = self._is_true(row.get("HH"))
        ll = self._is_true(row.get("LL"))
        lh = self._is_true(row.get("LH"))
        hl = self._is_true(row.get("HL"))

        w = self._cfg.swing_structure_weight

        if signal == "BUYEN":
            if hh:
                score += w
                reasons.append("✅ Higher High — bullish structure confirmed")
            elif lh:
                score -= 1
                blocks.append("⚠️ Lower High — bullish signal in downtrend")
        elif signal == "SELEX":
            if ll:
                score += w
                reasons.append("✅ Lower Low — bearish structure confirmed")
            elif hl:
                score -= 1
                blocks.append("⚠️ Higher Low — bearish signal in uptrend")

        return score, reasons, blocks

    def _check_room_to_run(
        self,
        row: pd.Series,
        signal: str,
        brick: float,
        score: int,
        reasons: list[str],
        blocks: list[str],
    ) -> tuple[int, list[str], list[str]]:
        bs_val   = self._safe_float(row.get("brick_size_hint", 50))  # fallback
        min_room = self._cfg.min_room_bricks

        last_high = self._safe_float(row.get("Last_High"))
        last_low  = self._safe_float(row.get("Last_Low"))

        if signal == "BUYEN" and last_high and last_high > 0 and bs_val:
            dist = (last_high - brick) / bs_val
            if dist <= 0:
                # Last_High is at or below current brick — resistance already cleared,
                # nothing overhead to penalise.  Skip entirely (no score change).
                pass
            elif dist < min_room:
                score -= 1
                blocks.append(f"⚠️ Resistance only {dist:.1f}b away at {last_high:.0f}")
            elif dist > 3:
                score += 1
                reasons.append(f"✅ Resistance {dist:.1f}b away — room to rally")

        elif signal == "SELEX" and last_low and last_low > 0 and bs_val:
            dist = (brick - last_low) / bs_val
            if dist <= 0:
                # B-02 FIX: brick is BELOW last_low — support already broken.
                # This is a breakdown confirmation, the strongest PUT setup.
                # Old code had no guard so dist=-4.2b triggered -1 penalty and
                # logged "⚠️ Support only -4.2b away" — completely wrong.
                # Mirror the CALL path: dist<=0 means resistance/support cleared,
                # skip entirely (no penalty, no bonus — direction already confirmed).
                pass
            elif dist < min_room:
                score -= 1
                blocks.append(f"⚠️ Support only {dist:.1f}b away at {last_low:.0f}")
            elif dist > 3:
                score += 1
                reasons.append(f"✅ Support {dist:.1f}b away — room to fall")

        return score, reasons, blocks

    def _check_efficiency(
        self,
        df: pd.DataFrame,
        signal: str,
        score: int,
        reasons: list[str],
        blocks: list[str],
    ) -> tuple[int, list[str], list[str]]:
        """
        Directional efficiency — BONUS ONLY, no negative penalty.

        Efficiency = |net_displacement| / total_path over last N bricks.
        Range 0.0 (pure chop) → 1.0 (perfectly linear trend).

        Design change (verified against 4 days real NIFTY/BANKNIFTY data):
        The original -2 penalty below 0.35 was killing the most profitable
        signals. On event/breakout days, the prior 20 bricks are always a
        mix of range and directional movement — efficiency scores 0.00–0.20
        even when a genuine trend is starting. BANKNIFTY Feb-01 signals with
        eff=0.10 went on to be +1517, +1817pts in 60 minutes.

        Root cause: a BUYEN/SELEX fires on the 2-brick reversal (cbc=2).
        At that moment: ZLEMA(+2) + CBC(+1) = score 3 = grade B. Adding
        eff=-2 drops it to 1 = grade C = blocked. But the ZLEMA check already
        confirms direction; the CBC confirms momentum. Adding an efficiency
        penalty double-penalises breakouts from consolidation — exactly the
        highest-probability setups on NIFTY/BANKNIFTY.

        New rule: efficiency is BONUS ONLY.
          eff ≥ threshold (+0.60 default): +1 (confirms the move is clean)
          eff < threshold:                  0 (neutral — no penalty)

        Pure chop with no direction is already filtered by:
          - ZLEMA misalignment (-2 each way = REJECT)
          - No swing structure (0 points)
          - min_grade=B floor (needs ≥3 points)
        """
        lookback  = getattr(self._cfg, "efficiency_lookback", 20)
        threshold = getattr(self._cfg, "efficiency_threshold", 0.60)
        if lookback <= 0 or "direction" not in df.columns:
            return score, reasons, blocks

        window = df.iloc[-lookback:] if len(df) >= lookback else df
        if len(window) < 4:
            return score, reasons, blocks

        directions = window["direction"].fillna(0).astype(int).tolist()
        net_disp   = abs(sum(directions))
        total_path = len(directions)
        efficiency = net_disp / total_path if total_path > 0 else 1.0

        if efficiency >= threshold:
            score += 1
            reasons.append(
                f"✅ TREND: directional efficiency={efficiency:.2f} — clean directional move"
            )
        else:
            reasons.append(
                f"⚠️ efficiency={efficiency:.2f} (below {threshold:.2f} — breakout/consolidation context)"
            )

        return score, reasons, blocks

    # ── Helpers ─────────────────────────────────────────────────────────────────

    @staticmethod
    def _safe_float(val) -> Optional[float]:
        try:
            f = float(val)
            return f if f == f else None   # NaN check
        except (TypeError, ValueError):
            return None

    @staticmethod
    def _is_true(val) -> bool:
        return val is True or str(val).strip().lower() == "true"

    def _get_brick_count(self, df: pd.DataFrame) -> int:
        try:
            return int(df.iloc[-1].get("Colour_Brick_Count", 0) or 0)
        except Exception:
            return 0

    def _zlema_aligned(self, df: pd.DataFrame, signal: str) -> bool:
        last  = df.iloc[-1]
        brick = self._safe_float(last.get("Renko_Brick"))
        zlema = self._safe_float(last.get("zlema9"))
        if not (brick and zlema and zlema > 0):
            return False
        return (signal == "BUYEN" and brick > zlema) or (signal == "SELEX" and brick < zlema)
