"""
Directional Gate — directional_gate.py
=======================================
Regime-aware directional trade filter (Part 4).

Integrates trend state with market regime to enforce smart entry rules:

    TRENDING  → hard block counter-trend entries
    SIDEWAYS  → allow both, but score counter-trend down (handled in quality)
    VOLATILE  → allow both if quality is strong enough (threshold in pipeline)
    UNKNOWN   → prefer aligned, warn on counter-trend (but do not hard block)
    NEUTRAL   → in TRENDING regime, block fresh entries (no conviction)

This module is called by FilterPipeline.evaluate() BEFORE signal quality scoring
so that a hard block exits early without wasting the quality computation.

Design notes
------------
- Does NOT replace SignalQualityScorer — ZLEMA scoring still applies.
- Hard blocks are only issued in TRENDING + clear counter-trend cases.
- Counter-trend in SIDEWAYS/VOLATILE → size penalty (returned via FilterResult.half).
- Counter-trend in UNKNOWN → allowed but logged as warning.
- Neutral trend in TRENDING → block (no directional conviction to trade on).

Interface
---------
    gate = DirectionalGate()
    result = gate.check(signal, trend_state, regime)
    if not result.allowed:
        return pipeline_block(result.reason)
    # result.size_multiplier may be < 1.0 for penalised entries
"""

from __future__ import annotations

import logging
from typing import Union

from tcos_bot.filters.base import FilterResult
from tcos_bot.signals.trend_state import TrendState

log = logging.getLogger(__name__)

# Size multiplier applied to counter-trend entries in non-TRENDING regimes
_COUNTER_TREND_PENALTY = 0.5   # half position size for counter-trend in SIDEWAYS/VOLATILE/UNKNOWN


class DirectionalGate:
    """
    Regime-aware directional filter.

    Call check() once per signal evaluation, passing the current trend state
    and the market regime string.

    Returns a FilterResult with:
      - allowed=False  → hard block (caller should stop processing)
      - allowed=True, size_multiplier=0.5 → allowed but penalised
      - allowed=True, size_multiplier=1.0 → fully aligned, no adjustment
    """

    def check(
        self,
        signal: str,
        trend: TrendState,
        regime: Union[str, "MarketRegime"],  # noqa: F821
        symbol: str = "",
    ) -> FilterResult:
        """
        Evaluate whether this signal direction is appropriate for the
        current trend state and market regime.

        Parameters
        ----------
        signal : "BUYEN" (enter CALL) | "SELEX" (enter PUT)
        trend  : TrendState from detect_trend_state()
        regime : MarketRegime value string or enum
        symbol : for logging only
        """
        # Normalise regime to string value
        regime_str = regime.value if hasattr(regime, "value") else str(regime).upper()

        is_bull_signal = (signal == "BUYEN")
        is_bear_signal = (signal == "SELEX")

        # Determine alignment relative to trend
        trend_aligned   = (
            (is_bull_signal and trend == TrendState.UPTREND) or
            (is_bear_signal and trend == TrendState.DOWNTREND)
        )
        counter_trend   = (
            (is_bull_signal and trend == TrendState.DOWNTREND) or
            (is_bear_signal and trend == TrendState.UPTREND)
        )
        neutral_trend   = (trend == TrendState.NEUTRAL)

        # ── TRENDING regime: strictest rules ──────────────────────────────
        if regime_str == "TRENDING":
            if trend_aligned:
                log.debug(
                    "🎯 TREND_GATE PASS: %s %s aligned (%s)",
                    symbol, signal, trend.value,
                )
                return FilterResult.allow(
                    f"DIRECTIONAL_OK: {trend.value}+{signal} aligned in TRENDING"
                )

            if counter_trend:
                reason = (
                    f"DIRECTIONAL_BLOCK: TRENDING regime — {signal} is counter-trend "
                    f"({trend.value}). Hard block."
                )
                log.info("🚫 TREND_GATE BLOCK: %s %s — %s", symbol, signal, reason)
                return FilterResult.block(reason)

            # Neutral trend in TRENDING regime: reduce size but do NOT hard-block.
            # Coarse-brick instruments (BANKNIFTY=40, SENSEX=50) form fewer bricks
            # per hour than NIFTY=12 and can sit in NEUTRAL for 20-30 min even on a
            # clearly trending day. Hard-blocking here means these instruments NEVER
            # trade on trending days — they only get signals after NIFTY has already
            # moved 3-5 bricks (by which time the move is largely done).
            # Fix: treat TRENDING+NEUTRAL as half-size caution, same as SIDEWAYS.
            # The quality gate (CBC, ZLEMA, swing structure) still applies — a Grade-B
            # signal in NEUTRAL trend on a trending day is genuine reduced-conviction.
            reason = (
                "DIRECTIONAL_CAUTION: TRENDING regime but trend is NEUTRAL — "
                "half-size (coarse-brick instrument still confirming trend)"
            )
            log.info("⚠️ TREND_GATE HALF (NEUTRAL): %s %s — %s", symbol, signal, reason)
            return FilterResult.half(reason)

        # ── SIDEWAYS regime: allow both, penalise counter-trend ───────────
        if regime_str == "SIDEWAYS":
            if counter_trend:
                reason = (
                    f"DIRECTIONAL_WARN: SIDEWAYS + counter-trend {signal} "
                    f"({trend.value}) — half size"
                )
                log.debug("⚠️ TREND_GATE PENALTY: %s %s — %s", symbol, signal, reason)
                return FilterResult.half(reason)
            return FilterResult.allow(
                f"DIRECTIONAL_OK: SIDEWAYS regime, {signal} ({trend.value})"
            )

        # ── VOLATILE regime: allow both, penalise counter-trend ───────────
        if regime_str == "VOLATILE":
            if counter_trend:
                reason = (
                    f"DIRECTIONAL_WARN: VOLATILE + counter-trend {signal} "
                    f"({trend.value}) — half size"
                )
                log.debug("⚠️ TREND_GATE PENALTY: %s %s — %s", symbol, signal, reason)
                return FilterResult.half(reason)
            return FilterResult.allow(
                f"DIRECTIONAL_OK: VOLATILE regime, {signal} ({trend.value})"
            )

        # ── UNKNOWN regime: prefer aligned, warn on counter-trend ─────────
        if counter_trend:
            reason = (
                f"DIRECTIONAL_WARN: UNKNOWN regime + counter-trend {signal} "
                f"({trend.value}) — half size (caution)"
            )
            log.debug("⚠️ TREND_GATE WARN: %s %s — %s", symbol, signal, reason)
            return FilterResult.half(reason)

        return FilterResult.allow(
            f"DIRECTIONAL_OK: UNKNOWN/{signal}/{trend.value}"
        )
