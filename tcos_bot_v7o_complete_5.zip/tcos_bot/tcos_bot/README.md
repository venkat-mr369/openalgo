# TCOS-L Refactored Architecture

## Package Structure

```
tcos_bot/
│
├── config/
│   └── settings.py          ← ALL config in typed dataclasses (single source of truth)
│
├── models/
│   └── types.py             ← All enums, DTOs, value objects (no logic)
│
├── monitoring/
│   └── logger.py            ← IST-formatted structured logging + TradeLogger events
│
├── data/
│   ├── ltp_store.py         ← Thread-safe LTP cache (16-bucket hash locks)
│   └── trade_store.py       ← SQLite persistence (WAL, schema migration, typed API)
│
├── filters/
│   ├── base.py              ← FilterResult + BaseFilter abstract contract
│   ├── day_regime.py        ← Layer 1: Day regime classifier (TRENDING/SIDEWAYS/VOLATILE)
│   ├── signal_quality.py    ← Layer 2: Signal scorer (zlema9 + bricks + swing structure)
│   ├── option_quality.py    ← Layer 3: IV rank + day-of-week + strike selection
│   └── pipeline.py          ← Orchestrates all 3 layers, short-circuit on block
│
├── signals/
│   ├── renko_engine.py      ← Pure Renko computation (HL-Wick, Close-Traditional, Annotator)
│   └── signal_generator.py  ← Signal → filter pipeline → trade_manager row creation
│
├── risk/
│   └── risk_manager.py      ← Trailing stops, NFT, chop oscillation, whipsaw cooldown
│
├── execution/
│   ├── position_tracker.py  ← Broker positions + lot sizes + order router
│   └── option_resolver.py   ← Finds CE/PE contract symbols for entries and exits
│
├── core/
│   ├── engine.py            ← Main orchestration loop (all threads)
│   └── ws_manager.py        ← WebSocket + REST fallback
│
├── tests/
│   └── test_all.py          ← 22 unit tests (pytest, zero broker deps)
│
└── main.py                  ← Entry point (argparse, SIGINT handler)
```

---

## What Changed vs the Original 10,902-line File

### Deleted
| Category | What was removed |
|---|---|
| Dead code | ~40 commented-out code blocks, `'''...'''` disabled sections |
| Duplicate functions | `get_net_qty` + `get_net_qty_on_exchange` → single `PositionTracker.build_root_map` |
| Raw globals | `ltp_dict`, `ltp_timestamps`, `_trend_reentry_state` (thread-unsafe dicts) |
| Hardcoded constants | `_SIGNAL_MAX_AGE_MINUTES = 30` inline (now in `BrokerConfig`) |
| Bare excepts | All `except:` → `except Exception as e:` with structured logging |
| `print()` | All 400+ print statements → structured `logging` calls |

### Replaced
| Original | Refactored |
|---|---|
| 400+ `print(f"...")` | `log.info/warning/error(...)` + `TradeLogger` structured events |
| Global `ltp_dict[sym] = val` | `ltp_store.update(sym, val)` (16-bucket thread-safe) |
| Inline SQLite + CSV hybrid | `TradeStore` with WAL, schema migration, typed API |
| Flat 10k-line file | 12 focused modules, each < 400 lines |
| `if CHOP_OSCILLATION_ENABLED:` guards | `ChopOscillationChecker.check_and_annotate()` (self-contained) |
| `calculate_renko_hl_wick_safe()` + `calculate_renko_close_traditional()` | `RenkoHLWick` + `RenkoCloseTraditional` (pure, stateless, testable) |
| 3-layer pre-entry check scattered across 5 functions | `FilterPipeline.evaluate()` (single call, composable) |

### Added
| New | Purpose |
|---|---|
| `DayRegimeClassifier` | Classifies entire day before first trade (TRENDING/SIDEWAYS/VOLATILE) |
| `SignalQualityScorer` | Grades every signal A/B/C/REJECT using already-computed Renko columns |
| `OptionQualityGate` | IV rank check + day-of-week + dynamic strike selection |
| `QualityResult` | Immutable result carrying grade, size multiplier, reasons |
| `TradeLogger` | Structured trade event log (ENTRY/EXIT/STOP/BLOCK) for P&L tracking |
| 22 unit tests | Cover Renko engines, annotator, filters, signal scorer |

---

## Running

```bash
# Install deps
pip install pandas numpy scipy sqlalchemy

# Set credentials
export OPENALGO_API_KEY=your_key
export OPENALGO_HOST=http://localhost:5000
export OPENALGO_STRATEGY=TCOS_L
export OPENALGO_PRODUCT=MIS

# Run
python -m tcos_bot.main --symbols ohlcdata/symbols_to_trade.csv

# Tests
pytest tcos_bot/tests/ -v
```

---

## Key Design Decisions

### 1. Filters are stateless validators
Every filter returns `FilterResult(allowed, reason, size_multiplier)`.
No filter reads from DB or makes broker calls.
The pipeline collects all results and takes `min(size_multipliers)`.

### 2. Risk managers own their state
`TrailingStopManager`, `WhipsawCooldownTracker`, `NFTReentryBlocker`
each carry their own internal state under an `RLock`.
The engine injects them — no global state.

### 3. Trade execution is a pure function over trade_manager
`OrderRouter.execute_order()` takes a DataFrame, returns a DataFrame.
No mutations outside that function boundary.
The engine persists the result.

### 4. Write-ahead logging for crash safety
`OPEN → SENDING` is written to DB BEFORE the broker call.
On crash, the watchdog reconciles SENDING rows against broker positions.

### 5. Quality metadata travels with the trade
Every `BUYCL/BUYPT` row carries `signal_grade`, `quality_score`, `day_regime`.
This enables post-trade analysis: "were Grade A trades better than Grade B?"
