"""
Domain Models
=============
All data transfer objects, enums, and type aliases.
No logic here — pure data containers.
"""

from __future__ import annotations

import enum
from dataclasses import dataclass, field
from datetime import datetime
from typing import Optional, List


# ── Enums ─────────────────────────────────────────────────────────────────────

class Signal(str, enum.Enum):
    """Raw Renko signal types."""
    BUYEN  = "BUYEN"   # trend reversal up  → buy call
    SELEX  = "SELEX"   # trend reversal down → buy put
    BUYRE  = "BUYRE"   # close-renko buy reversal
    SELRE  = "SELRE"   # close-renko sell reversal
    SELST  = "SELST"   # stop-loss for call
    SELSP  = "SELSP"   # stop-loss for put


class OrderAction(str, enum.Enum):
    """Bot-level order actions."""
    BUYCL  = "BUYCL"   # enter call
    BUYPT  = "BUYPT"   # enter put
    SELCL  = "SELCL"   # exit call (reversal)
    SELPT  = "SELPT"   # exit put (reversal)
    SELST  = "SELST"   # stop call
    SELSP  = "SELSP"   # stop put


class OrderStatus(str, enum.Enum):
    OPEN          = "OPEN"
    SENDING       = "SENDING"
    INPOSITION    = "INPOSITION"
    CLOSED        = "CLOSED"
    CANCELLED     = "CANCELLED"
    PENDING_VERIFY = "PENDING_VERIFY"


class OptionType(str, enum.Enum):
    CALL = "CE"
    PUT  = "PE"


class MarketRegime(str, enum.Enum):
    TRENDING  = "TRENDING"
    SIDEWAYS  = "SIDEWAYS"
    VOLATILE  = "VOLATILE"
    UNKNOWN   = "UNKNOWN"


class SignalGrade(str, enum.Enum):
    """Signal quality grades."""
    A      = "A"       # full size
    B      = "B"       # half size or spread
    C      = "C"       # skip for long options
    REJECT = "REJECT"  # block entry


class CloseReason(str, enum.Enum):
    STOPLOSS                = "STOPLOSS"
    SIGNAL_EXIT             = "SIGNAL_EXIT"
    NFT_NO_FOLLOW_THROUGH   = "NFT_NO_FOLLOW_THROUGH"
    CHOP_OSCILLATION_EXIT   = "CHOP_OSCILLATION_EXIT"
    SQUARE_OFF              = "SQUARE_OFF"
    POSITION_ALREADY_CLOSED = "POSITION_ALREADY_CLOSED"
    RECONCILIATION_ORPHAN   = "RECONCILIATION_ORPHAN_CANCELLED"
    STALE_SIGNAL            = "STALE_SIGNAL"
    DAY_REGIME_BLOCK        = "DAY_REGIME_BLOCK"
    QUALITY_REJECT          = "QUALITY_REJECT"


# ── Value Objects ──────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class RenkoSignalEvent:
    """Immutable signal produced by the Renko signal generator."""
    timestamp:   datetime
    symbol:      str
    exchange:    str
    signal:      Signal
    entry_price: float
    brick_size:  float
    source:      str = "CLOSE_RENKO"   # CLOSE_RENKO | HL_RENKO


@dataclass(frozen=True)
class QualityResult:
    """Result of the 3-layer pre-entry quality pipeline."""
    allowed:        bool
    grade:          SignalGrade
    score:          int
    size_multiplier: float            # 0.0 = block, 0.5 = half, 1.0 = full
    reasons:        List[str] = field(default_factory=list)
    blocks:         List[str] = field(default_factory=list)
    regime:         MarketRegime = MarketRegime.UNKNOWN

    @property
    def blocked(self) -> bool:
        return not self.allowed or self.size_multiplier == 0.0


@dataclass(frozen=True)
class DayRegimeResult:
    """Output of the day regime classifier."""
    regime:       MarketRegime
    confidence:   float
    vix:          Optional[float]
    range_ratio:  float
    classified_at: datetime


@dataclass(frozen=True)
class OptionSymbol:
    """Resolved option contract details."""
    symbol:         str
    exchange:       str
    strike:         float
    option_type:    OptionType
    expiry:         datetime
    lot_size:       int
    root:           str


@dataclass
class TradeRow:
    """
    Represents one row in the trade_manager table.
    Mutable — updated through the trade lifecycle.
    """
    exchange:       str
    timestamp:      datetime
    renko_signal:   str           # OrderAction value
    symbol:         str
    entry_price:    float

    # Populated at execution
    exec_price:     Optional[float]  = None
    quantity:       Optional[int]    = None
    order_status:   str              = OrderStatus.OPEN.value
    orderid:        Optional[str]    = None
    close_reason:   Optional[str]    = None
    close_price:    Optional[float]  = None

    # Entry metadata
    signal_source:  Optional[str]    = None
    entry_mode:     Optional[str]    = None
    limit_entry_price: Optional[float] = None
    option_symbol:  Optional[str]    = None
    index_ltp:      Optional[float]  = None
    fill_timestamp: Optional[str]    = None

    # Peak tracking for re-entry
    peak_brick_since_entry: Optional[float] = None
    peak_ltp_since_entry:   Optional[float] = None

    # NFT tracking
    nft_validated:  int    = 0
    nft_target:     Optional[float] = None
    nft_rev_count:  int    = 0
    nft_last_dir:   Optional[str]   = None

    # Chop tracking
    chop_reversals: int    = 0
    chop_last_dir:  Optional[str]   = None
    chop_last_ltp:  Optional[float] = None

    # Quality metadata (new)
    signal_grade:   Optional[str]   = None
    quality_score:  Optional[int]   = None
    day_regime:     Optional[str]   = None


@dataclass
class LTPSnapshot:
    """Thread-safe LTP with staleness tracking."""
    symbol:    str
    ltp:       float
    timestamp: float   # time.time()

    def age_seconds(self, now: float) -> float:
        return now - self.timestamp

    def is_stale(self, threshold_secs: float, now: float) -> bool:
        return self.age_seconds(now) > threshold_secs


@dataclass
class StopState:
    """Tracks stop-loss levels for an active position."""
    symbol:       str
    direction:    str           # "CALL" | "PUT"
    entry_price:  float
    stop_price:   float
    catastrophe_price: float
    brick_size:   float
    is_renko_confirmed: bool = True

    # Trailing state
    trail_active: bool  = False
    breakeven_reached: bool = False
    peak_price:   float = 0.0


