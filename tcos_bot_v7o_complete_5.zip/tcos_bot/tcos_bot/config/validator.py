"""
Config Validator — tcos_bot/config/validator.py
================================================
PR-6: Validates all config values at startup before any threads are started.
Raises ConfigError with a full list of all violations (not fail-fast on first).

Validates:
- Brick sizes positive and within plausible range
- Time strings parseable as HH:MM
- Trailing stop params logically consistent
- NFT timeout_min < timeout_max
- MAX_LOTS vs estimated capital
- Session start < session end
- Exchange/symbol pair combinations
"""

from __future__ import annotations

import logging
from datetime import time as dtime
from typing import List

log = logging.getLogger(__name__)


class ConfigError(Exception):
    """Raised when config validation fails. Contains all violations."""
    pass


def validate_config(cfg) -> None:
    """
    Validate all config values.
    Raises ConfigError with ALL violations listed if any are found.
    """
    errors: List[str] = []

    # ── Brick sizes ────────────────────────────────────────────────────────────
    from tcos_bot.config.settings import BRICK_SIZES
    for sym, bs in BRICK_SIZES.items():
        if bs <= 0:
            errors.append(f"BRICK_SIZES[{sym}]={bs} must be > 0")
        if bs > 10_000:
            errors.append(f"BRICK_SIZES[{sym}]={bs} seems implausibly large (>10,000)")

    # ── Trailing stop consistency ──────────────────────────────────────────────
    t = cfg.trailing
    # Equality is valid: breakeven at the same point trailing starts is coherent.
    if t.breakeven_after > t.trail_start_after:
        errors.append(
            f"trailing.breakeven_after ({t.breakeven_after}) must be <= "
            f"trail_start_after ({t.trail_start_after})"
        )
    if t.trail_distance <= 0:
        errors.append(f"trailing.trail_distance ({t.trail_distance}) must be > 0")

    # ── Stop initial bricks ────────────────────────────────────────────────────
    s = cfg.stop
    if s.initial_stop_bricks <= 0:
        errors.append(f"stop.initial_stop_bricks ({s.initial_stop_bricks}) must be > 0")

    # ── NFT timeout range ──────────────────────────────────────────────────────
    n = cfg.nft
    if n.timeout_min >= n.timeout_max:
        errors.append(
            f"nft.timeout_min ({n.timeout_min}) must be < timeout_max ({n.timeout_max})"
        )
    if n.timeout_min <= 0:
        errors.append(f"nft.timeout_min ({n.timeout_min}) must be > 0")
    if n.target_sec_per_brick <= 0:
        errors.append(f"nft.target_sec_per_brick ({n.target_sec_per_brick}) must be > 0")

    # ── Session hours ──────────────────────────────────────────────────────────
    b = cfg.broker
    for attr in ("session_start", "session_end", "exit_all_by"):
        val = getattr(b, attr, None)
        if val is not None:
            if not _parse_time(str(val)):
                errors.append(f"broker.{attr}='{val}' is not a valid HH:MM time string")

    if hasattr(b, "session_start") and hasattr(b, "session_end"):
        t_start = _parse_time(str(b.session_start))
        t_end   = _parse_time(str(b.session_end))
        if t_start and t_end and t_start >= t_end:
            errors.append(
                f"broker.session_start ({b.session_start}) must be before "
                f"session_end ({b.session_end})"
            )

    # ── LOT sizes ──────────────────────────────────────────────────────────────
    from tcos_bot.config.settings import LOT_SIZES, MAX_LOTS
    for sym, ls in LOT_SIZES.items():
        if ls <= 0:
            errors.append(f"LOT_SIZES[{sym}]={ls} must be > 0")
    for sym, ml in MAX_LOTS.items():
        if ml <= 0:
            errors.append(f"MAX_LOTS[{sym}]={ml} must be > 0")
        if ml > 50:
            errors.append(f"MAX_LOTS[{sym}]={ml} is implausibly high (>50 lots)")

    # ── Whipsaw ────────────────────────────────────────────────────────────────
    w = cfg.whipsaw
    if w.flip_window_mins <= 0:
        errors.append(f"whipsaw.flip_window_mins must be > 0")
    if w.max_flips <= 0:
        errors.append(f"whipsaw.max_flips must be > 0")
    if w.cooldown_mins <= 0:
        errors.append(f"whipsaw.cooldown_mins must be > 0")

    # ── LTP staleness thresholds ───────────────────────────────────────────────
    if hasattr(b, "ltp_hard_block_secs") and b.ltp_hard_block_secs <= 0:
        errors.append(f"broker.ltp_hard_block_secs must be > 0")

    # ── Persist URL ────────────────────────────────────────────────────────────
    from tcos_bot.config.settings import cfg as _cfg
    db_url = getattr(_cfg.persistence, "db_url", "")
    if not db_url:
        errors.append("persistence.db_url is empty")

    # ── Report ─────────────────────────────────────────────────────────────────
    if errors:
        msg = "\n".join(f"  [{i+1}] {e}" for i, e in enumerate(errors))
        raise ConfigError(
            f"Config validation failed with {len(errors)} error(s):\n{msg}\n\n"
            "Fix config/settings.py before starting the bot."
        )
    log.info("✅ Config validation passed")


def _parse_time(s: str) -> dtime | None:
    """Parse 'HH:MM' → time object, or None if invalid."""
    try:
        parts = str(s).split(":")
        return dtime(int(parts[0]), int(parts[1]))
    except Exception:
        return None
