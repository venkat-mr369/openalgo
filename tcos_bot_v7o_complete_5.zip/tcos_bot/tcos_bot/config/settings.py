"""
settings.py — PATCHED (Issues A, B, C, D)
==========================================
Changes from original:
  1. NEW WebSocketConfig dataclass (supports ws_manager.py stale-detection params)
  2. WhipsawConfig — added adaptive cooldown fields (Issue C)
  3. ChopOscillationConfig — added min-hold / multi-confirm fields (Issue D)
  4. BotConfig — added `websocket: WebSocketConfig` field

No original fields were removed; all additions are backwards-compatible.
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, Optional
from zoneinfo import ZoneInfo

# ── Timezone ──────────────────────────────────────────────────────────────────
IST = ZoneInfo("Asia/Kolkata")


# ── Lot sizes ─────────────────────────────────────────────────────────────────
LOT_SIZES: Dict[str, int] = {
    "NIFTY":       65,
    "BANKNIFTY":   30,
    "FINNIFTY":    40,
    "MIDCPNIFTY":  75,
    "SENSEX":      20,
    "BANKEX":      20,
    "CRUDEOIL":   100,
    "CRUDEOILM":   10,
    "GOLDM":       10,
    "SILVERM":      5,
    "NATURALGAS": 1250,
}

# LOT-FIX: Hard overrides that take priority over openalgo.db symtoken table.
# The DB can contain wrong lotsize values (e.g. GOLDM=100 instead of 10 because
# the CE/PE query picks up non-OPTFUT rows whose lotsize is set incorrectly by
# the data vendor). These values are authoritative and bypass the DB entirely.
# Keys must match the instrument ROOT exactly (no expiry/strike suffix).
# Leave empty ({}) to always trust the DB.
LOT_SIZE_OVERRIDES: Dict[str, int] = {
    # MCX commodities — DB often has wrong values for these instruments
    "GOLDM":      10,    # 10 grams/lot (DB incorrectly reported 100)
    "SILVERM":     5,    # 5 kg/lot (DB correctly reports 5 — kept for safety)
    "CRUDEOIL":  100,    # 100 barrels/lot (correctly reported by DB)
    "CRUDEOILM":  10,    # 10 barrels/lot (mini crude)
    "NATURALGAS": 1250,  # 1250 MMBTU/lot
}

MAX_LOTS: Dict[str, int] = {
    # S-1 FIX: Enable grade-based size differentiation.
    # Grade-A (size=1.0): 2 lots. Grade-B (size=0.5): 1 lot.
    # min_combined_size=0.40 now correctly blocks Grade-B in low-activity
    # windows (0.5 × 0.5 = 0.25 < 0.40 → blocked outright, not half-sized).
    # FINNIFTY and MIDCPNIFTY stay at 1 lot — smaller contract, higher P&L/tick.
    "NIFTY":      2,
    "BANKNIFTY":  2,
    "SENSEX":     2,
    "BANKEX":     2,
    "FINNIFTY":   1,
    "MIDCPNIFTY": 1,
}
DEFAULT_MAX_LOTS: int = 1

PNL_RUPEE_PER_PT: Dict[str, float] = {
    "NIFTY":      1.0,
    "BANKNIFTY":  1.0,
    "FINNIFTY":   1.0,
    "MIDCPNIFTY": 1.0,
    "SENSEX":     1.0,
    "BANKEX":     1.0,
    # FIX: CRUDEOIL was 100.0, CRUDEOILM was 10.0 — both WRONG.
    # record_close formula: pnl_rs = pnl_pts * lots * lot_size * rps
    # This already multiplies by lot_size (barrels per lot), so rps must
    # be "INR per point per UNIT (barrel)", not "INR per point per LOT".
    # CRUDEOIL: 1 barrel * 1 pt = INR 1/unit → rps = 1.0
    #   Correct: -32 pts * 1 lot * 100 barrels * 1.0 = -3,200 INR ✓
    #   Was wrong: -32 * 1 * 100 * 100.0 = -320,000 INR (100x inflation)
    # CRUDEOILM: mini crude, same logic → rps = 1.0
    "CRUDEOIL":   1.0,   # was 100.0 — caused 100x P&L inflation
    "CRUDEOILM":  1.0,   # was 10.0  — caused 10x P&L inflation
    "GOLDM":      1.0,
    "SILVERM":    1.0,
    "NATURALGAS": 1.0,
}

# FIX I-01: Synced with main.py — previously BANKNIFTY=24,SENSEX=25,BANKEX=25,
# MCX values were also wrong. main.py is the runtime source of truth; these must
# match so modules that import BRICK_SIZES before engine._init_brick_sizes() runs
# (e.g. filters, signal quality) use the correct values.
BRICK_SIZES: Dict[str, float] = {
    "NIFTY":       12.0,
    "BANKNIFTY":   40.0,   # was 24.0 — caused trail to need 160pts, stops 120pts wide
    "FINNIFTY":    40.0,
    "MIDCPNIFTY":  25.0,
    "SENSEX":      50.0,   # was 25.0 — trail needed 200pts, today exited +5 not +143
    "BANKEX":      50.0,   # was 25.0 — same issue as SENSEX
    "CRUDEOIL":     8.0,   # was 1.0
    "CRUDEOILM":    1.0,
    "GOLDM":       150.0,  # was 10.0
    "SILVERM":     500.0,  # was 1.0
    "NATURALGAS":    4.0,  # was 0.5
}

STRIKE_STEPS: Dict[str, int] = {
    "NIFTY":       100,
    "BANKNIFTY":   100,
    "SENSEX":      100,
    "BANKEX":      100,
    "CRUDEOIL":     50,
    "GOLDM":       500,
    "SILVERM":    1000,
    "NATURALGAS":    5,
    "FINNIFTY":     50,
    "MIDCPNIFTY":   25,
}


# ── NEW: WebSocket configuration (supports ws_manager.py stale detection) ─────

@dataclass(frozen=True)
class WebSocketConfig:
    """
    Production parameters for WebSocket stale detection and auto-reconnect.

    stale_threshold_secs
        Seconds without a WS tick before the feed is declared unhealthy.
        Default 15s is conservative enough to survive brief broker hiccups
        (e.g. sub-second tick gaps) without triggering a false reconnect,
        while still catching real stale conditions quickly.

        DO NOT set below 5s — broker WS libraries often have 2–5s internal
        batching and the watchdog would thrash.

    hard_block_secs
        If feed_age > hard_block_secs, new BUY entries are blocked.
        Set equal to stale_threshold_secs for a tight block, or slightly
        higher (e.g. 30s) to give the reconnect a chance to restore data
        before blocking.  Exits (SEL*) are never blocked.

    reconnect_initial_delay
        First backoff delay in seconds after stale is detected.
        Kept short (2s) so the most common transient glitch reconnects fast.

    reconnect_max_delay
        Back-off ceiling.  60s is sufficient; longer delays cause missed
        signals after prolonged outages.

    reconnect_max_attempts
        Hard circuit-breaker.  After this many attempts without success,
        the watchdog stops retrying and logs CRITICAL.  Operator intervention
        required.  Set high (20) to survive exchange maintenance windows.

    watchdog_interval_secs
        How often the watchdog daemon checks feed age.  5s means stale is
        detected within 5s of the threshold breach.  Lower = faster detection
        but more CPU; 5s is a good balance.

    in_position_stale_action
        "LOG_ONLY"       → warn; do not exit positions on stale data
                           (safest default — option prices are unreliable when
                           underlying feed is stale; forced exits risk bad fills)
        "EMERGENCY_EXIT" → future hook for forced position close
                           (implement in engine.py; not auto-triggered here)

    health_log_interval_secs
        How often to emit the ✅ WS HEALTH log line.  60s matches the
        original bot's logging cadence.
    """
    stale_threshold_secs:     float = 30.0
    hard_block_secs:          float = 45.0
    reconnect_initial_delay:  float = 2.0
    reconnect_max_delay:      float = 60.0
    reconnect_max_attempts:   int   = 20
    watchdog_interval_secs:   float = 5.0
    in_position_stale_action: str   = "LOG_ONLY"   # "LOG_ONLY" | "EMERGENCY_EXIT"
    health_log_interval_secs: int   = 60
    # Startup grace period: suppress stale detection for this many seconds
    # after WS connects.  MCX futures can take 15-25s to start delivering
    # ticks after subscription — without a grace period the watchdog triggers
    # an immediate reconnect loop before any ticks arrive.
    startup_grace_secs:       float = 30.0


# ── Trailing stop ──────────────────────────────────────────────────────────────

@dataclass(frozen=True)
class TrailingConfig:
    enabled:             bool  = True
    # Trailing stop — 3b stop / 3b trail with 1:1 symmetry:
    #
    # breakeven_after = 3.0b — matches initial stop distance exactly.
    #   NIFTY:  3 × 12 = 36pts  → risk 36pts, gain 36pts protection (1:1)
    #   BNF:    3 × 24 = 72pts  (BNF stop is 4b=96pts via override)
    #
    # volatile_breakeven_after = 2.0b — VOLATILE days have tighter ranges.
    #   NIFTY: 2 × 12 = 24pts   BNF: 2 × 24 = 48pts
    #
    # UPGRADE T1-1: trail_start_after 4.0b → 3.0b (same as breakeven).
    #   Old: trail only activated 1b past breakeven.
    #        A 50pt NIFTY move (4.2b) → trail active for 0.2b → barely profitable exit.
    #   New: trail activates at breakeven point itself.
    #        A 50pt NIFTY move (4.2b) → trail active for 1.2b → captures 38pts (76%).
    #   A 40pt NIFTY move (3.3b) → old: no trail, exit at breakeven.
    #                              new: trail active 0.3b → exits at +0.3b = small profit.
    #   Risk: trail is active 1b sooner. On a pullback that immediately follows
    #         breakeven it will exit at breakeven+0.25b (buffer) instead of letting
    #         price recover. Acceptable — we WANT to lock that profit.
    breakeven_after:           float = 2.0   # configured: faster profit protection
    volatile_breakeven_after:  float = 2.0
    trail_start_after:         float = 3.0   # trail activates 1b after breakeven
    trail_distance:            float = 1.0
    # FIX I-03: was True — peak only advanced on brick close, causing "10k on screen
    # / 2k at close" gap. False = peak tracks real-time LTP, stop follows much closer.
    on_brick_confirm:          bool  = False
    breakeven_buffer:          float = 0.25
    adaptive_trail:            bool  = True
    # UPGRADE T1-2/3: adaptive trail tier thresholds raised.
    # Old: tier1=3b (widen to 1.5b trail at +7b from entry), tier2=6b (+10b from entry).
    #      On a 100pt NIFTY (8.3b) move: trail widened at +7b → captured only 72% of move.
    # New: tier1=5b (widen at +8b from entry), tier2=9b (widen at +12b from entry).
    #      Same 100pt move: tight 1b trail holds until +8b → captures 84% of move.
    #      12 extra points per lot = ₹780 NIFTY, ₹360 CRUDEOIL on a good day.
    # The tiers now widen only on genuinely large moves (≥8b from entry),
    # keeping the stop tight for all typical intraday moves (3–7b range).
    adaptive_trail_tier1_bricks: float = 5.0   # UPGRADE T1-2: was 3.0 → 5.0
    adaptive_trail_tier2_bricks: float = 9.0   # UPGRADE T1-3: was 6.0 → 9.0
    adaptive_trail_tier1_add:    float = 0.5   # extra trail distance bricks at tier 1
    adaptive_trail_tier2_add:    float = 1.0   # extra trail distance bricks at tier 2
    verbose_log:               bool  = True
    print_interval_secs:       int   = 30


@dataclass(frozen=True)
class StopConfig:
    use_renko_confirmed:         bool  = True
    use_structural_stop:         bool  = True
    catastrophe_extra_bricks:    float = 1.5
    # Initial stop bricks — recalibrated for actual brick sizes (FIX I-01):
    #   NIFTY:     3b × 12  =  36pts ✅ clears 90th %ile noise (~32pts)
    #   BANKNIFTY: 3b × 40  = 120pts ✅ clears 90th %ile noise (~78pts) — no override needed
    #   SENSEX:    3b × 50  = 150pts ✅ clears 90th %ile noise (~125pts)
    #   BANKEX:    3b × 50  = 150pts ✅ same as SENSEX
    initial_stop_bricks:         float = 3.0
    symbol_overrides:            Dict[str, float] = field(
        default_factory=lambda: {
            # FIX I-01: BANKNIFTY override removed — with brick=40, the default
            # 3b×40=120pts already clears the 78pt noise floor comfortably.
            # Old override was 4b×24=96pts; new default 3b×40=120pts is better.
        }
    )
    # MCX-BUG-2 FIX: Cap structural stop distance for coarse-brick MCX instruments.
    # The structural stop uses swing highs/lows from the Renko chart.  On MCX
    # coarse-brick instruments (GOLDM brick=150, SILVERM brick=500) a swing high
    # can be 5-8 bricks above entry, making the stop 1200-4000pts wide.
    # Today's GOLDM: struct_high=157500 (825pts above fill), stop=157575 (8.6b)
    # → trailing stop breakeven required +450pt move → never triggered in 80min.
    # Fix: cap struct_stop at max_struct_stop_bricks from entry price.
    # NSE/BSE instruments are NOT in the override dict → behaviour unchanged
    # (default cap=99b = effectively unlimited for equity instruments).
    max_struct_stop_bricks:      float = 99.0
    max_struct_stop_bricks_override: Dict[str, float] = field(
        default_factory=lambda: {
            "GOLDM":    4.0,   # 4×150 = 600pts max stop width
            "SILVERM":  4.0,   # 4×500 = 2000pts max stop width
            # FIX-4: CRUDEOIL reduced 4.0→3.5b (was 33% wider than nominal 3b stop)
            # 3.5b × 8 = 28pts max. Structural stop can still use swing high,
            # but capped at 28pts (was 32pts). Initial fixed stop stays at 3b=24pts.
            "CRUDEOIL": 3.5,   # 3.5×8 = 28pts max stop width (was 32pts)
            # NATURALGAS: coarse brick=4, structural can widen to 3.5b=14pts max
            "NATURALGAS": 3.5, # 3.5×4 = 14pts max stop width
            # NSE/BSE FIX: morning crash swing lows must not anchor afternoon
            # stops. Without this cap, struct_low from 09:15 gap-down sits in
            # Renko as Last_Low all day → afternoon CALL gets 10b+ wide stop.
            # With Fix #1 (max for CALL) fixed_stop already wins when struct is
            # wider, but 5b cap adds a hard backstop and correctly limits PUT
            # struct stops (which already used max correctly).
            "NIFTY":     5.0,  # 5×12  = 60pts  max stop width
            "BANKNIFTY": 5.0,  # 5×40  = 200pts max stop width
            "SENSEX":    5.0,  # 5×50  = 250pts max stop width
            "BANKEX":    5.0,  # 5×50  = 250pts max stop width
        }
    )

    # ── Confirmation tighten (smart early loss cut) ──────────────────────────
    # If price has NOT moved confirm_bricks in profit within confirm_mins,
    # tighten stop to tight_bricks. Unconfirmed trades have 0% win rate.
    # Confirmed trades (62% win rate) are NEVER affected.
    #
    # F-04 FIX: confirm_mins 3.0->1.5 min; tight_bricks 2.5->1.5b.
    #   Old dead zone = 3 min; loss per unconfirmed NIFTY trade = 30pts.
    #   New dead zone = 1.5 min; loss per unconfirmed NIFTY trade = 18pts.
    #   BANKNIFTY: 1.5 x 40 = 60pts (was 2.5 x 40 = 100pts).
    # Per-instrument override for slow MCX instruments.
    confirmation_tighten:        bool  = True
    confirm_mins:                float = 1.5   # F-04: was 3.0 -- halves dead zone
    confirm_bricks:              float = 1.5   # raised 0.5→1.5: 9pt spike (0.75b) was disabling both safety nets in 38s
    tight_bricks:                float = 1.5   # F-04: was 2.5 -- NIFTY: 18pts
    # ── Opening session grace period ─────────────────────────────────────────
    # On opening entries (before opening_confirm_cutoff), the market needs
    # more time to establish direction. The normal 1.5min tighten fires before
    # the opening flush resolves, killing correct trades.
    # opening_confirm_mins: grace period for trades entered during opening window.
    # opening_confirm_cutoff: IST time after which normal confirm_mins applies.
    # Logic: effective_confirm = max(opening_confirm_mins, instrument_override)
    #        if entry_ist_time < opening_confirm_cutoff else instrument_override
    # April 8: BNF 09:31 tightened at 1.6min → exit +1.40pts.
    #          With 5.0min grace → confirmed at 09:36 → rode +691pts.
    opening_confirm_mins:    float = 5.0    # grace for opening entries
    opening_confirm_cutoff:  str   = "09:40"  # IST cutoff for opening grace

    # Per-instrument confirm_mins override for slow-brick instruments.
    confirm_mins_override: Dict[str, float] = field(
        default_factory=lambda: {
            'GOLDM':      4.0,   # 150pt brick -- needs more time to confirm
            'SILVERM':    4.0,   # 500pt brick -- needs more time to confirm
            'NATURALGAS': 2.5,   # 4pt brick but slow-moving
        }
    )

    # ── F-06: Fast-fail gate (90-second post-entry momentum check) ──────────
    # If within fast_fail_secs of fill the position has not reached
    # fast_fail_profit_bricks profit AND a brick has moved against entry,
    # tighten the stop to fast_fail_tight_bricks immediately.
    # DEFAULT = False — paper-trade for 10 days before enabling live.
    fast_fail_enabled:       bool  = False  # FEATURE FLAG — default OFF
    fast_fail_secs:          float = 90.0   # window: 0–90s post-fill
    fast_fail_profit_bricks: float = 0.5    # min profit to disable fast-fail
    fast_fail_tight_bricks:  float = 1.0    # tighten to this if triggered

    # ── F-07: Momentum-failure exit ──────────────────────────────────────────
    # If an opposite-direction brick forms within N bricks of entry AND the
    # position has not yet reached profit, fire an immediate exit.
    # This catches "entry brick formed, immediately reversed" — the clearest
    # sign of a false breakout.
    # DEFAULT = False — validate against historical data before enabling.
    momentum_failure_enabled:       bool  = False  # FEATURE FLAG — default OFF
    momentum_failure_window_bricks: int   = 2      # bricks after entry to watch
    momentum_failure_profit_bricks: float = 0.5    # min profit to disable check

    # ── F-08: Breakout retest mode ───────────────────────────────────────────
    # After entry, if LTP returns within retest_proximity_bricks of entry:
    #   - Activate retest mode (start monitoring)
    #   - If LTP recovers above entry + retest_confirm_bricks: trade confirmed
    #   - If LTP falls below entry - retest_fail_bricks: fire failed-retest exit
    # DEFAULT = False — forward-test 20 days minimum before enabling.
    retest_mode_enabled:       bool  = False   # FEATURE FLAG — default OFF
    retest_proximity_bricks:   float = 0.5     # LTP within 0.5b of entry → retest
    retest_fail_bricks:        float = 0.5     # fail if LTP drops entry-0.5b
    retest_confirm_bricks:     float = 0.5     # confirm if LTP recovers entry+0.5b


@dataclass(frozen=True)
class NFTConfig:
    enabled:               bool  = True
    follow_through_bricks: float = 0.75
    option_profit_pct:     float = 5.0
    base_timeout_secs:     int   = 180
    timeout_min:           int   = 180
    timeout_max:           int   = 420
    target_sec_per_brick:  int   = 60
    dynamic_timeout:       bool  = True
    reversal_min:          int   = 4
    net_move_min_bricks:   float = 0.75
    # Profit guard: if position P&L >= this many bricks (measured from actual
    # fill price, not quote snapshot), the NFT checker marks it validated and
    # never exits. Prevents false NFT exits on stale quotes during fast moves.
    profit_guard_bricks:   float = 1.0
    smart_exit:            bool  = True
    # FIX-3: Per-instrument NFT timeout overrides for coarse-brick MCX contracts.
    # GOLDM (brick=150) and SILVERM (brick=500) move much slower than NIFTY (brick=12).
    # The global 420s max is too tight for these instruments — a 0.75b GOLDM move
    # needs ~112pts which can take 15-30 minutes in a normal commodity session.
    # Instruments not in this dict use timeout_min / timeout_max above.
    # Keys must match the instrument root exactly (e.g. "GOLDM", "SILVERM").
    timeout_min_override:  Dict[str, int] = field(default_factory=lambda: {
        "GOLDM":      600,    # 10 min minimum (brick=150, 0.75b=112pts is slow)
        "SILVERM":    600,    # 10 min minimum (brick=500, 0.75b=375pts is very slow)
        "NATURALGAS": 240,    # 4 min minimum (brick=4, relatively fast)
    })
    timeout_max_override:  Dict[str, int] = field(default_factory=lambda: {
        "GOLDM":      1200,   # 20 min maximum
        "SILVERM":    1200,   # 20 min maximum
        "NATURALGAS":  480,   # 8 min maximum
    })


@dataclass(frozen=True)
class ChopGateConfig:
    enabled:            bool  = True
    k_reversals:        int   = 3
    range_bricks:       float = 3.0
    release_bricks:     float = 0.75
    expiry_minutes:     int   = 15


# ── PATCHED: ChopOscillationConfig (Issue D) ───────────────────────────────────

@dataclass(frozen=True)
class ChopOscillationConfig:
    """
    Post-entry oscillation detection with improved multi-condition exit logic.

    --- ORIGINAL FIELDS (unchanged) ---
    enabled
    reversals_max      : oscillation count threshold
    range_bricks       : LTP range that qualifies as oscillation
    window_secs        : rolling window for reversal counting

    --- NEW FIELDS (Issue D fix) ---

    min_hold_secs (default 180s / 3 min)
        THE PRIMARY FIX for 73-second exits.
        Chop exit cannot be evaluated until the trade has been held for at
        least this many seconds.  This prevents the common pattern where
        normal post-entry noise (a 1–2 brick consolidation immediately after
        breakout) is mis-classified as chop.

        Rationale for 180s:
          - Renko brick at 50pts with 5s cycle = ~1 brick per minute minimum
          - We need at least 2–3 bricks to form before any exit judgement
          - 180s = 3 cycles of the OHLC refresh (meaningful Renko context)
          - NFT timeout (nft.base_timeout_secs) is also 180s; aligning these
            prevents gap where NFT exits but chop fires anyway.

    min_hold_bars (default 3)
        Minimum number of NEW Renko bricks since entry before chop exit
        is allowed.  Prevents exits during the first brick's development.
        Complementary to min_hold_secs — BOTH must be satisfied.

    adverse_excursion_bricks (default 0.75)
        Chop exit is ONLY allowed if the position's adverse excursion since
        entry is < this many bricks.  If the market has moved significantly
        against us, we use the stop-loss path instead of chop exit.
        Prevents chop_exit from replacing stop logic.

    require_momentum_decay (default True)
        Require that the brick momentum (Colour_Brick_Count on the last brick)
        is declining before a chop exit fires.  If momentum is still strong
        in our direction, a reversal is probably noise.

    regime_filter_enabled (default True)
        In a TRENDING regime, chop exits are disabled entirely — the position
        is given maximum room.  Only fires in SIDEWAYS or VOLATILE regimes.

    two_stage_required (default True)
        Require 2-stage confirmation: first chop breach → start confirmation
        window → second confirmation within confirmation_window_secs → exit.
        Prevents a single brief oscillation from triggering exit.

    confirmations_required (default 2)
        N-of-M confirmations in the confirmation window.

    confirmation_window_secs (default 30)
        Maximum time to wait for the second confirmation stage.
        If not confirmed in this window, reset the chop state.
    """
    # ── Original fields ──────────────────────────────────────────────────────
    enabled:         bool  = True
    reversals_max:   int   = 3
    range_bricks:    float = 1.0
    window_secs:     int   = 120

    # ── New fields (Issue D) ─────────────────────────────────────────────────
    min_hold_secs:           int   = 180     # NEW: minimum hold before any chop exit
    min_hold_bars:           int   = 3       # NEW: minimum new bricks since entry
    adverse_excursion_bricks: float = 0.75  # global default (per-symbol override below)
    # FIX-1: Per-symbol override for adverse_excursion_bricks.
    # NIFTY noise floor is ~12–15pts; 0.75b×12=9pts fires on every tick.
    # Raise NIFTY to 1.25b×12=15pts so chop gate only blocks when truly outside noise.
    adverse_excursion_bricks_override: Dict[str, float] = field(
        default_factory=lambda: {
            "NIFTY": 1.25,   # 1.25b × 12 = 15pts  — clears 1-min NIFTY noise
        }
    )
    require_momentum_decay:  bool  = True    # NEW: require decaying momentum
    regime_filter_enabled:   bool  = True    # NEW: disable in trending regimes
    two_stage_required:      bool  = True    # NEW: require 2-stage confirmation
    confirmations_required:  int   = 2       # NEW: N confirmations for 2nd stage
    confirmation_window_secs: int  = 30      # NEW: 2nd-stage window


# ── PATCHED: WhipsawConfig (Issue C) ──────────────────────────────────────────

@dataclass(frozen=True)
class WhipsawConfig:
    """
    Adaptive whipsaw cooldown.

    --- ORIGINAL FIELDS (unchanged) ---
    enabled
    max_flips
    flip_window_mins
    cooldown_mins          : legacy flat cooldown (used only if adaptive_enabled=False)
    momentum_clear_bricks

    --- NEW FIELDS (Issue C fix) ---

    adaptive_enabled (default True)
        Master switch for adaptive cooldown.  When False, flat cooldown_mins
        is used (legacy behaviour).

    base_cooldown_secs (default 120s / 2 min)
        Minimum cooldown even after the most benign exit.
        Prevents pure revenge re-entries with zero wait.

    false_chop_cooldown_secs (default 90s)
        Short cooldown when the exit reason was a false chop (position exited
        by chop oscillation but market immediately continued in signal direction).
        Detected when: exit reason = CHOP_OSCILLATION_EXIT AND next signal is
        same direction as the closed trade.
        Rationale: false chop = the market was right, we bailed too soon.
        A 90s pause is enough to let the exit price distance from re-entry price.

    whipsaw_cooldown_secs (default 600s / 10 min)
        Cooldown after a genuine first whipsaw (stop hit within flip_window_mins
        after entry, then signal reverses again).

    repeat_whipsaw_cooldown_secs (default 1800s / 30 min)
        Cooldown after two or more whipsaws within the session.
        Indicates choppy market; needs significantly more time before re-entry.

    trending_multiplier (default 0.5)
        In a TRENDING regime, halve the cooldown — trending markets have
        fewer false signals; re-entry should be faster.

    volatile_multiplier (default 2.0)
        In a VOLATILE regime, double the cooldown — volatile markets punish
        rapid re-entries harshly.

    sideways_multiplier (default 1.5)
        In a SIDEWAYS regime, 1.5× cooldown — sideways = dangerous for
        breakout entries.

    max_cooldown_secs (default 2700s / 45 min)
        Absolute ceiling regardless of multipliers and repeat count.

    revenge_guard_secs (default 60s)
        Hard minimum: even with all multipliers at 0, never re-enter faster
        than this.  Prevents same-second revenge trades from API race conditions.

    recent_flip_lookback_secs (default 1800s / 30 min)
        Window for counting recent flips.  If more than max_flips occurred in
        this window, use the longer whipsaw cooldown.
    """
    # ── Original fields ──────────────────────────────────────────────────────
    enabled:               bool = True
    max_flips:             int  = 2
    flip_window_mins:      int  = 30
    cooldown_mins:         int  = 45          # legacy fallback when adaptive=False
    momentum_clear_bricks: int  = 8
    # Seconds after a SIGNAL_EXIT during which the OPPOSITE direction is
    # blocked. Prevents noise bounces after a confirmed signal reversal.
    # UPGRADE T2-4: Now grade-differentiated.
    #   Grade-B (score 3-4): 120s block — standard protection for weaker signals.
    #   Grade-A (score ≥5):  30s block  — strong reversal confirmation can
    #     override sooner. On a fast BANKNIFTY reversal day, 120s = 80-120pts missed.
    #     Grade-A signals have ZLEMA + confirmed swing structure + momentum all
    #     aligned — the reversal is genuine, not a bounce.
    signal_exit_block_secs:        int  = 120   # Grade-B and default
    signal_exit_block_secs_grade_a: int = 30    # UPGRADE T2-4: Grade-A override

    # ── New fields (Issue C) ─────────────────────────────────────────────────
    adaptive_enabled:              bool  = True
    base_cooldown_secs:            int   = 120    # 2 min minimum always
    false_chop_cooldown_secs:      int   = 90     # very short after false chop
    whipsaw_cooldown_secs:         int   = 600    # 10 min after first whipsaw
    repeat_whipsaw_cooldown_secs:  int   = 1800   # 30 min after repeat whipsaw
    trending_multiplier:           float = 0.5    # halve in trending regime
    volatile_multiplier:           float = 2.0    # double in volatile regime
    sideways_multiplier:           float = 1.5    # 1.5× in sideways regime
    max_cooldown_secs:             int   = 2700   # 45 min absolute maximum
    revenge_guard_secs:            int   = 60     # hard minimum always
    recent_flip_lookback_secs:     int   = 1800   # 30 min for flip counting

    # FIX NEW — afternoon giveback prevention:
    # After a profitable STOP_EXIT (trailing stop triggered with positive P&L),
    # block the OPPOSITE direction for this many seconds.
    # Example: CALL exits via trail at +150pts → PUT blocked for 15 min.
    # Prevents immediate reversal trades that give back morning profits.
    # Set 0 to disable. Recommended: 900 (15 min) on trending days.
    # UPGRADE T1-4: Reduced from 900s → 600s (15min → 10min).
    # After a profitable trailing-stop exit, opposite direction is blocked
    # to prevent the classic "give back morning profits" whipsaw pattern.
    # 15 minutes was too conservative — on genuine V-reversals it blocked
    # the entire initial move of the new direction.
    # 10 minutes still protects against lunch-time whipsaws while releasing
    # 5 minutes earlier on strong continuation/reversal setups.
    no_reversal_after_profit_exit_secs: int = 600   # was 900


@dataclass(frozen=True)
class RiskEngineConfig:
    """
    FIX I-11: Previously missing from BotConfig — RiskEngine.__init__() read
    cfg.risk_engine but BotConfig had no such field → self._cfg was always None
    → daily-max-loss, consecutive-loss, AND daily-target were all dead code.

    All three circuit breakers are now live.
    """
    # Halt all trading if session P&L drops below this (rupees, as a loss).
    # e.g. 50000 means stop if down more than ₹50,000 on the day.
    max_daily_loss_rs:       float = 50000.0
    # Halt after N consecutive losing trades (counted by record_close).
    # S-4 FIX: 5→3. After 3 consecutive losses market is clearly not trending.
    max_consecutive_losses:  int   = 8   # configured: more runway in multi-instrument sessions
    # F-11 FIX: Softer daily profit target lock.
    # Once session P&L crosses daily_target_rs AND the current time is after
    # target_lock_after_time (default 13:30), block all new entries.
    # Rationale: morning trends (09:30-13:30) are legitimate and should not
    # be blocked. The giveback risk is highest in the final 2 hours.
    # Set daily_target_rs=0.0 to disable entirely.
    # Set target_lock_after_time="" to lock immediately (old behaviour).
    daily_target_rs:         float = 15000.0
    # F-11: Only engage target lock after this IST time (HH:MM).
    # Empty string = lock immediately when target hit (original behaviour).
    target_lock_after_time:  str   = "13:30"


@dataclass(frozen=True)
class EntryConfig:
    mode:                        str   = "BREAKOUT"
    offset_bricks:               float = 0.5
    pullback_bricks:             float = 0.0
    confirmation_buffer_bricks:  float = 0.25
    slippage_bricks:             float = 0.5
    cancel_bricks:               float = 2.0
    stale_entry_bricks:          float = 3.0
    reversal_extra_confirm_bricks: float = 1.0
    reversal_entry_confirmation:  bool  = True
    max_drift_bricks:             float = 1.5
    # FIX I-02: was 1.5 — with threshold at 1.5b, SENSEX (1.26b drift today) used
    # signal price as anchor → trail needed signal+4b=77025 but peak=76980 → trail
    # NEVER fired → exited at +5pts instead of +143pts. 0.5b ensures exec price is
    # used as anchor for all normal execution drifts (typical drift is 0.3-1.5b).
    drift_stop_override_bricks:   float = 0.5
    # Grade-A signals get a wider drift window because a large drift on a
    # Grade-A signal means confirmed momentum, not chasing.  Set to the same
    # value as max_drift_bricks to disable the distinction.
    grade_a_max_drift_bricks:     float = 3.0
    # MCX-BUG-3 FIX: Per-symbol drift tolerance override.
    # CRUDEOIL brick=8 → Grade-B limit 1.5b=12pts.  In a MCX momentum
    # session the engine's 5-second cycle means price moves 13-16pts between
    # signal and execution, cancelling every Grade-B CRUDEOIL entry.
    # Grade-A entries use grade_a_max_drift_bricks (3.0b=24pts) and are fine.
    # Raise CRUDEOIL Grade-B limit to 2.5b=20pts to survive the 5s cycle gap.
    # NSE/BSE instruments are NOT in this dict — their 1.5b default is unchanged.
    max_drift_bricks_override: Dict[str, float] = field(
        default_factory=lambda: {
            "CRUDEOIL":  2.5,   # 2.5×8 = 20pts — covers 5s MCX cycle lag
            "NATURALGAS": 2.5,  # 2.5×4 = 10pts — thin market, same logic
        }
    )
    # Require the Close Renko to have generated a matching BUYRE/SELRE signal
    # within the last N bricks before an HL signal is allowed to fire.
    # HL-only signals (no close backing) are wick traps or pure continuations
    # with no actual reversal confirmation from close prices.
    # Set require_close_confirmation=False to disable entirely.
    require_close_confirmation:   bool  = True
    # MCX-BUG-1 FIX: Exchanges exempt from require_close_confirmation.
    # MCX Close Renko with coarse bricks (GOLDM=150, SILVERM=500, CRUDEOIL=8)
    # reverses direction very infrequently — in 80 minutes of live session
    # 470 valid HL Renko signals were suppressed because no Close_Signal
    # appeared within 10 bricks.  The HL Renko correctly detects reversals
    # on wicks; the close confirmation gate was designed for NSE index wick
    # traps and is actively harmful on MCX.
    # NSE/BSE instruments are NOT in this tuple — their gate is unchanged.
    require_close_confirmation_exempt_exchanges: tuple = ("MCX",)
    # F-02 FIX: Tightened from 10 → 3 bricks.
    # At NIFTY brick speed (~1 brick per 6-8 min), 10 bricks = up to 80 min lookback.
    # A Close_Signal from 80 min ago does NOT confirm today's HL signal — this made
    # the close-confirmation gate nearly meaningless for wick-based HL signals.
    # 3 bricks = ~15-25 min for NIFTY, which is genuinely contemporaneous.
    # Per-instrument override via close_signal_window_override for slow instruments.
    close_signal_window_bricks:   int   = 3
    # Per-instrument override — raise for slow MCX instruments if signal count
    # drops excessively: e.g. {"GOLDM": 5, "SILVERM": 5}
    close_signal_window_override: Dict[str, int] = field(default_factory=dict)
    # MIN-ENTRY-BRICKS: Minimum consecutive same-direction bricks required
    # BEFORE an entry row is created.
    #
    # WHY: When BUYEN/SELEX fires, Colour_Brick_Count is always exactly 2
    # (the 2-brick reversal is what triggers the signal).  Most false reversals
    # — price bouncing 2 bricks then immediately snapping back — never form a
    # 3rd brick.  Waiting for the 3rd brick eliminates these noise entries with
    # no change to the signal engine itself.  Genuine momentum moves form the
    # 3rd brick quickly; the cost is 1 brick-width of later entry.
    #
    # Set to 2 to restore original behaviour (enter on signal = 2 bricks).
    # Set to 3 to require confirmed momentum (default — blocks most false entries).
    # Per-instrument override via min_entry_bricks_override dict below.
    #
    # Side effects:
    #   - Fewer trades overall (good: fewer small losses)
    #   - Slightly later entries (1 brick: 8pts CRUDEOIL, 150pts GOLDM)
    #   - NFT and stop still protect on all entries
    #   - Dedup key unchanged — 3rd brick re-evaluates because CBC changed
    min_entry_bricks:             int   = 3
    # Per-instrument override. NSE/BSE instruments may stay at 2 (faster market,
    # close-confirmation gate already provides the extra filter MCX lacks).
    # MCX instruments default to the global min_entry_bricks (3) above.
    min_entry_bricks_override: Dict[str, int] = field(
        default_factory=lambda: {
            # Phase 2: NIFTY stays at 3 (12pt bricks, chop risk).
            # BANKNIFTY=2 and SENSEX=2: 40pt/50pt bricks, 80-100pt confirmation
            # is meaningful, RR gate handles geometry filtering.
            # FINNIFTY/MIDCPNIFTY stay at 3 (smaller instruments, more noise).
            "NIFTY":      3,   # 3 × 12 = 36pts confirmation (unchanged)
            "BANKNIFTY":  2,   # 2 × 40 = 80pts confirmation (Phase 2: reduced)
            "SENSEX":     2,   # 2 × 50 = 100pts confirmation (Phase 2: reduced)
            "BANKEX":     2,   # BSE version of BANKNIFTY
            "FINNIFTY":   3,   # smaller contract, keep at 3
            "MIDCPNIFTY": 3,   # smaller contract, keep at 3
            # MCX — no close-gate, coarse bricks; require 3 bricks (global default)
            # CRUDEOIL, GOLDM, SILVERM, NATURALGAS → use min_entry_bricks = 3
        }
    )
    # F-09 FEATURE FLAG: when True, overrides all NSE/BSE entries in
    # min_entry_bricks_override to require 3 bricks (same as MCX).
    # DEFAULT = False — backtest win-rate impact before enabling.
    # To enable: set min_entry_bricks_nse_upgraded = True in BotConfig
    # instantiation after confirming CBC=2 NSE entries have <40% win rate.
    min_entry_bricks_nse_upgraded: bool = False  # Phase 2: per-instrument override controls CBC   # require 3 bricks on NSE/BSE (was 2)
    # F-03 FIX: LTP-deviation zombie check.
    # If current LTP is more than N bricks away from the signal price at evaluation
    # time, block the entry — the fill would place a stop far outside the intended
    # risk range (e.g. signal at 25000 but LTP is now 25144 = 12 bricks away on
    # NIFTY; the actual fill + stop distance = 180pts, not 36pts).
    # Set to 0.0 to disable.
    zombie_ltp_deviation_bricks: float = 2.0
    # CLOSE_SIGNAL_ZLEMA_GATE: Apply ZLEMA check to Close_Signal fallback path.
    # The HL signal path is ZLEMA-gated in renko_engine.py. Without this flag,
    # the Close_Signal fallback fires without any ZLEMA check — counter-trend
    # entries are possible whenever the HL signal is blocked by close-gate.
    # Default True — set False only for instruments where Close_Signal fires
    # legitimately during apparent counter-trend (e.g. mean-reversion strategies).
    close_signal_zlema_gate: bool = True


@dataclass(frozen=True)
class DayRegimeConfig:
    classify_at:          str   = "09:30"
    range_trending_ratio: float = 1.2
    # FIX I-09: Comment corrected. When sideways_hard_block=True (default),
    # ALL entries are blocked — both BUY_CALL and BUY_PUT. The previous comment
    # said "reversal entries preserved" which was wrong. Set False only if you
    # want half-size reversal plays at S/R levels on range-bound days.
    # S-3: Changed True → False. With sideways_hard_block=True the bot
    # sits completely idle on range-bound days (40-50% of NSE sessions).
    # Range days offer reversal entries at S/R boundaries:
    #   SELEX at range top + BUYEN at range bottom = consistent 2-3b gains.
    # With False: SIDEWAYS regime → half-size via directional gate penalty.
    # Grade-A only (CONF_GATE requires Grade-A when confidence is low).
    # Directional gate hard-blocks counter-trend in TRENDING — not SIDEWAYS.
    sideways_hard_block:  bool  = False
    range_sideways_ratio: float = 0.5
    vix_volatile_threshold: float = 20.0
    vix_low_threshold:      float = 13.0
    vix_ideal_max:          float = 16.0
    confidence_threshold:   float = 0.55
    chop_half_threshold:    float = 0.40
    reclassify_interval_min: int   = 45
    vix_trend_override_ratio: float = 3.5


@dataclass(frozen=True)
class SignalQualityConfig:
    min_grade:              str   = "B"
    min_consecutive_bricks: int   = 3
    min_room_bricks:        float = 1.5
    zlema_weight:           int   = 2
    brick_momentum_weight:  int   = 3
    swing_structure_weight: int   = 2
    # Directional efficiency — BONUS ONLY (no negative penalty).
    # Measures how efficiently price is moving over the last N bricks:
    #   efficiency = |net_displacement| / total_path  (range 0.0 – 1.0)
    # When efficiency >= threshold: +1 bonus score (confirms clean trend).
    # Below threshold: 0 (neutral) — no penalty.
    #
    # The -2 penalty approach was removed after real NIFTY/BANKNIFTY data
    # showed it blocked +728–+1817pt moves on breakout days. Breakout entries
    # always have low prior-lookback efficiency (consolidation before the move).
    # Direction is already confirmed by ZLEMA + 2-brick CBC at signal time.
    # Set efficiency_lookback=0 to disable entirely.
    efficiency_lookback:    int   = 20   # bricks to look back
    efficiency_threshold:   float = 0.60 # above this → +1 bonus
    # Hard floor on the combined size multiplier from all pipeline layers.
    # If regime × quality × direction = 0.25, the position is too small
    # to be meaningful — block it outright rather than placing a micro-lot.
    min_combined_size:      float = 0.40 # below this → hard block
    # F-05 FIX: Per-exchange override for min_combined_size.
    # MCX instruments always run UNKNOWN regime (equity VIX irrelevant to
    # commodities), which applies 0.5x size multiplier. Grade-B quality
    # adds another 0.5x → combined = 0.25, below the 0.40 global floor.
    # This blocked ALL Grade-B MCX signals permanently. MCX override = 0.25
    # allows Grade-B entries on commodities while the global 0.40 floor
    # protects NSE/BSE instruments from micro-lot entries.
    min_combined_size_override: Dict[str, float] = field(
        default_factory=lambda: {
            "MCX":     0.25,   # Grade-B + UNKNOWN = 0.25; allow it
            "MCX_FUT": 0.25,
            "MCX_OPT": 0.25,
        }
    )
    # When regime confidence is below this threshold, require a stronger signal.
    # Default: conf < 40% → only Grade A entries allowed (Grade B blocked).
    # Set low_conf_min_grade="B" to disable this tightening entirely.
    # NOTE: the check is strictly less-than — conf=40% with threshold=0.40
    # does NOT trigger the gate (40% is not < 40%).
    low_conf_threshold:     float = 0.40
    low_conf_min_grade:     str   = "A"
    # MCX-BUG-1 FIX: exchanges that structurally have no VIX/equity regime data
    # (e.g. MCX) always run with confidence=0.0 — not because the signal is weak
    # but because equity regime classification is intentionally skipped for them.
    # Penalising MCX signals for low confidence incorrectly blocks GOLDM, SILVERM,
    # and NATURALGAS at Grade B/C even on clean momentum moves.
    # List any exchange here to exempt it from the CONF_GATE entirely.
    low_conf_exempt_exchanges: tuple = ("MCX",)

    # ── RR Gate: Reward/Risk geometry check before entry ─────────────────────
    # Blocks entry when the nearest structural obstacle (swing high for CALL,
    # swing low for PUT) is less than rr_min_room_bricks away from entry.
    # Feature flag OFF by default — enable only after paper-trading validation.
    # rr_min_swing_points: gate transparent until this many swings exist in
    # Renko. Early session (<30min) has few swings → safe fallback to allow().
    rr_gate_enabled:      bool  = True   # Phase 2: enabled after paper-trade validation
    rr_min_room_bricks:   float = 2.5    # Layer 3: raised from 1.5 — filters marginal geometry (SENSEX 2.0b was losing)
    rr_min_swing_points:  int   = 5      # need 5+ swing points to activate


@dataclass(frozen=True)
class OptionQualityConfig:
    trade_on_expiry: bool = True
    dow_size_map:   Dict[int, float] = field(default_factory=lambda: {
        0: 1.0, 1: 1.0, 2: 0.5, 3: 0.0, 4: 0.5,
    })
    # BUG FIX v7m: minimum days-to-expiry for option selection.
    # Resolver previously picked nearest future expiry with no floor.
    # April 8: SENSEX Apr 9 (1 DTE) selected → extreme theta ate winners.
    # +74pt index win → only ₹130 real (should have been ~₹700).
    # With min_dte=5: Apr 9 skipped, Apr 16 (8 DTE) selected.
    # Fallback to nearest if no expiry meets the floor (never leave unresolved).
    min_dte_days:   int  = 5


@dataclass(frozen=True)
class MarketHoursConfig:
    nse_open:  str = "09:15"
    nse_close: str = "15:30"
    mcx_open:  str = "09:00"
    mcx_close: str = "23:30"
    # S-5: Reduced from 15:00 → 14:30. NSE options carry heavy gamma risk
    # in the last 30 minutes of the session. A 3b NIFTY stop = 36pts which
    # captures a normal session move, but with 15-min to close the same
    # 36pt adverse move can wipe 60-80% of option premium instantly.
    # Non-expiry days are also safer — afternoon moves tend to reverse at close.
    no_new_entries_nse:   str   = "15:00"   # Phase 2: RR gate replaces fixed time gate
    no_new_entries_mcx: str = "23:00"
    # EOD squareoff: exit ALL open NSE/BSE positions at this time (market order).
    # MCX instruments are NOT affected — they trade until 23:30.
    # Engine then stops completely at nse_close (15:30).
    eod_squareoff_time: str = "15:25"
    opening_filter_end_nse: str = "09:35"   # Phase 4: extended from 09:30 — avoids 5-min opening flush
    opening_filter_end_mcx: str = "09:10"
    # UPGRADE T2-5: Time-of-day low-activity windows.
    # During these windows trades are allowed but sized at half (0.5×).
    # This does NOT block signals — it applies a size penalty similar to
    # the VOLATILE regime multiplier. Circuit breakers still protect fully.
    #
    # NSE: 12:00–13:30 = lunch zone (low volume, high noise, false signals)
    # MCX: 11:30–15:00 = thin domestic afternoon before European overlap
    #
    # Format: list of (start_HH_MM, end_HH_MM, exchange_prefix) tuples.
    # exchange_prefix: "NSE"/"BSE" = equity, "MCX" = commodity, "" = all.
    # Size multiplier during these windows: low_activity_size_multiplier below.
    low_activity_windows: tuple = (
        ("12:00", "13:30", "NSE"),   # NSE/BSE lunch chop
        ("12:00", "13:30", "BSE"),
        ("11:30", "15:00", "MCX"),   # MCX thin domestic session
    )
    low_activity_size_multiplier: float = 0.5  # half size in dead zones


@dataclass(frozen=True)
class BrokerConfig:
    ltp_stale_threshold_secs: float = 10.0
    ltp_hard_block_secs:      float = 30.0
    min_process_interval_secs: float = 2.0
    orders_in_flight_ttl_secs: int  = 120
    position_reconcile_interval_secs: int = 60
    watchdog_stale_secs:       int  = 30
    signal_max_age_minutes:    int  = 10


@dataclass(frozen=True)
class PersistenceConfig:
    db_url:          str = "sqlite:///db/tradebook.db"
    tm_persist_interval_secs: int = 5
    symbols_file:    str = "ohlcdata/symbols_to_trade.csv"
    trade_manager_file: str = "ohlcdata/trade_manager.csv"


@dataclass
class BotConfig:
    """
    Master configuration container.
    All subsystem configs in one place.
    """
    websocket:      WebSocketConfig      = field(default_factory=WebSocketConfig)
    trailing:       TrailingConfig       = field(default_factory=TrailingConfig)
    stop:           StopConfig           = field(default_factory=StopConfig)
    nft:            NFTConfig            = field(default_factory=NFTConfig)
    chop_gate:      ChopGateConfig       = field(default_factory=ChopGateConfig)
    chop_oscillation: ChopOscillationConfig = field(default_factory=ChopOscillationConfig)
    whipsaw:        WhipsawConfig        = field(default_factory=WhipsawConfig)
    entry:          EntryConfig          = field(default_factory=EntryConfig)
    day_regime:     DayRegimeConfig      = field(default_factory=DayRegimeConfig)
    signal_quality: SignalQualityConfig  = field(default_factory=SignalQualityConfig)
    option_quality: OptionQualityConfig  = field(default_factory=OptionQualityConfig)
    market_hours:   MarketHoursConfig    = field(default_factory=MarketHoursConfig)
    broker:         BrokerConfig         = field(default_factory=BrokerConfig)
    persistence:    PersistenceConfig    = field(default_factory=PersistenceConfig)
    # FIX I-11: Added — was missing, making all RiskEngine circuit breakers dead code.
    risk_engine:    RiskEngineConfig     = field(default_factory=RiskEngineConfig)


# Module-level singleton — import this everywhere
cfg = BotConfig()
