"""
Signal Generator — signal_generator.py
=======================================
PR-1 changes
------------
BUG-8 FIXED : SignalDeduplicator.is_duplicate() + record() were two separate
               lock acquisitions — a TOCTOU race allowed two concurrent cycles
               to both pass the duplicate check before either recorded, producing
               two entry rows for the same signal.

               Fixed with atomic check_and_record() that holds the lock for
               the entire check + conditional update as one transaction.
"""

from __future__ import annotations

import logging
import re
import threading
import time
from collections import defaultdict
from datetime import datetime
from typing import Optional, Tuple

import pandas as pd

from tcos_bot.config.settings import cfg, IST
from tcos_bot.data.ltp_store import ltp_store
from tcos_bot.filters.pipeline import FilterPipeline
from tcos_bot.models.types import SignalGrade
from tcos_bot.monitoring.logger import TradeLogger
from tcos_bot.risk.risk_manager import (
    WhipsawCooldownTracker,
    whipsaw_tracker,
)

log = logging.getLogger(__name__)

# Module-level WebSocketManager reference — set by ws_manager at startup.
# _create_entry() reads this to gate entries on feed health.
# None = no WS manager available (e.g. test env) → gate is transparent.
_ws_manager_instance = None

_SIG_MAX_AGE_MINUTES = cfg.broker.signal_max_age_minutes


def _now() -> datetime:
    return datetime.now(tz=IST)


# ── Atomic Signal Deduplicator (BUG-8 FIX) ───────────────────────────────────

class SignalDeduplicator:
    """
    Remembers the last (timestamp, signal, price) per symbol.
    Prevents the same Renko row from generating duplicate trade rows.

    BUG-8 FIX
    ----------
    The old implementation had two separate lock acquisitions:
        is_duplicate()  → acquire lock, read, release
        record()        → acquire lock, write, release

    A TOCTOU window existed between the two calls where a second concurrent
    call could also pass is_duplicate() before either wrote to _seen.

    The fix: a SINGLE atomic check_and_record() that holds the lock for
    the entire "read → conditionally write" operation.  If the key is new,
    it is immediately recorded so no second caller can slip through.

    Usage
    -----
    recorded = dedup.check_and_record(symbol, ts, signal, price, has_active_pos)
    if recorded:
        # we are the one responsible for this signal — create entry row
    else:
        # duplicate — skip
    """

    def __init__(self) -> None:
        self._seen: dict[str, tuple] = {}
        self._lock = threading.Lock()

    def check_and_record(
        self,
        symbol:              str,
        timestamp:           str,
        signal:              str,
        price:               float,
        has_active_position: bool,
    ) -> bool:
        """
        Atomically check whether this (ts, signal, price) is new for *symbol*
        and, if so, record it.

        Returns
        -------
        True  → signal is NEW — caller should proceed with entry creation
        False → signal is a DUPLICATE — caller must skip
        """
        # C-15 FIX: use f"{price:.2f}" so that floating-point arithmetic
        # differences (e.g. 22350.4500000001 vs 22350.45) always produce the
        # same key and are correctly deduplicated.
        key = (str(timestamp), signal, f"{price:.2f}")
        with self._lock:
            last = self._seen.get(symbol)
            if last == key and not has_active_position:
                return False        # duplicate
            # Record immediately inside the lock — no window for a second caller
            self._seen[symbol] = key
            return True             # new, recorded atomically

    # ── Backward-compat shim (kept so existing call-sites compile) ────────────

    def is_duplicate(
        self,
        symbol:              str,
        timestamp:           str,
        signal:              str,
        price:               float,
        has_active_position: bool,
    ) -> bool:
        """
        DEPRECATED: use check_and_record() instead.
        This shim returns True if the signal was already seen BUT does NOT
        record — callers must call record() separately, restoring the TOCTOU.
        Left here only so old unit tests that test the old API still compile.
        Do NOT call this from production code.
        """
        key = (str(timestamp), signal, f"{price:.2f}")   # C-15 FIX: rounded
        with self._lock:
            return self._seen.get(symbol) == key and not has_active_position

    def record(self, symbol: str, timestamp: str, signal: str, price: float) -> None:
        """DEPRECATED: use check_and_record()."""
        key = (str(timestamp), signal, f"{price:.2f}")   # C-15 FIX: rounded
        with self._lock:
            self._seen[symbol] = key


# ── Signal Generator ───────────────────────────────────────────────────────────

class SignalGenerator:
    """
    Core signal processing loop called every cycle from the main engine.
    process() is the single entry point.
    """

    def __init__(self) -> None:
        self._dedup    = SignalDeduplicator()
        self._pipeline = FilterPipeline()
        self._cfg      = cfg
        # Tracks (symbol, signal) pairs already warned as zombie so the
        # "💀 ZOMBIE" line appears only ONCE per stale signal, not every cycle.
        self._zombie_logged: set[tuple[str, str]] = set()

    @property
    def pipeline(self) -> FilterPipeline:
        return self._pipeline

    def process(
        self,
        trade_manager:     pd.DataFrame,
        symbol:            str,
        exchange:          str,
        renko_df:          pd.DataFrame,
        ohlc_df:           Optional[pd.DataFrame],
        brick_size:        float,
        root_positions:    dict,
    ) -> Tuple[pd.DataFrame, bool]:
        changed = False

        timestamp, renko_signal, entry_price = self._extract_signal(
            renko_df, symbol, brick_size, exchange=exchange
        )
        if renko_signal is None or entry_price is None:
            return trade_manager, False

        if renko_signal in ("SELST", "BUYST"):
            return trade_manager, False

        # F-03: pass entry_price + brick_size so _is_zombie can check LTP deviation
        if self._is_zombie(
            timestamp, renko_signal, symbol, root_positions,
            signal_price=entry_price,
            brick_size=brick_size,
        ):
            return trade_manager, False

        # ── Momentum auto-clear (Fix 3) ───────────────────────────────────
        # If the market is printing a long run of consecutive bricks in one
        # direction, whipsaw conditions no longer apply — lift the cooldown
        # for that direction before we do anything else.
        if not renko_df.empty and "Colour_Brick_Count" in renko_df.columns:
            last_brick = renko_df.iloc[-1]
            consec     = int(last_brick.get("Colour_Brick_Count") or 0)
            # direction column: 1 = up (CALL), -1 = down (PUT)
            brick_dir  = int(last_brick.get("direction") or 0)
            if brick_dir == 1:
                whipsaw_tracker.on_brick_formed(symbol, "CALL", consec)
            elif brick_dir == -1:
                whipsaw_tracker.on_brick_formed(symbol, "PUT", consec)
        # ─────────────────────────────────────────────────────────────────

        # ── Min-entry-bricks gate ─────────────────────────────────────────────
        # BUYEN/SELEX fires at CBC=2 (the 2-brick reversal minimum).
        # Most false reversals snap back before forming a 3rd brick.
        # Checking BEFORE check_and_record is critical:
        #   - If we blocked AFTER dedup records, the CBC=3 re-entry would be
        #     seen as a duplicate (same ts/signal/price key) and also blocked.
        #   - By blocking here BEFORE dedup, the signal key is never recorded
        #     at CBC=2, so it is seen fresh at CBC=3 on the next cycle.
        # Per-instrument override: NSE/BSE = 2 (close-gate covers them),
        #                          MCX     = 3 (global default, no close-gate).
        # F-09: if min_entry_bricks_nse_upgraded=True, NSE/BSE also require 3.
        if renko_df is not None and not renko_df.empty and renko_signal in ("BUYEN", "SELEX"):
            import re as _re
            _root_sym = (
                _re.match(r"^([A-Z]+)", symbol.upper()) or
                _re.match(r"^([A-Z]+)", "X")
            ).group(1)
            _min_override = getattr(self._cfg.entry, "min_entry_bricks_override", {})
            _min_bricks   = _min_override.get(_root_sym, self._cfg.entry.min_entry_bricks)
            # F-09: upgrade NSE/BSE to 3 bricks if feature flag is enabled
            _nse_roots    = {"NIFTY", "BANKNIFTY", "SENSEX", "BANKEX", "FINNIFTY", "MIDCPNIFTY"}
            _nse_upgraded = getattr(self._cfg.entry, "min_entry_bricks_nse_upgraded", False)
            if _nse_upgraded and _root_sym in _nse_roots:
                _min_bricks = max(_min_bricks, 3)
            _cbc = int(renko_df.iloc[-1].get("Colour_Brick_Count", 0) or 0)
            if _cbc < _min_bricks:
                log.debug(
                    "⏳ MIN_ENTRY_BRICKS %s %s: CBC=%d < min=%d — "
                    "waiting for brick %d before dedup or entry",
                    renko_signal, symbol, _cbc, _min_bricks, _min_bricks,
                )
                return trade_manager, False
        # ─────────────────────────────────────────────────────────────────────

        call_qty = root_positions.get("CALL", 0)
        put_qty  = root_positions.get("PUT", 0)

        # ── Trade-manager position guard ──────────────────────────────────────
        # The broker positionbook can lag up to 60s after a fill, during which
        # root_positions shows qty=0 even though we already hold a position.
        # If a new Renko brick forms during this window, call_qty/put_qty would
        # be 0 and process() would place a SECOND entry for the same symbol.
        #
        # Fix: also check trade_manager INPOSITION rows as a secondary source.
        # If TM shows an open position for this symbol+direction, treat it as
        # if root_positions had qty>0 — regardless of what the broker says.
        tm_call = ((trade_manager["symbol"] == symbol) &
                   (trade_manager["renko_signal"] == "BUYCL") &
                   (trade_manager["order_status"] == "INPOSITION")).any()
        tm_put  = ((trade_manager["symbol"] == symbol) &
                   (trade_manager["renko_signal"] == "BUYPT") &
                   (trade_manager["order_status"] == "INPOSITION")).any()
        if tm_call:
            call_qty = max(call_qty, 1)
        if tm_put:
            put_qty = max(put_qty, 1)

        if renko_signal == "BUYEN":
            trade_manager = self._cancel_pending(
                trade_manager, symbol, exchange, "BUYPT", "SELSP"
            )

            if put_qty > 0:
                trade_manager, ok = self._create_exit(
                    trade_manager, symbol, exchange, "SELPT",
                    entry_price, timestamp, root_positions, renko_df
                )
                if ok:
                    changed = True
                elif call_qty == 0:
                    return trade_manager, changed

            if call_qty == 0 and put_qty == 0:
                has_pos = False
                # BUG-8 FIX: atomic check-and-record — no TOCTOU window
                recorded = self._dedup.check_and_record(
                    symbol, timestamp, renko_signal, entry_price, has_pos
                )
                if recorded:
                    # BUG-B FIX: _create_entry is called FIRST; record_flip is called
                    # only if the entry was actually accepted (added=True).
                    # The old code referenced `result` before it existed in this scope,
                    # causing NameError on every BUYEN/SELEX signal.
                    # Regime string is read from the pipeline AFTER evaluate() returns
                    # inside _create_entry — we surface it via _last_regime_str.
                    trade_manager, added = self._create_entry(
                        trade_manager, symbol, exchange, "BUYCL",
                        entry_price, timestamp, renko_df, ohlc_df, brick_size,
                    )
                    if added:
                        changed = True
                        # FIX I-07: record_flip REMOVED from entry path.
                        # Was called here AND in engine._fire_close_hooks → double-counting.
                        # Double count caused: after 1 trade flip_count=2 → 600s cooldown,
                        # after 2 trades → 1800s. Now counted only on EXIT (close hook).
                    # BUG-12 FIX: do NOT undo the dedup record on pipeline block.
                    # The dedup record expires naturally on new brick (new timestamp/price).

        elif renko_signal == "SELEX":
            trade_manager = self._cancel_pending(
                trade_manager, symbol, exchange, "BUYCL", "SELST"
            )

            if call_qty > 0:
                trade_manager, ok = self._create_exit(
                    trade_manager, symbol, exchange, "SELCL",
                    entry_price, timestamp, root_positions, renko_df
                )
                if ok:
                    changed = True
                elif put_qty == 0:
                    return trade_manager, changed

            if call_qty == 0 and put_qty == 0:
                has_pos = False
                recorded = self._dedup.check_and_record(
                    symbol, timestamp, renko_signal, entry_price, has_pos
                )
                if recorded:
                    # BUG-B FIX: same fix as BUYEN — _create_entry first, then record_flip.
                    trade_manager, added = self._create_entry(
                        trade_manager, symbol, exchange, "BUYPT",
                        entry_price, timestamp, renko_df, ohlc_df, brick_size,
                    )
                    if added:
                        changed = True
                        # FIX I-07: record_flip REMOVED from entry path (was double-counting).
                        # Flip is counted only on EXIT in engine._fire_close_hooks().
                    # BUG-12 FIX: same as BUYEN — do not undo dedup on block.

        return trade_manager, changed

    # ── Private helpers (unchanged from original) ───────────────────────────────

    def _extract_signal(
        self, renko_df: pd.DataFrame, symbol: str, brick_size: float,
        exchange: str = "",
    ) -> Tuple[Optional[str], Optional[str], Optional[float]]:
        if renko_df is None or renko_df.empty:
            return None, None, None

        last = renko_df.iloc[-1]
        ts   = last.get("timestamp")

        # ── Close Renko confirmation gate ──────────────────────────────────────
        # When require_close_confirmation=True (default), an HL signal is only
        # allowed to fire if the Close Renko has generated a matching signal
        # (BUYRE or SELRE) within the last N bricks (default 5).
        #
        # WHY: HL Renko fires on intrabar wicks — a down-wick creates SELEX even
        # if every candle closes higher (all-green close renko).  Similarly, an
        # HL BUYEN can fire during a pure uptrend where close renko never had a
        # red brick, producing a "continuation" entry with no actual reversal
        # signal from the more reliable close-based chart.
        #
        # The Close_Signal column (BUYRE/SELRE) only fires on a genuine
        # direction change in close prices — red→green for BUYRE, green→red for
        # SELRE.  Requiring its presence within the last N bricks ensures the HL
        # signal has close-price backing, not just a wick.
        #
        # F-02 FIX: window now defaults to 3 (was 10). Per-instrument override
        # available via close_signal_window_override dict for slow MCX instruments.
        import re as _csw_re
        _csw_root = (
            _csw_re.match(r"^([A-Z]+)", symbol.upper()) or
            _csw_re.match(r"^([A-Z]+)", "X")
        ).group(1)
        _csw_override = getattr(cfg.entry, "close_signal_window_override", {})
        close_signal_window = _csw_override.get(
            _csw_root, getattr(cfg.entry, "close_signal_window_bricks", 3)
        )
        # MCX-BUG-1 FIX: MCX exchanges bypass the close confirmation gate.
        # 470 HL signals suppressed in 80-min session — coarse MCX bricks rarely
        # generate Close_Signal within the window.  NSE/BSE unaffected.
        _close_exempt_exchanges = getattr(
            cfg.entry, "require_close_confirmation_exempt_exchanges", ()
        )
        _close_gate_exempt = exchange.upper() in _close_exempt_exchanges

        def _has_close_signal(signal_type: str) -> bool:
            """
            Return True if Close Renko confirms the HL signal direction.

            UPGRADE: Instead of binary any()-in-window, this now checks
            which close signal is MOST RECENT within the window.

            If both BUYRE and SELRE appear in the window, the most recent
            one wins.  This catches the pattern:
              brick[-3]=BUYRE, brick[-2]=SELRE, brick[-1]=wick → BUYEN
            Old logic: BUYRE exists → PASS  (wrong, trend reversed)
            New logic: SELRE is newer → SUPPRESS  (correct)

            Behaviour matrix:
              Only expected  in window  → PASS  (confirmed, same as before)
              Only opposite  in window  → SUPPRESS (same as before)
              Both in window, expected newer → PASS
              Both in window, opposite newer → SUPPRESS  ← KEY NEW CASE
              Nothing in window              → SUPPRESS (same as before)
            """
            if not getattr(cfg.entry, "require_close_confirmation", True):
                return True
            if _close_gate_exempt:          # MCX-BUG-1 FIX: MCX bypasses gate
                return True
            if "Close_Signal" not in renko_df.columns:
                return True   # no close data → gate transparent

            expected = "BUYRE" if signal_type == "BUYEN" else "SELRE"
            opposite = "SELRE" if signal_type == "BUYEN" else "BUYRE"

            window = renko_df.iloc[-close_signal_window:]
            has_expected = window["Close_Signal"].isin([expected]).any()
            has_opposite = window["Close_Signal"].isin([opposite]).any()

            if not has_expected:
                return False   # no confirmation in window → suppress

            if has_expected and not has_opposite:
                return True    # only our direction → pass (same as before)

            # Both directions appear in window — most recent wins
            expected_rows = window[window["Close_Signal"] == expected]
            opposite_rows = window[window["Close_Signal"] == opposite]
            last_expected_pos = expected_rows.index[-1]
            last_opposite_pos = opposite_rows.index[-1]

            if last_opposite_pos > last_expected_pos:
                # Opposite fired more recently — close trend reversed → suppress
                log.info(
                    "🔇 CLOSE_CONFIRM RECENCY SUPPRESS %s %s: "
                    "%s (pos=%d) is newer than %s (pos=%d) — "
                    "close trend reversed, HL wick suppressed",
                    symbol, signal_type,
                    opposite, last_opposite_pos,
                    expected, last_expected_pos,
                )
                return False

            return True   # expected is more recent → pass

        # BUG-ENTRY-2 FIX: Check Signal (HL, ZLEMA-gated) BEFORE Close_Signal.
        # Original order was reversed — weaker Close_Signal fired first, bypassing
        # the ZLEMA gate on the stronger HL Signal.
        for sig_col, price_col in [
            ("Signal",       "Renko_Brick"),   # HL signal — has ZLEMA check (stronger)
            ("Close_Signal", "Close_Price"),    # Close signal — fallback
        ]:
            if sig_col in renko_df.columns:
                rows_at_ts = renko_df[renko_df["timestamp"] == ts]
                sig_rows   = rows_at_ts[rows_at_ts[sig_col].isin(
                    ["BUYRE", "SELRE", "BUYEN", "SELEX"]
                )]
                if not sig_rows.empty:
                    # BUG-ENTRY-3 FIX: iloc[-1] takes the NEWEST brick at this
                    # timestamp (was iloc[0] = oldest, wrong in fast markets).
                    raw_sig = sig_rows[sig_col].iloc[-1]
                    price   = float(sig_rows[price_col].iloc[-1])
                    signal  = {"BUYRE": "BUYEN", "SELRE": "SELEX"}.get(raw_sig, raw_sig)

                    # ── Close Signal confirmation gate (HL signals only) ───────
                    # Close_Signal is self-confirming — no gate needed on it.
                    if sig_col == "Signal" and not _has_close_signal(signal):
                        log.info(
                            "🔇 CLOSE_CONFIRM SUPPRESS %s %s: "
                            "no matching Close_Signal in last %d bricks — "
                            "HL-only signal ignored (wick/continuation)",
                            symbol, signal, close_signal_window,
                        )
                        continue   # try Close_Signal fallback next

                    # ── CLOSE_SIGNAL_ZLEMA_GATE: ZLEMA gate for Close fallback ──
                    # The HL signal path is protected by ZLEMA in renko_engine.py.
                    # The Close_Signal fallback path was completely unguarded —
                    # a BUYRE→BUYEN could fire even with brick below ZLEMA (downtrend),
                    # and a SELRE→SELEX could fire even with brick above ZLEMA (uptrend).
                    # This gate makes the fallback path consistent with the HL path.
                    # Feature-flagged: close_signal_zlema_gate (default True).
                    if sig_col == "Close_Signal":
                        _cs_zlema_gate = getattr(cfg.entry, "close_signal_zlema_gate", True)
                        if _cs_zlema_gate:
                            _last_row = renko_df.iloc[-1]
                            _brick_val = float(_last_row.get("Renko_Brick") or 0)
                            _zlema_val = float(_last_row.get("zlema9") or 0)
                            if _brick_val > 0 and _zlema_val > 0:
                                if signal == "BUYEN" and _brick_val <= _zlema_val:
                                    log.info(
                                        "🔇 CLOSE_FALLBACK_ZLEMA_BLOCK %s BUYEN: "
                                        "brick=%.2f <= zlema=%.2f — counter-trend CALL blocked",
                                        symbol, _brick_val, _zlema_val,
                                    )
                                    continue  # skip fallback; no more paths → return None
                                if signal == "SELEX" and _brick_val >= _zlema_val:
                                    log.info(
                                        "🔇 CLOSE_FALLBACK_ZLEMA_BLOCK %s SELEX: "
                                        "brick=%.2f >= zlema=%.2f — counter-trend PUT blocked",
                                        symbol, _brick_val, _zlema_val,
                                    )
                                    continue
                    # ─────────────────────────────────────────────────────────

                    offset  = cfg.entry.offset_bricks * brick_size
                    # BUG-ENTRY-1 FIX: offset direction depends on entry mode.
                    # BREAKOUT: enter ABOVE the signal level (buy the breakout / sell the breakdown).
                    # PULLBACK: enter BELOW the signal level (wait for pullback into momentum).
                    # Original code was inverted for BREAKOUT (acted as PULLBACK).
                    is_breakout = getattr(cfg.entry, "mode", "BREAKOUT") != "PULLBACK"
                    if signal == "BUYEN":
                        price = price + offset if is_breakout else price - offset
                    elif signal == "SELEX":
                        price = price - offset if is_breakout else price + offset
                    return ts, signal, round(price, 2)
        return ts, None, None

    def _is_zombie(
        self,
        timestamp,
        signal,
        symbol,
        root_positions,
        signal_price: float = None,   # F-03: entry_price from _extract_signal
        brick_size:   float = 10.0,   # F-03: brick size for deviation calculation
    ) -> bool:
        if signal not in ("BUYEN", "SELEX"):
            return False

        # ── F-03: LTP-deviation check ─────────────────────────────────────────
        # Block if current LTP is more than N bricks from signal price.
        # This prevents late execution where the actual fill's stop distance
        # differs wildly from the intended risk (e.g. signal at 25000, LTP now
        # at 25144 on NIFTY = 12 bricks deviation; effective stop distance
        # becomes 180pts instead of the intended 36pts).
        # Runs BEFORE timestamp age check so stale+deviated signals are caught
        # on the first evaluation rather than only after 10 minutes.
        _dev_thresh = getattr(cfg.entry, "zombie_ltp_deviation_bricks", 2.0)
        if _dev_thresh > 0 and signal_price is not None and brick_size > 0:
            try:
                ltp, ltp_age = ltp_store.get(symbol)
                if ltp is not None and ltp_age < 30:   # only act on a fresh LTP
                    deviation_bricks = abs(ltp - signal_price) / brick_size
                    if deviation_bricks > _dev_thresh:
                        key = (symbol, signal)
                        if key not in self._zombie_logged:
                            log.info(
                                "💀 LTP_DEVIATION_ZOMBIE %s %s: "
                                "ltp=%.2f signal_price=%.2f dev=%.1fb > %.1fb — SKIP",
                                signal, symbol, ltp, signal_price,
                                deviation_bricks, _dev_thresh,
                            )
                            self._zombie_logged.add(key)
                        return True
                    # LTP is back within range — clear any prior deviation log flag
                    self._zombie_logged.discard((symbol, signal))
            except Exception:
                pass   # LTP unavailable → do not block (fail-open)
        # ─────────────────────────────────────────────────────────────────────

        try:
            sig_ts = pd.to_datetime(timestamp)
            # BUG-ENTRY-4 FIX: tz_localize() raises TypeError if the timestamp
            # already carries tzinfo (e.g. comes from a tz-aware Renko row).
            # The old bare except silently returned False, letting stale signals
            # bypass the 10-minute age guard entirely.
            if sig_ts.tzinfo is None:
                sig_ts = sig_ts.tz_localize(IST)
            else:
                sig_ts = sig_ts.tz_convert(IST)
            age_mins = (_now() - sig_ts).total_seconds() / 60
        except Exception:
            return False

        if age_mins <= _SIG_MAX_AGE_MINUTES:
            return False

        has_exit_pos = (
            (signal == "BUYEN" and root_positions.get("PUT", 0) > 0) or
            (signal == "SELEX" and root_positions.get("CALL", 0) > 0)
        )
        if not has_exit_pos:
            key = (symbol, signal)
            if key not in self._zombie_logged:
                log.info("💀 ZOMBIE %s %s: %.0f min old — SKIP", signal, symbol, age_mins)
                self._zombie_logged.add(key)
            return True
        # Signal is now actionable (position appeared) — clear the logged flag
        # so we warn again if it goes stale a second time.
        self._zombie_logged.discard((symbol, signal))
        return False

    def _cancel_pending(self, tm, symbol, exchange, *signals) -> pd.DataFrame:
        for sig in signals:
            mask = (
                (tm["symbol"] == symbol) &
                (tm["exchange"] == exchange) &
                (tm["renko_signal"] == sig) &
                (tm["order_status"] == "OPEN")
            )
            if mask.any():
                tm.loc[mask, "order_status"] = "CANCELLED"
                tm.loc[mask, "close_reason"] = "REVERSAL_CANCELLED"
        return tm

    def _create_exit(
        self,
        tm, symbol, exchange, exit_signal,
        entry_price, timestamp, root_positions, renko_df,
    ) -> Tuple[pd.DataFrame, bool]:
        active_statuses = ("OPEN", "SENDING", "INPOSITION")
        already = not tm[
            (tm["symbol"] == symbol) &
            (tm["exchange"] == exchange) &
            (tm["renko_signal"] == exit_signal) &
            (tm["order_status"].isin(active_statuses))
        ].empty
        if already:
            return tm, False

        entry_action = "BUYCL" if exit_signal in ("SELCL", "SELST") else "BUYPT"
        position_open = not tm[
            (tm["symbol"] == symbol) &
            (tm["exchange"] == exchange) &
            (tm["renko_signal"] == entry_action) &
            (tm["order_status"] == "INPOSITION")
        ].empty
        if not position_open:
            return tm, False

        opt_type = "CE" if exit_signal in ("SELCL", "SELST") else "PE"
        qty_key  = "CALL" if opt_type == "CE" else "PUT"
        qty      = int(root_positions.get(qty_key, 0))

        if qty == 0:
            entry_rows = tm[
                (tm["symbol"] == symbol) &
                (tm["renko_signal"] == entry_action) &
                (tm["order_status"] == "INPOSITION")
            ]
            if not entry_rows.empty:
                qty = int(entry_rows.iloc[0].get("quantity") or 0)

        row = {
            "exchange":     exchange,
            "timestamp":    _now().strftime("%Y-%m-%d %H:%M:%S"),
            "symbol":       symbol,
            "renko_signal": exit_signal,
            "entry_price":  float(entry_price),
            "quantity":     int(qty),
            "order_status": "OPEN",
            "close_reason": "",
        }
        tm = pd.concat([tm, pd.DataFrame([row])], ignore_index=True)
        log.info("🔴 EXIT ROW created: %s %s @ %.2f", exit_signal, symbol, entry_price)
        return tm, True

    def _create_entry(
        self, tm, symbol, exchange, action,
        entry_price, timestamp, renko_df, ohlc_df, brick_size,
    ) -> Tuple[pd.DataFrame, bool]:
        signal = "BUYEN" if action == "BUYCL" else "SELEX"
        ltp, ltp_age = ltp_store.get(symbol)

        if ltp_age > cfg.broker.ltp_hard_block_secs:
            log.warning("🚫 STALE LTP BLOCK %s: age=%.1fs", symbol, ltp_age)
            return tm, False

        # Feed-health gate — block new entries if websocket is degraded.
        # Uses the module-level _ws_manager_instance set at startup by ws_manager.
        # None means no WS manager available (e.g. test env) → gate is transparent.
        if _ws_manager_instance is not None and not _ws_manager_instance.is_feed_healthy():
            log.warning("🚫 FEED_HEALTH BLOCK %s: WS feed unhealthy — no new entries", symbol)
            return tm, False

        result = self._pipeline.evaluate(
            symbol=symbol, signal=signal, renko_df=renko_df,
            ohlc_df=ohlc_df, brick_size=brick_size,
            ltp=ltp, exchange=exchange, signal_timestamp=timestamp,
        )

        # BUG-B FIX: store regime on self so process() can read it for record_flip
        # without needing `result` to exist in the outer scope.
        _r = result.regime
        self._last_regime_str = _r.value if hasattr(_r, "value") else str(_r)

        if result.blocked:
            TradeLogger.filter_block(symbol, action, " | ".join(result.blocks))
            return tm, False

        # ── Whipsaw gate — direction-specific, with grade-A bypass (Fix 1+4) ──
        # Gate is checked HERE (after quality eval) so:
        #   a) exits always pass — they never reach _create_entry
        #   b) grade is known — grade-A bypasses the cooldown entirely
        #   c) direction is known — only the relevant direction is checked
        ws_direction = "CALL" if action == "BUYCL" else "PUT"
        opposite     = "PUT" if ws_direction == "CALL" else "CALL"

        # FIX NEW — profit-exit reversal block (ALL grades).
        # After a profitable trailing-stop exit, block opposite direction for N secs.
        # Prevents afternoon reversal trades that give back morning profits.
        if whipsaw_tracker.is_reversal_blocked_after_profit(symbol, ws_direction):
            TradeLogger.filter_block(symbol, action,
                f"PROFIT_EXIT_REVERSAL_BLOCK({ws_direction})")
            return tm, False

        # UPGRADE T2-4: Grade-differentiated signal_exit block.
        # Grade-A signals (score≥5) have confirmed swing structure + ZLEMA + momentum.
        # A genuine reversal with Grade-A quality should re-enter within 30s not 120s.
        # Grade-B stays at 120s to protect against noise bounces.
        # This recovers the 90-second head-start on fast reversal days.
        _grade_a_window = getattr(cfg.whipsaw, "signal_exit_block_secs_grade_a", 30)
        _grade_b_window = getattr(cfg.whipsaw, "signal_exit_block_secs", 120)
        sig_exit_window = (
            _grade_a_window if result.grade == SignalGrade.A else _grade_b_window
        )
        if whipsaw_tracker.signal_exit_too_recent(symbol, opposite, sig_exit_window):
            log.info(
                "🚫 SIGNAL_EXIT BLOCK %s %s (grade=%s): %s SIGNAL_EXIT within %ds",
                symbol, ws_direction, result.grade.value, opposite, sig_exit_window,
            )
            TradeLogger.filter_block(symbol, action,
                f"SIGNAL_EXIT_BLOCK({opposite} exit < {sig_exit_window}s ago, grade={result.grade.value})")
            return tm, False

        # SAME-CYCLE SIGNAL_EXIT BLOCK (race-condition fix):
        # engine cycle order: signal_gen.process() runs BEFORE _fire_close_hooks().
        # When a SELEX→BUYEN fires in the same cycle as a SIGNAL_EXIT close,
        # record_signal_exit() has NOT been called yet — the whipsaw tracker's
        # signal_exit_too_recent() returns False even though the opposite direction
        # JUST exited on a signal in this very cycle.
        # Fix: inspect trade_manager directly for CLOSED rows with SIGNAL_EXIT
        # reason for the opposite direction. This catches same-cycle reversals
        # that the whipsaw tracker hasn't recorded yet.
        # BUG FIX v7m: was "_opp_entry_action" checking BUYCL/BUYPT (entry signals).
        # A CALL exit writes renko_signal="SELCL"; a PUT exit writes "SELPT".
        # Entry signals (BUYCL/BUYPT) never appear in CLOSED rows, so the old
        # check always found nothing → block never fired → PUT entered 3s after
        # CALL SIGNAL_EXIT (April 8 10:08 BNF: -₹1,632 direct loss).
        #
        # SIDE-EFFECT FIX v7m: must add time filter to the TM search.
        # trade_manager accumulates ALL session rows, so an old SELCL SIGNAL_EXIT
        # row from 10:08 would still match at 11:32 (84 mins later), permanently
        # blocking PUT entries for the rest of the session. The SAME_CYCLE guard
        # must only match rows closed within one engine cycle window (~15 seconds).
        _opp_exit_action = "SELPT" if ws_direction == "CALL" else "SELCL"
        _same_cycle_cutoff = datetime.now(tz=IST) - __import__("datetime").timedelta(seconds=15)
        _sc_candidates = tm[
            (tm["symbol"] == symbol) &
            (tm["renko_signal"] == _opp_exit_action) &
            (tm["order_status"] == "CLOSED") &
            (tm["close_reason"].str.upper().str.contains("SIGNAL_EXIT", na=False))
        ]
        _same_cycle_signal_exit = False
        if not _sc_candidates.empty:
            try:
                _sc_ts = pd.to_datetime(_sc_candidates["timestamp"])
                if _sc_ts.dt.tz is None:
                    _sc_ts = _sc_ts.dt.tz_localize(IST)
                else:
                    _sc_ts = _sc_ts.dt.tz_convert(IST)
                _same_cycle_signal_exit = bool((_sc_ts >= _same_cycle_cutoff).any())
            except Exception:
                pass  # timestamp parse error — fail safe (don't block)
        if _same_cycle_signal_exit:
            log.info(
                "🚫 SAME_CYCLE_SIGNAL_EXIT_BLOCK %s %s (grade=%s): "
                "%s JUST closed via SIGNAL_EXIT this cycle — "
                "blocking immediate reversal (race-condition guard)",
                symbol, ws_direction, result.grade.value, opposite,
            )
            TradeLogger.filter_block(symbol, action,
                f"SAME_CYCLE_SIGNAL_EXIT_BLOCK({opposite} SIGNAL_EXIT this cycle)")
            return tm, False

        if result.grade != SignalGrade.A:
            blocked, ws_reason = whipsaw_tracker.is_blocked(symbol, ws_direction)
            if blocked:
                log.debug("🔄 WHIPSAW_BLOCKED %s %s: %s", symbol, ws_direction, ws_reason)
                TradeLogger.filter_block(symbol, action, ws_reason)
                return tm, False
        else:
            # Grade-A bypass: only allowed when the last exit was a clean SIGNAL_EXIT.
            # If ANY active cooldown on this symbol was triggered by STOP_EXIT/TRAIL_EXIT,
            # block the bypass — the market is choppy, not reversing cleanly.
            # Proven: PUT stop 17:57 → CALL Grade-A bypass 11s later → CALL stop = -₹5,100.
            if whipsaw_tracker.is_stop_exit_recent(symbol, ws_direction):
                log.info(
                    "🛑 GRADE-A BYPASS BLOCKED %s %s: last exit was STOP_EXIT — "
                    "cooldown enforced to prevent double-loss whipsaw",
                    symbol, ws_direction,
                )
                TradeLogger.filter_block(
                    symbol, action,
                    "STOP_EXIT_COOLDOWN(grade-A bypass disabled after stop loss)"
                )
                return tm, False
            _last_exit = whipsaw_tracker._last_exit_reason.get((symbol, ws_direction), "")
            _bypass_reason = (
                "first trade of session — no prior exit"
                if not _last_exit
                else f"last exit was {_last_exit or 'SIGNAL_EXIT'} — cooldown bypassed"
            )
            log.info(
                "⭐ GRADE-A WHIPSAW BYPASS %s %s: %s",
                symbol, ws_direction, _bypass_reason,
            )

        from tcos_bot.execution.position_tracker import get_lot_size
        from tcos_bot.config.settings import MAX_LOTS, DEFAULT_MAX_LOTS
        import math as _math
        root_sym = re.match(r"^([A-Z]+)", symbol.upper())
        root_sym = root_sym.group(1) if root_sym else symbol
        lot_size = get_lot_size(symbol)
        max_lots = MAX_LOTS.get(root_sym, DEFAULT_MAX_LOTS)
        # FIX I-14: was round() which uses banker's rounding — round(0.5)=0, round(2.5)=2.
        # max(1, round(1 * 0.5)) = max(1, 0) = 1 (saved by floor but wrong reason).
        # max(1, round(5 * 0.5)) = max(1, 2) = 2 (40% not 50% — incorrect).
        # Fix: int(x + 0.5) gives proper half-up rounding for all lot counts.
        lots     = max(1, int(max_lots * result.size_multiplier + 0.5))
        qty      = lots * lot_size

        row = {
            "exchange":        exchange,
            "timestamp":       _now().strftime("%Y-%m-%d %H:%M:%S"),
            "symbol":          symbol,
            "renko_signal":    action,
            "entry_price":     float(entry_price),
            "quantity":        int(qty),
            "order_status":    "OPEN",
            "close_reason":    "",
            "entry_mode":      cfg.entry.mode,
            "signal_grade":    result.grade.value,
            "quality_score":   int(result.score),
            "day_regime":      self._last_regime_str,
            "brick_size_hint": float(brick_size),
            # FIX I-16: set nft_validated=0 here so OPEN rows have defined state.
            # Previously unset → NaN; NFT mask (==0) correctly skipped NaN rows
            # but reconciler/watchdog reads could see NaN on OPEN rows.
            "nft_validated":   0,
            # Structural stop levels — used by TrailingStopManager.initialise()
            # to tighten the initial SL to the last confirmed swing level.
            # Populated from renko_df at signal time; None-safe in initialise().
            "struct_high":     float(renko_df.iloc[-1]["Last_High"])
                               if "Last_High" in renko_df.columns and pd.notna(renko_df.iloc[-1].get("Last_High"))
                               else None,
            "struct_low":      float(renko_df.iloc[-1]["Last_Low"])
                               if "Last_Low" in renko_df.columns and pd.notna(renko_df.iloc[-1].get("Last_Low"))
                               else None,
        }
        new_row_df = pd.DataFrame([row])
        for col in tm.columns:
            if col in new_row_df.columns and col not in (
                "order_status", "close_reason", "signal_grade",
                "day_regime", "renko_signal", "exchange", "timestamp", "symbol"
            ):
                try:
                    new_row_df[col] = new_row_df[col].astype(tm[col].dtype)
                except Exception:
                    pass
        tm = pd.concat([tm, new_row_df], ignore_index=True)
        log.info(
            "🟢 ENTRY ROW created: %s %s | grade=%s size=%.0f%% qty=%d @ %.2f",
            action, symbol, result.grade.value,
            result.size_multiplier * 100, qty, entry_price,
        )
        return tm, True

    @staticmethod
    def _is_fresh_signal(timestamp) -> bool:
        try:
            sig_ts = pd.to_datetime(timestamp)
            if sig_ts.tzinfo is None:
                sig_ts = sig_ts.tz_localize(IST)
            age_mins = (datetime.now(tz=IST) - sig_ts).total_seconds() / 60
            return age_mins <= _SIG_MAX_AGE_MINUTES
        except Exception:
            return True
