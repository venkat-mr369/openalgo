"""
Trend State Detector — trend_state.py
======================================
Classifies each Renko update into an explicit intraday directional state:

    UPTREND   — price structure and ZLEMA9 support bullish continuation
    DOWNTREND — price structure and ZLEMA9 support bearish continuation
    NEUTRAL   — signals conflict, trend is weak, or structure is unclear

Design principles
-----------------
- Uses ONLY columns already in renko_df — no new indicators.
- Recomputed on every signal evaluation (intraday-dynamic, not set at open).
- Requires multi-factor confirmation to avoid noisy flips.
- Returns a named constant so every module can compare strings cleanly.
- Fully testable from a dict/Series with no dependencies.

Confirmation requirements
--------------------------
UPTREND requires at least 2 of 3 bullish factors:
  1. Renko_Brick > zlema9  (price above zero-lag EMA)
  2. HH confirmed (Higher High in swing structure) OR  Colour_Brick_Count >= min_bricks in up-dir
  3. No HL/LH conflict that contradicts continuation

DOWNTREND requires at least 2 of 3 bearish factors:
  1. Renko_Brick < zlema9
  2. LL confirmed (Lower Low) OR  Colour_Brick_Count >= min_bricks in down-dir
  3. No HH/HL that contradicts continuation

NEUTRAL when:
  - Neither direction reaches 2/3 confirmation
  - Brick exactly on ZLEMA9 (ambiguous)
  - brick_count < minimum AND no swing confirmation

Noise guard
-----------
`detect_trend_state()` accepts an optional previous_state.  If the new
evidence is weak (score difference == 1 across the threshold), the old state
is preserved rather than flipping.  This prevents single-brick oscillation
from toggling the regime label on every tick.

Interface
---------
    from tcos_bot.signals.trend_state import detect_trend_state, TrendState

    state = detect_trend_state(renko_df.iloc[-1])
    # → TrendState.UPTREND | TrendState.DOWNTREND | TrendState.NEUTRAL

    info  = trend_state_info(renko_df.iloc[-1])
    # → {"state": "UPTREND", "score": 2, "factors": [...]}
"""

from __future__ import annotations

import enum
from typing import Optional, Union

import pandas as pd


# ── Public constants ───────────────────────────────────────────────────────────

class TrendState(str, enum.Enum):
    """Explicit intraday directional trend classification."""
    UPTREND   = "UPTREND"
    DOWNTREND = "DOWNTREND"
    NEUTRAL   = "NEUTRAL"


# Minimum consecutive same-direction bricks required for momentum confirmation.
# Configurable here; callers may override via the `min_bricks` parameter.
_DEFAULT_MIN_BRICKS = 2

# Hysteresis: how many net score points above threshold before we switch.
# 1 = any majority switches state; 2 = require a 2-point lead to avoid flip.
_HYSTERESIS = 1


# ── Public API ─────────────────────────────────────────────────────────────────

def detect_trend_state(
    row: Union[pd.Series, dict],
    previous_state: Optional[TrendState] = None,
    min_bricks: int = _DEFAULT_MIN_BRICKS,
) -> TrendState:
    """
    Classify current trend direction from a single Renko row.

    Parameters
    ----------
    row           : Last row of renko_df (Series or dict).
    previous_state: The prior trend state (enables hysteresis noise guard).
    min_bricks    : Minimum Colour_Brick_Count for momentum confirmation.

    Returns
    -------
    TrendState.UPTREND | TrendState.DOWNTREND | TrendState.NEUTRAL
    """
    info = _compute_scores(row, min_bricks)
    up_score   = info["up_score"]
    down_score = info["down_score"]

    # Threshold: 2 out of 3 factors required for directional classification
    THRESHOLD = 2

    up_clear   = up_score   >= THRESHOLD
    down_clear = down_score >= THRESHOLD

    if up_clear and not down_clear:
        candidate = TrendState.UPTREND
    elif down_clear and not up_clear:
        candidate = TrendState.DOWNTREND
    elif up_clear and down_clear:
        # Both sides qualify — stronger one wins, else NEUTRAL
        if up_score > down_score + _HYSTERESIS:
            candidate = TrendState.UPTREND
        elif down_score > up_score + _HYSTERESIS:
            candidate = TrendState.DOWNTREND
        else:
            candidate = TrendState.NEUTRAL
    else:
        candidate = TrendState.NEUTRAL

    # ── Hysteresis noise guard ─────────────────────────────────────────────
    # If we have a previous state and the new evidence is only marginally
    # different, keep the old state rather than flipping.
    if previous_state is not None and previous_state != TrendState.NEUTRAL:
        if candidate != previous_state and candidate != TrendState.NEUTRAL:
            # Opposite direction proposed — require stronger evidence
            if previous_state == TrendState.UPTREND and up_score < down_score - _HYSTERESIS:
                return TrendState.DOWNTREND
            if previous_state == TrendState.DOWNTREND and down_score < up_score - _HYSTERESIS:
                return TrendState.UPTREND
            # Not strong enough to flip — hold prior state
            return previous_state

    return candidate


def trend_state_info(
    row: Union[pd.Series, dict],
    previous_state: Optional[TrendState] = None,
    min_bricks: int = _DEFAULT_MIN_BRICKS,
) -> dict:
    """
    Return full scoring breakdown for logging/testing.

    Returns
    -------
    dict with keys: state, up_score, down_score, factors
    """
    info = _compute_scores(row, min_bricks)
    state = detect_trend_state(row, previous_state, min_bricks)
    return {
        "state":      state.value,
        "up_score":   info["up_score"],
        "down_score": info["down_score"],
        "factors":    info["factors"],
    }


def is_trade_allowed_for_trend(
    signal: str,
    trend: TrendState,
    regime: str,
) -> tuple[bool, str]:
    """
    Check whether a signal direction is consistent with the current trend.

    This is the integration point for the directional gate (Part 4).
    Returns (allowed, reason_string).

    Parameters
    ----------
    signal : "BUYEN" (want CALL) or "SELEX" (want PUT)
    trend  : current TrendState
    regime : MarketRegime string — "TRENDING"|"SIDEWAYS"|"VOLATILE"|"UNKNOWN"

    Rules (per Part 4 spec)
    -----------------------
    TRENDING + UPTREND   → BUYEN allowed, SELEX hard-blocked
    TRENDING + DOWNTREND → SELEX allowed, BUYEN hard-blocked
    TRENDING + NEUTRAL   → both soft-blocked (no directional conviction)
    SIDEWAYS / VOLATILE  → both allowed (quality filter handles selectivity)
    UNKNOWN              → aligned allowed; counter-trend penalised but not hard-blocked
    """
    regime_up = regime.upper() if regime else "UNKNOWN"

    if regime_up == "TRENDING":
        if trend == TrendState.UPTREND:
            if signal == "BUYEN":
                return True, "TREND_ALIGNED: UPTREND+CALL"
            return False, "TREND_BLOCK: TRENDING+DOWNSIDE signal in UPTREND"
        if trend == TrendState.DOWNTREND:
            if signal == "SELEX":
                return True, "TREND_ALIGNED: DOWNTREND+PUT"
            return False, "TREND_BLOCK: TRENDING+UPSIDE signal in DOWNTREND"
        # NEUTRAL in TRENDING regime — no directional conviction, block fresh entries
        return False, "TREND_BLOCK: TRENDING regime but no directional conviction (NEUTRAL)"

    if regime_up in ("SIDEWAYS", "VOLATILE"):
        # Both sides allowed; scoring/quality filter handles selectivity
        return True, f"TREND_OK: {regime_up} allows both directions"

    # UNKNOWN — prefer aligned, allow counter-trend (scoring will penalise it)
    if trend == TrendState.UPTREND and signal == "BUYEN":
        return True, "TREND_ALIGNED: UNKNOWN+UPTREND+CALL"
    if trend == TrendState.DOWNTREND and signal == "SELEX":
        return True, "TREND_ALIGNED: UNKNOWN+DOWNTREND+PUT"
    if trend == TrendState.NEUTRAL:
        return True, "TREND_OK: NEUTRAL trend, no block"
    # Counter-trend in UNKNOWN — allow but flag
    return True, f"TREND_WARN: counter-trend {signal} in {trend.value} (UNKNOWN regime)"


# ── Internal scoring ───────────────────────────────────────────────────────────

def _safe_float(val) -> Optional[float]:
    try:
        f = float(val)
        return f if f == f else None  # NaN check
    except (TypeError, ValueError):
        return None


def _is_true(val) -> bool:
    return val is True or str(val).strip().lower() == "true"


def _compute_scores(row: Union[pd.Series, dict], min_bricks: int) -> dict:
    """
    Compute raw bullish/bearish scores from a Renko row.

    Scoring rubric (each factor = 1 point; max = 3 per side):
      Factor 1 — ZLEMA alignment (price vs zero-lag EMA)
      Factor 2 — Swing structure (HH/HL for bull, LL/LH for bear)
      Factor 3 — Brick momentum (consecutive same-direction count >= min_bricks)
    """
    if isinstance(row, pd.Series):
        get = row.get
    else:
        get = row.get  # dict.get

    brick  = _safe_float(get("Renko_Brick"))
    zlema  = _safe_float(get("zlema9"))
    c_count = int(_safe_float(get("Colour_Brick_Count") or 0) or 0)
    direction = int(_safe_float(get("direction") or 0) or 0)  # 1=up, -1=down

    hh = _is_true(get("HH"))
    ll = _is_true(get("LL"))
    hl = _is_true(get("HL"))
    lh = _is_true(get("LH"))

    up_score   = 0
    down_score = 0
    factors    = []

    # ── Factor 1: ZLEMA alignment ──────────────────────────────────────────
    if brick is not None and zlema is not None and zlema > 0:
        if brick > zlema:
            up_score += 1
            factors.append(f"ZLEMA_BULL: brick={brick:.0f} > zlema={zlema:.0f}")
        elif brick < zlema:
            down_score += 1
            factors.append(f"ZLEMA_BEAR: brick={brick:.0f} < zlema={zlema:.0f}")
        else:
            factors.append("ZLEMA_FLAT: brick == zlema (ambiguous)")
    else:
        factors.append("ZLEMA_MISSING: cannot score")

    # ── Factor 2: Swing structure ──────────────────────────────────────────
    if hh:
        up_score += 1
        factors.append("SWING_BULL: HH confirmed")
    elif hl and not lh:
        # Higher Low without Lower High is mild bullish (accumulation)
        up_score += 1
        factors.append("SWING_BULL: HL (accumulation)")

    if ll:
        down_score += 1
        factors.append("SWING_BEAR: LL confirmed")
    elif lh and not hl:
        # Lower High without Higher Low is mild bearish (distribution)
        down_score += 1
        factors.append("SWING_BEAR: LH (distribution)")

    # ── Factor 3: Brick momentum ───────────────────────────────────────────
    if c_count >= min_bricks:
        # Momentum direction from the direction column or from sign of c_count
        if direction == 1:
            up_score += 1
            factors.append(f"MOMENTUM_BULL: {c_count} consecutive up bricks")
        elif direction == -1:
            down_score += 1
            factors.append(f"MOMENTUM_BEAR: {c_count} consecutive down bricks")
        else:
            # direction column missing — infer from ZLEMA side
            if brick is not None and zlema is not None:
                if brick > zlema:
                    up_score += 1
                    factors.append(f"MOMENTUM_BULL_INFERRED: {c_count} bricks, price>zlema")
                else:
                    down_score += 1
                    factors.append(f"MOMENTUM_BEAR_INFERRED: {c_count} bricks, price<zlema")
    else:
        factors.append(f"MOMENTUM_WEAK: only {c_count} bricks (need {min_bricks})")

    return {
        "up_score":   up_score,
        "down_score": down_score,
        "factors":    factors,
    }
