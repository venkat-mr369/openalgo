"""
Renko Engine
============
Pure computation module — no I/O, no state, no side effects.

Provides
--------
- RenkoHLWick            : TradingView-style H/L Renko (direction-aware)
- RenkoCloseTraditional  : Close-only 2-box reversal Renko
- RenkoAnnotator         : adds zlema9, swing labels, brick count to any Renko df
- HybridRenkoGenerator   : runs both and merges signals (replicates ru._generate_hybrid_base_signals)

All functions are deterministic given the same OHLC input + anchor.
"""

from __future__ import annotations

import logging
from collections import deque
from typing import Optional

import numpy as np
import pandas as pd
from scipy.signal import argrelextrema

log = logging.getLogger(__name__)


# ── HL-Wick Renko ─────────────────────────────────────────────────────────────

class RenkoHLWick:
    """
    TradingView-style High/Low Renko.

    Rules
    -----
    1. H/L used as thresholds only — never as brick prices.
    2. Brick close moves by exactly +/- brick_size.
    3. Candle direction determines processing order (no bullish bias).
    """

    @staticmethod
    def calculate(
        df: pd.DataFrame,
        brick_size: float,
        anchor: Optional[float] = None,
    ) -> pd.DataFrame:
        """
        Convert OHLC DataFrame to HL-Wick Renko bricks.

        Parameters
        ----------
        df:         DataFrame with columns [timestamp, open, high, low, close]
        brick_size: fixed brick height (must be > 0)
        anchor:     optional deterministic grid anchor (round number)

        Returns
        -------
        DataFrame with [timestamp, open, high, low, close, direction]
        """
        required = {"timestamp", "open", "high", "low", "close"}
        if not required.issubset(df.columns):
            raise ValueError(f"Missing columns: {required - set(df.columns)}")
        if not brick_size or brick_size <= 0:
            raise ValueError(f"brick_size={brick_size} must be > 0")

        # B-1 PERF FIX: replace iterrows() with direct numpy array access.
        # iterrows() creates a pandas Series object per row — on 5,760 rows
        # (4 days × 1440 1-min bars) this takes ~1-2s.  Extracting raw numpy
        # arrays and zipping them is 10-30× faster with identical logic.
        # No algorithmic change — same anchor, same brick grid, same output.
        ts_arr      = pd.to_datetime(df["timestamp"].values)
        high_arr    = df["high"].values.astype(float)
        low_arr     = df["low"].values.astype(float)
        close_arr   = df["close"].values.astype(float)
        open_arr    = df["open"].values.astype(float)
        bricks: list[dict] = []

        # Deterministic grid anchor — floor-to-grid avoids Python banker's rounding
        # which rounds 2.5 -> 2 and 3.5 -> 4, shifting the entire brick chain
        # on exact half-brick midpoints.  Floor is always safe and reproducible.
        if anchor is not None:
            last_close = anchor
        else:
            import math
            first_mid  = (high_arr[0] + low_arr[0]) / 2
            last_close = math.floor(first_mid / brick_size) * brick_size

        for ts, high, low, close, open_ in zip(ts_arr, high_arr, low_arr, close_arr, open_arr):
            bullish = close >= open_
            moved   = False

            if bullish:
                while high >= last_close + brick_size:
                    b_open = last_close
                    last_close += brick_size
                    bricks.append({"timestamp": ts, "open": b_open,
                                   "close": last_close, "direction": 1})
                    moved = True
                if not moved:
                    while low <= last_close - brick_size:
                        b_open = last_close
                        last_close -= brick_size
                        bricks.append({"timestamp": ts, "open": b_open,
                                       "close": last_close, "direction": -1})
            else:
                while low <= last_close - brick_size:
                    b_open = last_close
                    last_close -= brick_size
                    bricks.append({"timestamp": ts, "open": b_open,
                                   "close": last_close, "direction": -1})
                    moved = True
                if not moved:
                    while high >= last_close + brick_size:
                        b_open = last_close
                        last_close += brick_size
                        bricks.append({"timestamp": ts, "open": b_open,
                                       "close": last_close, "direction": 1})

        if not bricks:
            return pd.DataFrame(
                columns=["timestamp", "open", "high", "low", "close", "direction"]
            )

        out = pd.DataFrame(bricks)
        out["high"] = out[["open", "close"]].max(axis=1)
        out["low"]  = out[["open", "close"]].min(axis=1)
        return out[["timestamp", "open", "high", "low", "close", "direction"]].reset_index(drop=True)


# ── Close Traditional Renko ───────────────────────────────────────────────────

class RenkoCloseTraditional:
    """
    Close-based traditional Renko.
    Continuation = 1 box; Reversal = 2 boxes (TradingView-compatible).
    """

    @staticmethod
    def calculate(
        df: pd.DataFrame,
        brick_size: float,
        anchor: Optional[float] = None,
    ) -> pd.DataFrame:
        """
        Convert OHLC (uses only 'close') to Close Renko bricks.

        Parameters
        ----------
        df:         DataFrame with columns [timestamp, close]
        brick_size: fixed brick height
        anchor:     optional deterministic grid anchor

        Returns
        -------
        DataFrame with [timestamp, open, high, low, close, direction]
        """
        required = {"timestamp", "close"}
        if not required.issubset(df.columns):
            raise ValueError(f"Missing columns: {required - set(df.columns)}")
        if not brick_size or brick_size <= 0:
            raise ValueError(f"brick_size={brick_size} must be > 0")

        # B-2 PERF FIX: replace iterrows() with direct numpy array access.
        # Same logic, same output — 10-30x faster on large OHLC frames.
        ts_arr    = pd.to_datetime(df["timestamp"].values)
        close_arr = df["close"].values.astype(float)
        bricks: list[dict] = []

        if anchor is not None:
            last_close = anchor
        else:
            import math
            last_close = math.floor(close_arr[0] / brick_size) * brick_size

        direction = 0   # 0=unknown, 1=up, -1=down

        for ts, price in zip(ts_arr, close_arr):

            while True:
                if direction == 0:
                    if price >= last_close + brick_size:
                        last_close += brick_size
                        bricks.append({"timestamp": ts, "open": last_close - brick_size,
                                       "close": last_close, "direction": 1})
                        direction = 1
                        continue
                    if price <= last_close - brick_size:
                        last_close -= brick_size
                        bricks.append({"timestamp": ts, "open": last_close + brick_size,
                                       "close": last_close, "direction": -1})
                        direction = -1
                        continue
                    break

                if direction == 1:
                    if price >= last_close + brick_size:
                        last_close += brick_size
                        bricks.append({"timestamp": ts, "open": last_close - brick_size,
                                       "close": last_close, "direction": 1})
                        continue
                    if price <= last_close - 2 * brick_size:
                        while price <= last_close - brick_size:
                            last_close -= brick_size
                            bricks.append({"timestamp": ts, "open": last_close + brick_size,
                                           "close": last_close, "direction": -1})
                        direction = -1
                        continue
                    break

                if direction == -1:
                    if price <= last_close - brick_size:
                        last_close -= brick_size
                        bricks.append({"timestamp": ts, "open": last_close + brick_size,
                                       "close": last_close, "direction": -1})
                        continue
                    if price >= last_close + 2 * brick_size:
                        while price >= last_close + brick_size:
                            last_close += brick_size
                            bricks.append({"timestamp": ts, "open": last_close - brick_size,
                                           "close": last_close, "direction": 1})
                        direction = 1
                        continue
                    break

        if not bricks:
            return pd.DataFrame(
                columns=["timestamp", "open", "high", "low", "close", "direction"]
            )

        out = pd.DataFrame(bricks)
        out["high"] = out[["open", "close"]].max(axis=1)
        out["low"]  = out[["open", "close"]].min(axis=1)
        return out[["timestamp", "open", "high", "low", "close", "direction"]].reset_index(drop=True)


# ── Renko Annotator ───────────────────────────────────────────────────────────

class RenkoAnnotator:
    """
    Adds quality-scoring columns to any Renko DataFrame.
    These columns are consumed by SignalQualityScorer — never recomputed there.

    Added columns
    -------------
    Renko_Brick         float  — brick close price
    Colour_Brick_Count  int    — consecutive same-direction brick count
    zlema9              float  — zero-lag EMA(9) of brick price
    HH, HL, LH, LL      bool   — swing structure flags (last confirmed swing)
    Last_High           float  — last confirmed swing high
    Last_Low            float  — last confirmed swing low
    Signal              str    — HL-based reversal signal (BUYEN/SELEX/None)
    Close_Signal        str    — Close-based reversal signal (BUYRE/SELRE/None)
    """

    _ZLEMA_PERIOD   = 9
    _SWING_ORDER    = 5
    _SWING_K        = 3

    @classmethod
    def annotate(cls, df: pd.DataFrame, brick_size: float) -> pd.DataFrame:
        """
        Annotate a Renko brick DataFrame in-place.

        Parameters
        ----------
        df:         Renko DataFrame from RenkoHLWick or RenkoCloseTraditional
        brick_size: used to set brick_size_hint for SignalQualityScorer

        Returns
        -------
        Annotated DataFrame (same index, additional columns)
        """
        if df is None or df.empty:
            return df

        df = df.copy()
        df["Renko_Brick"] = df["close"].astype(float)
        df["brick_size_hint"] = brick_size

        # ── Consecutive brick count ─────────────────────────────────────────
        df["Colour_Brick_Count"] = cls._consecutive_count(df["direction"].tolist())

        # ── Zero-lag EMA ────────────────────────────────────────────────────
        df["zlema9"] = cls._zlema(df["Renko_Brick"], period=cls._ZLEMA_PERIOD)

        # ── Swing structure ─────────────────────────────────────────────────
        df = cls._add_swings(df)

        return df

    # ── Private helpers ─────────────────────────────────────────────────────────

    @staticmethod
    def _consecutive_count(directions: list[int]) -> list[int]:
        """Return per-row count of consecutive same-direction bricks.

        B-9 PERF FIX: replace Python for-loop with numpy vectorized approach.

        Algorithm
        ---------
        1. Mark positions where direction changes (boolean array).
        2. Assign a group ID to each brick via cumsum of the change markers.
        3. Record the start index of each group.
        4. Count within group = current index - group_start + 1.

        Zero Python iteration — runs in ~0.1ms on 800 bricks vs ~0.3ms
        for the old loop.  Output is identical to the original for-loop.
        """
        if not directions:
            return []
        arr     = np.array(directions, dtype=int)
        # True at index 0 and wherever direction changes
        changes          = np.empty(len(arr), dtype=bool)
        changes[0]       = True
        changes[1:]      = arr[1:] != arr[:-1]
        # Group IDs: 0 for first run, 1 for second, etc.
        group_id         = np.cumsum(changes) - 1
        # Start index of each group
        group_starts     = np.where(changes)[0]
        # Count within group = index - group_start + 1
        return (np.arange(len(arr)) - group_starts[group_id] + 1).tolist()

    @staticmethod
    def _zlema(series: pd.Series, period: int = 9) -> pd.Series:
        """Zero-lag EMA: 2*EMA(n) - EMA(EMA(n))."""
        ema1 = series.ewm(span=period, adjust=False).mean()
        ema2 = ema1.ewm(span=period, adjust=False).mean()
        return 2 * ema1 - ema2

    @classmethod
    def _add_swings(cls, df: pd.DataFrame) -> pd.DataFrame:
        """Annotate HH / HL / LH / LL and Last_High / Last_Low."""
        n = len(df)
        if n < cls._SWING_ORDER * 2 + 1:
            for col in ("HH", "HL", "LH", "LL", "Last_High", "Last_Low"):
                df[col] = False if col not in ("Last_High", "Last_Low") else np.nan
            return df

        prices = df["Renko_Brick"].values

        hh_idx = cls._higher_highs(prices)
        hl_idx = cls._higher_lows(prices)
        lh_idx = cls._lower_highs(prices)
        ll_idx = cls._lower_lows(prices)

        df["HH"] = False
        df["HL"] = False
        df["LH"] = False
        df["LL"] = False

        for idx in hh_idx:
            df.at[df.index[idx], "HH"] = True
        for idx in hl_idx:
            df.at[df.index[idx], "HL"] = True
        for idx in lh_idx:
            df.at[df.index[idx], "LH"] = True
        for idx in ll_idx:
            df.at[df.index[idx], "LL"] = True

        # Rolling last confirmed high/low
        df["Last_High"] = np.where(df["HH"] | df["LH"], df["Renko_Brick"], np.nan)
        df["Last_Low"]  = np.where(df["LL"] | df["HL"], df["Renko_Brick"], np.nan)
        df["Last_High"] = df["Last_High"].ffill()
        df["Last_Low"]  = df["Last_Low"].ffill()

        return df

    @classmethod
    def _higher_highs(cls, data: np.ndarray) -> list[int]:
        return cls._swing_indices(data, is_high=True, higher=True)

    @classmethod
    def _higher_lows(cls, data: np.ndarray) -> list[int]:
        return cls._swing_indices(data, is_high=False, higher=True)

    @classmethod
    def _lower_highs(cls, data: np.ndarray) -> list[int]:
        return cls._swing_indices(data, is_high=True, higher=False)

    @classmethod
    def _lower_lows(cls, data: np.ndarray) -> list[int]:
        return cls._swing_indices(data, is_high=False, higher=False)

    @classmethod
    def _swing_indices(
        cls, data: np.ndarray, is_high: bool, higher: bool
    ) -> list[int]:
        if is_high:
            candidate_idx = argrelextrema(data, np.greater, order=cls._SWING_ORDER)[0]
        else:
            candidate_idx = argrelextrema(data, np.less, order=cls._SWING_ORDER)[0]

        if len(candidate_idx) < 2:
            return []

        values    = data[candidate_idx]
        confirmed = []
        dq        = deque(maxlen=cls._SWING_K)

        for i, idx in enumerate(candidate_idx):
            if i > 0:
                went_higher = values[i] > values[i - 1]
                if went_higher != higher:
                    dq.clear()
            dq.append(idx)
            if len(dq) == cls._SWING_K:
                last = dq[-1]
                if not confirmed or confirmed[-1] != last:
                    confirmed.append(last)
        return confirmed


# ── Hybrid Signal Generator ───────────────────────────────────────────────────

class HybridRenkoGenerator:
    """
    Runs both Renko variants, annotates them, and merges signals.
    Replaces ru._generate_hybrid_base_signals().

    Output columns added to the HL Renko DataFrame
    -----------------------------------------------
    Signal        — BUYEN | SELEX | None  (HL-based)
    Close_Signal  — BUYRE | SELRE | None  (Close-based)
    Close_Price   — close brick price at Close_Signal
    """

    def __init__(self, entry_offset_bricks: float = 0.5) -> None:
        self._offset = entry_offset_bricks

    def generate(
        self,
        ohlc_df:    pd.DataFrame,
        brick_size: float,
        anchor:     Optional[float] = None,
    ) -> pd.DataFrame:
        """
        Parameters
        ----------
        ohlc_df:    1-minute OHLC DataFrame
        brick_size: Renko brick size
        anchor:     optional deterministic grid anchor

        Returns
        -------
        Annotated HL Renko DataFrame with all signal columns
        """
        if ohlc_df is None or ohlc_df.empty:
            return pd.DataFrame()

        # ── Build both Renko variants ──────────────────────────────────────
        hl_df    = RenkoHLWick.calculate(ohlc_df, brick_size, anchor)
        close_df = RenkoCloseTraditional.calculate(ohlc_df, brick_size, anchor)

        if hl_df.empty:
            log.warning("HybridRenkoGenerator: HL renko returned empty for brick=%s", brick_size)
            return pd.DataFrame()

        # ── Annotate HL ────────────────────────────────────────────────────
        hl_df = RenkoAnnotator.annotate(hl_df, brick_size)

        # ── Add HL signals ─────────────────────────────────────────────────
        hl_df = self._add_hl_signals(hl_df, brick_size)

        # ── Merge Close signals onto HL frame ──────────────────────────────
        if not close_df.empty:
            close_annotated = RenkoAnnotator.annotate(close_df.copy(), brick_size)
            close_annotated = self._add_close_signals(close_annotated, brick_size)
            hl_df = self._merge_close_signals(hl_df, close_annotated)
        else:
            hl_df["Close_Signal"] = None
            hl_df["Close_Price"]  = np.nan

        return hl_df

    # ── Private ─────────────────────────────────────────────────────────────────

    def _add_hl_signals(self, df: pd.DataFrame, brick_size: float) -> pd.DataFrame:
        """Annotate BUYEN / SELEX based on 2-brick reversal logic with Last_High/Low.

        B-3 PERF FIX: replace iterrows() with zip(arrays).
        iterrows() on 700-800 Renko bricks creates a Series per row; zip on raw
        numpy arrays is 10-30x faster.  Logic is identical — same state machine,
        same signals, same ZLEMA gates.
        """
        signals    = []
        last_high  = None
        last_low   = None
        position   = None

        zlema_col = "zlema9" if "zlema9" in df.columns else None
        brick_arr = df["Renko_Brick"].values.astype(float)
        if zlema_col:
            zlema_arr = df[zlema_col].values.astype(float)
        else:
            zlema_arr = np.full(len(df), np.nan)

        for brick, zlema_raw in zip(brick_arr, zlema_arr):
            zlema = None if np.isnan(zlema_raw) else float(zlema_raw)

            sig = None
            if position is None:
                # BUG-ENTRY-5 FIX: Initial BUYEN (from flat, first entry) now
                # requires ZLEMA confirmation — same gate applied to:
                #   • initial SELEX (was already gated)
                #   • reversal BUYEN from SELL position (was already gated)
                # Without this, an initial CALL entry could fire during a
                # downtrend (brick bouncing from low while ZLEMA still points down).
                if (
                    last_low is not None
                    and brick >= last_low + 2 * brick_size
                    and (zlema is None or brick > zlema)
                ):
                    sig      = "BUYEN"
                    position = "BUY"
                    last_high = brick
                    last_low  = None
                elif (
                    last_high is not None
                    and brick <= last_high - 2 * brick_size
                    and (zlema is None or brick < zlema)
                ):
                    sig      = "SELEX"
                    position = "SELL"
                    last_low  = brick
                    last_high = None

            elif position == "BUY":
                # F-01 FIX: Add ZLEMA gate — mirrors the SELL→BUY and flat→SELL paths.
                # Previously this branch had NO ZLEMA check, allowing SELEX to fire
                # on any 2-brick pullback from peak regardless of trend direction.
                # A valid reversal from a BUY must also confirm brick is below ZLEMA.
                if (
                    brick <= last_high - 2 * brick_size
                    and (zlema is None or brick < zlema)
                ):
                    sig      = "SELEX"
                    position = "SELL"
                    last_low  = brick
                    last_high = None

            elif position == "SELL":
                if (
                    brick >= last_low + 2 * brick_size
                    and (zlema is None or brick > zlema)
                ):
                    sig      = "BUYEN"
                    position = "BUY"
                    last_high = brick
                    last_low  = None

            if last_low is None or brick < last_low:
                last_low = brick
            if last_high is None or brick > last_high:
                last_high = brick

            signals.append(sig)

        df["Signal"] = signals
        return df

    def _add_close_signals(self, df: pd.DataFrame, brick_size: float) -> pd.DataFrame:
        """Generate BUYRE / SELRE from close Renko direction changes.

        B-3 PERF FIX: replace iterrows() with zip(arrays).
        """
        signals     = []
        close_prices = []
        prev_dir    = None

        dir_arr   = df["direction"].values.astype(int) if "direction" in df.columns else np.zeros(len(df), int)
        brick_arr = df["Renko_Brick"].values.astype(float)

        for d, brick in zip(dir_arr, brick_arr):
            sig   = None

            if prev_dir is not None and d != prev_dir:
                if d == 1:
                    sig = "BUYRE"
                elif d == -1:
                    sig = "SELRE"

            signals.append(sig)
            close_prices.append(brick if sig else np.nan)
            prev_dir = d

        df["Close_Signal"] = signals
        df["Close_Price"]  = close_prices
        return df

    @staticmethod
    def _merge_close_signals(
        hl_df: pd.DataFrame, close_df: pd.DataFrame
    ) -> pd.DataFrame:
        """
        Align Close signals onto HL frame by matching timestamps.
        When multiple close bricks share the same timestamp as an HL brick,
        take the last signal.
        """
        if "Close_Signal" not in close_df.columns:
            hl_df["Close_Signal"] = None
            hl_df["Close_Price"]  = np.nan
            return hl_df

        close_sig_by_ts = (
            close_df[close_df["Close_Signal"].notna()]
            .groupby("timestamp")
            .last()[["Close_Signal", "Close_Price"]]
            .reset_index()
        )

        if close_sig_by_ts.empty:
            hl_df["Close_Signal"] = None
            hl_df["Close_Price"]  = np.nan
            return hl_df

        return hl_df.merge(close_sig_by_ts, on="timestamp", how="left")
