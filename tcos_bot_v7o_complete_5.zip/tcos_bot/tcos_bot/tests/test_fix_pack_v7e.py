"""
test_fix_pack_v7e.py
====================
Unit tests for all fixes applied in the v7e Minimum Safe Fix Pack.

Covers:
  F-01  ZLEMA gate on SELEX-from-BUY
  F-02  close_signal_window = 3 + per-instrument override
  F-03  LTP-deviation zombie check
  F-04  confirm_mins=1.5, tight_bricks=1.5 + per-instrument override
  F-05  MCX min_combined_size override = 0.25
  F-06  fast_fail gate (feature-flagged, default False)
  F-07  momentum_failure exit (feature-flagged, default False)
  F-08  retest_mode (feature-flagged, default False)
  F-09  min_entry_bricks_nse_upgraded (feature-flagged, default False)
  F-10  signal_exit_block <5min = 120s (was 300s)
  F-11  daily_target_rs time gate (target_lock_after_time)
  CZ    Close_Signal ZLEMA gate
"""
from __future__ import annotations

import time
from datetime import datetime
from unittest.mock import patch
from zoneinfo import ZoneInfo

import pandas as pd
import pytest

IST = ZoneInfo("Asia/Kolkata")


# ─────────────────────────────────────────────────────────────────────────────
# F-01: ZLEMA gate on SELEX-from-BUY
# ─────────────────────────────────────────────────────────────────────────────

class TestF01ZlemaSelex:
    """SELEX-from-BUY must require brick < zlema (same as all other signal paths)."""

    def _build_renko(self, prices_up: int, prices_down: int, brick: float = 12.0):
        from tcos_bot.signals.renko_engine import HybridRenkoGenerator
        base = 24900.0
        all_prices = (
            [base + i * brick for i in range(prices_up)]
            + [base + prices_up * brick - i * brick for i in range(1, prices_down + 1)]
        )
        rows = [
            {
                "timestamp": pd.Timestamp("2024-01-15 09:30") + pd.Timedelta(minutes=i * 5),
                "open": p, "high": p + brick * 0.5, "low": p - brick * 0.5, "close": p,
            }
            for i, p in enumerate(all_prices)
        ]
        return HybridRenkoGenerator().generate(pd.DataFrame(rows), brick_size=brick)

    def test_selex_blocked_when_zlema_pointing_up(self):
        """12 up, 3 down — ZLEMA still up → SELEX must NOT fire from BUY position."""
        out = self._build_renko(12, 3)
        # Last row must not have SELEX if ZLEMA > brick
        last = out.iloc[-1]
        if pd.notna(last.get("zlema9")) and pd.notna(last.get("Renko_Brick")):
            if float(last["Renko_Brick"]) > float(last["zlema9"]):
                assert last["Signal"] != "SELEX", (
                    f"SELEX fired with brick={last['Renko_Brick']:.1f} > zlema={last['zlema9']:.2f}"
                )

    def test_selex_fires_when_zlema_pointing_down(self):
        """6 up, 10 down — ZLEMA pointing down → SELEX must fire."""
        out = self._build_renko(6, 10)
        selex_rows = out[out["Signal"] == "SELEX"]
        assert not selex_rows.empty, "SELEX should fire when ZLEMA points down"
        # All SELEX rows must have brick < zlema
        for _, row in selex_rows.iterrows():
            brick_val = float(row.get("Renko_Brick", 0) or 0)
            zlema_val = float(row.get("zlema9", 0) or 0)
            if zlema_val > 0:
                assert brick_val < zlema_val, (
                    f"SELEX fired with brick={brick_val:.1f} >= zlema={zlema_val:.2f}"
                )

    def test_buyen_from_sell_still_zlema_gated(self):
        """SELL→BUY path is pre-existing ZLEMA gate — must still work correctly."""
        out = self._build_renko(6, 10)
        buyen_rows = out[out["Signal"] == "BUYEN"]
        # All BUYEN rows must have brick > zlema (or zlema unavailable)
        for _, row in buyen_rows.iterrows():
            brick_val = float(row.get("Renko_Brick", 0) or 0)
            zlema_val = float(row.get("zlema9", 0) or 0)
            if zlema_val > 0 and brick_val > 0:
                assert brick_val > zlema_val, (
                    f"BUYEN fired with brick={brick_val:.1f} <= zlema={zlema_val:.2f}"
                )


# ─────────────────────────────────────────────────────────────────────────────
# F-02: close_signal_window = 3
# ─────────────────────────────────────────────────────────────────────────────

class TestF02CloseSignalWindow:
    def test_default_window_is_3(self):
        from tcos_bot.config.settings import cfg
        assert cfg.entry.close_signal_window_bricks == 3, (
            f"Expected 3, got {cfg.entry.close_signal_window_bricks}"
        )

    def test_override_dict_exists_and_empty_by_default(self):
        from tcos_bot.config.settings import cfg
        assert hasattr(cfg.entry, "close_signal_window_override")
        assert isinstance(cfg.entry.close_signal_window_override, dict)

    def test_per_instrument_override_is_respected(self):
        """Simulate the override read logic in _extract_signal."""
        import re
        from tcos_bot.config.settings import cfg
        symbol   = "GOLDM"
        root     = re.match(r"^([A-Z]+)", symbol.upper()).group(1)
        override = {"GOLDM": 5}
        window   = override.get(root, cfg.entry.close_signal_window_bricks)
        assert window == 5

    def test_nifty_uses_global_window_3(self):
        import re
        from tcos_bot.config.settings import cfg
        symbol = "NIFTY"
        root   = re.match(r"^([A-Z]+)", symbol.upper()).group(1)
        window = cfg.entry.close_signal_window_override.get(
            root, cfg.entry.close_signal_window_bricks
        )
        assert window == 3


# ─────────────────────────────────────────────────────────────────────────────
# F-03: LTP-deviation zombie check
# ─────────────────────────────────────────────────────────────────────────────

class TestF03LtpDeviationZombie:
    def setup_method(self):
        from tcos_bot.signals.signal_generator import SignalGenerator
        self.gen = SignalGenerator()
        self.now_ts = datetime.now(tz=IST).isoformat()

    def test_zombie_blocked_when_ltp_3b_away(self):
        with patch("tcos_bot.signals.signal_generator.ltp_store") as m:
            m.get.return_value = (25036.0, 5.0)   # 3b above signal 25000
            result = self.gen._is_zombie(
                self.now_ts, "BUYEN", "NIFTY", {},
                signal_price=25000.0, brick_size=12.0,
            )
        assert result is True, "Should be zombie: deviation=3b > threshold=2b"

    def test_zombie_allowed_when_ltp_1pt5b_away(self):
        with patch("tcos_bot.signals.signal_generator.ltp_store") as m:
            m.get.return_value = (25018.0, 5.0)   # 1.5b above signal
            result = self.gen._is_zombie(
                self.now_ts, "BUYEN", "NIFTY", {},
                signal_price=25000.0, brick_size=12.0,
            )
        assert result is False, "Should not be zombie: deviation=1.5b < threshold=2b"

    def test_stale_ltp_skips_deviation_check(self):
        """LTP age > 30s → fail-open, no block."""
        with patch("tcos_bot.signals.signal_generator.ltp_store") as m:
            m.get.return_value = (26000.0, 60.0)  # stale: age=60s
            result = self.gen._is_zombie(
                self.now_ts, "BUYEN", "NIFTY", {},
                signal_price=25000.0, brick_size=12.0,
            )
        assert result is False, "Stale LTP should skip deviation check (fail-open)"

    def test_no_signal_price_bypasses_check(self):
        """signal_price=None → old behaviour, check not applied."""
        with patch("tcos_bot.signals.signal_generator.ltp_store") as m:
            m.get.return_value = (30000.0, 5.0)   # way off, but no signal_price
            result = self.gen._is_zombie(
                self.now_ts, "BUYEN", "NIFTY", {},
                signal_price=None, brick_size=12.0,
            )
        assert result is False

    def test_config_field_exists_with_correct_default(self):
        from tcos_bot.config.settings import cfg
        assert hasattr(cfg.entry, "zombie_ltp_deviation_bricks")
        assert cfg.entry.zombie_ltp_deviation_bricks == 2.0


# ─────────────────────────────────────────────────────────────────────────────
# F-04: confirm_mins=1.5, tight_bricks=1.5 + per-instrument override
# ─────────────────────────────────────────────────────────────────────────────

class TestF04ConfirmTighten:
    def test_config_confirm_mins_is_1pt5(self):
        from tcos_bot.config.settings import cfg
        assert cfg.stop.confirm_mins == 1.5, f"Expected 1.5, got {cfg.stop.confirm_mins}"

    def test_config_tight_bricks_is_1pt5(self):
        from tcos_bot.config.settings import cfg
        assert cfg.stop.tight_bricks == 1.5, f"Expected 1.5, got {cfg.stop.tight_bricks}"

    def test_nifty_uses_global_confirm_mins(self):
        from tcos_bot.risk.risk_manager import TrailingStopManager
        mgr = TrailingStopManager()
        mgr.initialise("NIFTY", "CALL", entry_price=25000, brick_size=12)
        state = mgr._stops["NIFTY"]
        assert state["confirm_mins"] == 1.5, f"NIFTY confirm_mins={state['confirm_mins']}"

    def test_nifty_tight_stop_is_entry_minus_1pt5b(self):
        from tcos_bot.risk.risk_manager import TrailingStopManager
        mgr = TrailingStopManager()
        entry, bs = 25000.0, 12.0
        mgr.initialise("NIFTY", "CALL", entry_price=entry, brick_size=bs)
        state = mgr._stops["NIFTY"]
        expected = round(entry - 1.5 * bs, 2)
        assert abs(state["tight_stop"] - expected) < 0.01, (
            f"tight_stop={state['tight_stop']} expected={expected}"
        )

    def test_goldm_uses_override_confirm_mins_4(self):
        from tcos_bot.risk.risk_manager import TrailingStopManager
        mgr = TrailingStopManager()
        mgr.initialise("GOLDM", "CALL", entry_price=70000, brick_size=150)
        state = mgr._stops["GOLDM"]
        assert state["confirm_mins"] == 4.0, f"GOLDM confirm_mins={state['confirm_mins']}"

    def test_silverm_uses_override_confirm_mins_4(self):
        from tcos_bot.risk.risk_manager import TrailingStopManager
        mgr = TrailingStopManager()
        mgr.initialise("SILVERM", "PUT", entry_price=90000, brick_size=500)
        state = mgr._stops["SILVERM"]
        assert state["confirm_mins"] == 4.0, f"SILVERM confirm_mins={state['confirm_mins']}"

    def test_banknifty_tight_stop_is_entry_minus_1pt5b(self):
        from tcos_bot.risk.risk_manager import TrailingStopManager
        mgr = TrailingStopManager()
        entry, bs = 50000.0, 40.0
        mgr.initialise("BANKNIFTY", "CALL", entry_price=entry, brick_size=bs)
        state = mgr._stops["BANKNIFTY"]
        expected = round(entry - 1.5 * bs, 2)
        assert abs(state["tight_stop"] - expected) < 0.01


# ─────────────────────────────────────────────────────────────────────────────
# F-05: MCX min_combined_size override = 0.25
# ─────────────────────────────────────────────────────────────────────────────

class TestF05McxMinCombinedSize:
    def test_global_min_size_is_0pt40(self):
        from tcos_bot.config.settings import cfg
        assert cfg.signal_quality.min_combined_size == 0.40

    def test_mcx_override_is_0pt25(self):
        from tcos_bot.config.settings import cfg
        overrides = cfg.signal_quality.min_combined_size_override
        assert overrides.get("MCX") == 0.25
        assert overrides.get("MCX_FUT") == 0.25
        assert overrides.get("MCX_OPT") == 0.25

    def test_mcx_grade_b_not_blocked_by_floor(self):
        """Grade-B (0.5) × UNKNOWN (0.5) = 0.25; MCX floor=0.25 → allowed."""
        from tcos_bot.config.settings import cfg
        size      = 0.25
        exchange  = "MCX"
        overrides = cfg.signal_quality.min_combined_size_override
        min_size  = overrides.get(exchange, cfg.signal_quality.min_combined_size)
        assert size >= min_size, f"MCX Grade-B size={size} should not be blocked by floor={min_size}"

    def test_nse_grade_b_still_blocked(self):
        """NSE Grade-B (0.5) × UNKNOWN (0.5) = 0.25 < 0.40 → blocked."""
        from tcos_bot.config.settings import cfg
        size      = 0.25
        exchange  = "NSE_INDEX"
        overrides = cfg.signal_quality.min_combined_size_override
        min_size  = overrides.get(exchange, cfg.signal_quality.min_combined_size)
        assert size < min_size, "NSE Grade-B+UNKNOWN should still be blocked"

    def test_nse_grade_a_passes_floor(self):
        """NSE Grade-A (1.0) × UNKNOWN (0.5) = 0.50 >= 0.40 → allowed."""
        from tcos_bot.config.settings import cfg
        size      = 0.50
        exchange  = "NSE_INDEX"
        overrides = cfg.signal_quality.min_combined_size_override
        min_size  = overrides.get(exchange, cfg.signal_quality.min_combined_size)
        assert size >= min_size


# ─────────────────────────────────────────────────────────────────────────────
# F-06: fast_fail gate (default False)
# ─────────────────────────────────────────────────────────────────────────────

class TestF06FastFail:
    def test_default_is_false(self):
        from tcos_bot.config.settings import cfg
        assert cfg.stop.fast_fail_enabled is False

    def test_no_tighten_when_disabled(self):
        from tcos_bot.risk.risk_manager import TrailingStopManager
        mgr = TrailingStopManager()
        mgr.initialise("NIFTY", "CALL", entry_price=25000, brick_size=12)
        mgr._stops["NIFTY"]["entry_time"] = time.monotonic() - 30
        stop_before = mgr.get_stop_price("NIFTY")
        mgr.update("NIFTY", ltp=24988.0, new_brick=24988.0)
        assert mgr.get_stop_price("NIFTY") == stop_before, "No tighten when flag=False"

    def test_tighten_fires_when_enabled(self):
        from tcos_bot.risk.risk_manager import TrailingStopManager

        class EnabledCfg:
            enabled = True
            fast_fail_enabled       = True
            fast_fail_secs          = 90.0
            fast_fail_profit_bricks = 0.5
            fast_fail_tight_bricks  = 1.0
            on_brick_confirm        = True
            breakeven_after         = 3.0
            trail_start_after       = 3.0
            trail_distance          = 1.0
            adaptive_trail          = False
            breakeven_buffer        = 0.25

        mgr = TrailingStopManager()
        mgr._cfg = EnabledCfg()
        entry, bs = 25000.0, 12.0
        mgr.initialise("NIFTY_FF", "CALL", entry_price=entry, brick_size=bs)
        mgr._stops["NIFTY_FF"]["entry_time"] = time.monotonic() - 30
        mgr.update("NIFTY_FF", ltp=24988.0, new_brick=24988.0)
        expected = round(entry - 1.0 * bs, 2)
        assert abs(mgr.get_stop_price("NIFTY_FF") - expected) < 0.01

    def test_no_tighten_when_peak_above_threshold(self):
        from tcos_bot.risk.risk_manager import TrailingStopManager

        class EnabledCfg:
            enabled = True
            fast_fail_enabled       = True
            fast_fail_secs          = 90.0
            fast_fail_profit_bricks = 0.5
            fast_fail_tight_bricks  = 1.0
            on_brick_confirm        = True
            breakeven_after         = 3.0
            trail_start_after       = 3.0
            trail_distance          = 1.0
            adaptive_trail          = False
            breakeven_buffer        = 0.25

        mgr = TrailingStopManager()
        mgr._cfg = EnabledCfg()
        entry, bs = 25000.0, 12.0
        mgr.initialise("NIFTY_FF2", "CALL", entry_price=entry, brick_size=bs)
        mgr._stops["NIFTY_FF2"]["entry_time"] = time.monotonic() - 30
        # Peak already above threshold (0.6b profit)
        mgr._stops["NIFTY_FF2"]["peak_price"] = entry + 0.6 * bs
        stop_before = mgr.get_stop_price("NIFTY_FF2")
        mgr.update("NIFTY_FF2", ltp=24988.0, new_brick=24988.0)
        assert mgr.get_stop_price("NIFTY_FF2") == stop_before, "Should not fast-fail when profitable"


# ─────────────────────────────────────────────────────────────────────────────
# F-07: momentum_failure (default False)
# ─────────────────────────────────────────────────────────────────────────────

class TestF07MomentumFailure:
    def test_default_is_false(self):
        from tcos_bot.config.settings import cfg
        assert cfg.stop.momentum_failure_enabled is False

    def test_config_fields_exist(self):
        from tcos_bot.config.settings import cfg
        assert hasattr(cfg.stop, "momentum_failure_window_bricks")
        assert hasattr(cfg.stop, "momentum_failure_profit_bricks")
        assert cfg.stop.momentum_failure_window_bricks == 2
        assert cfg.stop.momentum_failure_profit_bricks == 0.5

    def test_state_dicts_in_engine_init(self):
        import inspect
        from tcos_bot.core.engine import TradingEngine
        src = inspect.getsource(TradingEngine.__init__)
        assert "_mf_entry_brick_count" in src
        assert "_mf_entry_direction"   in src
        assert "_mf_bricks_since"      in src

    def test_state_cleanup_in_close_hooks(self):
        import inspect
        from tcos_bot.core.engine import TradingEngine
        src = inspect.getsource(TradingEngine._fire_close_hooks)
        assert "_mf_entry_brick_count.pop" in src
        assert "_mf_entry_direction.pop"   in src
        assert "_mf_bricks_since.pop"      in src

    def test_check_method_exists(self):
        from tcos_bot.core.engine import TradingEngine
        assert hasattr(TradingEngine, "_check_momentum_failure")


# ─────────────────────────────────────────────────────────────────────────────
# F-08: retest_mode (default False)
# ─────────────────────────────────────────────────────────────────────────────

class TestF08RetestMode:
    def test_default_is_false(self):
        from tcos_bot.config.settings import cfg
        assert cfg.stop.retest_mode_enabled is False

    def test_config_fields_exist(self):
        from tcos_bot.config.settings import cfg
        assert hasattr(cfg.stop, "retest_proximity_bricks")
        assert hasattr(cfg.stop, "retest_fail_bricks")
        assert hasattr(cfg.stop, "retest_confirm_bricks")

    def test_state_dict_in_engine_init(self):
        import inspect
        from tcos_bot.core.engine import TradingEngine
        src = inspect.getsource(TradingEngine.__init__)
        assert "_retest_state" in src

    def test_state_cleanup_in_close_hooks(self):
        import inspect
        from tcos_bot.core.engine import TradingEngine
        src = inspect.getsource(TradingEngine._fire_close_hooks)
        assert "_retest_state.pop" in src

    def test_check_method_exists(self):
        from tcos_bot.core.engine import TradingEngine
        assert hasattr(TradingEngine, "_check_retest_state")


# ─────────────────────────────────────────────────────────────────────────────
# F-09: min_entry_bricks_nse_upgraded (default False)
# ─────────────────────────────────────────────────────────────────────────────

class TestF09NseUpgrade:
    def test_flag_is_false_phase2(self):
        """Phase 2: flag is False — per-instrument override dict controls CBC."""
        from tcos_bot.config.settings import cfg
        assert cfg.entry.min_entry_bricks_nse_upgraded is False, (
            "Phase 2: nse_upgraded must be False"
        )

    def test_nifty_explicitly_3_in_override(self):
        """Phase 2: NIFTY=3 set explicitly in override dict."""
        from tcos_bot.config.settings import cfg
        overrides = cfg.entry.min_entry_bricks_override
        assert overrides.get("NIFTY") == 3, (
            f"NIFTY must be 3 in override dict. Got: {overrides.get('NIFTY')}"
        )

    def test_upgrade_path_returns_3_for_nifty(self):
        """Simulate flag=True code path from signal_generator.process()."""
        from tcos_bot.config.settings import cfg
        import re
        root      = "NIFTY"
        override  = cfg.entry.min_entry_bricks_override
        min_b     = override.get(root, cfg.entry.min_entry_bricks)
        nse_roots = {"NIFTY", "BANKNIFTY", "SENSEX", "BANKEX", "FINNIFTY", "MIDCPNIFTY"}
        # Simulate flag=True
        if True and root in nse_roots:
            min_b = max(min_b, 3)
        assert min_b == 3

    def test_mcx_not_affected_by_upgrade_flag(self):
        """MCX instruments use global default (3), flag has no effect on them."""
        from tcos_bot.config.settings import cfg
        root     = "CRUDEOIL"
        override = cfg.entry.min_entry_bricks_override
        min_b    = override.get(root, cfg.entry.min_entry_bricks)
        assert min_b == 3   # global default, no override


# ─────────────────────────────────────────────────────────────────────────────
# F-10: signal_exit_block <5min = 120s
# ─────────────────────────────────────────────────────────────────────────────

class TestF10SignalExitBlock:
    def setup_method(self):
        from tcos_bot.risk.risk_manager import WhipsawCooldownTracker
        self.tracker = WhipsawCooldownTracker()

    def _get_window(self, symbol: str, direction: str) -> int:
        with self.tracker._lock:
            return self.tracker._signal_exit_windows.get((symbol, direction), -1)

    def test_short_trade_block_is_120s(self):
        """< 5 min held → 120s (was 300s)."""
        self.tracker.record_signal_exit("NIFTY", "CALL", trade_held_secs=90)
        assert self._get_window("NIFTY", "CALL") == 120

    def test_medium_trade_block_is_180s(self):
        """5–15 min held → 180s (unchanged)."""
        self.tracker.record_signal_exit("NIFTY", "PUT", trade_held_secs=480)
        assert self._get_window("NIFTY", "PUT") == 180

    def test_long_trade_block_is_120s(self):
        """> 15 min held → 120s (unchanged, reads signal_exit_block_secs)."""
        self.tracker.record_signal_exit("BANKNIFTY", "CALL", trade_held_secs=1200)
        assert self._get_window("BANKNIFTY", "CALL") == 120

    def test_zero_held_secs_is_120s(self):
        """Edge case: 0s held → 120s block."""
        self.tracker.record_signal_exit("NIFTY", "CALL", trade_held_secs=0)
        assert self._get_window("NIFTY", "CALL") == 120

    def test_exactly_299s_is_120s(self):
        """299s = just under 5 min → 120s."""
        self.tracker.record_signal_exit("NIFTY", "CALL", trade_held_secs=299)
        assert self._get_window("NIFTY", "CALL") == 120

    def test_exactly_300s_is_180s(self):
        """300s = exactly 5 min → 180s bucket."""
        self.tracker.record_signal_exit("NIFTY", "CALL", trade_held_secs=300)
        assert self._get_window("NIFTY", "CALL") == 180


# ─────────────────────────────────────────────────────────────────────────────
# F-11: daily_target_rs time gate
# ─────────────────────────────────────────────────────────────────────────────

class TestF11DailyTargetTimeGate:
    def setup_method(self):
        from tcos_bot.risk.risk_manager import RiskEngine
        self.engine = RiskEngine()

    def _fake_now(self, h: int, m: int):
        return datetime(2024, 1, 15, h, m, 0, tzinfo=IST)

    def test_config_target_lock_after_time_is_13_30(self):
        from tcos_bot.config.settings import cfg
        assert cfg.risk_engine.target_lock_after_time == "13:30"

    def test_before_lock_time_returns_false(self):
        with patch("tcos_bot.risk.risk_manager._now", return_value=self._fake_now(11, 0)):
            assert self.engine._is_past_target_lock_time() is False

    def test_after_lock_time_returns_true(self):
        with patch("tcos_bot.risk.risk_manager._now", return_value=self._fake_now(14, 0)):
            assert self.engine._is_past_target_lock_time() is True

    def test_exactly_at_lock_time_returns_true(self):
        with patch("tcos_bot.risk.risk_manager._now", return_value=self._fake_now(13, 30)):
            assert self.engine._is_past_target_lock_time() is True

    def test_one_minute_before_lock_time_returns_false(self):
        with patch("tcos_bot.risk.risk_manager._now", return_value=self._fake_now(13, 29)):
            assert self.engine._is_past_target_lock_time() is False

    def test_empty_string_always_locks(self):
        """Empty target_lock_after_time → always return True (old behaviour)."""
        class MockCfg:
            target_lock_after_time = ""
            daily_target_rs = 15000.0
            max_daily_loss_rs = 50000.0
            max_consecutive_losses = 3
        self.engine._cfg = MockCfg()
        assert self.engine._is_past_target_lock_time() is True


# ─────────────────────────────────────────────────────────────────────────────
# CLOSE_SIGNAL_ZLEMA_GATE
# ─────────────────────────────────────────────────────────────────────────────

class TestCloseSignalZlemaGate:
    def test_config_field_exists_and_true(self):
        from tcos_bot.config.settings import cfg
        assert hasattr(cfg.entry, "close_signal_zlema_gate")
        assert cfg.entry.close_signal_zlema_gate is True

    def test_gate_logic_blocks_buyen_when_brick_below_zlema(self):
        """When brick < zlema, BUYEN Close fallback must be blocked."""
        # Simulate the gate condition check from _extract_signal
        brick_val = 24984.0
        zlema_val = 25009.0
        signal    = "BUYEN"
        _should_block = signal == "BUYEN" and brick_val <= zlema_val
        assert _should_block, "BUYEN should be blocked when brick below ZLEMA"

    def test_gate_logic_blocks_selex_when_brick_above_zlema(self):
        """When brick > zlema, SELEX Close fallback must be blocked."""
        brick_val = 25030.0
        zlema_val = 25009.0
        signal    = "SELEX"
        _should_block = signal == "SELEX" and brick_val >= zlema_val
        assert _should_block, "SELEX should be blocked when brick above ZLEMA"

    def test_gate_logic_allows_buyen_when_brick_above_zlema(self):
        brick_val = 25030.0
        zlema_val = 25009.0
        signal    = "BUYEN"
        _should_block = signal == "BUYEN" and brick_val <= zlema_val
        assert not _should_block, "BUYEN should be allowed when brick above ZLEMA"

    def test_gate_logic_allows_selex_when_brick_below_zlema(self):
        brick_val = 24984.0
        zlema_val = 25009.0
        signal    = "SELEX"
        _should_block = signal == "SELEX" and brick_val >= zlema_val
        assert not _should_block, "SELEX should be allowed when brick below ZLEMA"

    def test_gate_skipped_when_zlema_zero(self):
        """Zero ZLEMA (no data) → gate transparent."""
        brick_val = 24984.0
        zlema_val = 0.0
        # Gate condition: _brick_val > 0 and _zlema_val > 0 → both must be positive
        gate_active = brick_val > 0 and zlema_val > 0
        assert not gate_active, "Gate should be skipped when ZLEMA is zero"
