"""
test_bug_fixes_v7m.py — Two bug fixes confirmed by live log analysis.

Written BEFORE implementation. All tests must FAIL before code changes
and PASS after.

BUG 1: SAME_CYCLE_SIGNAL_EXIT_BLOCK wrong signal type
  signal_generator.py ~line 734:
    _opp_entry_action = "BUYCL" if ws_direction == "CALL" else "BUYPT"
  BUG: Looks for the ENTRY signal of opp direction in trade_manager.
  But an exited CALL has renko_signal="SELCL" (exit signal), NOT "BUYCL".
  Result: block never fires → PUT enters 3s after CALL SIGNAL_EXIT.
  Evidence: April 8 10:08 BNF PUT entered immediately after CALL SIGNAL_EXIT.

  Fix: change to _opp_exit_action = "SELPT" if ws_direction == "CALL" else "SELCL"

BUG 2: option_resolver picks nearest expiry with no DTE floor
  option_resolver.py ~line 329: picks first exp > today, no min_dte check.
  Result: SENSEX Apr 9 (1 DTE) selected → extreme theta → winners net ₹130
  instead of ₹700. Evidence: April 8 tradebook.

  Fix: add min_dte_days config (default 5), skip expiries below floor.
"""
import pandas as pd
import pytest
from datetime import date, timedelta
from unittest.mock import MagicMock, patch


# ═══════════════════════════════════════════════════════════════════════════
# BUG 1 TESTS — SAME_CYCLE_SIGNAL_EXIT_BLOCK correct signal type
# ═══════════════════════════════════════════════════════════════════════════

def _make_tm_with_signal_exit(sym, exit_signal, close_reason="SIGNAL_EXIT"):
    """Build a trade_manager DataFrame simulating a just-closed position."""
    return pd.DataFrame([{
        "symbol":       sym,
        "exchange":     "NSE_INDEX",
        "renko_signal": exit_signal,   # "SELCL" for CALL exit, "SELPT" for PUT exit
        "order_status": "CLOSED",
        "close_reason": close_reason,
        "entry_price":  55260.0,
        "quantity":     30,
        "timestamp":    "2026-04-08 10:08:38",
    }])


def _check_same_cycle_block(tm, symbol, ws_direction):
    """
    Run ONLY the SAME_CYCLE_SIGNAL_EXIT_BLOCK logic as it appears in
    signal_generator._create_entry. Returns True if block fires.

    After the fix, _opp_exit_action = "SELPT" if CALL else "SELCL".
    """
    # This mirrors the fixed code path
    _opp_exit_action = "SELPT" if ws_direction == "CALL" else "SELCL"
    blocked = (
        not tm[
            (tm["symbol"] == symbol) &
            (tm["renko_signal"] == _opp_exit_action) &
            (tm["order_status"] == "CLOSED") &
            (tm["close_reason"].str.upper().str.contains("SIGNAL_EXIT", na=False))
        ].empty
    )
    return blocked


def _check_same_cycle_block_OLD(tm, symbol, ws_direction):
    """The OLD (buggy) logic — used to verify it was actually wrong."""
    _opp_entry_action = "BUYCL" if ws_direction == "CALL" else "BUYPT"
    blocked = (
        not tm[
            (tm["symbol"] == symbol) &
            (tm["renko_signal"] == _opp_entry_action) &
            (tm["order_status"] == "CLOSED") &
            (tm["close_reason"].str.upper().str.contains("SIGNAL_EXIT", na=False))
        ].empty
    )
    return blocked


def test_b1_old_logic_fails_to_block_put_after_call_signal_exit():
    """
    PROVE THE BUG: Old logic looks for renko_signal="BUYPT" (wrong).
    The CALL exit has renko_signal="SELCL". Old logic finds nothing → no block.
    """
    tm = _make_tm_with_signal_exit("BANKNIFTY", exit_signal="SELCL")
    blocked = _check_same_cycle_block_OLD(tm, "BANKNIFTY", ws_direction="PUT")
    assert not blocked, (
        "Old logic should NOT block (this proves the bug existed). "
        "It looks for 'BUYPT' but exit row has 'SELCL'."
    )


def test_b2_fixed_logic_blocks_put_after_call_signal_exit():
    """
    After fix: entering PUT checks for SELCL (CALL exit signal) → FOUND → BLOCK.
    This is the April 8 10:08 BNF scenario.
    """
    tm = _make_tm_with_signal_exit("BANKNIFTY", exit_signal="SELCL")
    blocked = _check_same_cycle_block(tm, "BANKNIFTY", ws_direction="PUT")
    assert blocked, (
        "Fixed logic must BLOCK PUT entry when BANKNIFTY CALL was just "
        "SIGNAL_EXIT closed (renko_signal='SELCL' in same cycle). "
        "April 8 10:08: this block would have prevented -₹1,632 BNF PE loss."
    )


def test_b3_fixed_logic_blocks_call_after_put_signal_exit():
    """
    Symmetric: entering CALL after PUT SIGNAL_EXIT → looks for SELPT → BLOCK.
    """
    tm = _make_tm_with_signal_exit("SENSEX", exit_signal="SELPT")
    blocked = _check_same_cycle_block(tm, "SENSEX", ws_direction="CALL")
    assert blocked, (
        "Fixed logic must BLOCK CALL entry when SENSEX PUT was just "
        "SIGNAL_EXIT closed (renko_signal='SELPT' in same cycle)."
    )


def test_b4_no_block_when_exit_was_stop_not_signal_exit():
    """
    If the CALL exited via STOP_EXIT (not SIGNAL_EXIT), same-cycle block must NOT fire.
    Stop exits are not the problem — they're clean exits.
    """
    tm = _make_tm_with_signal_exit("NIFTY", exit_signal="SELCL",
                                   close_reason="STOP_EXIT")
    blocked = _check_same_cycle_block(tm, "NIFTY", ws_direction="PUT")
    assert not blocked, (
        "SAME_CYCLE block must NOT fire when previous exit was STOP_EXIT. "
        "Only SIGNAL_EXIT triggers the block."
    )


def test_b5_no_block_when_different_symbol():
    """Block must not fire for a different symbol's SIGNAL_EXIT."""
    tm = _make_tm_with_signal_exit("SENSEX", exit_signal="SELCL")
    blocked = _check_same_cycle_block(tm, "BANKNIFTY", ws_direction="PUT")
    assert not blocked, (
        "SAME_CYCLE block must NOT fire for BANKNIFTY when SENSEX was "
        "the one that SIGNAL_EXITed."
    )


def test_b6_no_block_when_trade_manager_empty():
    """Empty trade_manager → no block."""
    tm = pd.DataFrame(columns=["symbol","exchange","renko_signal",
                                "order_status","close_reason"])
    blocked = _check_same_cycle_block(tm, "BANKNIFTY", ws_direction="PUT")
    assert not blocked, "Empty TM must not trigger SAME_CYCLE block."


def test_b7_signal_generator_uses_correct_exit_signal():
    """
    Integration: verify signal_generator.py contains the fixed _opp_exit_action
    formula rather than the old _opp_entry_action formula.
    """
    import inspect
    from tcos_bot.signals import signal_generator as sg
    src = inspect.getsource(sg)

    # Fixed code must reference SELPT/SELCL
    assert "SELPT" in src and "SELCL" in src, (
        "signal_generator.py must contain 'SELPT' and 'SELCL' in the "
        "SAME_CYCLE_SIGNAL_EXIT_BLOCK section after fix."
    )
    # The old wrong formula must NOT appear in the same-cycle block context
    # (it could still appear elsewhere for different purposes — we check the
    # specific variable name _opp_entry_action which is the bug)
    # _opp_entry_action now only appears in a comment explaining the fix
    # The actual variable used must be _opp_exit_action
    assert "_opp_exit_action" in src, (
        "signal_generator.py must use '_opp_exit_action' after fix. "
        "The variable was renamed from '_opp_entry_action' to use exit signals."
    )


# ═══════════════════════════════════════════════════════════════════════════
# BUG 2 TESTS — Minimum DTE for option expiry selection
# ═══════════════════════════════════════════════════════════════════════════

def test_b8_min_dte_config_exists():
    """min_dte_days must exist in settings with default value of 5."""
    from tcos_bot.config.settings import cfg
    assert hasattr(cfg.option_quality, "min_dte_days"), (
        "cfg.option_quality.min_dte_days must exist after fix. "
        "Controls minimum days-to-expiry for option selection."
    )
    val = cfg.option_quality.min_dte_days
    assert val == 5, (
        f"min_dte_days default must be 5. Got {val}. "
        "5 DTE ensures reasonable delta tracking without extreme theta."
    )


def test_b9_expiry_below_min_dte_skipped():
    """
    Simulate option_resolver expiry selection: expiry with < min_dte_days
    must be skipped. Expiry with >= min_dte_days must be selected.
    """
    from tcos_bot.config.settings import cfg
    today = date(2026, 4, 8)
    min_dte = cfg.option_quality.min_dte_days  # should be 5

    expiry_map = {
        date(2026, 4, 9):  "SENSEX09APR2677400PE",   # 1 DTE → must skip
        date(2026, 4, 16): "SENSEX16APR2677400PE",   # 8 DTE → must select
        date(2026, 4, 23): "SENSEX23APR2677400PE",   # 15 DTE
    }

    # Simulate the fixed selection logic
    selected = None
    for exp in sorted(expiry_map):
        dte = (exp - today).days
        if exp > today and dte >= min_dte:
            selected = exp
            break

    assert selected == date(2026, 4, 16), (
        f"With min_dte=5, April 9 (1 DTE) must be skipped. "
        f"April 16 (8 DTE) must be selected. Got: {selected}. "
        f"Evidence: April 8 SENSEX09APR selected (1 DTE) → only ₹130 on "
        f"a winning 74pt trade due to extreme theta."
    )


def test_b10_expiry_exactly_at_min_dte_selected():
    """Expiry at exactly min_dte_days must be selected (>= not >)."""
    from tcos_bot.config.settings import cfg
    today = date(2026, 4, 8)
    min_dte = cfg.option_quality.min_dte_days  # 5

    # April 13 = exactly 5 DTE from April 8
    expiry_map = {
        date(2026, 4, 9):  "SYMBOL09APR",   # 1 DTE → skip
        date(2026, 4, 13): "SYMBOL13APR",   # 5 DTE → select (= min_dte)
        date(2026, 4, 16): "SYMBOL16APR",   # 8 DTE
    }

    selected = None
    for exp in sorted(expiry_map):
        dte = (exp - today).days
        if exp > today and dte >= min_dte:
            selected = exp
            break

    assert selected == date(2026, 4, 13), (
        f"Expiry exactly at min_dte={min_dte} must be selected (>=, not >). "
        f"Got: {selected}."
    )


def test_b11_fallback_when_all_expiries_below_min_dte():
    """
    If NO expiry meets min_dte, fall back to nearest future expiry.
    Never leave the trade without an option.
    """
    from tcos_bot.config.settings import cfg
    today = date(2026, 4, 8)
    min_dte = cfg.option_quality.min_dte_days  # 5

    expiry_map = {
        date(2026, 4, 9):  "SYMBOL09APR",   # 1 DTE only option
    }

    selected = None
    for exp in sorted(expiry_map):
        dte = (exp - today).days
        if exp > today and dte >= min_dte:
            selected = exp
            break

    # Fallback: if nothing meets min_dte, pick nearest
    if selected is None and expiry_map:
        future = {e: s for e, s in expiry_map.items() if e > today}
        if future:
            selected = min(future)

    assert selected == date(2026, 4, 9), (
        "When no expiry meets min_dte, fallback to nearest future expiry. "
        "Never leave unresolved."
    )


def test_b12_april8_sensex_scenario_would_pick_apr16():
    """
    Reproduce the exact April 8 SENSEX scenario.
    With min_dte=5, Apr 9 (1 DTE) is skipped, Apr 16 (8 DTE) selected.
    """
    from tcos_bot.config.settings import cfg
    today = date(2026, 4, 8)
    min_dte = cfg.option_quality.min_dte_days

    # What was available on April 8 for SENSEX
    expiry_map = {
        date(2026, 4, 9):  "SENSEX09APR2677400PE",
        date(2026, 4, 16): "SENSEX16APR2677400PE",
        date(2026, 4, 23): "SENSEX23APR2677400PE",
        date(2026, 4, 30): "SENSEX30APR2677400PE",
    }

    selected = None
    for exp in sorted(expiry_map):
        dte = (exp - today).days
        if exp > today and dte >= min_dte:
            selected = expiry_map[exp]
            break
    if selected is None:
        selected = expiry_map[min(e for e in expiry_map if e > today)]

    assert selected == "SENSEX16APR2677400PE", (
        f"April 8 SENSEX: with min_dte=5, must pick SENSEX16APR (8 DTE) "
        f"not SENSEX09APR (1 DTE which only gave ₹130 on a 74pt winner). "
        f"Got: {selected}"
    )


# ═══════════════════════════════════════════════════════════════════════════
# BUG 1 SIDE EFFECT TESTS — Time filter required on SAME_CYCLE check
# ═══════════════════════════════════════════════════════════════════════════

def _make_tm_with_aged_signal_exit(sym, exit_signal, age_seconds):
    """Build TM row with a timestamp N seconds in the past."""
    from datetime import datetime, timedelta
    from tcos_bot.config.settings import IST
    ts = (datetime.now(tz=IST) - timedelta(seconds=age_seconds)).strftime(
        "%Y-%m-%d %H:%M:%S"
    )
    return pd.DataFrame([{
        "symbol":       sym,
        "exchange":     "NSE_INDEX",
        "renko_signal": exit_signal,
        "order_status": "CLOSED",
        "close_reason": "SIGNAL_EXIT",
        "entry_price":  55260.0,
        "quantity":     30,
        "timestamp":    ts,
    }])


def _check_same_cycle_with_time_filter(tm, symbol, ws_direction, window_secs=15):
    """
    The correct SAME_CYCLE check — exit signal type AND recent timestamp.
    Only catches same-cycle events (within window_secs seconds).
    """
    from datetime import datetime, timedelta
    from tcos_bot.config.settings import IST
    import pandas as _pd

    _opp_exit_action = "SELPT" if ws_direction == "CALL" else "SELCL"
    _cutoff = datetime.now(tz=IST) - timedelta(seconds=window_secs)

    candidates = tm[
        (tm["symbol"] == symbol) &
        (tm["renko_signal"] == _opp_exit_action) &
        (tm["order_status"] == "CLOSED") &
        (tm["close_reason"].str.upper().str.contains("SIGNAL_EXIT", na=False))
    ]
    if candidates.empty:
        return False

    # Apply time filter
    try:
        ts_series = _pd.to_datetime(candidates["timestamp"])
        if ts_series.dt.tz is None:
            ts_series = ts_series.dt.tz_localize(IST)
        else:
            ts_series = ts_series.dt.tz_convert(IST)
        recent = (ts_series >= _cutoff).any()
        return bool(recent)
    except Exception:
        return False


def test_b13_same_cycle_block_fires_for_recent_signal_exit():
    """
    SIGNAL_EXIT 5 seconds ago (same cycle) → block must fire.
    """
    tm = _make_tm_with_aged_signal_exit("BANKNIFTY", "SELCL", age_seconds=5)
    blocked = _check_same_cycle_with_time_filter(tm, "BANKNIFTY", "PUT")
    assert blocked, (
        "SAME_CYCLE block must fire when CALL SIGNAL_EXIT was 5s ago (same cycle)."
    )


def test_b14_same_cycle_block_does_not_fire_for_old_signal_exit():
    """
    CRITICAL SIDE EFFECT TEST:
    SIGNAL_EXIT 84 minutes ago (April 8: 10:08 → 11:32) must NOT block.
    Old code (without time filter) would fire on this → permanently blocks PUT.
    """
    tm = _make_tm_with_aged_signal_exit("BANKNIFTY", "SELCL", age_seconds=84*60)
    blocked = _check_same_cycle_with_time_filter(tm, "BANKNIFTY", "PUT")
    assert not blocked, (
        "SAME_CYCLE block must NOT fire 84 minutes after SIGNAL_EXIT. "
        "April 8: 10:08 BNF CALL SIGNAL_EXIT must not block 11:32 BNF PUT. "
        "Without time filter: old session rows permanently block future entries."
    )


def test_b15_same_cycle_block_does_not_fire_for_130s_old():
    """
    SIGNAL_EXIT 130 seconds ago (just past the 120s cooldown window).
    signal_exit_too_recent returns False at this point.
    SAME_CYCLE check must also NOT fire — it's not the same cycle.
    """
    tm = _make_tm_with_aged_signal_exit("SENSEX", "SELCL", age_seconds=130)
    blocked = _check_same_cycle_with_time_filter(tm, "SENSEX", "PUT")
    assert not blocked, (
        "SAME_CYCLE block must NOT fire 130s after SIGNAL_EXIT. "
        "At 130s the 120s cooldown has expired and a genuine signal should enter. "
        "Window=15s ensures only true same-cycle events are caught."
    )


def test_b16_same_cycle_boundary_at_window_edge():
    """
    SIGNAL_EXIT exactly at window boundary (15s) must be caught.
    14s ago → caught. 16s ago → not caught.
    """
    tm_14s = _make_tm_with_aged_signal_exit("NIFTY", "SELCL", age_seconds=14)
    tm_16s = _make_tm_with_aged_signal_exit("NIFTY", "SELCL", age_seconds=16)

    assert _check_same_cycle_with_time_filter(tm_14s, "NIFTY", "PUT"), \
        "14s ago (within 15s window) must be caught."
    assert not _check_same_cycle_with_time_filter(tm_16s, "NIFTY", "PUT"), \
        "16s ago (outside 15s window) must NOT be caught."


def test_b17_signal_generator_has_time_filter_in_same_cycle_block():
    """
    Verify signal_generator.py has the time filter applied to SAME_CYCLE check.
    """
    import inspect
    from tcos_bot.signals import signal_generator as sg
    src = inspect.getsource(sg)
    assert "timedelta" in src or "seconds=15" in src or "_cutoff" in src, (
        "signal_generator.py SAME_CYCLE block must include a time filter "
        "to prevent session-level false blocks from old SIGNAL_EXIT rows."
    )
