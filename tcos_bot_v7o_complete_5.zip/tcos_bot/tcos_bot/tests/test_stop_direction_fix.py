"""
test_stop_direction_fix.py — Stop trigger must only fire on opposite-direction brick.

Written BEFORE implementation. All tests must FAIL before code changes
and PASS after.

BUG: engine.py stop trigger checks brick price against stop level but
does NOT check brick direction. A DOWN brick can fire a PUT stop exit
when trailing stop slips below the confirmed brick (race condition).

Evidence: April 9 NIFTY PUT exited with no reverse brick visible on
1-min Renko chart. Log: brick=23,880 ≥ stop=23,866 (ltp=23,854).
Last confirmed brick was a DOWN brick (market still falling).
Stop fired incorrectly because trailing stop (updated by LTP at 23,854)
slipped below the confirmed brick (23,880).

Fix: in engine.py stop trigger:
  SELST (exit CALL): skip if brick direction == +1 (UP = CALL's direction)
  SELSP (exit PUT):  skip if brick direction == -1 (DOWN = PUT's direction)

Only fire on:
  SELST: DOWN brick (-1) crossing the stop level ← genuine reversal for CALL
  SELSP: UP brick (+1) crossing the stop level   ← genuine reversal for PUT

Direction=0 or None (unknown/renko unavailable): allow stop to fire (safe default).
"""
import pandas as pd
import pytest
from unittest.mock import MagicMock, patch


# ── helper: build minimal renko_df with one last brick ───────────────────────

def _make_renko(brick_price: float, direction: int, brick_col="Renko_Brick"):
    """Return a one-row renko_df representing the latest confirmed brick."""
    return pd.DataFrame([{
        brick_col:            brick_price,
        "direction":          direction,
        "Colour_Brick_Count": 2,
        "zlema9":             brick_price,
    }])


def _should_trigger(action: str, brick_price: float, brick_dir: int,
                    stop_price: float) -> bool:
    """
    Simulate the FIXED engine stop-trigger logic.
    Returns True if the stop should fire, False if it should be skipped.
    
    action:      "SELST" (exit CALL) or "SELSP" (exit PUT)
    brick_price: last confirmed Renko brick close price
    brick_dir:   +1 (UP), -1 (DOWN), 0 (unknown)
    stop_price:  current stop level (entry_price in the stop row)
    """
    # Direction guard — the core fix
    if action == "SELST":             # exit CALL: only DOWN brick can trigger
        if brick_dir == 1:            # UP brick = CALL's direction → skip
            return False
    else:                             # exit PUT: only UP brick can trigger
        if brick_dir == -1:           # DOWN brick = PUT's direction → skip
            return False

    # Price check (unchanged from original)
    if action == "SELST":
        return brick_price <= stop_price   # CALL stop: brick went DOWN past stop
    else:
        return brick_price >= stop_price   # PUT stop: brick went UP past stop


def _should_trigger_OLD(action: str, brick_price: float,
                         stop_price: float) -> bool:
    """The OLD (buggy) logic — no direction check."""
    if action == "SELST":
        return brick_price <= stop_price
    else:
        return brick_price >= stop_price


# ═══════════════════════════════════════════════════════════════════════════
# PROVE THE BUG — old logic fires incorrectly
# ═══════════════════════════════════════════════════════════════════════════

def test_p1_old_logic_fires_put_stop_on_down_brick():
    """
    PROVE THE BUG: April 9 scenario.
    PUT stop at 23,866. Last brick 23,880 (DOWN). LTP 23,854 (falling).
    Old logic: 23,880 >= 23,866 → fires → WRONG (market still falling for PUT)
    """
    fired = _should_trigger_OLD("SELSP", brick_price=23880, stop_price=23866)
    assert fired, (
        "Old logic must fire (proving the bug). "
        "23,880 >= 23,866 fires the PUT stop even on a DOWN brick. "
        "April 9: NIFTY PUT exited with no reverse brick visible."
    )


def test_p2_old_logic_fires_call_stop_on_up_brick():
    """
    PROVE THE BUG: symmetric for CALL.
    CALL stop at 23,900. Last brick 23,888 (UP). Market still rising.
    Old logic: 23,888 <= 23,900 → fires → WRONG (market going UP = CALL direction)
    """
    fired = _should_trigger_OLD("SELST", brick_price=23888, stop_price=23900)
    assert fired, (
        "Old logic must fire on UP brick for CALL stop (proving symmetric bug). "
        "23,888 <= 23,900 fires even though UP brick = CALL's direction."
    )


# ═══════════════════════════════════════════════════════════════════════════
# PUT STOP (SELSP) — only UP brick should trigger
# ═══════════════════════════════════════════════════════════════════════════

def test_s1_put_stop_does_not_fire_on_down_brick():
    """
    April 9 NIFTY scenario: PUT stop at 23,866, DOWN brick at 23,880.
    Fixed logic: direction=-1 → SKIP → no exit.
    Market still falling — holding PUT is correct.
    """
    fired = _should_trigger("SELSP", brick_price=23880, brick_dir=-1,
                            stop_price=23866)
    assert not fired, (
        "PUT stop must NOT fire on DOWN brick (direction=-1). "
        "April 9: 23,880 DOWN brick should not have exited the NIFTY PUT. "
        "Market was still falling at LTP=23,854."
    )


def test_s2_put_stop_fires_on_up_brick_above_stop():
    """
    Genuine PUT reversal: UP brick at 23,880 with stop at 23,866.
    Fixed logic: direction=+1 → check price → 23,880 >= 23,866 → EXIT.
    """
    fired = _should_trigger("SELSP", brick_price=23880, brick_dir=+1,
                            stop_price=23866)
    assert fired, (
        "PUT stop MUST fire on UP brick (direction=+1) that crosses stop. "
        "23,880 >= 23,866 with direction=+1 = genuine reversal → exit."
    )


def test_s3_put_stop_up_brick_below_stop_no_exit():
    """
    UP brick at 23,860 but stop at 23,866. Brick hasn't reached stop yet.
    Even though it's an UP brick (correct direction for trigger), price
    hasn't crossed the stop level — no exit.
    """
    fired = _should_trigger("SELSP", brick_price=23860, brick_dir=+1,
                            stop_price=23866)
    assert not fired, (
        "PUT stop must NOT fire when UP brick (23,860) is below stop (23,866). "
        "Price hasn't crossed the stop level yet."
    )


def test_s4_put_stop_down_brick_below_stop_no_exit():
    """
    DOWN brick at 23,850 with stop at 23,866.
    Direction=-1 → skip regardless of price. No exit.
    """
    fired = _should_trigger("SELSP", brick_price=23850, brick_dir=-1,
                            stop_price=23866)
    assert not fired, (
        "PUT stop must NOT fire on DOWN brick even when brick is below stop level. "
        "DOWN brick = PUT's direction = skip always."
    )


def test_s5_put_stop_up_brick_exactly_at_stop():
    """
    UP brick exactly at stop level (23,866 == 23,866). Must fire (>= check).
    """
    fired = _should_trigger("SELSP", brick_price=23866, brick_dir=+1,
                            stop_price=23866)
    assert fired, (
        "PUT stop MUST fire when UP brick equals stop exactly (>= boundary). "
        "23,866 >= 23,866 with direction=+1 → EXIT."
    )


def test_s6_put_stop_unknown_direction_fires_if_price_crosses():
    """
    Direction = 0 (unknown/missing column). Safe default: allow stop to fire.
    23,880 >= 23,866 with direction=0 → EXIT (don't block unknown direction).
    """
    fired = _should_trigger("SELSP", brick_price=23880, brick_dir=0,
                            stop_price=23866)
    assert fired, (
        "PUT stop must fire when direction=0 (unknown) if price crosses stop. "
        "Unknown direction → safe default → allow stop. "
        "Prevents Renko column issues from blocking all stops."
    )


# ═══════════════════════════════════════════════════════════════════════════
# CALL STOP (SELST) — only DOWN brick should trigger
# ═══════════════════════════════════════════════════════════════════════════

def test_s7_call_stop_does_not_fire_on_up_brick():
    """
    CALL stop at 23,900. UP brick at 23,888 (market still rising for CALL).
    Fixed logic: direction=+1 → SKIP → no exit.
    """
    fired = _should_trigger("SELST", brick_price=23888, brick_dir=+1,
                            stop_price=23900)
    assert not fired, (
        "CALL stop must NOT fire on UP brick (direction=+1). "
        "UP brick = CALL's direction → skip. Market rising = hold CALL."
    )


def test_s8_call_stop_fires_on_down_brick_below_stop():
    """
    Genuine CALL reversal: DOWN brick at 23,888 with stop at 23,900.
    direction=-1 → check price → 23,888 <= 23,900 → EXIT.
    """
    fired = _should_trigger("SELST", brick_price=23888, brick_dir=-1,
                            stop_price=23900)
    assert fired, (
        "CALL stop MUST fire on DOWN brick (direction=-1) that crosses stop. "
        "23,888 <= 23,900 with direction=-1 = genuine reversal → exit."
    )


def test_s9_call_stop_down_brick_above_stop_no_exit():
    """
    DOWN brick at 23,912 but stop at 23,900. Brick hasn't crossed stop.
    direction=-1 allowed but price check fails: 23,912 > 23,900 → no exit.
    """
    fired = _should_trigger("SELST", brick_price=23912, brick_dir=-1,
                            stop_price=23900)
    assert not fired, (
        "CALL stop must NOT fire when DOWN brick (23,912) is above stop (23,900). "
        "Direction=-1 allowed but price 23,912 > 23,900 → no trigger."
    )


def test_s10_call_stop_up_brick_above_stop_no_exit():
    """
    UP brick at 23,912 with stop at 23,900.
    direction=+1 → skip → no exit (regardless of price).
    """
    fired = _should_trigger("SELST", brick_price=23912, brick_dir=+1,
                            stop_price=23900)
    assert not fired, (
        "CALL stop must NOT fire on UP brick even when brick is above stop. "
        "UP brick = CALL's direction → skip always."
    )


def test_s11_call_stop_unknown_direction_fires_if_price_crosses():
    """
    Direction = 0 (unknown). Safe default: allow stop to fire.
    23,888 <= 23,900 with direction=0 → EXIT.
    """
    fired = _should_trigger("SELST", brick_price=23888, brick_dir=0,
                            stop_price=23900)
    assert fired, (
        "CALL stop must fire when direction=0 (unknown) if price crosses stop. "
        "Unknown direction → safe default → allow stop."
    )


# ═══════════════════════════════════════════════════════════════════════════
# FULL SCENARIO TESTS
# ═══════════════════════════════════════════════════════════════════════════

def test_s12_april9_nifty_put_scenario_not_triggered():
    """
    Exact April 9 NIFTY PUT scenario from the log:
      brick=23,880 (DOWN), stop=23,866, ltp=23,854
    With direction fix: must NOT trigger.
    """
    # The DOWN brick at 23,880 should NOT exit the PUT
    fired = _should_trigger("SELSP", brick_price=23880.0, brick_dir=-1,
                            stop_price=23866.0)
    assert not fired, (
        "April 9 exact scenario: PUT stop must NOT fire. "
        "brick=23,880 (DOWN), stop=23,866. "
        "This is the race condition: LTP trailed stop below confirmed brick. "
        "With fix: DOWN brick skipped → trade holds → rides further downtrend."
    )


def test_s13_april9_nifty_genuine_reversal_triggers():
    """
    After April 9 scenario: if market genuinely reverses UP.
    UP brick at 23,880 with stop at 23,866 → must trigger.
    """
    fired = _should_trigger("SELSP", brick_price=23880.0, brick_dir=+1,
                            stop_price=23866.0)
    assert fired, (
        "After direction fix: genuine reversal (UP brick at 23,880, "
        "stop=23,866) must still trigger the PUT stop exit. "
        "First UP brick crossing the stop = confirmed reversal → exit."
    )


def test_s14_initial_stop_call_fires_on_first_down_brick():
    """
    CALL entered. Market immediately reverses. First DOWN brick crosses initial stop.
    Must exit immediately — no delay on initial stop hit.
    """
    # Initial stop 3 bricks below entry (entry=23,100, stop=22,964)
    fired = _should_trigger("SELST", brick_price=22964.0, brick_dir=-1,
                            stop_price=22964.0)
    assert fired, (
        "Initial stop for CALL must fire on first DOWN brick crossing stop. "
        "direction=-1, 22,964 <= 22,964 → EXIT immediately. "
        "No delay on initial adverse move."
    )


def test_s15_initial_stop_put_fires_on_first_up_brick():
    """
    PUT entered. Market immediately reverses UP. First UP brick crosses initial stop.
    Must exit immediately.
    """
    # Initial stop 3 bricks above entry (entry=23,100, stop=23,236)
    fired = _should_trigger("SELSP", brick_price=23236.0, brick_dir=+1,
                            stop_price=23236.0)
    assert fired, (
        "Initial stop for PUT must fire on first UP brick crossing stop. "
        "direction=+1, 23,236 >= 23,236 → EXIT immediately. "
        "No delay on initial adverse move."
    )


def test_s16_engine_direction_check_in_source():
    """
    Verify engine.py contains the direction check after fix.
    """
    import inspect
    from tcos_bot.core import engine as eng
    src = inspect.getsource(eng)
    assert "_brick_direction" in src, (
        "engine.py must contain '_brick_direction' variable after fix. "
        "The direction check must be added to the stop trigger block."
    )
    assert "brick_dir == 1" in src or "_brick_direction == 1" in src, (
        "engine.py must check direction == 1 (UP brick) for PUT stop skip."
    )
    assert "brick_dir == -1" in src or "_brick_direction == -1" in src, (
        "engine.py must check direction == -1 (DOWN brick) for CALL stop skip."
    )
