"""
test_opening_grace.py — Tests for Layer 2: Opening Grace Period.

Written BEFORE implementation. All tests must FAIL before code changes
and PASS after.

Change: Session-aware confirm_mins in risk_manager.initialise()
  Before 09:40 IST → use max(opening_confirm_mins, instrument_override)
  After  09:40 IST → use existing logic (instrument override or global)

Key audit findings:
  - fast_fail unchanged (price-based, separate mechanism)
  - VOLATILE +2min still applied ON TOP of opening_confirm_mins
  - MCX opening entries (before 09:40) also get the grace
  - Instrument overrides that are HIGHER than opening_confirm_mins win
"""
import time
import pytest
from unittest.mock import MagicMock, patch
from datetime import datetime


IST_OFFSET = 5.5 * 3600  # seconds


def _make_state_via_initialise(
    symbol: str,
    direction: str,
    entry_price: float,
    brick_size: float,
    regime: str,
    entry_ist_time: str,   # "HH:MM" string
) -> dict:
    """
    Call TrailingStopManager.initialise() with a mocked IST time.
    Returns the resulting state dict (from _stops).
    """
    from tcos_bot.risk.risk_manager import TrailingStopManager
    from tcos_bot.config.settings import IST

    h, m = map(int, entry_ist_time.split(":"))
    stop = (entry_price - 3 * brick_size if direction == "CALL"
            else entry_price + 3 * brick_size)

    with patch("tcos_bot.risk.risk_manager.cfg") as mock_cfg:
        mock_cfg.stop.confirmation_tighten      = True
        mock_cfg.stop.confirm_bricks            = 1.5
        mock_cfg.stop.confirm_mins              = 1.5
        mock_cfg.stop.tight_bricks              = 1.5
        mock_cfg.stop.initial_stop_bricks       = 3.0
        mock_cfg.stop.catastrophe_extra_bricks  = 1.5
        mock_cfg.stop.fast_fail_enabled         = False
        mock_cfg.stop.use_structural_stop       = False
        mock_cfg.stop.max_struct_stop_bricks    = 99.0
        mock_cfg.stop.max_struct_stop_bricks_override = {}
        mock_cfg.stop.symbol_overrides          = {}
        mock_cfg.stop.confirm_mins_override     = {"GOLDM": 4.0, "SILVERM": 4.0}
        mock_cfg.stop.opening_confirm_mins      = 5.0
        mock_cfg.stop.opening_confirm_cutoff    = "09:40"
        mock_cfg.trailing.breakeven_after       = 2.0
        mock_cfg.trailing.trail_start_after     = 3.0
        mock_cfg.trailing.trail_distance        = 1.0
        mock_cfg.trailing.adaptive_trail        = False

        with patch("tcos_bot.risk.risk_manager.datetime") as mock_dt:
            mock_dt.now.return_value = datetime(2026, 4, 8, h, m, 0)
            mock_dt.side_effect = lambda *a, **kw: datetime(*a, **kw)

            tsm = TrailingStopManager()
            tsm.initialise(
                symbol=symbol,
                direction=direction,
                entry_price=entry_price,
                brick_size=brick_size,
                regime=regime,
            )
            return tsm._stops.get(symbol, {})


# ═══════════════════════════════════════════════════════════════════════════
# T1: Opening entry (09:31) → confirm_mins = 5.0 (grace)
# ═══════════════════════════════════════════════════════════════════════════
def test_t1_opening_entry_gets_grace_period():
    """
    Entry at 09:31 IST (before 09:40 cutoff) must use opening_confirm_mins=5.0.
    This is today's BANKNIFTY/SENSEX scenario at 09:31.
    With 5.0min grace, the tighten would not have fired at 90 seconds.
    """
    state = _make_state_via_initialise(
        symbol="BANKNIFTY", direction="CALL",
        entry_price=55020.0, brick_size=40.0,
        regime="TRENDING", entry_ist_time="09:31",
    )

    confirm_mins = state.get("confirm_mins", 0)
    assert confirm_mins >= 5.0, (
        f"Opening entry at 09:31 must get confirm_mins >= 5.0 (grace). "
        f"Got: {confirm_mins}. "
        f"Today's tighten fired at 1.6min — with 5.0min grace it would not have."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T2: After-opening entry (10:15) → confirm_mins = 1.5 (normal)
# ═══════════════════════════════════════════════════════════════════════════
def test_t2_midday_entry_normal_confirm_mins():
    """
    Entry at 10:15 IST (after 09:40 cutoff) must use normal confirm_mins=1.5.
    The opening grace must NOT affect midday entries.
    """
    state = _make_state_via_initialise(
        symbol="NIFTY", direction="CALL",
        entry_price=23000.0, brick_size=12.0,
        regime="TRENDING", entry_ist_time="10:15",
    )

    confirm_mins = state.get("confirm_mins", 0)
    assert confirm_mins < 5.0, (
        f"Midday entry at 10:15 must NOT get opening grace. "
        f"confirm_mins should be ~1.5, got: {confirm_mins}."
    )
    assert 1.0 <= confirm_mins <= 2.0, (
        f"Midday confirm_mins should be around 1.5. Got: {confirm_mins}."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T3: Entry exactly at 09:40 → normal confirm_mins (cutoff is exclusive)
# ═══════════════════════════════════════════════════════════════════════════
def test_t3_entry_at_cutoff_uses_normal():
    """
    Entry at exactly 09:40 must use normal confirm_mins.
    The opening grace applies BEFORE 09:40, not at or after.
    """
    state = _make_state_via_initialise(
        symbol="SENSEX", direction="CALL",
        entry_price=77000.0, brick_size=50.0,
        regime="TRENDING", entry_ist_time="09:40",
    )

    confirm_mins = state.get("confirm_mins", 0)
    assert confirm_mins < 5.0, (
        f"Entry at 09:40 (cutoff) must NOT get grace. Got: {confirm_mins}."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T4: Opening entry on VOLATILE day → 5.0 + 2.0 = 7.0 min
# ═══════════════════════════════════════════════════════════════════════════
def test_t4_volatile_opening_entry_adds_on_top():
    """
    Opening entry (09:35) on VOLATILE day:
    confirm_mins = opening_confirm_mins(5.0) + VOLATILE_bonus(2.0) = 7.0
    The VOLATILE +2min grace stacks ON TOP of the opening grace.
    """
    state = _make_state_via_initialise(
        symbol="NIFTY", direction="CALL",
        entry_price=23000.0, brick_size=12.0,
        regime="VOLATILE", entry_ist_time="09:35",
    )

    confirm_mins = state.get("confirm_mins", 0)
    assert confirm_mins >= 7.0, (
        f"VOLATILE opening entry must get 5.0 + 2.0 = 7.0min. Got: {confirm_mins}."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T5: GOLDM with override=4.0 at opening → max(5.0, 4.0) = 5.0
# ═══════════════════════════════════════════════════════════════════════════
def test_t5_instrument_override_lower_than_grace_uses_grace():
    """
    GOLDM has confirm_mins_override=4.0.
    Opening grace = 5.0.
    During opening: max(5.0, 4.0) = 5.0 (grace wins).
    """
    state = _make_state_via_initialise(
        symbol="GOLDM", direction="CALL",
        entry_price=85000.0, brick_size=100.0,
        regime="TRENDING", entry_ist_time="09:25",
    )

    confirm_mins = state.get("confirm_mins", 0)
    assert confirm_mins >= 5.0, (
        f"GOLDM opening entry: max(grace=5.0, override=4.0)=5.0. Got: {confirm_mins}."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T6: New config field exists in settings
# ═══════════════════════════════════════════════════════════════════════════
def test_t6_config_fields_exist():
    """
    settings.py must have opening_confirm_mins and opening_confirm_cutoff.
    """
    from tcos_bot.config.settings import cfg
    assert hasattr(cfg.stop, "opening_confirm_mins"), (
        "cfg.stop.opening_confirm_mins must exist after Layer 2."
    )
    assert hasattr(cfg.stop, "opening_confirm_cutoff"), (
        "cfg.stop.opening_confirm_cutoff must exist after Layer 2."
    )
    assert cfg.stop.opening_confirm_mins == 5.0, (
        f"opening_confirm_mins must be 5.0. Got: {cfg.stop.opening_confirm_mins}"
    )
    assert cfg.stop.opening_confirm_cutoff == "09:40", (
        f"opening_confirm_cutoff must be 09:40. Got: {cfg.stop.opening_confirm_cutoff}"
    )


# ═══════════════════════════════════════════════════════════════════════════
# T7: Today reproduced — BNF 09:31 would survive with 5min grace
# ═══════════════════════════════════════════════════════════════════════════
def test_t7_today_bnf_09_31_gets_5min_grace():
    """
    TODAY'S BANKNIFTY entry at 09:31:18.
    Without grace: tightened at 1.6min → exit at +1.40pts.
    With grace: confirm_mins=5.0 → tighten fires at 5min (not 1.6min).
    BANKNIFTY confirmed +1.5b (60pts) by 09:36 → trade confirmed, NOT tightened.
    Result: +691pts instead of +1.40pts.
    """
    state = _make_state_via_initialise(
        symbol="BANKNIFTY", direction="CALL",
        entry_price=55020.0, brick_size=40.0,
        regime="TRENDING", entry_ist_time="09:31",
    )

    confirm_mins = state.get("confirm_mins", 0)

    # The tighten fired at 1.6 minutes today
    # With grace, it should not fire until 5.0 minutes
    assert confirm_mins > 1.6, (
        f"BNF 09:31 must have confirm_mins > 1.6 (today's tighten time). "
        f"Got: {confirm_mins}."
    )
    assert confirm_mins >= 5.0, (
        f"BNF 09:31 must have confirm_mins >= 5.0 (opening grace). "
        f"Got: {confirm_mins}."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T8: Entry at 09:39 still gets grace (last minute before cutoff)
# ═══════════════════════════════════════════════════════════════════════════
def test_t8_entry_at_09_39_still_gets_grace():
    """
    Entry at 09:39 is still before the 09:40 cutoff.
    Must still get the opening grace period.
    """
    state = _make_state_via_initialise(
        symbol="NIFTY", direction="PUT",
        entry_price=23000.0, brick_size=12.0,
        regime="TRENDING", entry_ist_time="09:39",
    )

    confirm_mins = state.get("confirm_mins", 0)
    assert confirm_mins >= 5.0, (
        f"Entry at 09:39 (before 09:40 cutoff) must still get grace. "
        f"Got: {confirm_mins}."
    )
