"""
test_phase2.py — Tests for Phase 2 config changes.

Written BEFORE implementation. All tests must FAIL before config changes
and PASS after.

Changes being tested:
  1. rr_gate_enabled: False → True
  2. no_new_entries_nse: "14:30" → "15:00"
  3. min_entry_bricks_nse_upgraded: True → False
  4. min_entry_bricks_override: NIFTY=3, BANKNIFTY=2, SENSEX=2

Key audit findings validated:
  - CBC=2 safe ONLY because RR gate is enabled simultaneously
  - MCX CBC unchanged at 3
  - Entry at 14:50 safe — EOD squareoff at 15:25 protects
  - VOLATILE half-size preserved (Phase 3 item)
"""
import time
import threading
import pytest
from unittest.mock import MagicMock, patch


# ═══════════════════════════════════════════════════════════════════════════
# CHANGE 1 — rr_gate_enabled = True
# ═══════════════════════════════════════════════════════════════════════════

class TestRRGateEnabled:
    """rr_gate_enabled must be True in config after Phase 2."""

    def test_rr_gate_enabled_in_config(self):
        """Config must have rr_gate_enabled=True after Phase 2."""
        from tcos_bot.config.settings import cfg
        assert cfg.signal_quality.rr_gate_enabled is True, (
            f"rr_gate_enabled should be True after Phase 2. "
            f"Got: {cfg.signal_quality.rr_gate_enabled}"
        )

    def test_rr_gate_blocks_through_full_pipeline(self):
        """
        With rr_gate_enabled=True, a signal with wall 1.4b away must be
        blocked when evaluated through the full pipeline.
        
        This tests the end-to-end integration — not just the method in isolation.
        """
        import pandas as pd
        from tcos_bot.filters.pipeline import FilterPipeline
        from tcos_bot.filters.base import FilterResult

        pipeline = FilterPipeline.__new__(FilterPipeline)
        pipeline._trend_lock = threading.Lock()
        pipeline._last_trend_by_symbol = {}
        pipeline._day_regime = MagicMock()
        pipeline._day_regime.check.return_value = FilterResult.allow("TRENDING")
        pipeline._day_regime.current_regime = MagicMock()
        pipeline._day_regime.current_regime.value = "TRENDING"
        pipeline._day_regime.current_confidence = 0.8
        pipeline._sig_quality = MagicMock()
        pipeline._sig_quality.check.return_value = FilterResult.allow("QUALITY_OK")
        pipeline._sig_quality.score_only.return_value = {"grade": "B", "score": 4}
        pipeline._directional_gate = MagicMock()
        pipeline._directional_gate.check.return_value = FilterResult.allow("DIR_OK")
        pipeline._opt_quality = MagicMock()
        pipeline._opt_quality.check.return_value = FilterResult.allow("OPT_OK")

        # Build renko_df with wall 1.4b above entry (same as today's losing trade)
        # Must have >= 5 swing points for RR gate to activate (rr_min_swing_points=5)
        entry = 23033.0
        bs    = 12.0
        wall  = 23050.0   # 1.4b above
        rows = []
        # 10 base bricks below entry — alternate HL/LL for 5 swing points
        for i in range(10):
            price = entry - (10-i)*bs
            rows.append({"Renko_Brick": price, "HH": False, "LH": False,
                         "HL": i % 2 == 0, "LL": i % 2 == 1,
                         "Last_High": wall, "Last_Low": entry - 10*bs,
                         "Colour_Brick_Count": 3, "zlema9": entry - 5*bs})
        # Wall row (historical swing high above entry)
        rows.append({"Renko_Brick": wall, "HH": False, "LH": True,
                     "HL": False, "LL": False, "Last_High": wall,
                     "Last_Low": entry - 3*bs, "Colour_Brick_Count": 3,
                     "zlema9": entry})
        # Entry brick last (iloc[-1])
        rows.append({"Renko_Brick": entry, "HH": False, "LH": False,
                     "HL": False, "LL": False, "Last_High": wall,
                     "Last_Low": entry - 3*bs, "Colour_Brick_Count": 3,
                     "zlema9": entry})
        renko_df = pd.DataFrame(rows)

        # Patch only the time/opening checks so they pass
        from unittest.mock import patch as _patch
        with _patch("tcos_bot.filters.pipeline.cfg") as mock_cfg:
            mock_cfg.market_hours.opening_filter_end_nse = "09:30"
            mock_cfg.market_hours.opening_filter_end_mcx = "09:10"
            mock_cfg.market_hours.no_new_entries_nse     = "15:00"
            mock_cfg.market_hours.no_new_entries_mcx     = "23:00"
            mock_cfg.market_hours.nse_open               = "09:15"
            mock_cfg.market_hours.nse_close              = "15:30"
            mock_cfg.market_hours.mcx_open               = "09:00"
            mock_cfg.market_hours.mcx_close              = "23:30"
            mock_cfg.market_hours.low_activity_windows   = ()
            mock_cfg.signal_quality.rr_gate_enabled      = True   # ← ENABLED
            mock_cfg.signal_quality.rr_min_room_bricks   = 1.5
            mock_cfg.signal_quality.rr_min_swing_points  = 5
            mock_cfg.signal_quality.low_conf_threshold   = 0.4
            mock_cfg.signal_quality.low_conf_min_grade   = "A"
            mock_cfg.signal_quality.low_conf_exempt_exchanges = ("MCX",)
            mock_cfg.signal_quality.min_combined_size    = 0.4
            mock_cfg.signal_quality.min_combined_size_override = {}

            from datetime import time as dtime
            with _patch("tcos_bot.filters.pipeline.datetime") as mock_dt:
                mock_now_obj = MagicMock()
                mock_now_obj.time.return_value = dtime(10, 30)
                mock_dt.now.return_value = mock_now_obj
                result = pipeline.evaluate(
                    symbol="NIFTY", signal="BUYEN",
                    renko_df=renko_df, brick_size=bs,
                    exchange="NSE_INDEX",
                    signal_timestamp="2026-04-07 13:53:00",
                )

        assert not result.allowed, (
            "With rr_gate_enabled=True and wall 1.4b away, signal must be BLOCKED "
            "through the full pipeline. "
            "If this passes, rr_gate_enabled is not being read correctly."
        )


# ═══════════════════════════════════════════════════════════════════════════
# CHANGE 2 — no_new_entries_nse = "15:00"
# ═══════════════════════════════════════════════════════════════════════════

class TestNoNewEntriesRelaxed:
    """no_new_entries_nse must be "15:00" after Phase 2."""

    def test_no_new_entries_config_value(self):
        """Config value must be 15:00 after Phase 2."""
        from tcos_bot.config.settings import cfg
        assert cfg.market_hours.no_new_entries_nse == "15:00", (
            f"no_new_entries_nse should be 15:00 after Phase 2. "
            f"Got: {cfg.market_hours.no_new_entries_nse}"
        )

    def test_nse_entry_at_14_45_passes_time_gate(self):
        """
        NSE signal at 14:45 must PASS the time gate.
        Previously blocked at 14:30. Now allowed until 15:00.
        This is the April 6 BNF afternoon rally scenario.
        """
        from tcos_bot.filters.pipeline import FilterPipeline
        from datetime import time as dtime

        pipeline = FilterPipeline.__new__(FilterPipeline)

        with patch("tcos_bot.filters.pipeline.cfg") as mock_cfg:
            mock_cfg.market_hours.no_new_entries_nse = "15:00"
            mock_cfg.market_hours.nse_open           = "09:15"
            mock_cfg.market_hours.nse_close          = "15:30"
            mock_cfg.market_hours.no_new_entries_mcx = "23:00"
            mock_cfg.market_hours.mcx_open           = "09:00"
            mock_cfg.market_hours.mcx_close          = "23:30"
            mock_cfg.market_hours.low_activity_windows = ()

            with patch("tcos_bot.filters.pipeline.datetime") as mock_dt:
                mock_now_obj = MagicMock()
                mock_now_obj.time.return_value = dtime(14, 45)
                mock_dt.now.return_value = mock_now_obj

                result = pipeline._check_market_time(
                    "BUYEN",
                    {"exchange": "NSE_INDEX"}
                )

        assert result.allowed, (
            "NSE signal at 14:45 must PASS time gate with no_new_entries=15:00. "
            "Previously blocked at 14:30. Phase 2 relaxes this to 15:00."
        )

    def test_nse_entry_at_14_30_now_passes(self):
        """
        NSE signal at exactly 14:30 must now PASS (was blocked before).
        """
        from tcos_bot.filters.pipeline import FilterPipeline
        from datetime import time as dtime

        pipeline = FilterPipeline.__new__(FilterPipeline)

        with patch("tcos_bot.filters.pipeline.cfg") as mock_cfg:
            mock_cfg.market_hours.no_new_entries_nse = "15:00"
            mock_cfg.market_hours.nse_open           = "09:15"
            mock_cfg.market_hours.nse_close          = "15:30"
            mock_cfg.market_hours.no_new_entries_mcx = "23:00"
            mock_cfg.market_hours.mcx_open           = "09:00"
            mock_cfg.market_hours.mcx_close          = "23:30"
            mock_cfg.market_hours.low_activity_windows = ()

            with patch("tcos_bot.filters.pipeline.datetime") as mock_dt:
                mock_now_obj = MagicMock()
                mock_now_obj.time.return_value = dtime(14, 30)
                mock_dt.now.return_value = mock_now_obj

                result = pipeline._check_market_time(
                    "BUYEN",
                    {"exchange": "NSE_INDEX"}
                )

        assert result.allowed, (
            "NSE signal at 14:30 must now PASS (was blocked before Phase 2). "
            "no_new_entries changed from 14:30 to 15:00."
        )

    def test_nse_entry_at_15_01_still_blocked(self):
        """
        NSE signal at 15:01 must still be BLOCKED.
        The gate moved from 14:30 to 15:00, not removed entirely.
        """
        from tcos_bot.filters.pipeline import FilterPipeline
        from datetime import time as dtime

        pipeline = FilterPipeline.__new__(FilterPipeline)

        with patch("tcos_bot.filters.pipeline.cfg") as mock_cfg:
            mock_cfg.market_hours.no_new_entries_nse = "15:00"
            mock_cfg.market_hours.nse_open           = "09:15"
            mock_cfg.market_hours.nse_close          = "15:30"
            mock_cfg.market_hours.no_new_entries_mcx = "23:00"
            mock_cfg.market_hours.mcx_open           = "09:00"
            mock_cfg.market_hours.mcx_close          = "23:30"
            mock_cfg.market_hours.low_activity_windows = ()

            with patch("tcos_bot.filters.pipeline.datetime") as mock_dt:
                mock_now_obj = MagicMock()
                mock_now_obj.time.return_value = dtime(15, 1)
                mock_dt.now.return_value = mock_now_obj

                result = pipeline._check_market_time(
                    "BUYEN",
                    {"exchange": "NSE_INDEX"}
                )

        assert not result.allowed, (
            "NSE signal at 15:01 must still be BLOCKED. "
            "The gate moved to 15:00, not removed entirely."
        )

    def test_mcx_no_new_entries_unchanged(self):
        """MCX no_new_entries must remain at 23:00 — unchanged by Phase 2."""
        from tcos_bot.config.settings import cfg
        assert cfg.market_hours.no_new_entries_mcx == "23:00", (
            f"MCX no_new_entries must stay at 23:00. Got: {cfg.market_hours.no_new_entries_mcx}"
        )


# ═══════════════════════════════════════════════════════════════════════════
# CHANGES 3+4 — CBC per-instrument (NIFTY=3, BNF=2, SENSEX=2)
# ═══════════════════════════════════════════════════════════════════════════

class TestCBCPerInstrument:
    """
    After Phase 2:
      NIFTY: CBC=3 (unchanged)
      BANKNIFTY: CBC=2 (reduced from 3)
      SENSEX: CBC=2 (reduced from 3)
      MCX: CBC=3 (unchanged, not in NSE_ROOTS)
    """

    def _get_effective_cbc(self, symbol: str) -> int:
        """Simulate signal_generator CBC lookup."""
        import re
        from tcos_bot.config.settings import cfg

        root = (re.match(r"^([A-Z]+)", symbol.upper()) or re.match(r"^([A-Z]+)", "X")).group(1)
        overrides = getattr(cfg.entry, "min_entry_bricks_override", {})
        min_bricks = overrides.get(root, cfg.entry.min_entry_bricks)

        nse_roots = {"NIFTY", "BANKNIFTY", "SENSEX", "BANKEX", "FINNIFTY", "MIDCPNIFTY"}
        nse_upgraded = getattr(cfg.entry, "min_entry_bricks_nse_upgraded", False)
        if nse_upgraded and root in nse_roots:
            min_bricks = max(min_bricks, 3)

        return min_bricks

    def test_nifty_cbc_stays_at_3(self):
        """NIFTY must require CBC=3 after Phase 2."""
        cbc = self._get_effective_cbc("NIFTY")
        assert cbc == 3, f"NIFTY CBC must be 3. Got: {cbc}"

    def test_banknifty_cbc_drops_to_2(self):
        """
        BANKNIFTY must require only CBC=2 after Phase 2.
        Previously forced to 3 by min_entry_bricks_nse_upgraded=True.
        Now uses the override dict value of 2.
        """
        cbc = self._get_effective_cbc("BANKNIFTY")
        assert cbc == 2, (
            f"BANKNIFTY CBC must be 2 after Phase 2. Got: {cbc}. "
            f"Check min_entry_bricks_nse_upgraded=False and override dict."
        )

    def test_sensex_cbc_drops_to_2(self):
        """SENSEX must require only CBC=2 after Phase 2."""
        cbc = self._get_effective_cbc("SENSEX")
        assert cbc == 2, (
            f"SENSEX CBC must be 2 after Phase 2. Got: {cbc}."
        )

    def test_nse_upgraded_flag_is_false(self):
        """min_entry_bricks_nse_upgraded must be False after Phase 2."""
        from tcos_bot.config.settings import cfg
        flag = getattr(cfg.entry, "min_entry_bricks_nse_upgraded", True)
        assert flag is False, (
            f"min_entry_bricks_nse_upgraded must be False. Got: {flag}. "
            f"This flag was forcing all NSE to CBC=3."
        )

    def test_nifty_override_explicitly_3(self):
        """NIFTY must be explicitly 3 in the override dict."""
        from tcos_bot.config.settings import cfg
        overrides = cfg.entry.min_entry_bricks_override
        assert overrides.get("NIFTY") == 3, (
            f"NIFTY must be explicitly set to 3 in override dict. "
            f"Got: {overrides.get('NIFTY')}"
        )

    def test_mcx_cbc_unchanged_at_3(self):
        """MCX instruments must still require CBC=3. Not in NSE_ROOTS."""
        cbc_crude = self._get_effective_cbc("CRUDEOIL")
        assert cbc_crude == 3, (
            f"CRUDEOIL MCX must still need CBC=3. Got: {cbc_crude}. "
            f"MCX should be completely unaffected by Phase 2."
        )
