"""
test_phase3.py — Tests for Phase 3: Remove VOLATILE half-size.

Written BEFORE implementation. All tests must FAIL before the change
and PASS after.

Change: day_regime.py VOLATILE regime → FilterResult.allow() (was .half())

Audit findings:
  - Grade-A on VOLATILE: was 0.5 → now 1.0 (full lot) ✅
  - Grade-B on VOLATILE: was 0.25 (blocked by floor) → now 0.5 (half lot)
  - Whipsaw cooldown / NFT / confirm_mins use regime STRING not size → unchanged
  - SIDEWAYS + Grade-B still 0.25 → still blocked by floor ✅
  - Grade-B size = Phase 4 decision (separate change, needs more data)
"""
import pytest
from unittest.mock import MagicMock, patch


def _make_day_regime_filter(vix=25.0):
    """Build a DayRegimeFilter with VOLATILE classification."""
    from tcos_bot.filters.day_regime import DayRegimeClassifier

    filt = DayRegimeClassifier.__new__(DayRegimeClassifier)

    # Inject a pre-classified VOLATILE result
    result = MagicMock()
    result.regime.value  = "VOLATILE"
    result.confidence    = 0.85
    result.vix           = vix

    from tcos_bot.filters.day_regime import MarketRegime
    result.regime = MarketRegime.VOLATILE

    filt._result = result
    filt._cfg    = MagicMock()
    filt._cfg.sideways_hard_block  = False
    filt._cfg.chop_half_threshold  = 0.40
    return filt


# ═══════════════════════════════════════════════════════════════════════════
# T1: VOLATILE regime returns allow() at size 1.0
# ═══════════════════════════════════════════════════════════════════════════
def test_t1_volatile_regime_returns_full_size():
    """
    After Phase 3: VOLATILE day → FilterResult.allow() with size=1.0.
    Before Phase 3: FilterResult.half() with size=0.5.
    This is the core change of Phase 3.
    """
    filt = _make_day_regime_filter(vix=25.58)
    result = filt.check("NIFTY", "BUYEN", None)

    assert result.allowed, (
        "VOLATILE regime must ALLOW entry after Phase 3. "
        "Was previously always blocking via half-size path."
    )
    assert result.size_multiplier == 1.0, (
        f"VOLATILE regime must give size=1.0 after Phase 3. "
        f"Got: {result.size_multiplier}. "
        f"Was 0.5 before — Phase 3 removes this penalty."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T2: Grade-A on VOLATILE day → full lot via pipeline
# ═══════════════════════════════════════════════════════════════════════════
def test_t2_grade_a_volatile_day_full_lot():
    """
    VOLATILE day + Grade-A signal → size = 1.0 × 1.0 = 1.0 (full lot).
    Before Phase 3: 0.5 (VOLATILE) × 1.0 (Grade-A) = 0.5.
    After Phase 3: 1.0 (VOLATILE) × 1.0 (Grade-A) = 1.0.

    Today's NIFTY PUT 12:04 Grade-A score=5 is this scenario.
    """
    from tcos_bot.filters.base import FilterResult

    volatile_allow  = FilterResult.allow("VOLATILE_DAY — full-size (Phase 3)")
    grade_a_allow   = FilterResult.allow("QUALITY_A: score=5")

    # Compound the sizes as pipeline does
    size = 1.0
    size = min(size, volatile_allow.size_multiplier)
    size = min(size, grade_a_allow.size_multiplier)

    assert size == 1.0, (
        f"Grade-A on VOLATILE must compound to 1.0. Got: {size}. "
        "Phase 3 goal: Grade-A VOLATILE signals run at full lot."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T3: Grade-B on VOLATILE day → half lot (not blocked)
# ═══════════════════════════════════════════════════════════════════════════
def test_t3_grade_b_volatile_day_half_lot():
    """
    VOLATILE day + Grade-B signal → size = 1.0 × 0.5 = 0.5 (half lot).
    Before Phase 3: 0.5 × 0.5 = 0.25 → BLOCKED by min_combined_size floor.
    After Phase 3: 1.0 × 0.5 = 0.50 → passes floor (0.5 > 0.4).

    Today's SENSEX CALL 13:17 +228pts Grade-B score=4 is this scenario.
    It was running at 0.25 (then blocked by floor? actually it passed at 0.5).
    After Phase 3: still 0.5 for Grade-B VOLATILE signals.
    Grade-B full size = Phase 4 (needs more data).
    """
    from tcos_bot.filters.base import FilterResult

    volatile_allow  = FilterResult.allow("VOLATILE_DAY — full-size (Phase 3)")
    grade_b_allow   = FilterResult.allow("QUALITY_B: score=4")
    grade_b_allow   = FilterResult(
        allowed=True, reason="QUALITY_B", size_multiplier=0.5
    )

    size = 1.0
    size = min(size, volatile_allow.size_multiplier)
    size = min(size, grade_b_allow.size_multiplier)

    assert size == 0.5, (
        f"Grade-B on VOLATILE must be 0.5 (half lot). Got: {size}."
    )
    assert size > 0.4, (
        f"Grade-B VOLATILE size={size} must be above min_combined_size=0.4 floor. "
        "Was blocked (0.25) before Phase 3."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T4: TRENDING regime unchanged — still full size
# ═══════════════════════════════════════════════════════════════════════════
def test_t4_trending_regime_unchanged():
    """
    TRENDING day → still full size 1.0.
    Phase 3 only changes VOLATILE. TRENDING must be untouched.
    """
    from tcos_bot.filters.day_regime import DayRegimeClassifier, MarketRegime

    filt = DayRegimeClassifier.__new__(DayRegimeClassifier)
    result_mock = MagicMock()
    result_mock.regime     = MarketRegime.TRENDING
    result_mock.confidence = 0.75
    result_mock.vix        = 14.0
    filt._result = result_mock
    filt._cfg    = MagicMock()
    filt._cfg.sideways_hard_block = False
    filt._cfg.chop_half_threshold = 0.40

    result = filt.check("NIFTY", "BUYEN", None)

    assert result.allowed, "TRENDING regime must allow entry"
    assert result.size_multiplier == 1.0, (
        f"TRENDING must still be full size 1.0. Got: {result.size_multiplier}. "
        "Phase 3 must not affect TRENDING."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T5: VOLATILE reason string updated — no longer says "half-size"
# ═══════════════════════════════════════════════════════════════════════════
def test_t5_volatile_reason_no_longer_says_half_size():
    """
    After Phase 3, the VOLATILE log reason must not say 'half-size'.
    Log clarity: VOLATILE_DAY reason should reflect the new behaviour.
    """
    filt = _make_day_regime_filter(vix=25.58)
    result = filt.check("NIFTY", "BUYEN", None)

    assert "half-size" not in result.reason.lower(), (
        f"VOLATILE reason must not say 'half-size' after Phase 3. "
        f"Got: '{result.reason}'. Update the reason string in day_regime.py."
    )
    assert "volatile" in result.reason.lower() or "vix" in result.reason.lower(), (
        f"VOLATILE reason must still mention VOLATILE or VIX. "
        f"Got: '{result.reason}'."
    )
