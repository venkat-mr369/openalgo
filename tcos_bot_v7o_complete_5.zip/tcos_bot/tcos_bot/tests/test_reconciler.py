"""
Tests — test_reconciler.py
===========================
Covers:
  A) Startup reconcile: orphan broker position → imported into trade_manager
  B) Startup reconcile: DB INPOSITION with broker flat → marked CLOSED
  C) Cycle reconcile: manual close detected → CLOSED + sibling CANCELLED
  D) Cycle reconcile: re-run does NOT re-close or re-log (idempotency)
  E) Pre-flight check: position gone → returns False, prevents exit
  F) engine.py symbol routing: NSE_INDEX/BSE_INDEX → NFO/BFO futures exchange
  G) option_resolver: FUTIDX included in fut_types so NIFTY futures found

Run with:
    pytest tcos_bot/tests/test_reconciler.py -v
"""

from __future__ import annotations

import os
import threading
from datetime import datetime, timedelta
from typing import Dict
from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

from tcos_bot.config.settings import IST

# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_tm(**overrides) -> pd.DataFrame:
    """Return a minimal trade_manager DataFrame."""
    base = {
        "id":             [1],
        "symbol":         ["NIFTY"],
        "exchange":       ["NSE_INDEX"],
        "renko_signal":   ["BUYCL"],
        "order_status":   ["INPOSITION"],
        "entry_price":    [22000.0],
        "quantity":       [65],
        "option_symbol":  ["NIFTY27MAR2522500CE"],
        "fill_timestamp": [(datetime.now(tz=IST) - timedelta(seconds=120)).strftime(
            "%Y-%m-%d %H:%M:%S")],
        "close_reason":   [None],
        "position_key":   ["NIFTY:NIFTY27MAR2522500CE:CALL"],
    }
    base.update(overrides)
    # Ensure all lists same length
    length = len(next(iter(base.values())))
    for k, v in base.items():
        if not isinstance(v, list):
            base[k] = [v] * length
    return pd.DataFrame(base)


def _make_positions_df(qty: int = 65) -> pd.DataFrame:
    """Simulate broker positionbook with one CALL position."""
    return pd.DataFrame([{
        "symbol":         "NIFTY27MAR2522500CE",
        "exchange":       "NFO",
        "quantity":       qty,
        "average_price":  22000.0,
        "buy_price":      22000.0,
    }])


# ── A: Startup reconcile — import orphan position ─────────────────────────────

def test_startup_reconcile_imports_orphan():
    """Broker has a CE position; trade_manager is empty → row imported."""
    from tcos_bot.execution.reconciler import startup_reconcile

    mock_client = MagicMock()
    mock_client.positionbook.return_value = {
        "status": "success",
        "data": [
            {
                "symbol":        "NIFTY27MAR2522500CE",
                "exchange":      "NFO",
                "quantity":      65,
                "average_price": 150.0,
            }
        ],
    }

    imported_rows: list = []

    mock_ts = MagicMock()
    mock_ts.read_df.return_value = pd.DataFrame()  # empty DB
    mock_ts.import_position.side_effect = lambda row: imported_rows.append(row)

    mock_ltp = MagicMock()
    mock_ltp.get.return_value = (None, 0.0)  # (ltp, age)

    with patch("tcos_bot.execution.reconciler.trade_store", mock_ts), \
         patch("tcos_bot.execution.reconciler.ltp_store", mock_ltp):

        startup_reconcile(
            client      = mock_client,
            known_roots = ["NIFTY"],
            brick_sizes = {"NIFTY": 12.0},
        )

    # Should have imported the INPOSITION entry row AND a stop row
    assert len(imported_rows) == 2
    entry = imported_rows[0]
    assert entry["renko_signal"]  == "BUYCL"
    assert entry["order_status"]  == "INPOSITION"
    assert entry["signal_source"] == "RECONCILE_IMPORT"
    assert entry["symbol"]        == "NIFTY"
    assert entry["entry_price"]   == 150.0

    stop = imported_rows[1]
    assert stop["renko_signal"] == "SELST"
    assert stop["order_status"] == "OPEN"


# ── B: Startup reconcile — close orphan DB rows ───────────────────────────────

def test_startup_reconcile_closes_orphan_db_rows():
    """DB has INPOSITION for NIFTY; broker returns empty → row closed."""
    from tcos_bot.execution.reconciler import startup_reconcile

    mock_client = MagicMock()
    mock_client.positionbook.return_value = {"status": "success", "data": []}

    tm = _make_tm()  # has INPOSITION BUYCL for NIFTY
    saved: list = []

    mock_ts = MagicMock()
    # read_df called twice: once in startup_reconcile, once in _close_orphan_db_rows
    mock_ts.read_df.return_value = tm.copy()
    mock_ts.save_df.side_effect = lambda df: saved.append(df.copy())

    mock_ltp = MagicMock()
    mock_ltp.get.return_value = (22000.0, 5.0)

    with patch("tcos_bot.execution.reconciler.trade_store", mock_ts), \
         patch("tcos_bot.execution.reconciler.ltp_store", mock_ltp):

        startup_reconcile(
            client      = mock_client,
            known_roots = ["NIFTY"],
            brick_sizes = {"NIFTY": 12.0},
        )

    # save_df must have been called
    assert saved, "Expected trade_store.save_df to be called"
    final = saved[-1]
    closed_rows = final[final["order_status"] == "CLOSED"]
    assert len(closed_rows) == 1
    assert closed_rows.iloc[0]["close_reason"] == "RECONCILE_BROKER_FLAT"


# ── C: Cycle reconcile — manual close detected ────────────────────────────────

def test_cycle_reconcile_detects_manual_close():
    """INPOSITION row but broker qty=0 → marked CLOSED + MANUAL_CLOSE_DETECTED."""
    from tcos_bot.execution.reconciler import cycle_reconcile, _LOG_ONCE
    _LOG_ONCE.clear()

    tm = _make_tm()
    root_positions = {"NIFTY": {"CALL": 0, "PUT": 0}}  # broker flat

    with patch("tcos_bot.execution.reconciler.ltp_store") as mock_ltp:
        mock_ltp.get.return_value = (22300.0, 5.0)
        result_tm, changed = cycle_reconcile(tm, root_positions, api_ok=True)

    assert changed is True
    row = result_tm[result_tm["renko_signal"] == "BUYCL"].iloc[0]
    assert row["order_status"]  == "CLOSED"
    assert row["close_reason"]  == "MANUAL_CLOSE_DETECTED"
    assert row["close_price"]   == 22300.0


# ── D: Idempotency — re-run does not re-close ─────────────────────────────────

def test_cycle_reconcile_idempotent():
    """Running cycle_reconcile twice does not double-close or spam logs."""
    from tcos_bot.execution.reconciler import cycle_reconcile, _LOG_ONCE
    _LOG_ONCE.clear()

    tm = _make_tm()
    root_positions = {"NIFTY": {"CALL": 0, "PUT": 0}}

    with patch("tcos_bot.execution.reconciler.ltp_store") as mock_ltp:
        mock_ltp.get.return_value = (22300.0, 5.0)
        tm, changed1 = cycle_reconcile(tm, root_positions, api_ok=True)

    # Row now has close_reason set; second call must skip it
    with patch("tcos_bot.execution.reconciler.ltp_store") as mock_ltp:
        mock_ltp.get.return_value = (22350.0, 5.0)
        tm2, changed2 = cycle_reconcile(tm.copy(), root_positions, api_ok=True)

    assert changed2 is False  # nothing changed on second pass
    row = tm2[tm2["renko_signal"] == "BUYCL"].iloc[0]
    assert row["close_price"] == 22300.0  # not overwritten


# ── D2: cycle_reconcile skips fresh fills (grace period) ─────────────────────

def test_cycle_reconcile_grace_period():
    """A fill within 60s must not be falsely closed."""
    from tcos_bot.execution.reconciler import cycle_reconcile

    now_ist = datetime.now(tz=IST)
    fresh_fill = (now_ist - timedelta(seconds=30)).strftime("%Y-%m-%d %H:%M:%S")
    tm = _make_tm(fill_timestamp=[fresh_fill])
    root_positions = {"NIFTY": {"CALL": 0, "PUT": 0}}

    with patch("tcos_bot.execution.reconciler.ltp_store") as mock_ltp:
        mock_ltp.get.return_value = (22300.0, 5.0)
        _, changed = cycle_reconcile(tm, root_positions, api_ok=True)

    assert changed is False  # grace period protects fresh fill


# ── D3: cycle_reconcile skips when api_ok=False ───────────────────────────────

def test_cycle_reconcile_api_fail():
    from tcos_bot.execution.reconciler import cycle_reconcile

    tm = _make_tm()
    _, changed = cycle_reconcile(tm, {}, api_ok=False)
    assert changed is False


# ── E: Pre-flight check — position gone ───────────────────────────────────────

def test_preflight_returns_false_when_position_gone():
    from tcos_bot.execution.reconciler import preflight_position_check

    mock_client = MagicMock()
    mock_client.positionbook.return_value = {"status": "success", "data": []}

    result = preflight_position_check(
        client        = mock_client,
        symbol        = "NIFTY",
        option_symbol = "NIFTY27MAR2522500CE",
        direction     = "CALL",
        known_roots   = ["NIFTY"],
    )
    assert result is False


def test_preflight_returns_true_when_position_exists():
    from tcos_bot.execution.reconciler import preflight_position_check

    mock_client = MagicMock()
    mock_client.positionbook.return_value = {
        "status": "success",
        "data": [{"symbol": "NIFTY27MAR2522500CE", "exchange": "NFO", "quantity": 65}],
    }

    result = preflight_position_check(
        client        = mock_client,
        symbol        = "NIFTY",
        option_symbol = "NIFTY27MAR2522500CE",
        direction     = "CALL",
        known_roots   = ["NIFTY"],
    )
    assert result is True


def test_preflight_allows_order_on_api_failure():
    """If API fails, be conservative and allow the exit to proceed."""
    from tcos_bot.execution.reconciler import preflight_position_check

    mock_client = MagicMock()
    mock_client.positionbook.side_effect = RuntimeError("timeout")

    result = preflight_position_check(
        client        = mock_client,
        symbol        = "NIFTY",
        option_symbol = "NIFTY27MAR2522500CE",
        direction     = "CALL",
        known_roots   = ["NIFTY"],
    )
    assert result is True  # conservative: allow order when API fails


# ── E2: Pre-flight exit is cancelled in execute loop ─────────────────────────

def test_execute_open_orders_cancels_on_preflight_fail():
    """
    Simulate _execute_open_orders: SELST row present but pre-flight says
    position gone → row cancelled, no order placed.
    """
    from tcos_bot.execution.reconciler import preflight_position_check

    # Build a minimal SELST row
    tm = pd.DataFrame([{
        "id":            1,
        "symbol":        "NIFTY",
        "exchange":      "NSE_INDEX",
        "renko_signal":  "SELST",
        "order_status":  "OPEN",
        "entry_price":   21800.0,
        "quantity":      65,
        "option_symbol": "NIFTY27MAR2522500CE",
        "close_reason":  None,
    }])

    mock_client = MagicMock()
    mock_client.positionbook.return_value = {"status": "success", "data": []}

    # Simulate the guard logic inline (as engine._execute_open_orders does)
    row = tm.iloc[0]
    action    = str(row["renko_signal"])
    symbol    = str(row["symbol"])
    direction = "CALL" if action in ("SELCL", "SELST") else "PUT"

    ok = preflight_position_check(
        mock_client, symbol, str(row.get("option_symbol", "")),
        direction, ["NIFTY"]
    )
    if not ok:
        tm.at[0, "order_status"] = "CANCELLED"
        tm.at[0, "close_reason"] = "PREFLIGHT_POSITION_GONE"

    assert tm.at[0, "order_status"] == "CANCELLED"
    mock_client.placesmartorder.assert_not_called()


# ── F: Symbol routing — NSE_INDEX and BSE_INDEX pass through as-is ───────────

def test_resolve_ohlc_symbol_nse_index_routes_to_nfo(tmp_path):
    """
    _resolve_ohlc_symbol for NSE_INDEX must return exchange=NSE_INDEX unchanged.

    History: an earlier design remapped NSE_INDEX → NFO, but OpenAlgo's
    /history endpoint accepts NSE_INDEX directly for spot-index OHLC and
    Flattrade rejects NIFTY on NFO with "no data".  The engine code has a
    detailed comment explaining this.  This test was wrong; corrected here.
    """
    import threading
    from tcos_bot.core.engine import TradingEngine
    eng = TradingEngine.__new__(TradingEngine)
    eng._cache_lock           = threading.RLock()
    eng._futures_symbol_cache = {}
    eng._fsc_lock             = threading.RLock()
    eng._brick_sizes          = {"NIFTY": 12.0}

    sym, ex = eng._resolve_ohlc_symbol("NIFTY", "NSE_INDEX")

    assert ex  == "NSE_INDEX", f"Expected NSE_INDEX (pass-through), got {ex!r}"
    assert sym == "NIFTY",     f"Expected NIFTY (pass-through), got {sym!r}"


def test_resolve_ohlc_symbol_bse_index_routes_to_bfo(tmp_path):
    """BSE_INDEX also passes through unchanged — same reasoning as NSE_INDEX."""
    import threading
    from tcos_bot.core.engine import TradingEngine
    eng = TradingEngine.__new__(TradingEngine)
    eng._cache_lock           = threading.RLock()
    eng._futures_symbol_cache = {}
    eng._fsc_lock             = threading.RLock()
    eng._brick_sizes          = {"SENSEX": 50.0}

    sym, ex = eng._resolve_ohlc_symbol("SENSEX", "BSE_INDEX")

    assert ex  == "BSE_INDEX", f"Expected BSE_INDEX (pass-through), got {ex!r}"
    assert sym == "SENSEX",    f"Expected SENSEX (pass-through), got {sym!r}"


def test_resolve_ohlc_symbol_mcx_unchanged():
    """MCX futures path must still work."""
    import threading
    with patch("tcos_bot.execution.option_resolver.resolve_front_month_futures",
               return_value="CRUDEOILM19MAR26FUT"):

        from tcos_bot.core.engine import TradingEngine
        eng = TradingEngine.__new__(TradingEngine)
        eng._cache_lock           = threading.RLock()
        eng._futures_symbol_cache = {}
        eng._fsc_lock             = threading.RLock()
        eng._brick_sizes          = {"CRUDEOIL": 8.0}

        sym, ex = eng._resolve_ohlc_symbol("CRUDEOIL", "MCX")

    assert ex  == "MCX"
    assert sym == "CRUDEOILM19MAR26FUT"


# ── G: option_resolver fut_types includes FUTIDX ─────────────────────────────

def test_resolve_front_month_futures_futidx(tmp_path):
    """
    resolve_front_month_futures must find NIFTY futures (instrumenttype=FUTIDX)
    in openalgo.db.
    """
    import sqlite3

    db = tmp_path / "db" / "openalgo.db"
    db.parent.mkdir()
    con = sqlite3.connect(str(db))
    con.execute("""
        CREATE TABLE symtoken (
            symbol TEXT, exchange TEXT, instrumenttype TEXT,
            expiry TEXT, lotsize INTEGER
        )
    """)
    # Simulate the two contract types present in a real OpenAlgo DB
    con.executemany("INSERT INTO symtoken VALUES (?,?,?,?,?)", [
        ("NIFTY27MAR26FUT", "NFO", "FUTIDX", "27-Mar-26", 75),
        ("NIFTY24APR26FUT", "NFO", "FUTIDX", "24-Apr-26", 75),
    ])
    con.commit()
    con.close()

    with patch("tcos_bot.execution.option_resolver._openalgo_db_path",
               return_value=str(db)):
        from tcos_bot.execution.option_resolver import resolve_front_month_futures
        result = resolve_front_month_futures("NIFTY", "NSE_INDEX")

    # Should pick the nearest expiry ≥ today
    assert result is not None, "Expected a front-month futures symbol"
    assert result.startswith("NIFTY"), f"Expected NIFTY*, got {result!r}"


def test_resolve_front_month_futures_returns_none_for_missing_db():
    """No DB → graceful None, no exception."""
    with patch("tcos_bot.execution.option_resolver._openalgo_db_path",
               return_value="/nonexistent/path/openalgo.db"):
        from tcos_bot.execution.option_resolver import resolve_front_month_futures
        result = resolve_front_month_futures("NIFTY", "NSE_INDEX")

    assert result is None


# ── G2: OHLC failure does not block exit evaluation ──────────────────────────

def test_ohlc_failure_does_not_skip_renko_cache():
    """
    If OHLC fetch fails, renko_cache stays None for that symbol
    (no crash) and the cycle loop logs debug + continues.
    The cycle must still process symbols that DO have renko data.
    """
    # This is a structural test: the engine's _cycle() checks
    # `if renko_df is None or renko_df.empty: continue`
    # We verify that logic exists and doesn't raise.
    from tcos_bot.core.engine import _ProtectedCache

    lock  = __import__("threading").RLock()
    cache = _ProtectedCache(lock)
    # NIFTY missing → get returns None
    assert cache.get("NIFTY") is None
    # CRUDEOIL present → get returns data
    dummy_df = pd.DataFrame({"close": [100.0]})
    cache.set("CRUDEOIL", dummy_df)
    assert cache.get("CRUDEOIL") is not None


# ── TradeStore.import_position idempotency ────────────────────────────────────

def test_trade_store_import_position_idempotent():
    """
    Calling import_position twice with the same position_key
    must insert only one row.
    Works with both the SQLAlchemy TradeStore and the FallbackTradeStore.
    """
    from tcos_bot.data.trade_store import trade_store, _SQLALCHEMY_AVAILABLE

    pkey = "BANKNIFTY:BANKNIFTY27MAR2548000CE:CALL"
    row = {
        "symbol":        "BANKNIFTY",
        "exchange":      "NSE_INDEX",
        "renko_signal":  "BUYCL",
        "order_status":  "INPOSITION",
        "entry_price":   48000.0,
        "quantity":      30,
        "option_symbol": "BANKNIFTY27MAR2548000CE",
        "signal_source": "RECONCILE_IMPORT",
        "position_key":  pkey,
        "timestamp":     "2026-03-12 09:30:00",
    }

    # Clean up any prior test residue using the public API
    if _SQLALCHEMY_AVAILABLE:
        # SQLAlchemy path: delete by position_key via engine
        try:
            from sqlalchemy import text as _text
            from tcos_bot.data.trade_store import get_engine
            with get_engine().begin() as cn:
                cn.execute(_text("DELETE FROM trade_manager WHERE position_key = :pk"),
                           {"pk": pkey})
        except Exception:
            pass
    else:
        # Fallback path: remove matching rows from in-memory DataFrame
        df = trade_store.read_df()
        if not df.empty and "position_key" in df.columns:
            trade_store.save_df(df[df["position_key"] != pkey])

    r1 = trade_store.import_position(row)
    r2 = trade_store.import_position(row)  # second call — must be deduped

    assert r1 is True,  "First import should succeed"
    assert r2 is False, "Second import should be blocked (idempotency)"

    df = trade_store.read_df()
    pkey_rows = df[df["position_key"] == pkey] if "position_key" in df.columns else pd.DataFrame()
    assert len(pkey_rows) == 1, f"Expected 1 row with this pkey, got {len(pkey_rows)}"
