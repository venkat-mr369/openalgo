"""
test_new_features.py
====================
Regression + feature tests for all changes in the implementation pass:

  Part 3 — Explicit TrendState module (detect_trend_state)
  Part 4 — Regime-aware DirectionalGate
  Part 5 — Whipsaw/chop integration (regime-aware cooldown)
  Part 6 — Feed-health gate (websocket safety)
  Part 7 — Bug-fix regressions (Bug A, B, C, D, E)
  Part 8 — All required test scenarios

Run:  pytest tcos_bot/tests/test_new_features.py -v
"""

from __future__ import annotations

import threading
import time
import types
import unittest
from datetime import datetime
from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

# ── Helpers ────────────────────────────────────────────────────────────────────

def _renko_row(
    brick=22000.0,
    zlema=21800.0,
    c_count=3,
    direction=1,
    hh=True, ll=False, hl=False, lh=False,
    last_high=22500.0,
    last_low=21500.0,
) -> dict:
    """Build a minimal Renko row dict for trend detection tests."""
    return {
        "Renko_Brick":      brick,
        "zlema9":           zlema,
        "Colour_Brick_Count": c_count,
        "direction":        direction,
        "HH":               hh,
        "LL":               ll,
        "HL":               hl,
        "LH":               lh,
        "Last_High":        last_high,
        "Last_Low":         last_low,
        "timestamp":        "2026-03-15 10:00:00",
        "brick_size_hint":  50.0,
    }


def _renko_df(row_dict: dict) -> pd.DataFrame:
    return pd.DataFrame([row_dict])


# ══════════════════════════════════════════════════════════════════════════════
# PART 3 — TrendState detection
# ══════════════════════════════════════════════════════════════════════════════

class TestTrendStateDetection(unittest.TestCase):
    """Tests for detect_trend_state() — Part 3."""

    def setUp(self):
        from tcos_bot.signals.trend_state import detect_trend_state, TrendState, trend_state_info
        self.detect = detect_trend_state
        self.info   = trend_state_info
        self.TS     = TrendState

    def test_uptrend_all_factors(self):
        """Price > ZLEMA9, HH confirmed, 3+ consecutive up bricks → UPTREND."""
        row = _renko_row(brick=22000, zlema=21800, c_count=3, direction=1, hh=True)
        state = self.detect(row)
        self.assertEqual(state, self.TS.UPTREND)

    def test_downtrend_all_factors(self):
        """Price < ZLEMA9, LL confirmed, 3 consecutive down bricks → DOWNTREND."""
        row = _renko_row(brick=21500, zlema=21800, c_count=3, direction=-1, hh=False, ll=True)
        state = self.detect(row)
        self.assertEqual(state, self.TS.DOWNTREND)

    def test_neutral_conflicting_signals(self):
        """Price > ZLEMA (bullish) but LL confirmed (bearish) and no momentum → NEUTRAL."""
        row = _renko_row(brick=22000, zlema=21800, c_count=1, direction=1, hh=False, ll=True)
        state = self.detect(row)
        # up: zlema=+1; down: ll=+1, c_count<2 → no momentum; scores tied at 1 each → NEUTRAL
        self.assertEqual(state, self.TS.NEUTRAL)

    def test_neutral_price_on_zlema(self):
        """Price == ZLEMA → no ZLEMA contribution → NEUTRAL unless other factors dominate."""
        row = _renko_row(brick=22000, zlema=22000, c_count=1, direction=0, hh=False, ll=False)
        state = self.detect(row)
        self.assertEqual(state, self.TS.NEUTRAL)

    def test_neutral_weak_momentum(self):
        """Only 1 brick and no swing structure → NEUTRAL."""
        row = _renko_row(brick=22000, zlema=21800, c_count=1, direction=1, hh=False, ll=False)
        state = self.detect(row)
        # up: zlema=+1 only; needs 2 → NEUTRAL
        self.assertEqual(state, self.TS.NEUTRAL)

    def test_uptrend_zlema_and_momentum_without_hh(self):
        """ZLEMA aligned + strong momentum without HH is enough for UPTREND (2/3 factors)."""
        row = _renko_row(brick=22000, zlema=21800, c_count=3, direction=1, hh=False)
        state = self.detect(row)
        self.assertEqual(state, self.TS.UPTREND)

    def test_downtrend_zlema_and_momentum_without_ll(self):
        """ZLEMA aligned + strong momentum without LL is enough for DOWNTREND."""
        row = _renko_row(brick=21500, zlema=21800, c_count=3, direction=-1, hh=False, ll=False)
        state = self.detect(row)
        self.assertEqual(state, self.TS.DOWNTREND)

    def test_no_noisy_flip_with_hysteresis(self):
        """
        When previous state is UPTREND and new evidence only marginally
        supports DOWNTREND, hysteresis should preserve UPTREND.
        """
        # Strong UPTREND row → establish state
        row_up = _renko_row(brick=22000, zlema=21800, c_count=3, direction=1, hh=True)
        # Ambiguous row — ZLEMA now bearish by tiny margin, no LL, weak momentum
        row_ambig = _renko_row(brick=21799, zlema=21800, c_count=1, direction=-1,
                               hh=False, ll=False)
        prev = self.detect(row_up)
        result = self.detect(row_ambig, previous_state=prev)
        # Ambiguous evidence shouldn't flip from established UPTREND
        self.assertNotEqual(result, self.TS.DOWNTREND,
                            "Should not flip to DOWNTREND on marginal evidence")

    def test_strong_reversal_overrides_hysteresis(self):
        """
        When new evidence STRONGLY supports the opposite direction (2+ point lead),
        the state should flip regardless of previous state.
        """
        from tcos_bot.signals.trend_state import TrendState
        row_up = _renko_row(brick=22000, zlema=21800, c_count=3, direction=1, hh=True)
        # Very strong downtrend: price well below ZLEMA, LL, strong down momentum
        row_down = _renko_row(brick=20000, zlema=21800, c_count=5, direction=-1,
                              hh=False, ll=True)
        prev = self.detect(row_up)
        result = self.detect(row_down, previous_state=prev)
        self.assertEqual(result, TrendState.DOWNTREND)

    def test_trend_state_info_returns_full_breakdown(self):
        """trend_state_info() returns state, scores, and factor list."""
        row = _renko_row(brick=22000, zlema=21800, c_count=3, direction=1, hh=True)
        info = self.info(row)
        self.assertIn("state",      info)
        self.assertIn("up_score",   info)
        self.assertIn("down_score", info)
        self.assertIn("factors",    info)
        self.assertIsInstance(info["factors"], list)
        self.assertGreater(len(info["factors"]), 0)

    def test_missing_zlema_does_not_crash(self):
        """Row with no zlema9 column should return NEUTRAL without exception."""
        row = {"Renko_Brick": 22000, "Colour_Brick_Count": 1, "HH": False}
        state = self.detect(row)
        self.assertEqual(state, self.TS.NEUTRAL)

    def test_nan_values_handled(self):
        """NaN values in numeric columns should not crash detect_trend_state."""
        import math
        row = _renko_row(brick=float("nan"), zlema=float("nan"), c_count=0)
        state = self.detect(row)
        self.assertEqual(state, self.TS.NEUTRAL)


# ══════════════════════════════════════════════════════════════════════════════
# PART 4 — Regime-aware DirectionalGate
# ══════════════════════════════════════════════════════════════════════════════

class TestDirectionalGate(unittest.TestCase):
    """Tests for DirectionalGate — Part 4."""

    def setUp(self):
        from tcos_bot.filters.directional_gate import DirectionalGate
        from tcos_bot.signals.trend_state import TrendState
        self.gate = DirectionalGate()
        self.TS   = TrendState

    # ── TRENDING regime ──────────────────────────────────────────────────────

    def test_trending_uptrend_allows_call(self):
        r = self.gate.check("BUYEN", self.TS.UPTREND, "TRENDING")
        self.assertTrue(r.allowed)
        self.assertEqual(r.size_multiplier, 1.0)

    def test_trending_uptrend_blocks_put(self):
        """TRENDING + UPTREND must hard-block PUT (SELEX) entries."""
        r = self.gate.check("SELEX", self.TS.UPTREND, "TRENDING")
        self.assertFalse(r.allowed, "Counter-trend PUT in TRENDING UPTREND must be blocked")

    def test_trending_downtrend_allows_put(self):
        r = self.gate.check("SELEX", self.TS.DOWNTREND, "TRENDING")
        self.assertTrue(r.allowed)
        self.assertEqual(r.size_multiplier, 1.0)

    def test_trending_downtrend_blocks_call(self):
        """TRENDING + DOWNTREND must hard-block CALL (BUYEN) entries."""
        r = self.gate.check("BUYEN", self.TS.DOWNTREND, "TRENDING")
        self.assertFalse(r.allowed, "Counter-trend CALL in TRENDING DOWNTREND must be blocked")

    def test_trending_neutral_halves_both(self):
        """TRENDING + NEUTRAL → half-size caution (not hard block).
        Coarse-brick instruments (BANKNIFTY=40, SENSEX=50) confirm trend slower
        than NIFTY=12. Hard-blocking NEUTRAL in TRENDING locked them out entirely.
        Fix: half-size penalty, same treatment as SIDEWAYS counter-trend."""
        r_call = self.gate.check("BUYEN", self.TS.NEUTRAL, "TRENDING")
        r_put  = self.gate.check("SELEX", self.TS.NEUTRAL, "TRENDING")
        self.assertTrue(r_call.allowed,          "TRENDING+NEUTRAL should allow (half-size)")
        self.assertTrue(r_put.allowed,           "TRENDING+NEUTRAL should allow (half-size)")
        self.assertAlmostEqual(r_call.size_multiplier, 0.5, msg="TRENDING+NEUTRAL must be half size")
        self.assertAlmostEqual(r_put.size_multiplier,  0.5, msg="TRENDING+NEUTRAL must be half size")

    # ── SIDEWAYS regime ──────────────────────────────────────────────────────

    def test_sideways_allows_aligned_call(self):
        r = self.gate.check("BUYEN", self.TS.UPTREND, "SIDEWAYS")
        self.assertTrue(r.allowed)

    def test_sideways_allows_aligned_put(self):
        r = self.gate.check("SELEX", self.TS.DOWNTREND, "SIDEWAYS")
        self.assertTrue(r.allowed)

    def test_sideways_penalises_counter_trend_call(self):
        """Counter-trend CALL in SIDEWAYS → half size, not hard block."""
        r = self.gate.check("BUYEN", self.TS.DOWNTREND, "SIDEWAYS")
        self.assertTrue(r.allowed, "SIDEWAYS counter-trend should not hard-block")
        self.assertEqual(r.size_multiplier, 0.5)

    def test_sideways_penalises_counter_trend_put(self):
        r = self.gate.check("SELEX", self.TS.UPTREND, "SIDEWAYS")
        self.assertTrue(r.allowed)
        self.assertEqual(r.size_multiplier, 0.5)

    # ── VOLATILE regime ──────────────────────────────────────────────────────

    def test_volatile_allows_aligned(self):
        r = self.gate.check("BUYEN", self.TS.UPTREND, "VOLATILE")
        self.assertTrue(r.allowed)
        self.assertEqual(r.size_multiplier, 1.0)

    def test_volatile_penalises_counter_trend(self):
        r = self.gate.check("BUYEN", self.TS.DOWNTREND, "VOLATILE")
        self.assertTrue(r.allowed)
        self.assertEqual(r.size_multiplier, 0.5)

    # ── UNKNOWN regime ──────────────────────────────────────────────────────

    def test_unknown_allows_aligned_call(self):
        r = self.gate.check("BUYEN", self.TS.UPTREND, "UNKNOWN")
        self.assertTrue(r.allowed)

    def test_unknown_allows_counter_trend_with_warning(self):
        """UNKNOWN regime: counter-trend allowed but penalised."""
        r = self.gate.check("BUYEN", self.TS.DOWNTREND, "UNKNOWN")
        self.assertTrue(r.allowed, "UNKNOWN should not hard-block counter-trend")
        self.assertEqual(r.size_multiplier, 0.5)

    def test_unknown_neutral_trend_allows_both(self):
        r_call = self.gate.check("BUYEN", self.TS.NEUTRAL, "UNKNOWN")
        r_put  = self.gate.check("SELEX", self.TS.NEUTRAL, "UNKNOWN")
        self.assertTrue(r_call.allowed)
        self.assertTrue(r_put.allowed)

    # ── Enum / string input safety ────────────────────────────────────────────

    def test_regime_enum_object_accepted(self):
        """DirectionalGate must accept MarketRegime enum as well as plain string."""
        from tcos_bot.models.types import MarketRegime
        r = self.gate.check("BUYEN", self.TS.UPTREND, MarketRegime.TRENDING)
        self.assertTrue(r.allowed)

    def test_lowercase_regime_normalised(self):
        r = self.gate.check("BUYEN", self.TS.UPTREND, "trending")
        self.assertTrue(r.allowed)


# ══════════════════════════════════════════════════════════════════════════════
# PART 4 — Reversal behaviour preserved
# ══════════════════════════════════════════════════════════════════════════════

class TestReversalPreservation(unittest.TestCase):
    """
    Valid reversals must NOT be globally killed by the new filter.
    This tests the specific scenario from the spec: reversals in non-trending
    contexts must still pass.
    """

    def setUp(self):
        from tcos_bot.filters.directional_gate import DirectionalGate
        from tcos_bot.signals.trend_state import TrendState
        self.gate = DirectionalGate()
        self.TS   = TrendState

    def test_reversal_call_allowed_in_sideways(self):
        """
        A BUYEN (enter CALL) against a mildly bearish trend is valid reversal
        on a range day and must be allowed in SIDEWAYS (with penalty).
        """
        r = self.gate.check("BUYEN", self.TS.DOWNTREND, "SIDEWAYS")
        self.assertTrue(r.allowed, "Counter-trend reversal must be allowed in SIDEWAYS")
        self.assertLess(r.size_multiplier, 1.0, "But with a size penalty")

    def test_reversal_put_allowed_in_sideways(self):
        r = self.gate.check("SELEX", self.TS.UPTREND, "SIDEWAYS")
        self.assertTrue(r.allowed)
        self.assertLess(r.size_multiplier, 1.0)

    def test_reversal_allowed_in_volatile(self):
        """Reversals in VOLATILE regime should pass (with penalty)."""
        r = self.gate.check("BUYEN", self.TS.DOWNTREND, "VOLATILE")
        self.assertTrue(r.allowed)

    def test_reversal_hard_blocked_only_in_trending(self):
        """Hard block is strictly reserved for TRENDING regime only."""
        for regime in ("SIDEWAYS", "VOLATILE", "UNKNOWN"):
            r = self.gate.check("BUYEN", self.TS.DOWNTREND, regime)
            self.assertTrue(r.allowed,
                            f"Counter-trend should not be hard-blocked in {regime}")


# ══════════════════════════════════════════════════════════════════════════════
# PART 7 — Bug-fix regressions
# ══════════════════════════════════════════════════════════════════════════════

class TestBugARegumeStringConsistency(unittest.TestCase):
    """
    Bug A: regime values stored as str(enum) produced 'MarketRegime.TRENDING'
    instead of 'TRENDING'. Verify the fix.
    """

    def test_regime_value_is_plain_string(self):
        from tcos_bot.models.types import MarketRegime
        regime = MarketRegime.TRENDING
        # After fix: use .value everywhere, not str(enum)
        self.assertEqual(regime.value, "TRENDING")
        self.assertNotIn("MarketRegime", regime.value)

    def test_day_regime_result_uses_value(self):
        """DayRegimeResult.regime is a MarketRegime enum whose .value is plain."""
        from tcos_bot.filters.day_regime import DayRegimeClassifier
        clf = DayRegimeClassifier()
        ohlc = pd.DataFrame({
            "timestamp": pd.date_range("2026-03-15 09:15", periods=20, freq="1min"),
            "open":  [22000] * 20, "high":  [22100] * 20,
            "low":   [21900] * 20, "close": [22050] * 20,
            "atr":   [80.0]  * 20,
        })
        result = clf.classify(ohlc, vix=14.0, brick_size=50)
        self.assertIsInstance(result.regime.value, str)
        self.assertNotIn("MarketRegime", result.regime.value)

    def test_whipsaw_manager_accepts_regime_value(self):
        """
        The whipsaw manager must correctly match regime strings to multipliers.
        If regime were stored as 'MarketRegime.TRENDING', the multiplier
        would silently fall back to 1.0 (UNKNOWN) instead of 0.5 (TRENDING).
        """
        from tcos_bot.risk.whipsaw_manager import AdaptiveWhipsawManager
        mgr = AdaptiveWhipsawManager()
        # Record a flip with proper regime string
        mgr.record_flip("NIFTY", "STOPLOSS", regime="TRENDING")
        info = mgr.cooldown_info("NIFTY")
        self.assertIsNotNone(info)
        # Trending multiplier is 0.5 — cooldown must be < base_cooldown
        # Just verify the regime string was accepted (no exception)
        self.assertIn("TRENDING", info["reason"])


class TestBugBResultNameError(unittest.TestCase):
    """
    Bug B: signal_generator.process() referenced `result` before it existed
    in scope (before _create_entry was called), causing NameError.
    Verify the fix: process() no longer crashes on BUYEN/SELEX signals.
    """

    def _make_generator(self):
        """Build a SignalGenerator with a fully mocked pipeline that passes."""
        from unittest.mock import MagicMock, patch
        from tcos_bot.signals.signal_generator import SignalGenerator
        from tcos_bot.models.types import MarketRegime, QualityResult, SignalGrade

        gen = SignalGenerator()

        # Mock pipeline to pass with grade A
        mock_result = QualityResult(
            allowed=True, grade=SignalGrade.A, score=7,
            size_multiplier=1.0, reasons=["mock"], blocks=[],
            regime=MarketRegime.TRENDING,
        )
        gen._pipeline.evaluate = MagicMock(return_value=mock_result)
        # Set _result so current_regime property returns TRENDING
        from tcos_bot.models.types import DayRegimeResult
        from datetime import datetime
        gen._pipeline._day_regime._result = DayRegimeResult(
            regime=MarketRegime.TRENDING, confidence=0.85, vix=14.0,
            range_ratio=2.0, classified_at=datetime.now()
        )
        return gen

    def _make_renko(self, signal="BUYEN"):
        ts = "2026-03-15 10:00:00"
        return pd.DataFrame([{
            "timestamp": ts, "Signal": signal, "Renko_Brick": 22000.0,
            "zlema9": 21800.0, "Colour_Brick_Count": 3, "direction": 1,
            "HH": True, "LL": False, "HL": False, "LH": False,
            "Last_High": 22500.0, "Last_Low": 21500.0,
        }])

    @patch("tcos_bot.signals.signal_generator.ltp_store")
    @patch("tcos_bot.risk.risk_manager.whipsaw_tracker")
    def test_buyen_does_not_raise_nameerror(self, mock_ws, mock_ltp):
        """process() with BUYEN signal must not raise NameError."""
        mock_ltp.get.return_value = (22000.0, 0.5)   # fresh LTP
        gen = self._make_generator()
        renko = self._make_renko("BUYEN")
        tm = pd.DataFrame(columns=["symbol", "exchange", "renko_signal",
                                    "order_status", "entry_price", "quantity",
                                    "timestamp", "close_reason"])
        # Should not raise
        try:
            gen.process(tm, "NIFTY", "NSE_INDEX", renko, None, 50.0, {})
        except NameError as e:
            self.fail(f"NameError raised — Bug B not fixed: {e}")

    @patch("tcos_bot.signals.signal_generator.ltp_store")
    @patch("tcos_bot.risk.risk_manager.whipsaw_tracker")
    def test_selex_does_not_raise_nameerror(self, mock_ws, mock_ltp):
        mock_ltp.get.return_value = (22000.0, 0.5)
        gen = self._make_generator()
        renko = self._make_renko("SELEX")
        tm = pd.DataFrame(columns=["symbol", "exchange", "renko_signal",
                                    "order_status", "entry_price", "quantity",
                                    "timestamp", "close_reason"])
        try:
            gen.process(tm, "NIFTY", "NSE_INDEX", renko, None, 50.0, {})
        except NameError as e:
            self.fail(f"NameError raised — Bug B not fixed: {e}")


class TestBugCSavedfRobustness(unittest.TestCase):
    """
    Bug C: position_tracker.execute_order() called trade_store.save_df()
    unconditionally; fake trade stores without that method crashed with AttributeError.
    Verify the fix: hasattr guard prevents crash.
    """

    def test_fake_store_without_save_df_does_not_crash(self):
        """A trade store object without save_df must be tolerated."""
        class MinimalStore:
            def read_df(self): return pd.DataFrame()
            # deliberately NO save_df

        store = MinimalStore()
        # The guard: hasattr(trade_store, "save_df")
        self.assertFalse(hasattr(store, "save_df"))
        # Calling with guard should be safe
        if hasattr(store, "save_df"):
            store.save_df(pd.DataFrame())   # would crash
        # We reach here without exception — guard works


class TestBugDGetEngine(unittest.TestCase):
    """
    Bug D: _engine was module-level — crash if imported before TRADE_DB_URL set.
    Fix: lazy _get_engine() + public get_engine() accessor.
    When SQLAlchemy is unavailable, get_engine() raises ImportError cleanly.
    """

    def test_get_engine_is_exported(self):
        from tcos_bot.data.trade_store import get_engine
        self.assertTrue(callable(get_engine))

    def test_get_engine_returns_engine_or_raises_cleanly(self):
        """
        With SQLAlchemy installed: get_engine() returns an engine with .connect.
        Without SQLAlchemy: get_engine() raises ImportError with a clear message
        (not a cryptic crash or AttributeError).
        """
        from tcos_bot.data.trade_store import get_engine, _SQLALCHEMY_AVAILABLE
        if _SQLALCHEMY_AVAILABLE:
            eng = get_engine()
            self.assertIsNotNone(eng)
            self.assertTrue(hasattr(eng, "connect"))
        else:
            # No SQLAlchemy — must raise ImportError, not crash silently
            with self.assertRaises(ImportError) as ctx:
                get_engine()
            self.assertIn("sqlalchemy", str(ctx.exception).lower())

    def test_get_engine_idempotent_when_available(self):
        """When SQLAlchemy is available, repeated calls return the same instance."""
        from tcos_bot.data.trade_store import get_engine, _SQLALCHEMY_AVAILABLE
        if not _SQLALCHEMY_AVAILABLE:
            self.skipTest("SQLAlchemy not installed — idempotency test skipped")
        e1 = get_engine()
        e2 = get_engine()
        self.assertIs(e1, e2)


# ══════════════════════════════════════════════════════════════════════════════
# PART 6 — Websocket / feed health
# ══════════════════════════════════════════════════════════════════════════════

class TestFeedHealthGate(unittest.TestCase):
    """
    Part 6: New entries must be blocked when WebSocket feed is unhealthy.
    The _create_entry() method in signal_generator now checks is_feed_healthy()
    before placing an entry, returning (tm, False) on unhealthy feed.
    """

    def _make_generator(self, feed_healthy: bool):
        from unittest.mock import MagicMock
        from tcos_bot.signals.signal_generator import SignalGenerator
        from tcos_bot.models.types import MarketRegime, QualityResult, SignalGrade, DayRegimeResult
        from datetime import datetime

        gen = SignalGenerator()
        mock_result = QualityResult(
            allowed=True, grade=SignalGrade.A, score=7,
            size_multiplier=1.0, reasons=["mock"], blocks=[],
            regime=MarketRegime.TRENDING,
        )
        gen._pipeline.evaluate = MagicMock(return_value=mock_result)
        gen._pipeline._day_regime._result = DayRegimeResult(
            regime=MarketRegime.TRENDING, confidence=0.85, vix=14.0,
            range_ratio=2.0, classified_at=datetime.now()
        )

        # Inject a mock ws_manager_instance that reports feed health
        mock_ws = MagicMock()
        mock_ws.is_feed_healthy.return_value = feed_healthy
        return gen, mock_ws

    @patch("tcos_bot.signals.signal_generator.ltp_store")
    def test_stale_feed_blocks_entry(self, mock_ltp):
        """When WS feed is unhealthy, _create_entry must return (tm, False)."""
        mock_ltp.get.return_value = (22000.0, 0.5)
        gen, mock_ws = self._make_generator(feed_healthy=False)

        tm = pd.DataFrame(columns=["symbol", "exchange", "renko_signal",
                                    "order_status", "entry_price"])
        renko = pd.DataFrame([_renko_row()])

        with patch("tcos_bot.signals.signal_generator._ws_manager_instance", mock_ws):
            result_tm, added = gen._create_entry(
                tm, "NIFTY", "NSE_INDEX", "BUYCL",
                22000.0, "2026-03-15 10:00:00", renko, None, 50.0,
            )
        self.assertFalse(added, "Entry must be blocked when feed is unhealthy")

    @patch("tcos_bot.signals.signal_generator.ltp_store")
    def test_healthy_feed_allows_entry_to_proceed_to_pipeline(self, mock_ltp):
        """When WS feed is healthy, feed-health gate is transparent."""
        mock_ltp.get.return_value = (22000.0, 0.5)
        gen, mock_ws = self._make_generator(feed_healthy=True)

        tm = pd.DataFrame(columns=["symbol", "exchange", "renko_signal",
                                    "order_status", "entry_price",
                                    "quantity", "timestamp", "close_reason"])
        renko = pd.DataFrame([_renko_row()])

        with patch("tcos_bot.signals.signal_generator._ws_manager_instance", mock_ws):
            result_tm, added = gen._create_entry(
                tm, "NIFTY", "NSE_INDEX", "BUYCL",
                22000.0, "2026-03-15 10:00:00", renko, None, 50.0,
            )
        # Pipeline was reached (not blocked by feed gate)
        gen._pipeline.evaluate.assert_called_once()

    @patch("tcos_bot.signals.signal_generator.ltp_store")
    def test_no_ws_manager_allows_entry(self, mock_ltp):
        """When _ws_manager_instance is None (e.g. test env), gate is transparent."""
        mock_ltp.get.return_value = (22000.0, 0.5)
        gen, _ = self._make_generator(feed_healthy=True)

        tm = pd.DataFrame(columns=["symbol", "exchange", "renko_signal",
                                    "order_status", "entry_price",
                                    "quantity", "timestamp", "close_reason"])
        renko = pd.DataFrame([_renko_row()])

        with patch("tcos_bot.signals.signal_generator._ws_manager_instance", None):
            result_tm, added = gen._create_entry(
                tm, "NIFTY", "NSE_INDEX", "BUYCL",
                22000.0, "2026-03-15 10:00:00", renko, None, 50.0,
            )
        # Gate absent → pipeline reached
        gen._pipeline.evaluate.assert_called_once()

    def test_stale_ltp_still_blocks_independently(self):
        """LTP staleness gate operates independently from feed-health gate."""
        from unittest.mock import MagicMock, patch
        from tcos_bot.signals.signal_generator import SignalGenerator
        from tcos_bot.models.types import MarketRegime, QualityResult, SignalGrade
        from tcos_bot.config.settings import cfg

        gen = SignalGenerator()
        gen._pipeline.evaluate = MagicMock(return_value=MagicMock(blocked=False))

        tm = pd.DataFrame(columns=["symbol"])
        renko = pd.DataFrame([_renko_row()])

        # LTP age > hard block threshold — entry blocked before feed check
        stale_age = cfg.broker.ltp_hard_block_secs + 10
        with patch("tcos_bot.signals.signal_generator.ltp_store") as mock_ltp:
            mock_ltp.get.return_value = (22000.0, stale_age)
            result_tm, added = gen._create_entry(
                tm, "NIFTY", "NSE_INDEX", "BUYCL",
                22000.0, "2026-03-15 10:00:00", renko, None, 50.0,
            )
        self.assertFalse(added)
        # Pipeline not even reached
        gen._pipeline.evaluate.assert_not_called()


# ══════════════════════════════════════════════════════════════════════════════
# PART 8 — Regime consistency end-to-end
# ══════════════════════════════════════════════════════════════════════════════

class TestRegimeStringNormalization(unittest.TestCase):
    """
    Verify that regime strings stored in trade rows match what the whipsaw
    manager and other comparators expect — plain 'TRENDING', not 'MarketRegime.TRENDING'.
    """

    def test_pipeline_returns_plain_regime_string_on_block(self):
        """Pipeline QualityResult.regime on a block path uses .value."""
        from tcos_bot.filters.pipeline import FilterPipeline
        from tcos_bot.models.types import MarketRegime

        pipe = FilterPipeline()
        # Force classify to SIDEWAYS (will now return half-size, not block)
        from tcos_bot.models.types import DayRegimeResult
        pipe._day_regime._result = DayRegimeResult(
            regime=MarketRegime.SIDEWAYS,
            confidence=0.8, vix=14.0, range_ratio=0.5,
            classified_at=datetime.now(),
        )
        # SIDEWAYS no longer hard-blocks (design fix) — check regime value on pass
        result = pipe.evaluate(
            "NIFTY", "BUYEN", None,  # no renko — default grade B
            ltp=22000.0, exchange="NSE_INDEX",
            signal_timestamp="2026-03-15 10:00:00",
        )
        # regime field should be plain string
        regime_val = result.regime
        if hasattr(regime_val, "value"):
            regime_val = regime_val.value
        self.assertNotIn("MarketRegime", str(regime_val),
                         f"Regime should be plain value, got: {regime_val}")

    def test_quality_result_regime_is_string_valued(self):
        """QualityResult.regime is always a comparable string, not repr."""
        from tcos_bot.models.types import MarketRegime, QualityResult, SignalGrade
        r = QualityResult(
            allowed=True, grade=SignalGrade.A, score=5,
            size_multiplier=1.0, reasons=[], blocks=[],
            regime=MarketRegime.TRENDING,
        )
        # The whipsaw manager does: regime.upper() → must work cleanly
        regime = r.regime
        regime_str = regime.value if hasattr(regime, "value") else str(regime)
        self.assertEqual(regime_str.upper(), "TRENDING")


# ══════════════════════════════════════════════════════════════════════════════
# PART 8 — Pipeline integration: directional gate blocks counter-trend in TRENDING
# ══════════════════════════════════════════════════════════════════════════════

class TestPipelineDirectionalIntegration(unittest.TestCase):
    """
    End-to-end: FilterPipeline.evaluate() with TRENDING regime + strong downtrend
    must block a BUYEN (CALL) entry via the DirectionalGate layer.
    """

    def _make_classified_pipeline(self, regime_str: str):
        from tcos_bot.filters.pipeline import FilterPipeline
        from tcos_bot.models.types import DayRegimeResult, MarketRegime
        pipe = FilterPipeline()
        pipe._day_regime._result = DayRegimeResult(
            regime=MarketRegime(regime_str),
            confidence=0.85, vix=14.0, range_ratio=2.0,
            classified_at=datetime.now(),
        )
        return pipe

    def _renko_downtrend(self) -> pd.DataFrame:
        """Strong downtrend: price < ZLEMA, LL, 3 down bricks."""
        return _renko_df(_renko_row(
            brick=21000, zlema=21800, c_count=3, direction=-1,
            hh=False, ll=True, hl=False, lh=False,
        ))

    def _renko_uptrend(self) -> pd.DataFrame:
        """Strong uptrend: price > ZLEMA, HH, 3 up bricks."""
        return _renko_df(_renko_row(
            brick=22000, zlema=21800, c_count=3, direction=1,
            hh=True, ll=False, hl=False, lh=False,
        ))

    def test_trending_downtrend_blocks_buyen(self):
        """TRENDING + clear downtrend → BUYEN (CALL) must be hard-blocked."""
        pipe = self._make_classified_pipeline("TRENDING")
        result = pipe.evaluate(
            "NIFTY", "BUYEN", self._renko_downtrend(),
            ltp=21000.0, exchange="NSE_INDEX",
            signal_timestamp="2026-03-15 10:00:00",
        )
        self.assertFalse(result.allowed,
                         "TRENDING+downtrend BUYEN must be blocked by DirectionalGate")

    def test_trending_uptrend_allows_buyen(self):
        """TRENDING + clear uptrend → BUYEN aligned → must pass."""
        pipe = self._make_classified_pipeline("TRENDING")
        result = pipe.evaluate(
            "NIFTY", "BUYEN", self._renko_uptrend(),
            ltp=22000.0, exchange="NSE_INDEX",
            signal_timestamp="2026-03-15 10:00:00",
        )
        # May still be blocked by signal quality / option quality in test env,
        # but must NOT be blocked by DirectionalGate specifically
        if not result.allowed:
            self.assertNotIn("DIRECTIONAL_BLOCK", " ".join(result.blocks),
                             "Should not be blocked by DirectionalGate for aligned signal")

    def test_sideways_allows_counter_trend_with_penalty(self):
        """SIDEWAYS + downtrend → BUYEN should be allowed (with ≤ 0.5 size)."""
        pipe = self._make_classified_pipeline("SIDEWAYS")
        result = pipe.evaluate(
            "NIFTY", "BUYEN", self._renko_downtrend(),
            ltp=21000.0, exchange="NSE_INDEX",
            signal_timestamp="2026-03-15 10:00:00",
        )
        if result.allowed:
            self.assertLessEqual(result.size_multiplier, 0.5,
                                 "Counter-trend in SIDEWAYS must have size penalty")
        else:
            # Only acceptable block reason is non-directional (quality/time/etc.)
            self.assertNotIn("DIRECTIONAL_BLOCK", " ".join(result.blocks),
                             "DirectionalGate must not hard-block in SIDEWAYS")


# ══════════════════════════════════════════════════════════════════════════════
# PART 8 — Persistence robustness
# ══════════════════════════════════════════════════════════════════════════════

class TestPersistenceRobustness(unittest.TestCase):
    """
    Bug C regression: any object without save_df must not crash the bot.
    Also verify the real TradeStore has save_df and get_engine.
    """

    def test_real_trade_store_has_save_df(self):
        from tcos_bot.data.trade_store import trade_store
        self.assertTrue(hasattr(trade_store, "save_df"))
        self.assertTrue(callable(trade_store.save_df))

    def test_real_trade_store_has_get_engine(self):
        from tcos_bot.data.trade_store import get_engine
        self.assertTrue(callable(get_engine))

    def test_hasattr_guard_pattern_is_safe(self):
        """Direct proof that the hasattr guard pattern works."""
        class NoSaveDF:
            pass

        store = NoSaveDF()
        df = pd.DataFrame([{"a": 1}])
        # This is the exact guard pattern in position_tracker.py
        called = False
        if hasattr(store, "save_df"):
            store.save_df(df)
            called = True
        self.assertFalse(called, "save_df should not be called on a store without it")


# ══════════════════════════════════════════════════════════════════════════════
# PART 8 — Whipsaw cooldown regime-awareness
# ══════════════════════════════════════════════════════════════════════════════

class TestWhipsawRegimeAwareness(unittest.TestCase):
    """
    Verify adaptive whipsaw cooldowns respect regime multipliers.
    After Bug A fix, regime strings flow correctly into the manager.
    """

    def setUp(self):
        from tcos_bot.risk.whipsaw_manager import AdaptiveWhipsawManager
        self.mgr = AdaptiveWhipsawManager()

    def test_trending_cooldown_shorter_than_volatile(self):
        """
        TRENDING multiplier (0.5×) → cooldown shorter than VOLATILE (2.0×).
        """
        self.mgr.record_flip("SYM_T", "STOPLOSS", regime="TRENDING")
        self.mgr.record_flip("SYM_V", "STOPLOSS", regime="VOLATILE")

        info_t = self.mgr.cooldown_info("SYM_T")
        info_v = self.mgr.cooldown_info("SYM_V")

        self.assertIsNotNone(info_t)
        self.assertIsNotNone(info_v)
        self.assertLess(info_t["remaining_secs"], info_v["remaining_secs"],
                        "TRENDING cooldown must be shorter than VOLATILE")

    def test_chop_exit_shorter_than_stoploss(self):
        """CHOP_OSCILLATION_EXIT cooldown is shorter than STOPLOSS cooldown."""
        self.mgr.record_flip("SYM_C", "CHOP_OSCILLATION_EXIT", regime="UNKNOWN")
        self.mgr.record_flip("SYM_S", "STOPLOSS",              regime="UNKNOWN")

        info_c = self.mgr.cooldown_info("SYM_C")
        info_s = self.mgr.cooldown_info("SYM_S")

        self.assertIsNotNone(info_c)
        self.assertIsNotNone(info_s)
        self.assertLess(info_c["remaining_secs"], info_s["remaining_secs"],
                        "Chop exit must be penalised less than a real stop")

    def test_regime_string_mismatch_uses_unknown_multiplier(self):
        """
        If a bad regime string like 'MarketRegime.TRENDING' is passed
        (the old bug), multiplier silently falls to 1.0 (UNKNOWN).
        The fix ensures proper strings are passed.
        """
        self.mgr.record_flip("BAD_A", "STOPLOSS", regime="MarketRegime.TRENDING")
        self.mgr.record_flip("GOOD_A", "STOPLOSS", regime="TRENDING")

        info_bad  = self.mgr.cooldown_info("BAD_A")
        info_good = self.mgr.cooldown_info("GOOD_A")

        self.assertIsNotNone(info_bad)
        self.assertIsNotNone(info_good)
        # Bad string → UNKNOWN multiplier (1.0) → longer cooldown than TRENDING (0.5×)
        self.assertGreater(info_bad["remaining_secs"], info_good["remaining_secs"],
                           "Malformed regime string should result in longer cooldown (UNKNOWN path)")


if __name__ == "__main__":
    unittest.main(verbosity=2)
