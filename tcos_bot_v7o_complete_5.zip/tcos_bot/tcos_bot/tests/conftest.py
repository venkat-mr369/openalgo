import pytest
"""
conftest.py — test fixtures
============================
Sets TRADE_DB_URL to a temp-file SQLite before any module-level SQLAlchemy
engine is created, so tests never touch the real tradebook.db.

NOTE: :memory: does NOT work with NullPool (each connection gets a fresh DB).
Use a real tmp file instead.
"""

import os
import sys
import tempfile

# Create a temp file for the test session DB
_db_fd, _db_path = tempfile.mkstemp(suffix=".db", prefix="tcos_test_")
os.close(_db_fd)

# Must be set BEFORE any tcos_bot module is imported so the
# module-level `_engine = create_engine(cfg.persistence.db_url)` picks it up.
os.environ["TRADE_DB_URL"] = f"sqlite:///{_db_path}"
os.environ.setdefault("OPENALGO_API_KEY", "test-key-placeholder")
os.environ.setdefault("OPENALGO_HOST",    "http://localhost:5000")

# Patch cfg so all subsequent imports use the temp DB
from tcos_bot.config.settings import cfg, PersistenceConfig
import dataclasses
object.__setattr__(cfg, "persistence", dataclasses.replace(
    cfg.persistence, db_url=f"sqlite:///{_db_path}"
))

import sys as _sys

@pytest.fixture(autouse=True, scope="function")
def _restore_real_modules(request):
    """
    test_patches.py stubs out tcos_bot.data.trade_store and tcos_bot.data.ltp_store
    at MODULE LEVEL (not inside tests), which permanently replaces them in sys.modules
    for the entire pytest session.  Any test that needs the REAL trade_store (e.g.
    test_reconciler, test_flow TradeStoreRoundTrip) runs after test_patches has
    already injected the stub and gets the wrong module.

    This fixture removes the stubs from sys.modules before each test so that
    subsequent imports resolve to the real modules.  test_patches tests are
    unaffected because they use the already-imported stub references directly.
    """
    _STUBS = ("tcos_bot.data.trade_store", "tcos_bot.data.ltp_store")
    removed = {}
    for name in _STUBS:
        mod = _sys.modules.get(name)
        if mod is not None and getattr(mod, "__file__", None) is None:
            # Module has no __file__ → it's a stub, not the real package
            removed[name] = _sys.modules.pop(name)
    yield
    # Restore stubs after test so test_patches tests still work if run again
    for name, mod in removed.items():
        _sys.modules.setdefault(name, mod)
