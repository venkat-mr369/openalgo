"""
test_expiry_day.py
==================
Pins the expiry-day block / bypass behaviour for OptionQualityGate and
the full FilterPipeline.

Tests are organised into four groups:

  A. OptionQualityGate._check_dow  — unit tests, no pipeline overhead
  B. FilterPipeline.evaluate       — integration tests through the full gate
  C. Safety controls not affected  — market-hours + opening-range filters
     must remain active regardless of trade_on_expiry setting
  D. Strike selection unaffected   — select_strike still works on Thursday

Run with:
    pytest tcos_bot/tests/test_expiry_day.py -v
"""

from __future__ import annotations

import threading
from datetime import datetime, date
from typing import Optional
from unittest.mock import patch, MagicMock

import pandas as pd
import pytest

from tcos_bot.filters.base import FilterResult
from tcos_bot.filters.option_quality import OptionQualityGate, _DOW_LABELS
from tcos_bot.config.settings import OptionQualityConfig


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _make_gate(trade_on_expiry: bool) -> OptionQualityGate:
    """Build an OptionQualityGate with a patched config flag."""
    gate = OptionQualityGate.__new__(OptionQualityGate)
    gate._cfg = OptionQualityConfig(trade_on_expiry=trade_on_expiry)
    return gate


def _thursday_patch():
    """Context manager: make datetime.now().weekday() return 3 (Thursday)."""
    mock_dt = MagicMock(wraps=datetime)
    mock_dt.now.return_value = MagicMock(weekday=MagicMock(return_value=3))
    return patch("tcos_bot.filters.option_quality.datetime", mock_dt)


def _day_patch(weekday: int):
    """Context manager: make datetime.now().weekday() return *weekday*."""
    mock_dt = MagicMock(wraps=datetime)
    mock_dt.now.return_value = MagicMock(weekday=MagicMock(return_value=weekday))
    return patch("tcos_bot.filters.option_quality.datetime", mock_dt)


def _minimal_renko() -> pd.DataFrame:
    """Minimal Renko-like DataFrame that passes SignalQualityScorer."""
    return pd.DataFrame([{
        "Renko_Brick":       22500.0,
        "zlema9":            22200.0,
        "Colour_Brick_Count": 4,
        "HH": True, "HL": False, "LH": False, "LL": False,
        "Last_High": 22800.0,
        "Last_Low":  22000.0,
        "brick_size_hint": 50,
        "Signal": "BUYEN",
        "Close_Signal": "BUYEN",
    }])


# ─────────────────────────────────────────────────────────────────────────────
# A. OptionQualityGate unit tests
# ─────────────────────────────────────────────────────────────────────────────

class TestOptionQualityGateDow:

    # ── trade_on_expiry=True (default) ────────────────────────────────────────

    def test_thursday_allowed_when_trade_on_expiry_true(self):
        """Thursday must NOT block when trade_on_expiry=True."""
        gate = _make_gate(trade_on_expiry=True)
        with _thursday_patch():
            result = gate._check_dow()
        assert result.allowed is True, (
            f"Expected allowed=True on Thursday with trade_on_expiry=True, "
            f"got reason={result.reason!r}"
        )

    def test_thursday_full_size_when_trade_on_expiry_true(self):
        """Thursday bypass should return size_multiplier=1.0."""
        gate = _make_gate(trade_on_expiry=True)
        with _thursday_patch():
            result = gate._check_dow()
        assert result.size_multiplier == 1.0

    def test_thursday_reason_contains_bypass_when_trade_on_expiry_true(self):
        """Reason string should mention the bypass for observability."""
        gate = _make_gate(trade_on_expiry=True)
        with _thursday_patch():
            result = gate._check_dow()
        assert "BYPASS" in result.reason or "bypass" in result.reason.lower(), (
            f"Bypass not mentioned in reason: {result.reason!r}"
        )

    # ── trade_on_expiry=False (legacy) ────────────────────────────────────────

    def test_thursday_blocked_when_trade_on_expiry_false(self):
        """Thursday must BLOCK when trade_on_expiry=False (legacy mode)."""
        gate = _make_gate(trade_on_expiry=False)
        with _thursday_patch():
            result = gate._check_dow()
        assert result.allowed is False, (
            f"Expected allowed=False on Thursday with trade_on_expiry=False, "
            f"got reason={result.reason!r}"
        )

    def test_thursday_block_reason_when_legacy(self):
        """Legacy block reason must contain DOW_BLOCK."""
        gate = _make_gate(trade_on_expiry=False)
        with _thursday_patch():
            result = gate._check_dow()
        assert "DOW_BLOCK" in result.reason

    def test_thursday_block_size_zero_when_legacy(self):
        gate = _make_gate(trade_on_expiry=False)
        with _thursday_patch():
            result = gate._check_dow()
        assert result.size_multiplier == 0.0

    # ── Other days unaffected by flag ─────────────────────────────────────────

    @pytest.mark.parametrize("dow,expected_allowed,expected_size", [
        (0, True,  1.0),   # Monday — full
        (1, True,  1.0),   # Tuesday — full
        (2, True,  0.5),   # Wednesday — half
        (4, True,  0.5),   # Friday — half
    ])
    def test_non_thursday_days_unaffected_by_trade_on_expiry_true(
        self, dow, expected_allowed, expected_size
    ):
        """Non-Thursday days must behave identically regardless of trade_on_expiry."""
        for flag in (True, False):
            gate = _make_gate(trade_on_expiry=flag)
            with _day_patch(dow):
                result = gate._check_dow()
            assert result.allowed is expected_allowed, (
                f"DOW={dow} trade_on_expiry={flag}: expected allowed={expected_allowed}, "
                f"got {result.allowed} (reason={result.reason!r})"
            )
            assert result.size_multiplier == expected_size, (
                f"DOW={dow} trade_on_expiry={flag}: expected size={expected_size}, "
                f"got {result.size_multiplier}"
            )

    def test_wednesday_half_size_trade_on_expiry_true(self):
        gate = _make_gate(trade_on_expiry=True)
        with _day_patch(2):
            result = gate._check_dow()
        assert result.allowed is True
        assert result.size_multiplier == 0.5

    def test_friday_half_size_trade_on_expiry_false(self):
        gate = _make_gate(trade_on_expiry=False)
        with _day_patch(4):
            result = gate._check_dow()
        assert result.allowed is True
        assert result.size_multiplier == 0.5

    # ── Full check() surface (not just _check_dow) ────────────────────────────

    def test_check_passes_on_thursday_when_trade_on_expiry_true(self):
        gate = _make_gate(trade_on_expiry=True)
        with _thursday_patch():
            result = gate.check("NIFTY", "BUYEN")
        assert result.allowed is True

    def test_check_blocks_on_thursday_when_trade_on_expiry_false(self):
        gate = _make_gate(trade_on_expiry=False)
        with _thursday_patch():
            result = gate.check("NIFTY", "BUYEN")
        assert result.allowed is False


# ─────────────────────────────────────────────────────────────────────────────
# B. FilterPipeline integration tests
# ─────────────────────────────────────────────────────────────────────────────

class TestFilterPipelineExpiryDay:
    """
    Test the full FilterPipeline.evaluate() path on Thursday.
    We patch: datetime (weekday=Thursday), market time (within session),
    day regime (classified, not blocked), signal quality (pass).
    """

    def _make_pipeline(self, trade_on_expiry: bool):
        """Return a FilterPipeline whose OptionQualityGate uses the given flag."""
        from tcos_bot.filters.pipeline import FilterPipeline
        pipeline = FilterPipeline()
        # Swap out the option quality gate with a custom-configured one
        pipeline._opt_quality = _make_gate(trade_on_expiry=trade_on_expiry)
        return pipeline

    def _evaluate_on_thursday(self, pipeline, signal: str = "BUYEN"):
        """
        Call pipeline.evaluate() with all non-expiry filters bypassed or
        set to pass, on a mocked Thursday at 10:30 IST (well within session).
        """
        from tcos_bot.filters.pipeline import FilterPipeline
        renko_df = _minimal_renko()

        # Patch market-time check to always allow (we test it separately)
        def _allow_time(*a, **kw): return FilterResult.allow("TIME_OK")
        def _allow_or(*a, **kw):   return FilterResult.allow("OR_OK")

        # Patch day_regime.check to allow
        pipeline._day_regime.check = lambda *a, **kw: FilterResult.allow("REGIME_OK", size=1.0)

        # Patch signal_quality.check + score_only
        pipeline._sig_quality.check = lambda *a, **kw: FilterResult.allow("SQ_OK", size=1.0)
        pipeline._sig_quality.score_only = lambda *a, **kw: {"grade": "A", "score": 7}

        with (
            _thursday_patch(),
            patch.object(pipeline, "_check_market_time", _allow_time),
            patch.object(pipeline, "_check_opening_range", _allow_or),
        ):
            return pipeline.evaluate(
                symbol="NIFTY",
                signal=signal,
                renko_df=renko_df,
                exchange="NSE_INDEX",
                signal_timestamp=pd.Timestamp("2025-01-16 10:30:00"),
                ohlc_df=pd.DataFrame(),
                brick_size=50,
                ltp=22500.0,
            )

    def test_pipeline_allows_entry_on_thursday_when_trade_on_expiry_true(self):
        """Full pipeline must pass BUYEN on Thursday when trade_on_expiry=True."""
        pipeline = self._make_pipeline(trade_on_expiry=True)
        result = self._evaluate_on_thursday(pipeline, "BUYEN")
        assert result.allowed is True, (
            f"Pipeline blocked on Thursday with trade_on_expiry=True: "
            f"blocks={result.blocks}"
        )

    def test_pipeline_blocks_entry_on_thursday_when_trade_on_expiry_false(self):
        """Full pipeline must block BUYEN on Thursday when trade_on_expiry=False."""
        pipeline = self._make_pipeline(trade_on_expiry=False)
        result = self._evaluate_on_thursday(pipeline, "BUYEN")
        assert result.allowed is False, (
            f"Pipeline should have blocked on Thursday with trade_on_expiry=False, "
            f"but allowed=True"
        )
        assert any("DOW_BLOCK" in b for b in result.blocks), (
            f"Expected DOW_BLOCK in blocks, got: {result.blocks}"
        )

    def test_pipeline_block_reason_is_dow_expiry(self):
        """Block reason must clearly identify Thursday (EXPIRY) as the cause."""
        pipeline = self._make_pipeline(trade_on_expiry=False)
        result = self._evaluate_on_thursday(pipeline, "BUYEN")
        assert any("Thursday" in b or "EXPIRY" in b for b in result.blocks), (
            f"Block reason should mention Thursday/EXPIRY, got: {result.blocks}"
        )


# ─────────────────────────────────────────────────────────────────────────────
# C. Safety controls must remain active regardless of trade_on_expiry
# ─────────────────────────────────────────────────────────────────────────────

class TestSafetyControlsUnchanged:
    """
    Verify that market-hours and opening-range filters in FilterPipeline are
    completely independent of trade_on_expiry. Even with trade_on_expiry=True,
    entries must still be blocked outside market hours or during opening range.
    """

    def _pipeline_with_expiry_on(self):
        from tcos_bot.filters.pipeline import FilterPipeline
        pipeline = FilterPipeline()
        pipeline._opt_quality = _make_gate(trade_on_expiry=True)
        pipeline._day_regime.check      = lambda *a, **kw: FilterResult.allow("REGIME_OK", size=1.0)
        pipeline._sig_quality.check     = lambda *a, **kw: FilterResult.allow("SQ_OK", size=1.0)
        pipeline._sig_quality.score_only = lambda *a, **kw: {"grade": "A", "score": 7}
        return pipeline

    def test_market_closed_still_blocks_on_thursday(self):
        """
        Entries after market close (15:35) must be blocked even on Thursday
        with trade_on_expiry=True.
        """
        from tcos_bot.filters.pipeline import FilterPipeline
        pipeline = self._pipeline_with_expiry_on()

        # Patch IST now to 15:35 (after close)
        mock_dt = MagicMock(wraps=datetime)
        mock_dt.now.return_value = MagicMock(
            weekday=MagicMock(return_value=3),  # Thursday
            time=MagicMock(return_value=datetime(2025, 1, 16, 15, 35).time()),
        )

        with (
            patch("tcos_bot.filters.option_quality.datetime", mock_dt),
            patch("tcos_bot.filters.pipeline.datetime", mock_dt),
        ):
            result = pipeline.evaluate(
                symbol="NIFTY",
                signal="BUYEN",
                renko_df=_minimal_renko(),
                exchange="NSE_INDEX",
                signal_timestamp=pd.Timestamp("2025-01-16 15:35:00"),
                ohlc_df=pd.DataFrame(),
                brick_size=50,
                ltp=22500.0,
            )

        assert result.allowed is False, "After-hours entry must be blocked"
        assert any(
            "MARKET_CLOSED" in b or "NO_NEW_ENTRIES" in b for b in result.blocks
        ), f"Expected time-based block, got: {result.blocks}"

    def test_opening_range_still_blocks_on_thursday(self):
        """
        Entries during opening range (before 09:30) must be blocked on Thursday
        with trade_on_expiry=True.
        """
        from tcos_bot.filters.pipeline import FilterPipeline
        pipeline = self._pipeline_with_expiry_on()

        mock_dt = MagicMock(wraps=datetime)
        mock_dt.now.return_value = MagicMock(
            weekday=MagicMock(return_value=3),
            time=MagicMock(return_value=datetime(2025, 1, 16, 9, 20).time()),
        )

        with (
            patch("tcos_bot.filters.option_quality.datetime", mock_dt),
            patch("tcos_bot.filters.pipeline.datetime", mock_dt),
        ):
            result = pipeline.evaluate(
                symbol="NIFTY",
                signal="BUYEN",
                renko_df=_minimal_renko(),
                exchange="NSE_INDEX",
                signal_timestamp=pd.Timestamp("2025-01-16 09:20:00"),
                ohlc_df=pd.DataFrame(),
                brick_size=50,
                ltp=22500.0,
            )

        assert result.allowed is False, "Opening-range entry must be blocked"
        assert any(
            "OPENING_RANGE" in b for b in result.blocks
        ), f"Expected OPENING_RANGE block, got: {result.blocks}"


# ─────────────────────────────────────────────────────────────────────────────
# D. Strike selection unaffected
# ─────────────────────────────────────────────────────────────────────────────

class TestStrikeSelectionOnExpiry:
    """
    select_strike() uses days_to_expiry for strike logic, not the DoW flag.
    It must behave identically regardless of trade_on_expiry.
    """

    @pytest.mark.parametrize("trade_on_expiry", [True, False])
    def test_atm_strike_on_dte_zero(self, trade_on_expiry):
        """DTE=0 (expiry day itself) → ATM strike for both flag values."""
        gate = _make_gate(trade_on_expiry=trade_on_expiry)
        result = gate.select_strike(
            spot=22345.0, signal="BUYEN", symbol="NIFTY", days_to_expiry=0
        )
        assert result["strike"] == 22300  # round(22345/100)*100
        assert "ATM" in result["label"]

    @pytest.mark.parametrize("trade_on_expiry", [True, False])
    def test_itm_call_strike_on_normal_dte(self, trade_on_expiry):
        """DTE=5 → 1-ITM CALL strike for both flag values."""
        gate = _make_gate(trade_on_expiry=trade_on_expiry)
        result = gate.select_strike(
            spot=22345.0, signal="BUYEN", symbol="NIFTY", days_to_expiry=5
        )
        assert result["strike"] == 22200  # ATM=22300, 1-ITM CALL = 22300-100
        assert "ITM" in result["label"]

    @pytest.mark.parametrize("trade_on_expiry", [True, False])
    def test_itm_put_strike_on_normal_dte(self, trade_on_expiry):
        gate = _make_gate(trade_on_expiry=trade_on_expiry)
        result = gate.select_strike(
            spot=22345.0, signal="SELEX", symbol="NIFTY", days_to_expiry=5
        )
        assert result["strike"] == 22400  # ATM=22300, 1-ITM PUT = 22300+100


# ─────────────────────────────────────────────────────────────────────────────
# E. Config default value pinning
# ─────────────────────────────────────────────────────────────────────────────

class TestConfigDefaults:

    def test_trade_on_expiry_default_is_true(self):
        """Default config must enable expiry-day trading (trade_on_expiry=True)."""
        from tcos_bot.config.settings import cfg
        assert cfg.option_quality.trade_on_expiry is True, (
            "Default trade_on_expiry should be True so the bot trades on expiry days "
            "unless explicitly disabled."
        )

    def test_dow_size_map_thursday_still_zero_in_default(self):
        """
        dow_size_map[3] must remain 0.0 so that setting trade_on_expiry=False
        restores legacy blocking behaviour without any other change.
        """
        from tcos_bot.config.settings import cfg
        assert cfg.option_quality.dow_size_map[3] == 0.0, (
            "dow_size_map[3] must stay 0.0 as the legacy fallback value."
        )

    def test_option_quality_config_accepts_trade_on_expiry_false(self):
        """OptionQualityConfig can be constructed with trade_on_expiry=False."""
        c = OptionQualityConfig(trade_on_expiry=False)
        assert c.trade_on_expiry is False
