"""
Full Flow Integration Tests  –  v2
===================================
Tests every critical path in the bot without a real broker or real DB.

Coverage
--------
 1.  Trailing stop — initial stop, breakeven, trail, put-side, never-moves-down
 2.  Whipsaw — grace period, cooldown, expiry, clear, symbol independence
 3.  Exit dedup — OPEN, SENDING, no position, qty fallback from TM
 4.  Lot sizing — grade A/B, min-1-lot, always multiple of lot_size
 5.  PositionTracker.build_root_map — longs, shorts ignored, zero-qty, mix
 6.  Close reason — STOP_EXIT (SELST/SELSP) vs SIGNAL_EXIT (SELCL/SELPT)
 7.  brick_size_hint propagation — stop price uses correct brick_size per symbol
 8.  NFT exit dedup — OPEN + SENDING both block duplicate row
 9.  Chop exit dedup — same
10.  TradeStore DB round-trip — save / read / schema migration
11.  Reversal cancellation — BUYEN cancels BUYPT, SELEX cancels BUYCL
12.  Day regime filter — SIDEWAYS blocks, chop-guard halves, trending full-size
13.  Option resolver — CE/PE exit finds correct symbol, handles no-position
14.  Engine per-cycle double-exit block — two OPEN SELCL rows → only one dispatch
15.  Watchdog — SENDING reconciliation via broker positions
"""

from __future__ import annotations

import sys
import os
import time
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import MagicMock, patch

import pandas as pd
import pytest

_ROOT = Path(__file__).resolve().parent.parent.parent
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

os.environ.setdefault("OPENALGO_API_KEY", "test_key_123")
os.environ.setdefault("OPENALGO_HOST",    "http://localhost:5000")

from tcos_bot.filters.base import FilterResult
from tcos_bot.models.types import DayRegimeResult, MarketRegime
from tcos_bot.risk.risk_manager import (
    WhipsawCooldownTracker, TrailingStopManager,
    NFTChecker, ChopOscillationChecker,
)
from tcos_bot.signals.renko_engine import HybridRenkoGenerator


# ── helpers ───────────────────────────────────────────────────────────────────

def _make_ohlc(n=120, start=23000.0, step=10.0):
    ts = pd.date_range("2025-01-06 09:15", periods=n, freq="1min")
    return pd.DataFrame([
        {"timestamp": t, "open": start+i*step, "high": start+i*step+8,
         "low": start+i*step-4, "close": start+i*step+6}
        for i, t in enumerate(ts)
    ])

def _make_renko(brick_size=50, n=120):
    return HybridRenkoGenerator().generate(_make_ohlc(n=n), brick_size=brick_size)

def _empty_tm():
    cols = [
        "exchange","timestamp","renko_signal","symbol","entry_price","quantity",
        "order_status","close_reason","signal_grade","quality_score","day_regime",
        "brick_size_hint","orderid","option_symbol","index_ltp","fill_timestamp",
        "peak_brick_since_entry","peak_ltp_since_entry","nft_validated","nft_target",
        "nft_rev_count","nft_last_dir","chop_reversals","chop_last_dir","chop_last_ltp",
        "close_price","exec_price","entry_mode",
    ]
    return pd.DataFrame(columns=cols)

def _inposition_row(symbol="NIFTY", exchange="NSE_INDEX", action="BUYCL",
                    entry_price=23900.0, qty=65, brick_size=12.0, fill_ts=None):
    ts = fill_ts or datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    return {
        "exchange":exchange,"timestamp":ts,"renko_signal":action,"symbol":symbol,
        "entry_price":entry_price,"quantity":qty,"order_status":"INPOSITION",
        "close_reason":"","signal_grade":"B","quality_score":4,"day_regime":"TRENDING",
        "brick_size_hint":brick_size,"orderid":"TEST001",
        "option_symbol":f"{symbol}17MAR2624100CE","index_ltp":entry_price,
        "fill_timestamp":ts,"peak_brick_since_entry":entry_price,
        "peak_ltp_since_entry":entry_price,"nft_validated":0,
        "nft_target":entry_price+3*brick_size,"nft_rev_count":0,"nft_last_dir":None,
        "chop_reversals":0,"chop_last_dir":None,"chop_last_ltp":entry_price,
        "close_price":None,"exec_price":entry_price,"entry_mode":"signal",
    }

def _open_stop_row(symbol="NIFTY", exchange="NSE_INDEX", stop_price=23876.0, qty=65):
    return {
        "exchange":exchange,"timestamp":datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "renko_signal":"SELST","symbol":symbol,"entry_price":stop_price,
        "quantity":qty,"order_status":"OPEN","close_reason":"",
    }

def _tm_with_open_position():
    tm = _empty_tm()
    tm = pd.concat([tm, pd.DataFrame([_inposition_row()])], ignore_index=True)
    tm = pd.concat([tm, pd.DataFrame([_open_stop_row()])],  ignore_index=True)
    return tm

def _day_regime_result(regime, confidence=0.6, vix=14.0):
    return DayRegimeResult(
        regime=regime, confidence=confidence, vix=vix,
        range_ratio=1.2, classified_at=datetime.now(),
    )


# ═══════════════════════════════════════════════════════════════════════════════
# 1. Trailing Stop
# ═══════════════════════════════════════════════════════════════════════════════

class TestTrailingStop:
    def _mgr(self): return TrailingStopManager()

    def test_call_initial_stop(self):
        from tcos_bot.config.settings import cfg
        stop = self._mgr().initialise("NIFTY","CALL",23900,12)
        assert abs(stop - (23900 - cfg.stop.initial_stop_bricks*12)) < 0.01

    def test_banknifty_override(self):
        """BANKNIFTY uses symbol_overrides=4.0b, not the global initial_stop_bricks."""
        from tcos_bot.config.settings import cfg
        bs = 24.0  # correct brick size
        stop = self._mgr().initialise("BANKNIFTY", "CALL", 55980, bs)
        override = cfg.stop.symbol_overrides.get("BANKNIFTY", cfg.stop.initial_stop_bricks)
        expected = 55980 - override * bs
        assert abs(stop - expected) < 0.01, (
            f"BANKNIFTY stop={stop}, expected {expected} ({override}b × {bs}pts)"
        )

    def test_put_stop_above_entry(self):
        from tcos_bot.config.settings import cfg
        stop = self._mgr().initialise("NIFTY","PUT",23900,12)
        assert abs(stop - (23900 + cfg.stop.initial_stop_bricks*12)) < 0.01

    def test_catastrophe_below_initial(self):
        from tcos_bot.config.settings import cfg
        m = self._mgr()
        stop = m.initialise("NIFTY","CALL",23900,12)
        floor = 23900 - (cfg.stop.initial_stop_bricks + cfg.stop.catastrophe_extra_bricks)*12
        assert stop > floor

    def test_no_move_below_breakeven(self):
        m = self._mgr()
        m.initialise("NIFTY","CALL",23900,12)
        assert m.update("NIFTY", 23900+12) is None

    def test_breakeven_stop_at_entry(self):
        from tcos_bot.config.settings import cfg
        m = self._mgr(); entry=23900
        m.initialise("NIFTY","CALL",entry,12)
        m.update("NIFTY", entry + cfg.trailing.breakeven_after*12 + 1)
        stop = m.get_stop_price("NIFTY")
        if stop: assert stop >= entry

    def test_trail_moves_up(self):
        from tcos_bot.config.settings import cfg
        m = self._mgr(); entry=23900; bs=12
        m.initialise("NIFTY","CALL",entry,bs)
        m.update("NIFTY", entry+(cfg.trailing.trail_start_after+2)*bs)
        s1 = m.get_stop_price("NIFTY") or 0
        m.update("NIFTY", entry+(cfg.trailing.trail_start_after+5)*bs)
        s2 = m.get_stop_price("NIFTY") or 0
        assert s2 >= s1

    def test_stop_never_decreases(self):
        from tcos_bot.config.settings import cfg
        m = self._mgr(); entry=23900
        m.initialise("NIFTY","CALL",entry,12)
        high = entry+(cfg.trailing.trail_start_after+4)*12
        m.update("NIFTY",high)
        s1 = m.get_stop_price("NIFTY") or 0
        m.update("NIFTY",high-6)
        s2 = m.get_stop_price("NIFTY") or 0
        assert s2 >= s1

    def test_remove_clears(self):
        m = self._mgr()
        m.initialise("NIFTY","CALL",23900,12)
        m.remove("NIFTY")
        assert m.get_stop_price("NIFTY") is None

    def test_two_symbols_independent(self):
        m = self._mgr()
        m.initialise("NIFTY","CALL",23900,12)
        m.initialise("BANKNIFTY","CALL",55980,40)
        m.remove("NIFTY")
        assert m.get_stop_price("NIFTY") is None
        assert m.get_stop_price("BANKNIFTY") is not None


# ═══════════════════════════════════════════════════════════════════════════════
# 2. Whipsaw Tracker
# ═══════════════════════════════════════════════════════════════════════════════

class TestWhipsawTracker:
    """Tests for WhipsawCooldownTracker direction-specific improvements."""

    def _past_grace(self) -> "WhipsawCooldownTracker":
        t = WhipsawCooldownTracker()
        t._start_time = time.monotonic() - t._STARTUP_GRACE_SECS - 1
        return t

    # ── Existing behaviour preserved ──────────────────────────────────────

    def test_grace_prevents_cooldown(self):
        t = WhipsawCooldownTracker()
        for _ in range(10):
            t.record_flip("NIFTY", "CALL")
        assert not t.is_blocked("NIFTY", "CALL")[0]

    def test_cooldown_after_grace(self):
        from tcos_bot.config.settings import cfg
        t = self._past_grace()
        for _ in range(cfg.whipsaw.max_flips):
            t.record_flip("NIFTY", "CALL")
        blocked, reason = t.is_blocked("NIFTY", "CALL")
        assert blocked and "NIFTY" in reason and "CALL" in reason

    def test_cooldown_expires(self):
        from tcos_bot.config.settings import cfg
        t = self._past_grace()
        for _ in range(cfg.whipsaw.max_flips):
            t.record_flip("NIFTY", "CALL")
        # Force expiry by back-dating the cooldown end
        t._cooldown_until[("NIFTY", "CALL")] = time.monotonic() - 1
        assert not t.is_blocked("NIFTY", "CALL")[0]

    def test_clear_works(self):
        from tcos_bot.config.settings import cfg
        t = self._past_grace()
        for _ in range(cfg.whipsaw.max_flips):
            t.record_flip("NIFTY", "CALL")
        t.clear("NIFTY")                                # direction=None clears both
        assert not t.is_blocked("NIFTY", "CALL")[0]

    def test_symbols_independent(self):
        from tcos_bot.config.settings import cfg
        t = self._past_grace()
        for _ in range(cfg.whipsaw.max_flips):
            t.record_flip("NIFTY", "CALL")
        assert     t.is_blocked("NIFTY",     "CALL")[0]
        assert not t.is_blocked("BANKNIFTY", "CALL")[0]

    # ── New: direction isolation (Fix 1) ──────────────────────────────────

    def test_call_locked_put_free(self):
        """Locking CALL must not affect PUT for the same symbol."""
        from tcos_bot.config.settings import cfg
        t = self._past_grace()
        for _ in range(cfg.whipsaw.max_flips):
            t.record_flip("NIFTY", "CALL")
        assert     t.is_blocked("NIFTY", "CALL")[0]
        assert not t.is_blocked("NIFTY", "PUT")[0]

    def test_put_locked_call_free(self):
        """Locking PUT must not affect CALL for the same symbol."""
        from tcos_bot.config.settings import cfg
        t = self._past_grace()
        for _ in range(cfg.whipsaw.max_flips):
            t.record_flip("NIFTY", "PUT")
        assert not t.is_blocked("NIFTY", "CALL")[0]
        assert     t.is_blocked("NIFTY", "PUT")[0]

    def test_clear_direction_partial(self):
        """clear(symbol, 'CALL') lifts CALL but leaves PUT intact."""
        from tcos_bot.config.settings import cfg
        t = self._past_grace()
        for _ in range(cfg.whipsaw.max_flips):
            t.record_flip("NIFTY", "CALL")
            t.record_flip("NIFTY", "PUT")
        assert t.is_blocked("NIFTY", "CALL")[0]
        assert t.is_blocked("NIFTY", "PUT")[0]
        t.clear("NIFTY", direction="CALL")
        assert not t.is_blocked("NIFTY", "CALL")[0]
        assert     t.is_blocked("NIFTY", "PUT")[0]   # PUT still locked

    # ── New: momentum auto-clear (Fix 3) ─────────────────────────────────

    def test_momentum_clear_lifts_locked_direction(self):
        """8+ consecutive bricks in locked direction clears the cooldown."""
        import types as _types
        from tcos_bot.config.settings import cfg
        t = self._past_grace()
        for _ in range(cfg.whipsaw.max_flips):
            t.record_flip("NIFTY", "CALL")
        assert t.is_blocked("NIFTY", "CALL")[0]
        # Simulate 8 consecutive UP bricks
        for i in range(1, 9):
            t.on_brick_formed("NIFTY", "CALL", i)
        assert not t.is_blocked("NIFTY", "CALL")[0]

    def test_momentum_clear_wrong_direction_no_effect(self):
        """Consecutive PUT bricks must NOT clear a CALL cooldown."""
        from tcos_bot.config.settings import cfg
        t = self._past_grace()
        for _ in range(cfg.whipsaw.max_flips):
            t.record_flip("NIFTY", "CALL")
        assert t.is_blocked("NIFTY", "CALL")[0]
        # Many PUT bricks — different direction
        t.on_brick_formed("NIFTY", "PUT", 12)
        assert t.is_blocked("NIFTY", "CALL")[0]   # still locked

    def test_momentum_clear_below_threshold_no_effect(self):
        """7 consecutive bricks (below threshold of 8) must not clear cooldown."""
        from tcos_bot.config.settings import cfg
        t = self._past_grace()
        for _ in range(cfg.whipsaw.max_flips):
            t.record_flip("NIFTY", "CALL")
        t.on_brick_formed("NIFTY", "CALL", 7)     # one below default threshold
        assert t.is_blocked("NIFTY", "CALL")[0]   # still locked




# ═══════════════════════════════════════════════════════════════════════════════
# 3. Exit Deduplication
# ═══════════════════════════════════════════════════════════════════════════════

class TestExitDedup:
    def _sg(self):
        from tcos_bot.signals.signal_generator import SignalGenerator
        return SignalGenerator()

    def _tm_with_exit(self, status):
        tm = _empty_tm()
        tm = pd.concat([tm, pd.DataFrame([_inposition_row()])], ignore_index=True)
        tm = pd.concat([tm, pd.DataFrame([{
            "symbol":"NIFTY","exchange":"NSE_INDEX","renko_signal":"SELCL",
            "order_status":status,"entry_price":23900.0,"quantity":65,"close_reason":"",
        }])], ignore_index=True)
        return tm

    def test_no_dup_when_open(self):
        sg=self._sg(); tm=self._tm_with_exit("OPEN"); before=len(tm)
        tm, added = sg._create_exit(tm,"NIFTY","NSE_INDEX","SELCL",23900.0,
                                    datetime.now(),{"CALL":65,"PUT":0},_make_renko(12))
        assert not added and len(tm)==before

    def test_no_dup_when_sending(self):
        sg=self._sg(); tm=self._tm_with_exit("SENDING"); before=len(tm)
        tm, added = sg._create_exit(tm,"NIFTY","NSE_INDEX","SELCL",23900.0,
                                    datetime.now(),{"CALL":65,"PUT":0},_make_renko(12))
        assert not added and len(tm)==before

    def test_no_exit_without_inposition(self):
        sg=self._sg(); tm=_empty_tm()
        tm, added = sg._create_exit(tm,"NIFTY","NSE_INDEX","SELCL",23900.0,
                                    datetime.now(),{"CALL":65,"PUT":0},_make_renko(12))
        assert not added

    def test_qty_fallback_from_tm(self):
        sg=self._sg(); tm=_empty_tm()
        tm=pd.concat([tm,pd.DataFrame([_inposition_row(qty=65)])],ignore_index=True)
        tm, added = sg._create_exit(tm,"NIFTY","NSE_INDEX","SELCL",23900.0,
                                    datetime.now(),{"CALL":0,"PUT":0},_make_renko(12))
        assert added
        assert int(tm[tm["renko_signal"]=="SELCL"].iloc[-1]["quantity"]) == 65

    def test_exit_created_cleanly(self):
        sg=self._sg(); tm=_empty_tm()
        tm=pd.concat([tm,pd.DataFrame([_inposition_row()])],ignore_index=True)
        tm, added = sg._create_exit(tm,"NIFTY","NSE_INDEX","SELCL",23900.0,
                                    datetime.now(),{"CALL":65,"PUT":0},_make_renko(12))
        assert added and len(tm[tm["renko_signal"]=="SELCL"])==1


# ═══════════════════════════════════════════════════════════════════════════════
# 4. Lot Sizing
# ═══════════════════════════════════════════════════════════════════════════════

class TestLotSizing:
    def test_grade_a(self):
        import tcos_bot.config.settings as s; s.MAX_LOTS["NIFTY"]=2
        assert max(1,round(2*1.0))*65 == 130

    def test_grade_b(self):
        import tcos_bot.config.settings as s; s.MAX_LOTS["NIFTY"]=2
        assert max(1,round(2*0.5))*65 == 65

    def test_min_one_lot(self):
        import tcos_bot.config.settings as s; s.MAX_LOTS["NIFTY"]=1
        assert max(1,round(1*0.5)) == 1

    def test_always_multiple_of_lot_size(self):
        for ml in range(1,6):
            for m in (0.5,1.0):
                qty = max(1,round(ml*m))*30
                assert qty%30==0


# ═══════════════════════════════════════════════════════════════════════════════
# 5. PositionTracker.build_root_map
# ═══════════════════════════════════════════════════════════════════════════════

class TestPositionTracker:
    def _t(self):
        from tcos_bot.execution.position_tracker import PositionTracker
        return PositionTracker(MagicMock())

    def test_long_call(self):
        r=self._t().build_root_map(pd.DataFrame([{"symbol":"NIFTY17MAR2624100CE","quantity":65,"exchange":"NFO"}]))
        assert r["NIFTY"]["CALL"]==65

    def test_short_call_ignored(self):
        r=self._t().build_root_map(pd.DataFrame([{"symbol":"NIFTY17MAR2624100CE","quantity":-65,"exchange":"NFO"}]))
        assert r["NIFTY"]["CALL"]==0, "Short CE must not count as CALL long"

    def test_only_positive_qty(self):
        r=self._t().build_root_map(pd.DataFrame([
            {"symbol":"NIFTY17MAR2624100CE","quantity": 65,"exchange":"NFO"},
            {"symbol":"NIFTY17MAR2624100CE","quantity":-65,"exchange":"NFO"},
        ]))
        assert r["NIFTY"]["CALL"]==65

    def test_put_separate(self):
        r=self._t().build_root_map(pd.DataFrame([
            {"symbol":"NIFTY17MAR2624100CE","quantity":65,"exchange":"NFO"},
            {"symbol":"NIFTY17MAR2623900PE","quantity":65,"exchange":"NFO"},
        ]))
        assert r["NIFTY"]["CALL"]==65 and r["NIFTY"]["PUT"]==65

    def test_zero_qty(self):
        r=self._t().build_root_map(pd.DataFrame([{"symbol":"NIFTY17MAR2624100CE","quantity":0,"exchange":"NFO"}]))
        assert r["NIFTY"]["CALL"]==0

    def test_empty(self):
        r=self._t().build_root_map(pd.DataFrame())
        assert r["NIFTY"]["CALL"]==0

    def test_multi_symbol(self):
        r=self._t().build_root_map(pd.DataFrame([
            {"symbol":"NIFTY17MAR2624100CE","quantity":65,"exchange":"NFO"},
            {"symbol":"BANKNIFTY30MAR2655900CE","quantity":30,"exchange":"NFO"},
        ]))
        assert r["NIFTY"]["CALL"]==65 and r["BANKNIFTY"]["CALL"]==30


# ═══════════════════════════════════════════════════════════════════════════════
# 6. Close Reason: STOP_EXIT vs SIGNAL_EXIT
# ═══════════════════════════════════════════════════════════════════════════════

class TestCloseReason:
    def _router(self):
        from tcos_bot.execution.position_tracker import OrderRouter
        c=MagicMock(); c.placesmartorder.return_value={"status":"success","orderid":"MOCK"}
        return OrderRouter(c,"TEST","MIS")

    def test_selst_stop_exit(self):
        router=self._router(); tm=_tm_with_open_position()
        idx=tm[tm["renko_signal"]=="SELST"].index[0]
        result=router.execute_order(tm,idx,tm.loc[idx],"NIFTY17MAR2624100CE","NFO",23876.0,0.0,65)
        reasons=result[(result["symbol"]=="NIFTY")&(result["order_status"]=="CLOSED")]["close_reason"].dropna().tolist()
        assert any("STOP_EXIT" in str(r) for r in reasons), f"Got: {reasons}"

    def test_selcl_signal_exit(self):
        router=self._router(); tm=_tm_with_open_position()
        tm=pd.concat([tm,pd.DataFrame([{
            "exchange":"NSE_INDEX","timestamp":"2025-01-06 10:00:00","symbol":"NIFTY",
            "renko_signal":"SELCL","entry_price":23900.0,"quantity":65,
            "order_status":"OPEN","close_reason":"",
        }])],ignore_index=True)
        idx=tm[tm["renko_signal"]=="SELCL"].index[-1]
        result=router.execute_order(tm,idx,tm.loc[idx],"NIFTY17MAR2624100CE","NFO",23950.0,0.0,65)
        reasons=result[(result["symbol"]=="NIFTY")&(result["order_status"]=="CLOSED")]["close_reason"].dropna().tolist()
        assert any("SIGNAL_EXIT" in str(r) for r in reasons), f"Got: {reasons}"


# ═══════════════════════════════════════════════════════════════════════════════
# 7. brick_size_hint propagates to trailing stop
# ═══════════════════════════════════════════════════════════════════════════════

class TestBrickSizeHint:
    def test_nifty_bs12_not_bs50(self):
        from tcos_bot.execution.position_tracker import OrderRouter
        from tcos_bot.risk.risk_manager import trailing_stop_mgr
        from tcos_bot.config.settings import cfg
        c=MagicMock(); c.placesmartorder.return_value={"status":"success","orderid":"BS"}
        router=OrderRouter(c,"TEST","MIS")
        tm=_empty_tm()
        row={**_inposition_row(entry_price=23900.0,brick_size=12.0),"order_status":"OPEN"}
        tm=pd.concat([tm,pd.DataFrame([row])],ignore_index=True); idx=tm.index[-1]
        trailing_stop_mgr.remove("NIFTY")
        result=router.execute_order(tm,idx,tm.loc[idx],"NIFTY17MAR2624100CE","NFO",23900.0,0.0,65)
        stop_rows=result[(result["symbol"]=="NIFTY")&(result["renko_signal"]=="SELST")&(result["order_status"]=="OPEN")]
        assert not stop_rows.empty, "SELST stop row was not created"
        actual=float(stop_rows.iloc[-1]["entry_price"])
        expected=23900.0 - cfg.stop.initial_stop_bricks*12.0
        wrong   =23900.0 - cfg.stop.initial_stop_bricks*50.0
        assert abs(actual-expected)<1.0, f"Stop {actual:.2f} != expected {expected:.2f} with bs=12"
        assert abs(actual-wrong)>10.0,   f"Stop {actual:.2f} is still using bs=50 (bug not fixed!)"


# ═══════════════════════════════════════════════════════════════════════════════
# 8. NFT Exit Dedup
# ═══════════════════════════════════════════════════════════════════════════════

class TestNFTDedup:
    def _tm_stale(self, status):
        fill_ts=(datetime.now()-timedelta(minutes=20)).strftime("%Y-%m-%d %H:%M:%S")
        tm=_empty_tm()
        tm=pd.concat([tm,pd.DataFrame([_inposition_row(fill_ts=fill_ts)])],ignore_index=True)
        tm=pd.concat([tm,pd.DataFrame([{
            "symbol":"NIFTY","exchange":"NSE_INDEX","renko_signal":"SELCL",
            "order_status":status,"entry_price":23900.0,"quantity":65,"close_reason":"",
        }])],ignore_index=True)
        return tm

    def test_no_dup_open(self):
        tm,_=NFTChecker().check_and_annotate(self._tm_stale("OPEN"),"NIFTY","NSE_INDEX",23900.0,12.0)
        assert len(tm[(tm["renko_signal"]=="SELCL")&(tm["order_status"].isin(["OPEN","SENDING"]))])<=1

    def test_no_dup_sending(self):
        tm,_=NFTChecker().check_and_annotate(self._tm_stale("SENDING"),"NIFTY","NSE_INDEX",23900.0,12.0)
        assert len(tm[(tm["renko_signal"]=="SELCL")&(tm["order_status"].isin(["OPEN","SENDING"]))])<=1


# ═══════════════════════════════════════════════════════════════════════════════
# 9. Chop Exit Dedup
# ═══════════════════════════════════════════════════════════════════════════════

class TestChopDedup:
    def _tm_chop(self, status):
        from tcos_bot.config.settings import cfg
        fill_ts=(datetime.now()-timedelta(seconds=30)).strftime("%Y-%m-%d %H:%M:%S")
        tm=_empty_tm()
        row={**_inposition_row(fill_ts=fill_ts),"chop_reversals":cfg.chop_oscillation.reversals_max,"chop_last_ltp":23900.0}
        tm=pd.concat([tm,pd.DataFrame([row])],ignore_index=True)
        tm=pd.concat([tm,pd.DataFrame([{
            "symbol":"NIFTY","exchange":"NSE_INDEX","renko_signal":"SELCL",
            "order_status":status,"entry_price":23900.0,"quantity":65,"close_reason":"",
        }])],ignore_index=True)
        return tm

    def test_no_dup_open(self):
        tm,_=ChopOscillationChecker().check_and_annotate(self._tm_chop("OPEN"),"NIFTY","NSE_INDEX",23900.0,12.0)
        assert len(tm[(tm["renko_signal"]=="SELCL")&(tm["order_status"].isin(["OPEN","SENDING"]))])<=1

    def test_no_dup_sending(self):
        tm,_=ChopOscillationChecker().check_and_annotate(self._tm_chop("SENDING"),"NIFTY","NSE_INDEX",23900.0,12.0)
        assert len(tm[(tm["renko_signal"]=="SELCL")&(tm["order_status"].isin(["OPEN","SENDING"]))])<=1


# ═══════════════════════════════════════════════════════════════════════════════
# 10. TradeStore DB round-trip (uses conftest.py in-memory engine)
# ═══════════════════════════════════════════════════════════════════════════════

class TestTradeStoreRoundTrip:
    def test_save_and_read(self):
        from tcos_bot.data.trade_store import trade_store
        trade_store.save_df(pd.DataFrame([_inposition_row()]))
        result=trade_store.read_df()
        assert not result.empty
        assert "NIFTY" in result["symbol"].values

    def test_schema_auto_migrates(self):
        from tcos_bot.data.trade_store import trade_store
        trade_store.save_df(pd.DataFrame([{
            "symbol":"BANKNIFTY","order_status":"OPEN","new_col_abc123":"hello"
        }]))
        assert "new_col_abc123" in trade_store.read_df().columns

    def test_append_rows(self):
        from tcos_bot.data.trade_store import trade_store
        trade_store.save_df(pd.DataFrame([_inposition_row()]))
        before=len(trade_store.read_df())
        trade_store.append_rows([{"symbol":"SENSEX","order_status":"OPEN","renko_signal":"BUYCL","entry_price":77000.0}])
        assert len(trade_store.read_df())==before+1


# ═══════════════════════════════════════════════════════════════════════════════
# 11. Reversal cancellation
# ═══════════════════════════════════════════════════════════════════════════════

class TestReversalCancellation:
    def _sg(self):
        from tcos_bot.signals.signal_generator import SignalGenerator
        return SignalGenerator()

    def test_buyen_cancels_buypt(self):
        sg=self._sg(); tm=_empty_tm()
        tm=pd.concat([tm,pd.DataFrame([{"symbol":"NIFTY","exchange":"NSE_INDEX","renko_signal":"BUYPT","order_status":"OPEN","entry_price":23900.0,"quantity":65,"close_reason":""}])],ignore_index=True)
        result=sg._cancel_pending(tm,"NIFTY","NSE_INDEX","BUYPT","SELSP")
        assert len(result[(result["renko_signal"]=="BUYPT")&(result["order_status"]=="CANCELLED")])==1

    def test_selex_cancels_buycl(self):
        sg=self._sg(); tm=_empty_tm()
        tm=pd.concat([tm,pd.DataFrame([{"symbol":"BANKNIFTY","exchange":"NSE_INDEX","renko_signal":"BUYCL","order_status":"OPEN","entry_price":55980.0,"quantity":30,"close_reason":""}])],ignore_index=True)
        result=sg._cancel_pending(tm,"BANKNIFTY","NSE_INDEX","BUYCL","SELST")
        assert len(result[(result["renko_signal"]=="BUYCL")&(result["order_status"]=="CANCELLED")])==1

    def test_cancel_does_not_affect_other_symbol(self):
        sg=self._sg(); tm=_empty_tm()
        for sym in ("NIFTY","BANKNIFTY"):
            tm=pd.concat([tm,pd.DataFrame([{"symbol":sym,"exchange":"NSE_INDEX","renko_signal":"BUYPT","order_status":"OPEN","entry_price":23900.0,"quantity":65,"close_reason":""}])],ignore_index=True)
        result=sg._cancel_pending(tm,"NIFTY","NSE_INDEX","BUYPT")
        assert result[result["symbol"]=="NIFTY"]["order_status"].iloc[0]=="CANCELLED"
        assert result[result["symbol"]=="BANKNIFTY"]["order_status"].iloc[0]=="OPEN"


# ═══════════════════════════════════════════════════════════════════════════════
# 12. Day Regime Filter  (class is DayRegimeClassifier)
# ═══════════════════════════════════════════════════════════════════════════════

class TestDayRegimeFilter:
    def _clf(self):
        from tcos_bot.filters.day_regime import DayRegimeClassifier
        return DayRegimeClassifier()

    def test_sideways_blocks_buyen(self):
        # S-3 FIX: sideways_hard_block=False — SIDEWAYS now allows half-size reversal
        # entries at S/R boundaries instead of sitting idle on 40-50% of sessions.
        c=self._clf(); c._result=_day_regime_result(MarketRegime.SIDEWAYS)
        r = c.check("NIFTY","BUYEN",pd.DataFrame())
        assert r.allowed, "SIDEWAYS should allow half-size entries (sideways_hard_block=False)"
        assert r.size_multiplier <= 0.5, f"Expected half-size for SIDEWAYS, got {r.size_multiplier}"

    def test_sideways_blocks_selex(self):
        # S-3 FIX: same — SIDEWAYS half-size allowed, not hard-blocked.
        c=self._clf(); c._result=_day_regime_result(MarketRegime.SIDEWAYS)
        r = c.check("NIFTY","SELEX",pd.DataFrame())
        assert r.allowed, "SIDEWAYS should allow half-size entries (sideways_hard_block=False)"
        assert r.size_multiplier <= 0.5, f"Expected half-size for SIDEWAYS, got {r.size_multiplier}"

    def test_chop_guard_halves(self):
        from tcos_bot.config.settings import cfg
        c=self._clf()
        c._result=_day_regime_result(MarketRegime.TRENDING, confidence=cfg.day_regime.chop_half_threshold-0.05)
        r=c.check("NIFTY","BUYEN",pd.DataFrame())
        assert r.allowed and r.size_multiplier==0.5, f"Expected half-size, got {r.size_multiplier}"

    def test_trending_high_conf_full_size(self):
        c=self._clf(); c._result=_day_regime_result(MarketRegime.TRENDING, confidence=0.70)
        r=c.check("NIFTY","BUYEN",pd.DataFrame())
        assert r.allowed and r.size_multiplier==1.0

    def test_volatile_full_size_phase3(self):
        """Phase 3: VOLATILE regime now gives full size 1.0 (was 0.5)."""
        c=self._clf(); c._result=_day_regime_result(MarketRegime.VOLATILE)
        r=c.check("NIFTY","BUYEN",pd.DataFrame())
        assert r.allowed and r.size_multiplier==1.0, (
            f"Phase 3: VOLATILE must give size=1.0, got {r.size_multiplier}"
        )

    def test_unclassified_half(self):
        c=self._clf(); c._result=None
        r=c.check("NIFTY","BUYEN",pd.DataFrame())
        assert r.allowed and r.size_multiplier==0.5


# ═══════════════════════════════════════════════════════════════════════════════
# 13. Option Resolver (exit path — no DB needed)
# ═══════════════════════════════════════════════════════════════════════════════

class TestOptionResolver:
    def _r(self):
        from tcos_bot.execution.option_resolver import OptionResolver
        return OptionResolver(MagicMock())

    def test_selcl_finds_ce(self):
        sym,ex,_=self._r().resolve("SELCL","NIFTY","NSE_INDEX",pd.DataFrame([{"symbol":"NIFTY17MAR2624100CE","quantity":65,"exchange":"NFO"}]))
        assert sym=="NIFTY17MAR2624100CE" and ex=="NFO"

    def test_selpt_finds_pe(self):
        sym,_,_=self._r().resolve("SELPT","NIFTY","NSE_INDEX",pd.DataFrame([{"symbol":"NIFTY17MAR2623900PE","quantity":65,"exchange":"NFO"}]))
        assert sym=="NIFTY17MAR2623900PE"

    def test_selst_stop_finds_ce(self):
        sym,_,_=self._r().resolve("SELST","BANKNIFTY","NSE_INDEX",pd.DataFrame([{"symbol":"BANKNIFTY30MAR2655900CE","quantity":30,"exchange":"NFO"}]))
        assert sym=="BANKNIFTY30MAR2655900CE"

    def test_selsp_stop_finds_pe(self):
        sym,_,_=self._r().resolve("SELSP","SENSEX","BSE_INDEX",pd.DataFrame([{"symbol":"SENSEX12MAR2677100PE","quantity":20,"exchange":"BFO"}]))
        assert sym=="SENSEX12MAR2677100PE"

    def test_no_position_returns_none(self):
        sym,_,_=self._r().resolve("SELCL","NIFTY","NSE_INDEX",pd.DataFrame())
        assert sym is None

    def test_zero_qty_ignored(self):
        sym,_,_=self._r().resolve("SELCL","NIFTY","NSE_INDEX",pd.DataFrame([{"symbol":"NIFTY17MAR2624100CE","quantity":0,"exchange":"NFO"}]))
        assert sym is None


# ═══════════════════════════════════════════════════════════════════════════════
# 14. Engine per-cycle double-exit guard
# ═══════════════════════════════════════════════════════════════════════════════

class TestEngineDoubleExitGuard:
    def test_two_selcl_rows_one_dispatch(self):
        from tcos_bot.core.engine import TradingEngine
        from tcos_bot.data.ltp_store import ltp_store
        ltp_store.update("NIFTY",23900.0,source="TEST")
        c=MagicMock(); c.placesmartorder.return_value={"status":"success","orderid":"DBL"}
        c.positionbook.return_value={"status":"success","data":[{"symbol":"NIFTY17MAR2624100CE","quantity":65,"exchange":"NFO"}]}
        engine=TradingEngine(c,"TEST","MIS")
        tm=_empty_tm()
        tm=pd.concat([tm,pd.DataFrame([_inposition_row()])],ignore_index=True)
        for _ in range(2):
            tm=pd.concat([tm,pd.DataFrame([{"exchange":"NSE_INDEX","timestamp":"2025-01-06 10:00:00","symbol":"NIFTY","renko_signal":"SELCL","entry_price":23900.0,"quantity":65,"order_status":"OPEN","close_reason":""}])],ignore_index=True)
        positions_df=pd.DataFrame([{"symbol":"NIFTY17MAR2624100CE","quantity":65,"exchange":"NFO"}])
        with patch.object(engine,"_resolve_option",return_value=("NIFTY17MAR2624100CE","NFO",100.0)):
            engine._execute_open_orders(tm,positions_df)
        assert c.placesmartorder.call_count<=1, \
            f"placesmartorder called {c.placesmartorder.call_count}× — double-exit not blocked!"


# ═══════════════════════════════════════════════════════════════════════════════
# 15. Watchdog reconciliation
# ═══════════════════════════════════════════════════════════════════════════════

class TestWatchdog:
    def _pt(self, data):
        from tcos_bot.execution.position_tracker import PositionTracker
        c=MagicMock(); c.positionbook.return_value={"status":"success","data":data}
        return PositionTracker(c)

    def test_position_exists(self):
        pt=self._pt([{"symbol":"NIFTY17MAR2624100CE","quantity":65,"exchange":"NFO"}])
        assert pt.build_root_map(pt.fetch())["NIFTY"]["CALL"]==65

    def test_position_empty(self):
        pt=self._pt([])
        assert pt.build_root_map(pt.fetch())["NIFTY"]["CALL"]==0

    def test_api_error_returns_none(self):
        from tcos_bot.execution.position_tracker import PositionTracker
        c=MagicMock(); c.positionbook.return_value={"status":"error","message":"Unauthorized"}
        assert PositionTracker(c).fetch() is None


if __name__ == "__main__":
    import subprocess
    subprocess.run([sys.executable,"-m","pytest",__file__,"-v","--tb=short"])


# ═══════════════════════════════════════════════════════════════════════════════
# 16. Entry drift cancel (Fix 1)
# ═══════════════════════════════════════════════════════════════════════════════

class TestDriftCancel:
    """Engine _execute_open_orders should cancel a BUY entry whose LTP has
    drifted more than cfg.entry.max_drift_bricks bricks from signal price."""

    def _engine(self):
        from tcos_bot.core.engine import TradingEngine
        c = MagicMock()
        c.placesmartorder.return_value = {"status": "success", "orderid": "X1"}
        c.positionbook.return_value    = {"status": "success", "data": []}
        return TradingEngine(c, "TEST", "MIS")

    def _open_buy(self, sig="BUYCL", sym="NIFTY", sig_px=23154.0):
        return {
            "exchange": "NSE_INDEX", "timestamp": "2026-03-13 13:31:00",
            "symbol": sym, "renko_signal": sig,
            "entry_price": sig_px, "quantity": 65,
            "order_status": "OPEN", "close_reason": "",
            "brick_size_hint": 12.0,
        }

    def test_call_drift_exceeds_limit_cancels_entry(self):
        """BUYCL where LTP is 2b above signal_price → DRIFT_CANCEL."""
        from tcos_bot.core.engine import TradingEngine
        from tcos_bot.data.ltp_store import ltp_store
        import tcos_bot.config.settings as s
        sig_px  = 23154.0
        # 2b above signal → exceeds 1.5b limit
        ltp_now = sig_px + 2 * 12.0   # = 23178
        ltp_store.update("NIFTY", ltp_now, source="TEST")
        engine = self._engine()
        tm = pd.concat([_empty_tm(), pd.DataFrame([self._open_buy("BUYCL", "NIFTY", sig_px)])],
                       ignore_index=True)
        # Also add sibling SELST so we can check it gets cancelled too
        sibling = self._open_buy("SELST", "NIFTY", sig_px)
        tm = pd.concat([tm, pd.DataFrame([sibling])], ignore_index=True)

        with patch.object(engine, "_resolve_option", return_value=("OPT", "NFO", 100.0)):
            tm, _ = engine._execute_open_orders(tm, pd.DataFrame())

        entry_row = tm[tm["renko_signal"] == "BUYCL"]
        assert entry_row.iloc[0]["order_status"] == "CANCELLED"
        assert "DRIFT_CANCEL" in str(entry_row.iloc[0]["close_reason"])
        # Broker must NOT have been called
        engine._order_router._client.placesmartorder.assert_not_called()

    def test_put_adverse_drift_cancels(self):
        """BUYPT where LTP is 2b BELOW signal_price (adverse for a put entry) → DRIFT_CANCEL."""
        from tcos_bot.data.ltp_store import ltp_store
        sig_px  = 23190.0
        ltp_now = sig_px - 2 * 12.0   # 2b below = adverse for PUT
        ltp_store.update("NIFTY", ltp_now, source="TEST")
        engine = self._engine()
        tm = pd.concat([_empty_tm(), pd.DataFrame([self._open_buy("BUYPT", "NIFTY", sig_px)])],
                       ignore_index=True)
        with patch.object(engine, "_resolve_option", return_value=("OPT", "NFO", 100.0)):
            tm, _ = engine._execute_open_orders(tm, pd.DataFrame())
        assert tm[tm["renko_signal"] == "BUYPT"].iloc[0]["order_status"] == "CANCELLED"

    def test_acceptable_drift_proceeds(self):
        """Drift within limit (1.0b < 1.5b) should NOT cancel."""
        from tcos_bot.data.ltp_store import ltp_store
        sig_px  = 23154.0
        ltp_now = sig_px + 1.0 * 12.0   # exactly 1b — within limit
        ltp_store.update("NIFTY", ltp_now, source="TEST")
        engine = self._engine()
        c = engine._order_router._client
        c.placesmartorder.return_value = {"status": "success", "orderid": "OK1"}
        tm = pd.concat([_empty_tm(), pd.DataFrame([self._open_buy("BUYCL", "NIFTY", sig_px)])],
                       ignore_index=True)
        with patch.object(engine, "_resolve_option", return_value=("OPT", "NFO", 100.0)):
            engine._execute_open_orders(tm, pd.DataFrame())
        # Broker should have been called (order placed, not cancelled)
        c.placesmartorder.assert_called_once()

    def test_drift_cancel_disabled_when_zero(self):
        """max_drift_bricks = 0 disables the guard entirely."""
        from tcos_bot.data.ltp_store import ltp_store
        import tcos_bot.config.settings as s_mod
        from dataclasses import replace as dc_replace
        # engine.py reads cfg at call time via `cfg.entry.max_drift_bricks`
        # so we patch the module-level cfg object directly.
        original_cfg = s_mod.cfg
        patched_cfg  = dc_replace(original_cfg,
                                  entry=dc_replace(original_cfg.entry, max_drift_bricks=0.0))
        sig_px  = 23154.0
        ltp_now = sig_px + 5 * 12.0   # massive drift but guard is off
        ltp_store.update("NIFTY", ltp_now, source="TEST")
        engine = self._engine()
        engine._order_router._client.placesmartorder.return_value = {
            "status": "success", "orderid": "NODRIFT"
        }
        tm = pd.concat([_empty_tm(), pd.DataFrame([self._open_buy("BUYCL", "NIFTY", sig_px)])],
                       ignore_index=True)
        with patch.object(s_mod, "cfg", patched_cfg),              patch("tcos_bot.core.engine.cfg", patched_cfg),              patch.object(engine, "_resolve_option", return_value=("OPT", "NFO", 100.0)):
            engine._execute_open_orders(tm, pd.DataFrame())
        engine._order_router._client.placesmartorder.assert_called_once()

    def test_sell_exit_never_drift_cancelled(self):
        """SEL rows must never be drift-cancelled regardless of LTP movement."""
        from tcos_bot.data.ltp_store import ltp_store
        ltp_store.update("NIFTY", 99999.0, source="TEST")  # absurd LTP
        engine = self._engine()
        c = engine._order_router._client
        c.placesmartorder.return_value = {"status": "success", "orderid": "EXIT1"}
        c.positionbook.return_value    = {"status": "success", "data": [
            {"symbol": "NIFTY17MAR2623100CE", "quantity": 65, "exchange": "NFO"}
        ]}
        tm = pd.concat([
            _empty_tm(),
            pd.DataFrame([_inposition_row()]),
            pd.DataFrame([{
                "exchange": "NSE_INDEX", "timestamp": "2026-03-13 13:32:00",
                "symbol": "NIFTY", "renko_signal": "SELCL",
                "entry_price": 23900.0, "quantity": 65,
                "order_status": "OPEN", "close_reason": "",
            }]),
        ], ignore_index=True)
        positions_df = pd.DataFrame([
            {"symbol": "NIFTY17MAR2623100CE", "quantity": 65, "exchange": "NFO"}
        ])
        with patch.object(engine, "_resolve_option",
                          return_value=("NIFTY17MAR2623100CE", "NFO", 100.0)):
            engine._execute_open_orders(tm, positions_df)
        c.placesmartorder.assert_called_once()


# ═══════════════════════════════════════════════════════════════════════════════
# 17. Stop anchor override on high-drift fills (Fix 2)
# ═══════════════════════════════════════════════════════════════════════════════

class TestStopAnchorOverride:
    """TrailingStopManager.initialise() should be called with exec_price
    (not signal_price) when drift exceeds drift_stop_override_bricks."""

    def _tracker(self):
        from tcos_bot.execution.position_tracker import OrderRouter
        c = MagicMock()
        c.placesmartorder.return_value = {"status": "success", "orderid": "T8"}
        return OrderRouter(c, "TEST", "MIS")

    def _tm(self, sig_px, brick_size=12.0):
        cols = [
            "exchange","timestamp","symbol","renko_signal","entry_price","quantity",
            "order_status","close_reason","signal_grade","quality_score","day_regime",
            "exec_price","entry_mode","brick_size_hint","struct_high","struct_low",
            "index_ltp","fill_timestamp","option_symbol","peak_brick_since_entry",
            "peak_ltp_since_entry","nft_validated","nft_target","chop_reversals",
            "chop_last_ltp","nft_last_ltp","nft_rev_count","chop_last_dir","orderid",
        ]
        row = {c_: None for c_ in cols}
        row.update({
            "exchange": "NSE_INDEX", "timestamp": "2026-03-13 13:31:00",
            "symbol": "NIFTY", "renko_signal": "BUYCL",
            "entry_price": sig_px, "quantity": 65,
            "order_status": "INPOSITION", "close_reason": "",
            "signal_grade": "A", "quality_score": 5, "day_regime": "TRENDING",
            "exec_price": sig_px, "entry_mode": "BREAKOUT",
            "brick_size_hint": brick_size,
            "struct_high": None, "struct_low": None,
        })
        return pd.DataFrame([row])

    def test_high_drift_anchors_to_exec_price(self):
        """When exec price drifted 3.75b above signal price, initialise() must
        receive exec_price as anchor, not signal_price."""
        from tcos_bot.risk.risk_manager import trailing_stop_mgr
        from tcos_bot.execution.position_tracker import OrderRouter
        sig_px  = 23154.0
        exec_px = 23199.0   # +3.75b drift
        brick   = 12.0

        tracker = self._tracker()
        tm      = self._tm(sig_px, brick)
        idx     = tm.index[0]

        with patch.object(trailing_stop_mgr, "initialise", return_value=23175.0) as mock_init:
            tracker._on_entry_fill(
                tm, idx, "NIFTY", "NIFTY17MAR2623100CE",
                "ORD99", exec_px, sig_px, "BUYCL", "SELST",
            )
            anchor = mock_init.call_args[0][2]   # 3rd positional arg = entry_price param
            assert anchor == exec_px, (
                f"Expected stop anchored to exec_px={exec_px}, got {anchor}. "
                f"T8 bug: stop was placed from signal_price leaving only 1.5b breathing room."
            )

    def test_low_drift_uses_signal_price(self):
        """FIX I-02: drift_stop_override_bricks changed 1.5→0.5b so exec price
        is used as stop anchor for all drifts > 0.5b. This correctly prevents the
        stop being anchored to a stale signal price when the fill is 1b+ away.
        Test updated: 0.3b drift (< 0.5b threshold) still uses signal price;
        1.0b drift (> 0.5b threshold) now correctly uses exec price."""
        from tcos_bot.risk.risk_manager import trailing_stop_mgr
        brick   = 12.0

        tracker = self._tracker()

        # Case 1: drift < 0.5b threshold → signal price still used
        sig_px1  = 23154.0
        exec_px1 = sig_px1 + 0.3 * brick  # 0.3b — below new 0.5b threshold
        tm1  = self._tm(sig_px1, brick)
        idx1 = tm1.index[0]
        with patch.object(trailing_stop_mgr, "initialise", return_value=23130.0) as mock_init1:
            tracker._on_entry_fill(
                tm1, idx1, "NIFTY", "NIFTY17MAR2623100CE",
                "ORD98", exec_px1, sig_px1, "BUYCL", "SELST",
            )
            anchor1 = mock_init1.call_args[0][2]
            assert anchor1 == sig_px1, (
                f"0.3b drift: expected signal_px={sig_px1}, got {anchor1}"
            )

        # Case 2: drift > 0.5b threshold → exec price now used (FIX I-02)
        sig_px2  = 23154.0
        exec_px2 = sig_px2 + 1.0 * brick  # 1.0b — above new 0.5b threshold
        tm2  = self._tm(sig_px2, brick)
        idx2 = tm2.index[0]
        with patch.object(trailing_stop_mgr, "initialise", return_value=23130.0) as mock_init2:
            tracker._on_entry_fill(
                tm2, idx2, "NIFTY", "NIFTY17MAR2623100CE",
                "ORD99", exec_px2, sig_px2, "BUYCL", "SELST",
            )
            anchor2 = mock_init2.call_args[0][2]
            assert anchor2 == exec_px2, (
                f"1.0b drift: expected exec_px={exec_px2} (FIX I-02), got {anchor2}"
            )


# ═══════════════════════════════════════════════════════════════════════════════
# 18. VIX override on strongly trending days (Fix 3)
# ═══════════════════════════════════════════════════════════════════════════════

class TestVixTrendOverride:
    def _clf(self):
        from tcos_bot.filters.day_regime import DayRegimeClassifier
        return DayRegimeClassifier()

    def test_high_range_ratio_caps_volatile_score(self):
        """range_ratio=4.45, VIX=21.9 should resolve to TRENDING with
        confidence >= 50% after the VIX VOLATILE cap is applied."""
        clf = self._clf()
        scores = clf._score(range_ratio=4.45, vix=21.9)
        # TRENDING should beat or tie VOLATILE after cap
        assert scores["TRENDING"] >= scores["VOLATILE"], (
            f"TRENDING={scores['TRENDING']} should >= VOLATILE={scores['VOLATILE']} "
            f"when range_ratio=4.45 (strongly trending override active)"
        )

    def test_low_range_ratio_does_not_cap(self):
        """range_ratio=1.5 (below vix_trend_override_ratio=3.5): VIX=21.9
        should still score full VOLATILE=2."""
        clf = self._clf()
        scores = clf._score(range_ratio=1.5, vix=21.9)
        assert scores["VOLATILE"] == 2, (
            f"VOLATILE should be 2 when range_ratio is not high-trending, got {scores['VOLATILE']}"
        )

    def test_no_vix_unchanged(self):
        """vix=None path must be unaffected by the override."""
        clf = self._clf()
        scores = clf._score(range_ratio=4.45, vix=None)
        # No VIX contribution at all — TRENDING gets +2 from range_ratio only
        assert scores["TRENDING"] == 2
        assert scores["VOLATILE"] == 0

    def test_override_disabled_when_zero(self):
        """vix_trend_override_ratio=0 disables the cap; VIX=21.9 scores VOLATILE=2."""
        import types
        # DayRegimeClassifier stores self._cfg = cfg.day_regime at __init__.
        # Directly override the instance's _cfg to avoid module-patching timing issues.
        from dataclasses import replace as dc_replace
        import tcos_bot.config.settings as s_mod
        clf = self._clf()
        disabled_cfg = dc_replace(clf._cfg, vix_trend_override_ratio=0.0)
        clf._cfg = disabled_cfg
        scores = clf._score(range_ratio=4.45, vix=21.9)
        assert scores["VOLATILE"] == 2


# ═══════════════════════════════════════════════════════════════════════════════
# 19. Intraday regime re-classification interval (Fix 4)
# ═══════════════════════════════════════════════════════════════════════════════

class TestRegimeReclassifyInterval:
    def _pipeline(self):
        from tcos_bot.filters.pipeline import FilterPipeline
        return FilterPipeline()

    def test_reclassify_triggered_after_interval(self):
        """After initial classification, should_classify_today() must return
        True once reclassify_interval_min minutes have elapsed."""
        import time
        import tcos_bot.config.settings as s_mod
        from dataclasses import replace as dc_replace
        original = s_mod.cfg.day_regime
        # Set interval to 0.001 min (~0.06s) so test is instant
        s_mod.cfg = dc_replace(s_mod.cfg,
                               day_regime=dc_replace(original, reclassify_interval_min=0.001))
        try:
            p = self._pipeline()
            # Force "already classified today"
            from tcos_bot.filters.pipeline import IST
            from datetime import datetime
            p._classified_date   = datetime.now(tz=IST).date()
            p._last_classified_at = time.monotonic()
            # Before interval elapses: should NOT re-classify
            assert not p.should_classify_today()
            # Wait for interval to elapse
            time.sleep(0.1)
            assert p.should_classify_today(), (
                "should_classify_today() should return True after interval elapsed"
            )
        finally:
            s_mod.cfg = dc_replace(s_mod.cfg, day_regime=original)

    def test_no_reclassify_when_interval_zero(self):
        """reclassify_interval_min=0 means classify once only (legacy behaviour)."""
        import time
        import tcos_bot.config.settings as s_mod
        from dataclasses import replace as dc_replace
        original = s_mod.cfg.day_regime
        s_mod.cfg = dc_replace(s_mod.cfg,
                               day_regime=dc_replace(original, reclassify_interval_min=0))
        try:
            p = self._pipeline()
            from tcos_bot.filters.pipeline import IST
            from datetime import datetime
            p._classified_date   = datetime.now(tz=IST).date()
            p._last_classified_at = time.monotonic() - 9999   # ancient timestamp
            # Even with old timestamp, interval=0 means never re-classify today
            assert not p.should_classify_today()
        finally:
            s_mod.cfg = dc_replace(s_mod.cfg, day_regime=original)


# ═══════════════════════════════════════════════════════════════════════════════
# 20. CHOP_EXIT resets whipsaw flip counter (Fix 5)
# ═══════════════════════════════════════════════════════════════════════════════

class TestChopExitResetsFlipCounter:
    def _make_tm(self, sym="NIFTY"):
        """One INPOSITION BUYCL row + one OPEN SELCL exit row (CHOP_EXIT)."""
        entry = {
            "exchange": "NSE_INDEX", "timestamp": "2026-03-13 12:47:00",
            "symbol": sym, "renko_signal": "BUYCL",
            "entry_price": 23214.0, "quantity": 65,
            "order_status": "INPOSITION", "close_reason": "",
            "signal_grade": "B", "quality_score": 4, "day_regime": "TRENDING",
            "exec_price": 23214.0, "entry_mode": "BREAKOUT",
            "brick_size_hint": 12.0,
            "struct_high": None, "struct_low": None,
            "index_ltp": 23214.0, "fill_timestamp": "2026-03-13 12:47:00",
            "option_symbol": f"{sym}17MAR2623100CE",
            "peak_brick_since_entry": 23214.0, "peak_ltp_since_entry": 23214.0,
            "nft_validated": 0, "nft_target": 23250.0, "chop_reversals": 4,
            "chop_last_ltp": 23214.0, "nft_last_ltp": 23214.0, "nft_rev_count": 0,
            "chop_last_dir": None, "orderid": "CHK99",
        }
        chop_exit = {
            "exchange": "NSE_INDEX", "timestamp": "2026-03-13 12:47:51",
            "symbol": sym, "renko_signal": "SELCL",
            "entry_price": 23214.0, "quantity": 65,
            "order_status": "OPEN", "close_reason": "CHOP_OSCILLATION_EXIT",
            "signal_grade": None, "quality_score": None, "day_regime": None,
            "exec_price": None, "entry_mode": None, "brick_size_hint": None,
            "struct_high": None, "struct_low": None,
            "index_ltp": None, "fill_timestamp": None, "option_symbol": None,
            "peak_brick_since_entry": None, "peak_ltp_since_entry": None,
            "nft_validated": None, "nft_target": None, "chop_reversals": None,
            "chop_last_ltp": None, "nft_last_ltp": None, "nft_rev_count": None,
            "chop_last_dir": None, "orderid": None,
        }
        return pd.DataFrame([entry, chop_exit])

    def test_chop_exit_fill_clears_call_flip_counter(self):
        """When a SELCL fill with close_reason=CHOP_OSCILLATION_EXIT completes,
        the CALL direction flip counter for that symbol must be reset to 0."""
        from tcos_bot.execution.position_tracker import OrderRouter
        from tcos_bot.risk.risk_manager import whipsaw_tracker, trailing_stop_mgr

        sym = "NIFTY"
        # Pre-arm the whipsaw tracker: 1 CALL flip already recorded
        whipsaw_tracker._flips[(sym, "CALL")] = [0.0]

        c = MagicMock()
        c.placesmartorder.return_value = {"status": "success", "orderid": "CHOP1"}
        router = OrderRouter(c, "TEST", "MIS")

        tm  = self._make_tm(sym)
        idx = tm[tm["renko_signal"] == "SELCL"].index[0]
        row = tm.loc[idx]

        trailing_stop_mgr.remove(sym)   # ensure clean state

        router._on_exit_fill(
            tm, idx, sym, "SELCL", "CHOP1", 23214.0,
            "BUYCL", "SELST", "SELCL",
        )

        remaining_flips = whipsaw_tracker._flips.get((sym, "CALL"), [])
        assert remaining_flips == [], (
            f"CALL flip counter should be reset after CHOP_EXIT, "
            f"but still has {len(remaining_flips)} flip(s)"
        )

    def test_normal_stop_exit_does_not_clear_flip_counter(self):
        """A STOP_EXIT must NOT reset the flip counter (only CHOP_EXIT should)."""
        from tcos_bot.execution.position_tracker import OrderRouter
        from tcos_bot.risk.risk_manager import whipsaw_tracker, trailing_stop_mgr

        sym = "NIFTY"
        whipsaw_tracker._flips[(sym, "CALL")] = [0.0]

        c = MagicMock()
        c.placesmartorder.return_value = {"status": "success", "orderid": "STOP1"}
        router = OrderRouter(c, "TEST", "MIS")

        tm  = self._make_tm(sym)
        idx = tm[tm["renko_signal"] == "SELCL"].index[0]
        # Override close_reason to simulate a STOP_EXIT (not CHOP)
        tm.at[idx, "close_reason"] = "STOP_EXIT"

        trailing_stop_mgr.remove(sym)

        router._on_exit_fill(
            tm, idx, sym, "SELCL", "STOP1", 23214.0,
            "BUYCL", "SELST", "SELCL",
        )

        remaining_flips = whipsaw_tracker._flips.get((sym, "CALL"), [])
        assert len(remaining_flips) == 1, (
            "STOP_EXIT should NOT clear the flip counter"
        )
