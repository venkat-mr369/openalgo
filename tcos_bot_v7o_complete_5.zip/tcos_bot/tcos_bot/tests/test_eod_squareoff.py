"""
test_eod_squareoff.py — Deep tests for EOD squareoff (15:25) and engine stop (15:30).

Covers:
  1.  Config field exists with correct default
  2.  _check_eod_squareoff does NOT fire before 15:25
  3.  _check_eod_squareoff fires at exactly 15:25
  4.  _check_eod_squareoff fires after 15:25 (idempotent repeat)
  5.  BUYCL → SELCL exit row created
  6.  BUYPT → SELPT exit row created
  7.  Duplicate guard: no second row if SELCL already OPEN
  8.  Duplicate guard: no second row if SELCL already SENDING
  9.  MCX instruments are SKIPPED at 15:25
  10. NSE_INDEX and BSE_INDEX both trigger squareoff
  11. close_reason = "EOD_SQUAREOFF"
  12. exit row order_status = "OPEN"
  13. exit row quantity matches entry quantity
  14. Engine stop check: stop_event set at nse_close (15:30)
  15. Engine stop: _cycle returns immediately without doing work after stop
  16. Multiple INPOSITION rows → all get exit rows in one pass
  17. Mixed NSE + MCX: only NSE gets exit row
  18. Already-CLOSED INPOSITION rows are not double-exited
"""
import threading
from datetime import time as dtime
from unittest.mock import MagicMock, patch
import pandas as pd
import pytest


# ── helpers ───────────────────────────────────────────────────────────────────

def _make_tm(rows):
    """Build a minimal trade_manager DataFrame."""
    base_cols = [
        "exchange", "timestamp", "symbol", "renko_signal",
        "entry_price", "quantity", "order_status", "close_reason",
        "option_symbol",
    ]
    df = pd.DataFrame(rows)
    for col in base_cols:
        if col not in df.columns:
            df[col] = "" if col in ("close_reason", "option_symbol") else None
    return df


def _inpos(symbol, exchange, renko_signal, qty=65, entry=22800.0):
    return {
        "exchange":     exchange,
        "timestamp":    "2026-04-07 14:00:00",
        "symbol":       symbol,
        "renko_signal": renko_signal,
        "entry_price":  entry,
        "quantity":     qty,
        "order_status": "INPOSITION",
        "close_reason": "",
        "option_symbol": f"{symbol}APR{int(entry)}CE",
    }


def _make_engine():
    """Build a minimal TradingEngine with all heavy dependencies mocked out."""
    from tcos_bot.core.engine import TradingEngine
    client = MagicMock()
    with patch("tcos_bot.core.engine.trade_store"), \
         patch("tcos_bot.core.engine.ltp_store") as mock_ltp, \
         patch("tcos_bot.core.engine.trailing_stop_mgr"), \
         patch("tcos_bot.core.engine.nft_checker"), \
         patch("tcos_bot.core.engine.chop_checker"), \
         patch("tcos_bot.core.engine.risk_engine"), \
         patch("tcos_bot.core.engine.whipsaw_tracker"):
        mock_ltp.get.return_value = (22850.0, 1.0)
        engine = TradingEngine.__new__(TradingEngine)
        engine._stop_event   = threading.Event()
        engine._tm_lock      = threading.Lock()
        engine._brick_sizes  = {"NIFTY": 12.0, "BANKNIFTY": 40.0, "CRUDEOIL": 8.0}
        engine._last_cycle   = 0.0
        engine._last_status_print = 0.0
        engine._last_status_hash  = ""
        engine._ws_manager   = None
        engine._signal_gen   = MagicMock()
        engine._position_tracker = MagicMock()
        engine._renko_cache  = MagicMock()
        engine._ohlc_cache   = MagicMock()
    return engine


# ── Config tests ───────────────────────────────────────────────────────────────

class TestEodConfig:
    def test_eod_squareoff_time_field_exists(self):
        from tcos_bot.config.settings import cfg
        assert hasattr(cfg.market_hours, "eod_squareoff_time"), \
            "eod_squareoff_time missing from MarketHoursConfig"

    def test_eod_squareoff_time_default_1525(self):
        from tcos_bot.config.settings import cfg
        assert cfg.market_hours.eod_squareoff_time == "15:25", (
            f"eod_squareoff_time should be '15:25', got "
            f"'{cfg.market_hours.eod_squareoff_time}'"
        )

    def test_nse_close_still_1530(self):
        from tcos_bot.config.settings import cfg
        assert cfg.market_hours.nse_close == "15:30"

    def test_eod_before_nse_close(self):
        """Squareoff time must be strictly before market close."""
        from tcos_bot.config.settings import cfg
        sq = dtime(*map(int, cfg.market_hours.eod_squareoff_time.split(":")))
        cl = dtime(*map(int, cfg.market_hours.nse_close.split(":")))
        assert sq < cl, "eod_squareoff_time must be before nse_close"

    def test_method_exists_on_engine(self):
        from tcos_bot.core.engine import TradingEngine
        assert hasattr(TradingEngine, "_check_eod_squareoff"), \
            "_check_eod_squareoff method missing from TradingEngine"


# ── Timing gate tests ──────────────────────────────────────────────────────────

class TestEodTiming:
    def _run_at(self, engine, tm, hhmm):
        """Run _check_eod_squareoff with a mocked current time."""
        h, m = map(int, hhmm.split(":"))
        fake_now = MagicMock()
        fake_now.time.return_value = dtime(h, m, 0)
        with patch("tcos_bot.core.engine._now", return_value=fake_now), \
             patch("tcos_bot.core.engine.ltp_store") as mock_ltp:
            mock_ltp.get.return_value = (22850.0, 1.0)
            engine2 = MagicMock(spec=["_check_eod_squareoff"])
            from tcos_bot.core.engine import TradingEngine
            return TradingEngine._check_eod_squareoff(engine, tm)

    def test_does_not_fire_before_1525(self):
        engine = _make_engine()
        tm = _make_tm([_inpos("NIFTY", "NSE_INDEX", "BUYCL")])
        with patch("tcos_bot.core.engine._now") as mock_now, \
             patch("tcos_bot.core.engine.ltp_store") as mock_ltp:
            mock_now.return_value.time.return_value = dtime(14, 0, 0)
            mock_ltp.get.return_value = (22850.0, 1.0)
            from tcos_bot.core.engine import TradingEngine
            _, changed = TradingEngine._check_eod_squareoff(engine, tm)
        assert not changed, "should NOT fire at 14:00"

    def test_does_not_fire_at_1524(self):
        engine = _make_engine()
        tm = _make_tm([_inpos("NIFTY", "NSE_INDEX", "BUYCL")])
        with patch("tcos_bot.core.engine._now") as mock_now, \
             patch("tcos_bot.core.engine.ltp_store") as mock_ltp:
            mock_now.return_value.time.return_value = dtime(15, 24, 59)
            mock_ltp.get.return_value = (22850.0, 1.0)
            from tcos_bot.core.engine import TradingEngine
            _, changed = TradingEngine._check_eod_squareoff(engine, tm)
        assert not changed, "should NOT fire at 15:24:59"

    def test_fires_at_exactly_1525(self):
        engine = _make_engine()
        tm = _make_tm([_inpos("NIFTY", "NSE_INDEX", "BUYCL")])
        with patch("tcos_bot.core.engine._now") as mock_now, \
             patch("tcos_bot.core.engine.ltp_store") as mock_ltp:
            mock_now.return_value.time.return_value = dtime(15, 25, 0)
            mock_now.return_value.strftime.return_value = "2026-04-07 15:25:00"
            mock_ltp.get.return_value = (22850.0, 1.0)
            from tcos_bot.core.engine import TradingEngine
            _, changed = TradingEngine._check_eod_squareoff(engine, tm)
        assert changed, "MUST fire at exactly 15:25:00"

    def test_fires_after_1525(self):
        engine = _make_engine()
        tm = _make_tm([_inpos("NIFTY", "NSE_INDEX", "BUYCL")])
        with patch("tcos_bot.core.engine._now") as mock_now, \
             patch("tcos_bot.core.engine.ltp_store") as mock_ltp:
            mock_now.return_value.time.return_value = dtime(15, 27, 30)
            mock_now.return_value.strftime.return_value = "2026-04-07 15:27:30"
            mock_ltp.get.return_value = (22850.0, 1.0)
            from tcos_bot.core.engine import TradingEngine
            _, changed = TradingEngine._check_eod_squareoff(engine, tm)
        assert changed, "must still fire at 15:27"


# ── Exit row content tests ──────────────────────────────────────────────────────

class TestEodExitRows:

    def _squareoff_at_1525(self, engine, tm):
        with patch("tcos_bot.core.engine._now") as mock_now, \
             patch("tcos_bot.core.engine.ltp_store") as mock_ltp:
            mock_now.return_value.time.return_value = dtime(15, 25, 0)
            mock_now.return_value.strftime.return_value = "2026-04-07 15:25:00"
            mock_ltp.get.return_value = (22850.0, 1.0)
            from tcos_bot.core.engine import TradingEngine
            return TradingEngine._check_eod_squareoff(engine, tm)

    def test_buycl_creates_selcl(self):
        engine = _make_engine()
        tm = _make_tm([_inpos("NIFTY", "NSE_INDEX", "BUYCL")])
        new_tm, changed = self._squareoff_at_1525(engine, tm)
        assert changed
        exits = new_tm[new_tm["renko_signal"] == "SELCL"]
        assert len(exits) == 1, "must create exactly 1 SELCL row"

    def test_buypt_creates_selpt(self):
        engine = _make_engine()
        tm = _make_tm([_inpos("NIFTY", "NSE_INDEX", "BUYPT")])
        new_tm, changed = self._squareoff_at_1525(engine, tm)
        assert changed
        exits = new_tm[new_tm["renko_signal"] == "SELPT"]
        assert len(exits) == 1, "must create exactly 1 SELPT row"

    def test_exit_row_order_status_is_open(self):
        engine = _make_engine()
        tm = _make_tm([_inpos("NIFTY", "NSE_INDEX", "BUYCL")])
        new_tm, _ = self._squareoff_at_1525(engine, tm)
        exit_row = new_tm[new_tm["renko_signal"] == "SELCL"].iloc[0]
        assert exit_row["order_status"] == "OPEN"

    def test_exit_row_close_reason_is_eod_squareoff(self):
        engine = _make_engine()
        tm = _make_tm([_inpos("NIFTY", "NSE_INDEX", "BUYCL")])
        new_tm, _ = self._squareoff_at_1525(engine, tm)
        exit_row = new_tm[new_tm["renko_signal"] == "SELCL"].iloc[0]
        assert exit_row["close_reason"] == "EOD_SQUAREOFF"

    def test_exit_row_quantity_matches_entry(self):
        engine = _make_engine()
        tm = _make_tm([_inpos("NIFTY", "NSE_INDEX", "BUYCL", qty=65)])
        new_tm, _ = self._squareoff_at_1525(engine, tm)
        exit_row = new_tm[new_tm["renko_signal"] == "SELCL"].iloc[0]
        assert int(exit_row["quantity"]) == 65

    def test_exit_row_symbol_matches(self):
        engine = _make_engine()
        tm = _make_tm([_inpos("BANKNIFTY", "NSE_INDEX", "BUYCL", qty=30)])
        new_tm, _ = self._squareoff_at_1525(engine, tm)
        exit_row = new_tm[new_tm["renko_signal"] == "SELCL"].iloc[0]
        assert exit_row["symbol"] == "BANKNIFTY"


# ── Duplicate guard tests ──────────────────────────────────────────────────────

class TestEodDuplicateGuard:

    def _squareoff_at_1525(self, engine, tm):
        with patch("tcos_bot.core.engine._now") as mock_now, \
             patch("tcos_bot.core.engine.ltp_store") as mock_ltp:
            mock_now.return_value.time.return_value = dtime(15, 25, 0)
            mock_now.return_value.strftime.return_value = "2026-04-07 15:25:00"
            mock_ltp.get.return_value = (22850.0, 1.0)
            from tcos_bot.core.engine import TradingEngine
            return TradingEngine._check_eod_squareoff(engine, tm)

    def test_no_duplicate_if_selcl_already_open(self):
        engine = _make_engine()
        existing_exit = {
            "exchange": "NSE_INDEX", "timestamp": "2026-04-07 15:25:01",
            "symbol": "NIFTY", "renko_signal": "SELCL",
            "entry_price": 22800.0, "quantity": 65,
            "order_status": "OPEN", "close_reason": "EOD_SQUAREOFF",
            "option_symbol": "",
        }
        tm = _make_tm([_inpos("NIFTY", "NSE_INDEX", "BUYCL"), existing_exit])
        new_tm, changed = self._squareoff_at_1525(engine, tm)
        assert not changed, "should NOT create duplicate when SELCL already OPEN"
        assert len(new_tm[new_tm["renko_signal"] == "SELCL"]) == 1

    def test_no_duplicate_if_selcl_already_sending(self):
        engine = _make_engine()
        existing_exit = {
            "exchange": "NSE_INDEX", "timestamp": "2026-04-07 15:25:01",
            "symbol": "NIFTY", "renko_signal": "SELCL",
            "entry_price": 22800.0, "quantity": 65,
            "order_status": "SENDING", "close_reason": "EOD_SQUAREOFF",
            "option_symbol": "",
        }
        tm = _make_tm([_inpos("NIFTY", "NSE_INDEX", "BUYCL"), existing_exit])
        new_tm, changed = self._squareoff_at_1525(engine, tm)
        assert not changed, "should NOT create duplicate when SELCL already SENDING"

    def test_idempotent_on_second_cycle(self):
        """Calling twice (two 2-second cycles) must not create two exit rows."""
        engine = _make_engine()
        tm = _make_tm([_inpos("NIFTY", "NSE_INDEX", "BUYCL")])
        tm1, _ = self._squareoff_at_1525(engine, tm)
        tm2, changed2 = self._squareoff_at_1525(engine, tm1)
        assert not changed2, "second call must be no-op"
        assert len(tm2[tm2["renko_signal"] == "SELCL"]) == 1


# ── Exchange filter tests ──────────────────────────────────────────────────────

class TestEodExchangeFilter:

    def _squareoff_at_1525(self, engine, tm):
        with patch("tcos_bot.core.engine._now") as mock_now, \
             patch("tcos_bot.core.engine.ltp_store") as mock_ltp:
            mock_now.return_value.time.return_value = dtime(15, 25, 0)
            mock_now.return_value.strftime.return_value = "2026-04-07 15:25:00"
            mock_ltp.get.return_value = (22850.0, 1.0)
            from tcos_bot.core.engine import TradingEngine
            return TradingEngine._check_eod_squareoff(engine, tm)

    def test_mcx_instrument_skipped(self):
        engine = _make_engine()
        tm = _make_tm([_inpos("CRUDEOIL", "MCX", "BUYCL", qty=100)])
        new_tm, changed = self._squareoff_at_1525(engine, tm)
        assert not changed, "MCX instruments must NOT be squaredoff at 15:25"
        assert new_tm[new_tm["renko_signal"] == "SELCL"].empty

    def test_nse_index_fires(self):
        engine = _make_engine()
        tm = _make_tm([_inpos("NIFTY", "NSE_INDEX", "BUYCL")])
        _, changed = self._squareoff_at_1525(engine, tm)
        assert changed, "NSE_INDEX must trigger squareoff"

    def test_bse_index_fires(self):
        engine = _make_engine()
        tm = _make_tm([_inpos("SENSEX", "BSE_INDEX", "BUYCL", qty=20)])
        _, changed = self._squareoff_at_1525(engine, tm)
        assert changed, "BSE_INDEX must trigger squareoff"

    def test_mixed_nse_mcx_only_nse_exits(self):
        engine = _make_engine()
        tm = _make_tm([
            _inpos("NIFTY",    "NSE_INDEX", "BUYCL", qty=65),
            _inpos("CRUDEOIL", "MCX",       "BUYCL", qty=100),
        ])
        new_tm, changed = self._squareoff_at_1525(engine, tm)
        assert changed
        exits = new_tm[new_tm["renko_signal"] == "SELCL"]
        assert len(exits) == 1, "only NIFTY (NSE) should get an exit row"
        assert exits.iloc[0]["symbol"] == "NIFTY"


# ── Multi-position tests ───────────────────────────────────────────────────────

class TestEodMultiPosition:

    def _squareoff_at_1525(self, engine, tm):
        with patch("tcos_bot.core.engine._now") as mock_now, \
             patch("tcos_bot.core.engine.ltp_store") as mock_ltp:
            mock_now.return_value.time.return_value = dtime(15, 25, 0)
            mock_now.return_value.strftime.return_value = "2026-04-07 15:25:00"
            mock_ltp.get.return_value = (22850.0, 1.0)
            from tcos_bot.core.engine import TradingEngine
            return TradingEngine._check_eod_squareoff(engine, tm)

    def test_three_nse_positions_all_exit(self):
        engine = _make_engine()
        tm = _make_tm([
            _inpos("NIFTY",     "NSE_INDEX", "BUYCL", qty=65),
            _inpos("BANKNIFTY", "NSE_INDEX", "BUYCL", qty=30),
            _inpos("SENSEX",    "BSE_INDEX", "BUYPT", qty=20),
        ])
        new_tm, changed = self._squareoff_at_1525(engine, tm)
        assert changed
        selcl = new_tm[new_tm["renko_signal"] == "SELCL"]
        selpt = new_tm[new_tm["renko_signal"] == "SELPT"]
        assert len(selcl) == 2, "NIFTY and BANKNIFTY should each get SELCL"
        assert len(selpt) == 1, "SENSEX should get SELPT"

    def test_no_inposition_rows_no_change(self):
        engine = _make_engine()
        tm = _make_tm([])  # empty
        _, changed = self._squareoff_at_1525(engine, tm)
        assert not changed, "no positions = no change"


# ── Engine stop tests ──────────────────────────────────────────────────────────

class TestEngineStop:

    def test_stop_event_source_code_present(self):
        """Verify the engine stop check is in _cycle()."""
        import inspect
        from tcos_bot.core.engine import TradingEngine
        src = inspect.getsource(TradingEngine._cycle)
        assert "nse_close" in src and "_stop_event.is_set()" in src, \
            "Engine stop check at nse_close missing from _cycle()"

    def test_stop_check_before_main_work(self):
        """Stop check must come before positionbook fetch and signal processing."""
        import inspect
        from tcos_bot.core.engine import TradingEngine
        src = inspect.getsource(TradingEngine._cycle)
        stop_idx   = src.find("_nse_close_t")
        fetch_idx  = src.find("_position_tracker.fetch")
        signal_idx = src.find("_signal_gen.process")
        assert stop_idx > 0, "stop check not found in _cycle()"
        assert stop_idx < fetch_idx,  "stop check must be before position fetch"
        assert stop_idx < signal_idx, "stop check must be before signal processing"

    def test_eod_squareoff_call_before_execute_orders(self):
        """_check_eod_squareoff must run before _execute_open_orders."""
        import inspect
        from tcos_bot.core.engine import TradingEngine
        src = inspect.getsource(TradingEngine._cycle)
        sq_idx  = src.find("_check_eod_squareoff")
        exe_idx = src.find("_execute_open_orders")
        assert sq_idx > 0,  "_check_eod_squareoff not called in _cycle()"
        assert exe_idx > 0, "_execute_open_orders not found in _cycle()"
        assert sq_idx < exe_idx, \
            "_check_eod_squareoff must run BEFORE _execute_open_orders"

    def test_eod_squareoff_call_before_fire_close_hooks(self):
        """_check_eod_squareoff must run before _fire_close_hooks."""
        import inspect
        from tcos_bot.core.engine import TradingEngine
        src = inspect.getsource(TradingEngine._cycle)
        sq_idx    = src.find("_check_eod_squareoff")
        hooks_idx = src.find("_fire_close_hooks")
        assert sq_idx < hooks_idx, \
            "_check_eod_squareoff must run BEFORE _fire_close_hooks"

    def test_nse_close_config_is_1530(self):
        from tcos_bot.config.settings import cfg
        assert cfg.market_hours.nse_close == "15:30"

    def test_engine_stop_method_sets_stop_event(self):
        """engine.stop() must set _stop_event (used by engine stop check)."""
        from tcos_bot.core.engine import TradingEngine
        engine = _make_engine()
        assert not engine._stop_event.is_set()
        with patch("tcos_bot.core.engine.risk_engine"), \
             patch.object(engine, "_ws_manager", None):
            engine.stop()
        assert engine._stop_event.is_set(), "_stop_event must be set after stop()"
