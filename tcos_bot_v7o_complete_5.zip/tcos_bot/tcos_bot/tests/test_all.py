"""
Unit Tests
==========
Tests for all pure-computation modules (no broker, no DB, no I/O).
Run with: pytest tests/ -v
"""

from __future__ import annotations

import math
from datetime import datetime

import numpy as np
import pandas as pd
import pytest

from tcos_bot.filters.base import FilterResult
from tcos_bot.signals.renko_engine import (
    HybridRenkoGenerator,
    RenkoAnnotator,
    RenkoCloseTraditional,
    RenkoHLWick,
)


# ── Fixtures ──────────────────────────────────────────────────────────────────

@pytest.fixture
def trending_ohlc() -> pd.DataFrame:
    """100 1-minute candles with a steady uptrend."""
    timestamps = pd.date_range("2025-01-06 09:15", periods=100, freq="1min")
    prices     = [22000 + i * 5 for i in range(100)]
    data = []
    for ts, p in zip(timestamps, prices):
        data.append({
            "timestamp": ts,
            "open":  p,
            "high":  p + 10,
            "low":   p - 5,
            "close": p + 8,
        })
    return pd.DataFrame(data)


@pytest.fixture
def choppy_ohlc() -> pd.DataFrame:
    """100 1-minute candles oscillating ±20 pts."""
    timestamps = pd.date_range("2025-01-06 09:15", periods=100, freq="1min")
    data = []
    base = 22000
    for i, ts in enumerate(timestamps):
        sign = 1 if i % 4 < 2 else -1
        p    = base + sign * 20
        data.append({
            "timestamp": ts,
            "open":  p,
            "high":  p + 5,
            "low":   p - 5,
            "close": p + (2 * sign),
        })
    return pd.DataFrame(data)


@pytest.fixture
def renko_df_bullish(trending_ohlc) -> pd.DataFrame:
    return RenkoHLWick.calculate(trending_ohlc, brick_size=50)


# ── RenkoHLWick tests ──────────────────────────────────────────────────────────

class TestRenkoHLWick:

    def test_returns_dataframe(self, trending_ohlc):
        df = RenkoHLWick.calculate(trending_ohlc, brick_size=50)
        assert isinstance(df, pd.DataFrame)

    def test_required_columns(self, renko_df_bullish):
        required = {"timestamp", "open", "high", "low", "close", "direction"}
        assert required.issubset(renko_df_bullish.columns)

    def test_uptrend_produces_up_bricks(self, renko_df_bullish):
        assert not renko_df_bullish.empty
        up_count = (renko_df_bullish["direction"] == 1).sum()
        assert up_count > 0

    def test_anchor_determinism(self, trending_ohlc):
        df1 = RenkoHLWick.calculate(trending_ohlc, brick_size=50, anchor=22000)
        df2 = RenkoHLWick.calculate(trending_ohlc, brick_size=50, anchor=22000)
        pd.testing.assert_frame_equal(df1, df2)

    def test_brick_size_zero_raises(self, trending_ohlc):
        with pytest.raises(ValueError, match="brick_size"):
            RenkoHLWick.calculate(trending_ohlc, brick_size=0)

    def test_brick_moves_exactly_one_brick(self, renko_df_bullish):
        """Each brick close should differ from its open by exactly brick_size."""
        brick_size = 50
        diff = (renko_df_bullish["close"] - renko_df_bullish["open"]).abs()
        assert (diff == brick_size).all(), "Some bricks are not exactly brick_size"


# ── RenkoCloseTraditional tests ───────────────────────────────────────────────

class TestRenkoCloseTraditional:

    def test_produces_bricks(self, trending_ohlc):
        df = RenkoCloseTraditional.calculate(trending_ohlc, brick_size=50)
        assert not df.empty

    def test_reversal_needs_two_boxes(self):
        """Close reversal requires 2 boxes, not 1."""
        # Create a sequence: go up 3 bricks, then drop exactly 1 brick — no reversal
        base = 22000
        rows = [{"timestamp": i, "close": base + i * 50} for i in range(4)]
        rows.append({"timestamp": 4, "close": base + 3 * 50 - 50})   # 1 box drop
        df = pd.DataFrame(rows)
        out = RenkoCloseTraditional.calculate(df, brick_size=50, anchor=base)
        # Should have only up bricks
        if not out.empty:
            assert (out["direction"] == 1).all()

    def test_reversal_triggers_at_two_boxes(self):
        base = 22000
        rows = [{"timestamp": i, "close": base + i * 50} for i in range(4)]
        rows.append({"timestamp": 4, "close": base + 3 * 50 - 100})  # 2 box drop
        df = pd.DataFrame(rows)
        out = RenkoCloseTraditional.calculate(df, brick_size=50, anchor=base)
        # Should have at least one down brick after the up bricks
        assert (out["direction"] == -1).any()


# ── RenkoAnnotator tests ──────────────────────────────────────────────────────

class TestRenkoAnnotator:

    def test_adds_all_columns(self, renko_df_bullish):
        annotated = RenkoAnnotator.annotate(renko_df_bullish, brick_size=50)
        for col in ("Renko_Brick", "Colour_Brick_Count", "zlema9"):
            assert col in annotated.columns, f"Missing column: {col}"

    def test_colour_brick_count_monotonic_in_trend(self, trending_ohlc):
        df = RenkoHLWick.calculate(trending_ohlc, brick_size=50)
        annotated = RenkoAnnotator.annotate(df, 50)
        # In pure uptrend, count should generally increase or restart at 1 on direction change
        counts = annotated["Colour_Brick_Count"].tolist()
        assert all(c >= 1 for c in counts)

    def test_zlema_is_numeric(self, renko_df_bullish):
        annotated = RenkoAnnotator.annotate(renko_df_bullish, 50)
        assert annotated["zlema9"].dropna().dtype in (np.float32, np.float64, float)

    def test_empty_df_returns_empty(self):
        empty = pd.DataFrame()
        result = RenkoAnnotator.annotate(empty, 50)
        assert result is None or result.empty


# ── FilterResult tests ────────────────────────────────────────────────────────

class TestFilterResult:

    def test_allow_factory(self):
        r = FilterResult.allow("test reason", size=1.0)
        assert r.allowed is True
        assert r.size_multiplier == 1.0
        assert "test reason" in r.reason

    def test_block_factory(self):
        r = FilterResult.block("blocked")
        assert r.allowed is False
        assert r.size_multiplier == 0.0

    def test_half_factory(self):
        r = FilterResult.half("half size")
        assert r.allowed is True
        assert r.size_multiplier == 0.5


# ── SignalQualityScorer tests ─────────────────────────────────────────────────

class TestSignalQualityScorer:

    def _make_renko_row(
        self,
        brick:     float,
        zlema:     float,
        c_count:   int,
        hh:        bool = False,
        ll:        bool = False,
        last_high: float = 23000,
        last_low:  float = 21000,
    ) -> pd.DataFrame:
        return pd.DataFrame([{
            "Renko_Brick":       brick,
            "zlema9":            zlema,
            "Colour_Brick_Count": c_count,
            "HH": hh, "HL": False, "LH": False, "LL": ll,
            "Last_High": last_high,
            "Last_Low":  last_low,
            "brick_size_hint": 50,
        }])

    def test_strong_bullish_signal_grades_A(self):
        from tcos_bot.filters.signal_quality import SignalQualityScorer
        scorer = SignalQualityScorer()
        df     = self._make_renko_row(brick=22500, zlema=22200, c_count=5, hh=True, last_high=22800)
        result = scorer.score_only(df, "BUYEN", "NIFTY")
        assert result["grade"] in ("A", "B"), f"Expected A/B but got {result['grade']}"

    def test_counter_trend_call_penalised(self):
        from tcos_bot.filters.signal_quality import SignalQualityScorer
        scorer = SignalQualityScorer()
        # Price below ZLEMA → counter-trend CALL
        df = self._make_renko_row(brick=22000, zlema=22300, c_count=1, hh=False)
        result = scorer.score_only(df, "BUYEN", "NIFTY")
        assert result["score"] <= 0

    def test_single_brick_penalised(self):
        from tcos_bot.filters.signal_quality import SignalQualityScorer
        scorer = SignalQualityScorer()
        df = self._make_renko_row(brick=22500, zlema=22200, c_count=1, hh=True)
        result = scorer.score_only(df, "BUYEN", "NIFTY")
        # Single brick should have lower score
        assert result["score"] < 5


# ── HybridRenkoGenerator tests ────────────────────────────────────────────────

class TestHybridRenkoGenerator:

    def test_produces_signal_columns(self, trending_ohlc):
        gen = HybridRenkoGenerator()
        out = gen.generate(trending_ohlc, brick_size=50)
        assert "Signal" in out.columns
        assert "Close_Signal" in out.columns

    def test_empty_input_returns_empty(self):
        gen = HybridRenkoGenerator()
        out = gen.generate(pd.DataFrame(), brick_size=50)
        assert out.empty

    def test_uptrend_has_buyen_signal(self, trending_ohlc):
        gen = HybridRenkoGenerator()
        out = gen.generate(trending_ohlc, brick_size=50)
        has_buyen = out["Signal"].isin(["BUYEN"]).any()
        assert has_buyen, "Uptrend should produce at least one BUYEN signal"


# ── Run with: pytest tcos_bot/tests/test_all.py -v


# ── STOP-REENTRY-FIX tests ──────────────────────────────────────────────────

class TestStopReentryBlock:
    """
    After a STOP_EXIT, Grade-A bypass must NOT allow immediate re-entry.
    This prevents the proven double-loss pattern:
      PUT stop → Grade-A CALL entry 16s later → CALL stop = -₹5,100 in 7 min.
    """

    def _make_tracker(self, cooldown_s=300):
        import time
        from tcos_bot.risk.risk_manager import WhipsawCooldownTracker
        t = WhipsawCooldownTracker()
        # Bypass the 120s startup grace so tests can record flips immediately.
        # In production the bot runs for minutes before any stop fires.
        t._start_time = time.monotonic() - 200
        return t

    def test_stop_exit_blocks_grade_a_bypass(self):
        """After STOP_EXIT, last_exit_was_stop returns True within cooldown window."""
        tracker = self._make_tracker()
        tracker.record_flip("CRUDEOIL", "PUT", exit_reason="STOP_EXIT", regime="UNKNOWN")
        assert tracker.is_stop_exit_recent("CRUDEOIL", "CALL") is True

    def test_signal_exit_does_not_block_grade_a_bypass(self):
        """After SIGNAL_EXIT, Grade-A bypass is allowed (clean directional change)."""
        tracker = self._make_tracker()
        tracker.record_flip("CRUDEOIL", "PUT", exit_reason="SIGNAL_EXIT", regime="UNKNOWN")
        assert tracker.is_stop_exit_recent("CRUDEOIL", "CALL") is False

    def test_trail_exit_blocks_grade_a_bypass(self):
        """After TRAIL_EXIT, treat as stop — Grade-A bypass blocked."""
        tracker = self._make_tracker()
        tracker.record_flip("CRUDEOIL", "PUT", exit_reason="TRAIL_EXIT", regime="UNKNOWN")
        assert tracker.is_stop_exit_recent("CRUDEOIL", "CALL") is True

    def test_nft_exit_does_not_block_grade_a_bypass(self):
        """After NFT exit (which records as SIGNAL_EXIT), Grade-A bypass is allowed."""
        tracker = self._make_tracker()
        tracker.record_flip("CRUDEOIL", "PUT", exit_reason="SIGNAL_EXIT", regime="UNKNOWN")
        assert tracker.is_stop_exit_recent("CRUDEOIL", "CALL") is False

    def test_stop_reentry_block_expires(self):
        """Block is gone once cooldown_until timestamp lapses."""
        import time
        tracker = self._make_tracker()
        tracker.record_flip("CRUDEOIL", "PUT", exit_reason="STOP_EXIT", regime="UNKNOWN")
        # Confirm it blocks while cooldown is active
        assert tracker.is_stop_exit_recent("CRUDEOIL", "CALL") is True
        # Force-expire the cooldown by rewinding _cooldown_until to the past
        tracker._cooldown_until[("CRUDEOIL", "PUT")] = time.monotonic() - 1
        assert tracker.is_stop_exit_recent("CRUDEOIL", "CALL") is False

    def test_cross_symbol_isolation(self):
        """CRUDEOIL stop does not block GOLDM Grade-A bypass."""
        tracker = self._make_tracker()
        tracker.record_flip("CRUDEOIL", "PUT", exit_reason="STOP_EXIT", regime="UNKNOWN")
        assert tracker.is_stop_exit_recent("GOLDM", "CALL") is False


# ── ATM-FOR-MCX tests ─────────────────────────────────────────────────────────

class TestAtmForMcx:
    """
    MCX options must resolve ATM (no step offset).
    NSE/BSE options must resolve 1-step ITM (existing behaviour preserved).
    """

    def _resolver(self):
        from tcos_bot.execution.option_resolver import OptionResolver
        return OptionResolver(client=None)

    def test_mcx_ce_uses_atm_not_itm(self):
        """CRUDEOIL CE: target must equal ATM, not ATM-step."""
        import tcos_bot.execution.option_resolver as mod
        r = self._resolver()
        ltp, step = 9000.0, 50
        atm = round(ltp / step) * step  # 9000
        # Simulate the new logic
        from tcos_bot.execution.option_resolver import _derivative_exchange
        deriv_ex = _derivative_exchange("MCX")
        _MCX = {"MCX", "MCX_FUT", "MCX_OPT"}
        target = atm if deriv_ex.upper() in _MCX else (atm - step)
        assert target == atm, f"MCX CE should be ATM={atm}, got target={target}"

    def test_mcx_pe_uses_atm_not_itm(self):
        """CRUDEOIL PE: target must equal ATM, not ATM+step."""
        from tcos_bot.execution.option_resolver import _derivative_exchange
        ltp, step = 9000.0, 50
        atm = round(ltp / step) * step
        deriv_ex = _derivative_exchange("MCX")
        _MCX = {"MCX", "MCX_FUT", "MCX_OPT"}
        target = atm if deriv_ex.upper() in _MCX else (atm + step)
        assert target == atm, f"MCX PE should be ATM={atm}, got target={target}"

    def test_nse_ce_stays_itm(self):
        """NIFTY CE: 1-step ITM preserved — NSE/BSE behaviour unchanged."""
        from tcos_bot.execution.option_resolver import _derivative_exchange
        ltp, step = 22000.0, 100
        atm = round(ltp / step) * step  # 22000
        deriv_ex = _derivative_exchange("NSE_INDEX")  # NFO
        _MCX = {"MCX", "MCX_FUT", "MCX_OPT"}
        target = atm if deriv_ex.upper() in _MCX else (atm - step)
        assert target == atm - step, f"NSE CE should be 1-step ITM={atm-step}, got {target}"

    def test_nse_pe_stays_itm(self):
        """NIFTY PE: 1-step ITM preserved."""
        from tcos_bot.execution.option_resolver import _derivative_exchange
        ltp, step = 22000.0, 100
        atm = round(ltp / step) * step
        deriv_ex = _derivative_exchange("NSE_INDEX")
        _MCX = {"MCX", "MCX_FUT", "MCX_OPT"}
        target = atm if deriv_ex.upper() in _MCX else (atm + step)
        assert target == atm + step, f"NSE PE should be 1-step ITM={atm+step}, got {target}"

    def test_bse_ce_stays_itm(self):
        """SENSEX CE: BSE 1-step ITM preserved."""
        from tcos_bot.execution.option_resolver import _derivative_exchange
        ltp, step = 73000.0, 100
        atm = round(ltp / step) * step
        deriv_ex = _derivative_exchange("BSE_INDEX")  # BFO
        _MCX = {"MCX", "MCX_FUT", "MCX_OPT"}
        target = atm if deriv_ex.upper() in _MCX else (atm - step)
        assert target == atm - step

    def test_goldm_mcx_uses_atm(self):
        """GOLDM: MCX commodity uses ATM."""
        from tcos_bot.execution.option_resolver import _derivative_exchange
        ltp, step = 88000.0, 500
        atm = round(ltp / step) * step
        deriv_ex = _derivative_exchange("MCX")
        _MCX = {"MCX", "MCX_FUT", "MCX_OPT"}
        target = atm if deriv_ex.upper() in _MCX else (atm - step)
        assert target == atm

    def test_naturalgas_mcx_uses_atm(self):
        """NATURALGAS: MCX uses ATM."""
        from tcos_bot.execution.option_resolver import _derivative_exchange
        ltp, step = 290.0, 5
        atm = round(ltp / step) * step
        deriv_ex = _derivative_exchange("MCX")
        _MCX = {"MCX", "MCX_FUT", "MCX_OPT"}
        target = atm if deriv_ex.upper() in _MCX else (atm - step)
        assert target == atm


# ── Same-cycle signal exit block + MCX Grade-B loss block tests ───────────────

class TestSameCycleSignalExitBlock:
    """
    Race condition fix: when SELEX→BUYEN fires in the same engine cycle as
    a SIGNAL_EXIT close, the new entry must be blocked even though the
    whipsaw tracker hasn't recorded the signal_exit yet.
    """

    def _make_closed_tm(self, symbol, direction, close_reason):
        """Trade manager with a just-closed position."""
        import pandas as pd
        action = "BUYCL" if direction == "CALL" else "BUYPT"
        return pd.DataFrame([{
            "symbol": symbol, "exchange": "MCX",
            "renko_signal": action,
            "order_status": "CLOSED",
            "close_reason": close_reason,
            "entry_price": 9000.0,
            "close_price": 9020.0 if direction == "CALL" else 8980.0,
            "quantity": 100,
        }])

    def test_same_cycle_signal_exit_blocks_reversal(self):
        """Grade-B CALL blocked when PUT just SIGNAL_EXITed this cycle."""
        import pandas as pd
        from tcos_bot.signals.signal_generator import SignalGenerator
        sg = SignalGenerator()
        tm = self._make_closed_tm("CRUDEOIL", "PUT", "SIGNAL_EXIT")
        # Simulate: PUT just closed via SIGNAL_EXIT, now CALL wants to enter
        # The same-cycle block should catch this
        opp_entry_action = "BUYPT"  # PUT entry = BUYPT
        closed_signal_exit = not tm[
            (tm["symbol"] == "CRUDEOIL") &
            (tm["renko_signal"] == opp_entry_action) &
            (tm["order_status"] == "CLOSED") &
            (tm["close_reason"].str.upper().str.contains("SIGNAL_EXIT", na=False))
        ].empty
        assert closed_signal_exit, "Should detect same-cycle SIGNAL_EXIT"

    def test_stop_exit_does_not_trigger_same_cycle_block(self):
        """STOP_EXIT close should NOT trigger the same-cycle block."""
        import pandas as pd
        tm = self._make_closed_tm("CRUDEOIL", "PUT", "STOP_EXIT")
        opp_entry_action = "BUYPT"
        closed_signal_exit = not tm[
            (tm["symbol"] == "CRUDEOIL") &
            (tm["renko_signal"] == opp_entry_action) &
            (tm["order_status"] == "CLOSED") &
            (tm["close_reason"].str.upper().str.contains("SIGNAL_EXIT", na=False))
        ].empty
        assert not closed_signal_exit, "STOP_EXIT should not trigger same-cycle block"

    def test_mcx_grade_b_blocked_after_loss(self):
        """MCX Grade-B entry blocked if last trade was a loss."""
        import pandas as pd
        from tcos_bot.models.types import SignalGrade
        # PUT entered at 9164, exited at 9182 (loss of 18pts for PUT direction)
        tm = pd.DataFrame([{
            "symbol": "CRUDEOIL", "exchange": "MCX",
            "renko_signal": "BUYPT",
            "order_status": "CLOSED",
            "close_reason": "SIGNAL_EXIT",
            "entry_price": 9164.0,
            "close_price": 9182.0,  # price went UP = PUT loss
            "quantity": 100,
        }])
        _closed = tm[(tm["symbol"] == "CRUDEOIL") & (tm["order_status"] == "CLOSED")]
        _last = _closed.iloc[-1]
        _action = str(_last.get("renko_signal", ""))
        _cp = float(_last["close_price"])
        _ep = float(_last["entry_price"])
        _pnl = (_cp - _ep) if _action == "BUYCL" else (_ep - _cp)
        assert _pnl < 0, f"Should be a loss, got {_pnl}"
        # Grade-B would be blocked on MCX after this loss
        assert SignalGrade.B != SignalGrade.A, "Grade-B != Grade-A"

    def test_mcx_grade_a_not_blocked_after_loss(self):
        """MCX Grade-A entry allowed even after a loss (Grade-A = conviction)."""
        from tcos_bot.models.types import SignalGrade
        # Grade-A bypasses the MCX Grade-B loss block
        grade = SignalGrade.A
        is_blocked = grade != SignalGrade.A  # block only if NOT Grade-A
        assert not is_blocked, "Grade-A should not be blocked after a loss"

    def test_nse_grade_b_not_affected_by_mcx_block(self):
        """NSE instruments are not subject to MCX Grade-B loss block."""
        # _is_mcx check: NSE exchange → False → block does not apply
        exchange = "NSE_INDEX"
        _is_mcx = str(exchange).upper() in {"MCX", "MCX_FUT", "MCX_OPT"}
        assert not _is_mcx, "NSE should not be treated as MCX"
