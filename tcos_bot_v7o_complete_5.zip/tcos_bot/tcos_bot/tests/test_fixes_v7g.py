"""
test_fixes_v7g.py — Tests for fixes #1, #2, #4 and Solution B.

Written BEFORE implementation — all Fix #1/2/4/SolB tests must FAIL
on the current codebase and PASS after fixes are applied.

Fix #1:  risk_manager.py — structural stop min → max for CALL
Fix #2:  settings.py    — confirm_bricks 0.5 → 1.5
Fix #4:  settings.py    — NSE max_struct_stop_bricks_override = 5b
SolB:    engine.py      — stop trigger uses brick close, not LTP tick

Tests are grouped by fix. Each group is independent.
"""
import time
import threading
import pandas as pd
import numpy as np
import pytest
from unittest.mock import MagicMock, patch, PropertyMock


# ── helpers ──────────────────────────────────────────────────────────────────

def _make_renko_df(brick_close: float, brick_col: str = "Renko_Brick",
                   direction: int = 0) -> pd.DataFrame:
    """Minimal renko_df with one completed brick at brick_close.
    direction: +1 UP, -1 DOWN, 0 unknown (default=0 so direction guard is skipped).
    v7n: direction=0 (unknown) skips the direction guard → safe for legacy tests.
    """
    return pd.DataFrame({
        "timestamp":   ["2026-04-07 13:33:00"],
        brick_col:     [brick_close],
        "close":       [brick_close],
        "direction":   [direction],
    })


# ═══════════════════════════════════════════════════════════════════════════
# FIX #1 — structural stop: min → max  (risk_manager.py line 603)
# ═══════════════════════════════════════════════════════════════════════════

class TestFix1StructuralStop:
    """
    For a CALL trade:
      fixed_stop  = entry - 3b  (below entry)
      struct_stop = struct_low - 0.5b  (below entry)
    
    Correct behaviour (after fix):
      max(fixed_stop, struct_stop) → picks the HIGHER value = tighter stop
    
    If struct_low is FAR below entry → struct_stop is lower → fixed_stop wins.
    If struct_low is NEAR entry     → struct_stop is higher → struct_stop wins.
    """

    def _initialise_call(self, entry, struct_low, brick_size=12.0):
        from tcos_bot.risk.risk_manager import TrailingStopManager
        mgr = TrailingStopManager.__new__(TrailingStopManager)
        mgr._lock   = threading.Lock()
        mgr._stops  = {}
        mgr._cfg    = MagicMock()
        mgr._cfg.enabled              = True
        mgr._cfg.trail_distance       = 1.0
        mgr._cfg.breakeven_after      = 2.0
        mgr._cfg.trail_start_after    = 3.0
        mgr._cfg.adaptive_trail       = False
        mgr._cfg.confirmation_tighten = True

        with patch("tcos_bot.risk.risk_manager.cfg") as mock_cfg:
            mock_cfg.stop.initial_stop_bricks          = 3.0
            mock_cfg.stop.catastrophe_extra_bricks     = 1.5
            mock_cfg.stop.use_structural_stop          = True
            mock_cfg.stop.max_struct_stop_bricks       = 99.0
            mock_cfg.stop.max_struct_stop_bricks_override = {}
            mock_cfg.stop.confirmation_tighten         = True
            mock_cfg.stop.confirm_mins                 = 1.5
            mock_cfg.stop.confirm_mins_override        = {}
            mock_cfg.stop.confirm_bricks               = 0.5  # unchanged for this test
            mock_cfg.stop.tight_bricks                 = 1.5
            mock_cfg.stop.symbol_overrides             = {}
            stop = mgr.initialise(
                "NIFTY", "CALL", entry, brick_size,
                struct_low=struct_low,
            )
        return stop

    def _initialise_put(self, entry, struct_high, brick_size=12.0):
        from tcos_bot.risk.risk_manager import TrailingStopManager
        mgr = TrailingStopManager.__new__(TrailingStopManager)
        mgr._lock   = threading.Lock()
        mgr._stops  = {}
        mgr._cfg    = MagicMock()
        mgr._cfg.enabled              = True
        mgr._cfg.trail_distance       = 1.0
        mgr._cfg.breakeven_after      = 2.0
        mgr._cfg.trail_start_after    = 3.0
        mgr._cfg.adaptive_trail       = False
        mgr._cfg.confirmation_tighten = True

        with patch("tcos_bot.risk.risk_manager.cfg") as mock_cfg:
            mock_cfg.stop.initial_stop_bricks          = 3.0
            mock_cfg.stop.catastrophe_extra_bricks     = 1.5
            mock_cfg.stop.use_structural_stop          = True
            mock_cfg.stop.max_struct_stop_bricks       = 99.0
            mock_cfg.stop.max_struct_stop_bricks_override = {}
            mock_cfg.stop.confirmation_tighten         = True
            mock_cfg.stop.confirm_mins                 = 1.5
            mock_cfg.stop.confirm_mins_override        = {}
            mock_cfg.stop.confirm_bricks               = 0.5
            mock_cfg.stop.tight_bricks                 = 1.5
            mock_cfg.stop.symbol_overrides             = {}
            stop = mgr.initialise(
                "NIFTY", "PUT", entry, brick_size,
                struct_high=struct_high,
            )
        return stop

    def test_call_far_struct_low_uses_fixed_stop(self):
        """
        CALL: struct_low is 10.9b below entry (today's disaster scenario).
        After fix: max() picks fixed_stop (3b). Stop = entry - 3b.
        """
        entry      = 23033.0
        struct_low = 22908.0   # 125pts below = 10.4b
        bs         = 12.0
        stop = self._initialise_call(entry, struct_low, bs)
        expected_fixed = entry - 3.0 * bs   # 22997
        assert stop == pytest.approx(expected_fixed, abs=0.1), (
            f"Expected fixed_stop={expected_fixed}, got {stop}. "
            f"max() should pick fixed_stop when struct is wider."
        )

    def test_call_near_struct_low_tightens_stop(self):
        """
        CALL: struct_low is 2b below entry (nearby swing low).
        After fix: max() picks struct_stop because it's TIGHTER (higher).
        struct_stop = entry - 2b - 0.5b = entry - 2.5b
        fixed_stop  = entry - 3b
        max(entry-3b, entry-2.5b) = entry-2.5b → struct wins (tighter)
        """
        entry      = 23033.0
        struct_low = entry - 2 * 12   # 22, only 24pts below
        bs         = 12.0
        stop = self._initialise_call(entry, struct_low, bs)
        expected_struct = struct_low - 0.5 * bs   # entry-2b-6 = entry-30
        expected_fixed  = entry - 3.0 * bs         # entry-36
        # struct_stop is HIGHER (closer to entry) → should win
        assert stop == pytest.approx(expected_struct, abs=0.1), (
            f"Expected struct_stop={expected_struct} (tighter), got {stop}. "
            f"max() should pick struct_stop when it's tighter than fixed."
        )
        assert stop > expected_fixed, (
            "Struct stop should be TIGHTER (higher) than fixed stop"
        )

    def test_call_struct_low_at_exactly_3b(self):
        """
        CALL: struct_low exactly at 3b below entry.
        struct_stop = struct_low - 0.5b = entry - 3.5b (22991)
        fixed_stop  = entry - 3b           = 22997
        max(22997, 22991) = 22997 → fixed_stop wins (higher = tighter).
        """
        entry      = 23033.0
        bs         = 12.0
        struct_low = entry - 3.0 * bs   # exactly 3b below = 22997
        stop = self._initialise_call(entry, struct_low, bs)
        expected_fixed = entry - 3.0 * bs   # 22997 — fixed wins
        assert stop == pytest.approx(expected_fixed, abs=0.1), (
            f"struct_low at 3b → struct_stop is 3.5b, fixed is 3b. "
            f"max() picks fixed_stop={expected_fixed} (tighter). Got {stop}."
        )

    def test_put_branch_unchanged(self):
        """
        PUT branch already uses max() — this test must pass BEFORE and AFTER fix.
        PUT: struct_high FAR above entry → struct_stop is wider → fixed_stop wins.
        """
        entry       = 23033.0
        struct_high = 23400.0   # 367pts above = 30b — very far
        bs          = 12.0
        stop = self._initialise_put(entry, struct_high, bs)
        expected_fixed = entry + 3.0 * bs   # 23069
        # struct_stop = 23400 + 6 = 23406. That's WIDER (farther from entry).
        # max(fixed=23069, struct=23406) = 23406? Wait for PUT max() picks wider.
        # Actually for PUT: max(fixed, struct) picks the HIGHER = FARTHER from entry.
        # This is the EXISTING behaviour (already uses max for PUT).
        # Current code: stop = max(fixed_stop, struct_stop)
        # max(23069, 23406) = 23406 — struct wins for PUT.
        # BUT struct is capped at 99b — so no cap fires here.
        # For PUT the WIDER stop is actually what max() picks (above entry both values).
        # This test verifies PUT branch is not accidentally changed.
        assert stop > entry, "PUT stop must be ABOVE entry"

    def test_catst_always_worse_than_stop(self):
        """
        catst must always be beyond the stop (worse outcome).
        CALL: catst < stop (further below entry).
        """
        entry      = 23033.0
        struct_low = 22908.0   # far, fixed_stop should win
        bs         = 12.0
        from tcos_bot.risk.risk_manager import TrailingStopManager
        mgr = TrailingStopManager.__new__(TrailingStopManager)
        mgr._lock  = threading.Lock()
        mgr._stops = {}
        mgr._cfg   = MagicMock()
        mgr._cfg.enabled              = True
        mgr._cfg.trail_distance       = 1.0
        mgr._cfg.breakeven_after      = 2.0
        mgr._cfg.trail_start_after    = 3.0
        mgr._cfg.adaptive_trail       = False
        mgr._cfg.confirmation_tighten = True

        with patch("tcos_bot.risk.risk_manager.cfg") as mock_cfg:
            mock_cfg.stop.initial_stop_bricks          = 3.0
            mock_cfg.stop.catastrophe_extra_bricks     = 1.5
            mock_cfg.stop.use_structural_stop          = True
            mock_cfg.stop.max_struct_stop_bricks       = 99.0
            mock_cfg.stop.max_struct_stop_bricks_override = {}
            mock_cfg.stop.confirmation_tighten         = True
            mock_cfg.stop.confirm_mins                 = 1.5
            mock_cfg.stop.confirm_mins_override        = {}
            mock_cfg.stop.confirm_bricks               = 0.5
            mock_cfg.stop.tight_bricks                 = 1.5
            mock_cfg.stop.symbol_overrides             = {}
            stop = mgr.initialise(
                "NIFTY", "CALL", entry, bs, struct_low=struct_low
            )
            state = mgr._stops["NIFTY"]
            catst = state["catastrophe"]

        assert catst < stop, (
            f"catst={catst} must be BELOW stop={stop} for CALL "
            f"(catst is the last resort, must be worse than stop)"
        )
        assert stop - catst == pytest.approx(1.5 * bs, abs=0.1), (
            f"catst must be exactly catastrophe_extra_bricks={1.5} × bs={bs} "
            f"below stop. Expected gap={1.5*bs}, got {stop-catst}"
        )


# ═══════════════════════════════════════════════════════════════════════════
# FIX #2 — confirm_bricks 0.5 → 1.5  (settings.py)
# ═══════════════════════════════════════════════════════════════════════════

class TestFix2ConfirmBricks:
    """
    confirm_bricks threshold determines when a trade is 'confirmed':
      peak_profit >= confirm_bricks → confirmed, tighten disabled forever

    After fix: confirm_bricks = 1.5b (was 0.5b)
    A 9pt spike (0.75b) must NOT confirm a NIFTY trade.
    An 18pt move (1.5b) MUST confirm it.
    """

    def _make_state(self, direction="CALL", entry=23033.0, bs=12.0,
                    confirm_bricks=1.5, confirm_mins=1.5):
        """Build a minimal trailing stop state dict."""
        if direction == "CALL":
            tight_stop = entry - 1.5 * bs
        else:
            tight_stop = entry + 1.5 * bs
        return {
            "direction":         direction,
            "entry_price":       entry,
            "stop_price":        entry - 3.0 * bs if direction == "CALL" else entry + 3.0 * bs,
            "catastrophe":       entry - 4.5 * bs if direction == "CALL" else entry + 4.5 * bs,
            "peak_price":        entry,
            "brick_size":        bs,
            "trail_active":      False,
            "breakeven_reached": False,
            "confirm_tighten":   True,
            "confirm_mins":      confirm_mins,
            "confirm_bricks":    confirm_bricks,
            "tight_stop":        tight_stop,
            "confirmed":         False,
            "tightened":         False,
            "entry_time":        time.monotonic() - 120.0,  # 2 min ago
        }

    def _run_update(self, state, ltp, new_brick=None):
        """Call update() with patched state."""
        from tcos_bot.risk.risk_manager import TrailingStopManager
        mgr = TrailingStopManager.__new__(TrailingStopManager)
        mgr._lock  = threading.Lock()
        mgr._stops = {"NIFTY": state}
        mgr._cfg   = MagicMock()
        mgr._cfg.enabled           = True
        mgr._cfg.trail_distance    = 1.0
        mgr._cfg.breakeven_after   = 2.0
        mgr._cfg.trail_start_after = 3.0
        mgr._cfg.adaptive_trail    = False
        mgr._cfg.on_brick_confirm  = True

        with patch("tcos_bot.risk.risk_manager.cfg") as mock_cfg:
            mock_cfg.stop.breakeven_buffer       = 0.25
            mock_cfg.stop.trail_start_after      = 3.0
            mock_cfg.stop.trail_distance         = 1.0
            mock_cfg.stop.breakeven_after        = 2.0
            mock_cfg.stop.volatile_breakeven_after = 2.0
            mock_cfg.stop.adaptive_trail         = False
            mock_cfg.stop.fast_fail_enabled      = False
            mock_cfg.stop.tight_bricks           = 1.5
            mock_cfg.stop.retest_mode_enabled    = False
            mock_cfg.trailing                    = MagicMock()
            mock_cfg.trailing.trail_distance     = 1.0
            mock_cfg.trailing.breakeven_after    = 2.0
            mock_cfg.trailing.trail_start_after  = 3.0
            mock_cfg.trailing.adaptive_trail     = False
            return mgr.update("NIFTY", ltp, new_brick=new_brick)

    def test_1point5b_profit_confirms(self):
        """At 1.5b profit → state['confirmed'] = True, tighten skipped."""
        bs    = 12.0
        entry = 23033.0
        state = self._make_state(confirm_bricks=1.5, confirm_mins=1.5)
        # Set peak to 1.5b above entry (manually, as if LTP reached it)
        state["peak_price"] = entry + 1.5 * bs   # 23051
        ltp = entry + 1.5 * bs

        self._run_update(state, ltp)

        assert state["confirmed"] is True, (
            "Trade must be CONFIRMED when peak_profit >= 1.5b"
        )
        assert state["tightened"] is False, (
            "Tighten must NOT fire when trade is confirmed"
        )

    def test_0point8b_profit_does_not_confirm(self):
        """
        At 0.8b profit → NOT confirmed after confirm_mins expires.
        Tighten must fire (time expired, profit < 1.5b).
        """
        bs    = 12.0
        entry = 23033.0
        state = self._make_state(confirm_bricks=1.5, confirm_mins=1.5)
        state["entry_time"] = time.monotonic() - 200.0  # 3.3min ago, past confirm_mins
        state["peak_price"] = entry + 0.8 * bs   # 0.8b peak — not enough

        ltp = entry - 0.5 * bs  # currently underwater

        self._run_update(state, ltp)

        assert state["tightened"] is True, (
            "Tighten MUST fire when peak < 1.5b and confirm_mins expired"
        )
        assert state["confirmed"] is False, (
            "Trade must NOT be confirmed on 0.8b peak"
        )

    def test_0point5b_old_threshold_no_longer_confirms(self):
        """
        KEY TEST: 0.5b (old threshold) must NOT confirm with new 1.5b setting.
        This test catches regression — if confirm_bricks were still 0.5,
        a 0.5b peak would confirm and skip tighten. With 1.5b it must not.
        """
        bs    = 12.0
        entry = 23033.0
        state = self._make_state(confirm_bricks=1.5, confirm_mins=1.5)
        state["entry_time"] = time.monotonic() - 200.0  # time expired
        state["peak_price"] = entry + 0.5 * bs   # exactly old threshold

        self._run_update(state, entry)

        assert state["confirmed"] is False, (
            "0.5b peak must NOT confirm with new 1.5b confirm_bricks. "
            "If this fails, confirm_bricks was not raised to 1.5."
        )
        assert state["tightened"] is True, (
            "Tighten must fire: 0.5b peak < 1.5b threshold and time expired"
        )

    def test_config_value_is_1point5(self):
        """confirm_bricks in settings.py must equal 1.5 after fix."""
        from tcos_bot.config.settings import cfg
        assert cfg.stop.confirm_bricks == 1.5, (
            f"confirm_bricks should be 1.5, got {cfg.stop.confirm_bricks}. "
            f"Fix #2 not applied to settings.py."
        )

    def test_confirm_bricks_less_than_breakeven(self):
        """
        After fix: confirm(1.5b) < breakeven(2.0b).
        Ensures confirmation happens before breakeven — logical sequence.
        """
        from tcos_bot.config.settings import cfg
        assert cfg.stop.confirm_bricks < cfg.trailing.breakeven_after, (
            f"confirm_bricks({cfg.stop.confirm_bricks}) must be < "
            f"breakeven_after({cfg.trailing.breakeven_after})"
        )


# ═══════════════════════════════════════════════════════════════════════════
# FIX #4 — NSE max_struct_stop_bricks_override  (settings.py)
# ═══════════════════════════════════════════════════════════════════════════

class TestFix4StructCap:
    """
    NSE instruments must have max_struct_stop_bricks_override = 5.
    This caps the structural stop at 5b regardless of swing level distance.
    """

    def test_nifty_has_5b_cap_in_config(self):
        from tcos_bot.config.settings import cfg
        overrides = cfg.stop.max_struct_stop_bricks_override
        assert "NIFTY" in overrides, "NIFTY missing from max_struct_stop_bricks_override"
        assert overrides["NIFTY"] == 5.0, (
            f"NIFTY cap should be 5.0b, got {overrides['NIFTY']}"
        )

    def test_banknifty_has_5b_cap_in_config(self):
        from tcos_bot.config.settings import cfg
        overrides = cfg.stop.max_struct_stop_bricks_override
        assert "BANKNIFTY" in overrides, "BANKNIFTY missing from override"
        assert overrides["BANKNIFTY"] == 5.0

    def test_sensex_has_5b_cap_in_config(self):
        from tcos_bot.config.settings import cfg
        overrides = cfg.stop.max_struct_stop_bricks_override
        assert "SENSEX" in overrides, "SENSEX missing from override"
        assert overrides["SENSEX"] == 5.0

    def test_mcx_caps_unchanged(self):
        """MCX caps must not be touched by Fix #4."""
        from tcos_bot.config.settings import cfg
        overrides = cfg.stop.max_struct_stop_bricks_override
        assert overrides.get("CRUDEOIL") == 3.5, "CRUDEOIL cap must remain 3.5"
        assert overrides.get("GOLDM")    == 4.0, "GOLDM cap must remain 4.0"


# ═══════════════════════════════════════════════════════════════════════════
# SOLUTION B — brick-confirmed stop trigger  (engine.py)
# ═══════════════════════════════════════════════════════════════════════════

class TestSolutionBBrickStop:
    """
    Stop trigger (SELST/SELSP) must use latest Renko brick close,
    not raw LTP tick.

    KEY SCENARIOS:
      brick < stop AND ltp < stop → EXIT (genuine stop hit)
      brick > stop AND ltp < stop → NO EXIT (wick, brick not through stop)
      brick < stop AND ltp > stop → EXIT (brick confirmed, LTP recovered — still exit)
      latest_brick = None         → fallback to LTP (startup safety)
    """

    def _make_tm_with_stop(self, symbol, action, stop_price, qty=65):
        """Build a trade_manager DataFrame with one open stop row."""
        return pd.DataFrame([{
            "exchange":      "NSE_INDEX",
            "timestamp":     "2026-04-07 13:17:00",
            "symbol":        symbol,
            "renko_signal":  action,
            "entry_price":   stop_price,   # stop level stored in entry_price
            "quantity":      qty,
            "order_status":  "OPEN",
            "close_reason":  "",
            "option_symbol": f"{symbol}APR2622900CE",
            "brick_size_hint": 12.0,
            "signal_grade":  "B",
        }])

    def _make_engine(self, renko_df):
        """Build minimal engine with mocked dependencies."""
        from tcos_bot.core.engine import TradingEngine
        engine = TradingEngine.__new__(TradingEngine)
        engine._stop_event        = threading.Event()
        engine._tm_lock           = threading.Lock()
        engine._brick_sizes       = {"NIFTY": 12.0, "SENSEX": 50.0}
        from collections import defaultdict
        engine._last_order_time   = defaultdict(float)
        engine._ws_manager        = None
        engine._signal_gen        = MagicMock()
        engine._position_tracker  = MagicMock()

        mock_cache = MagicMock()
        mock_cache.get.return_value = renko_df
        engine._renko_cache = mock_cache
        engine._ohlc_cache  = mock_cache
        engine._client      = MagicMock()
        engine._order_router = MagicMock()
        engine._order_router.execute_order.return_value = (
            pd.DataFrame(), False
        )
        # Mock _resolve_option so it returns a valid trading symbol
        engine._resolve_option = MagicMock(
            return_value=("NIFTY13APR2622900CE", "NSE_INDEX", 350.0)
        )
        return engine

    def _run_stop_check(self, engine, tm, ltp_value, positions_df=None):
        """
        Run _execute_open_orders with mocked ltp and positions.
        Returns (tm_result, changed).
        """
        if positions_df is None:
            positions_df = pd.DataFrame()

        with patch("tcos_bot.core.engine.ltp_store") as mock_ltp, \
             patch("tcos_bot.core.engine.preflight_position_check") as mock_pf, \
             patch("tcos_bot.core.engine.risk_engine") as mock_re, \
             patch("tcos_bot.core.engine.cfg") as mock_cfg:

            mock_ltp.get.return_value = (ltp_value, 1.0)
            mock_pf.return_value = True
            mock_re.is_entry_allowed.return_value = (True, "")
            mock_cfg.broker.ltp_hard_block_secs = 30.0

            return engine._execute_open_orders(tm, positions_df)

    # ── SELST (CALL stop) ──────────────────────────────────────────────────

    def test_selst_brick_below_stop_exits(self):
        """
        SELST: brick close BELOW stop → genuine stop hit → EXIT must fire.
        Both brick and LTP confirm the stop is breached.
        """
        stop   = 22997.0
        brick  = 22980.0   # 17pts below stop — brick confirmed break
        ltp    = 22985.0   # also below stop

        renko_df = _make_renko_df(brick, direction=-1)  # v7n: DOWN brick for CALL stop
        engine   = self._make_engine(renko_df)
        tm       = self._make_tm_with_stop("NIFTY", "SELST", stop)

        tm_result, changed = self._run_stop_check(engine, tm, ltp)

        assert engine._order_router.execute_order.called, (
            "execute_order must be called when brick < stop (genuine stop hit). "
            "v7n: SELST (exit CALL) requires DOWN brick (direction=-1)."
        )

    def test_selst_wick_below_stop_no_exit(self):
        """
        THE KEY TEST — Solution B.
        SELST: LTP ticks below stop (wick) but brick CLOSED above stop.
        
        Today's SENSEX CALL: ltp=74253 < stop=74254 but brick=74270 > stop.
        With LTP-based check: EXIT fires (wrong).
        With brick-based check: NO EXIT (correct — wick, not a brick close).
        """
        stop  = 22997.0
        brick = 23004.0   # brick ABOVE stop — candle closed above stop
        ltp   = 22990.0   # LTP dipped below stop (wick)

        renko_df = _make_renko_df(brick)
        engine   = self._make_engine(renko_df)
        tm       = self._make_tm_with_stop("NIFTY", "SELST", stop)

        tm_result, changed = self._run_stop_check(engine, tm, ltp)

        assert not engine._order_router.execute_order.called, (
            "execute_order must NOT be called when brick > stop. "
            "LTP dipped below stop (wick) but brick closed above. "
            "This is Solution B — exit on brick close, not LTP tick."
        )

    def test_selst_brick_below_ltp_above_exits(self):
        """
        SELST: brick confirmed stop breach but LTP has since recovered above stop.
        Brick already confirmed the break → exit must still fire.
        """
        stop  = 22997.0
        brick = 22980.0   # brick confirmed the break
        ltp   = 23010.0   # LTP recovered, but brick already confirmed

        renko_df = _make_renko_df(brick, direction=-1)  # v7n: DOWN brick for CALL stop
        engine   = self._make_engine(renko_df)
        tm       = self._make_tm_with_stop("NIFTY", "SELST", stop)

        tm_result, changed = self._run_stop_check(engine, tm, ltp)

        assert engine._order_router.execute_order.called, (
            "execute_order must fire: DOWN brick < stop confirms the break "
            "even if LTP has since recovered. "
            "v7n: SELST (exit CALL) requires DOWN brick (direction=-1)."
        )

    def test_selst_no_renko_fallback_to_ltp(self):
        """
        SELST: renko_df is None (startup, Renko not loaded yet).
        Fallback to LTP check must fire if ltp < stop.
        """
        stop = 22997.0
        ltp  = 22980.0   # below stop

        engine = self._make_engine(renko_df=None)  # no Renko
        tm     = self._make_tm_with_stop("NIFTY", "SELST", stop)

        tm_result, changed = self._run_stop_check(engine, tm, ltp)

        assert engine._order_router.execute_order.called, (
            "Fallback to LTP must work when renko_df is None. "
            "ltp < stop → exit must fire."
        )

    # ── SELSP (PUT stop) ───────────────────────────────────────────────────

    def test_selsp_brick_above_stop_exits(self):
        """
        SELSP: brick close ABOVE stop → genuine PUT stop hit → EXIT.
        """
        stop  = 23069.0   # stop above entry for PUT
        brick = 23085.0   # brick confirmed breach
        ltp   = 23080.0   # also above stop

        renko_df = _make_renko_df(brick)
        engine   = self._make_engine(renko_df)
        tm       = self._make_tm_with_stop("NIFTY", "SELSP", stop)

        tm_result, changed = self._run_stop_check(engine, tm, ltp)

        assert engine._order_router.execute_order.called, (
            "execute_order must fire when brick > stop (PUT stop hit)"
        )

    def test_selsp_wick_above_stop_no_exit(self):
        """
        SELSP: LTP ticked above PUT stop (wick) but brick closed below stop.
        Solution B: NO EXIT.
        """
        stop  = 23069.0
        brick = 23055.0   # brick below stop — not through
        ltp   = 23075.0   # LTP spiked above stop (wick)

        renko_df = _make_renko_df(brick)
        engine   = self._make_engine(renko_df)
        tm       = self._make_tm_with_stop("NIFTY", "SELSP", stop)

        tm_result, changed = self._run_stop_check(engine, tm, ltp)

        assert not engine._order_router.execute_order.called, (
            "PUT wick above stop must NOT trigger exit. "
            "Brick closed BELOW stop — wick only."
        )

    def test_todays_sensex_call_scenario(self):
        """
        Recreate today's exact scenario:
        SENSEX CALL trailing stop = 74254.86
        LTP briefly = 74253.19 (1.67pts below stop — wick)
        Brick at that moment = 74270 (above stop — candle hadn't closed below)
        
        Expected: NO EXIT. Market continues to 74,600.
        """
        stop  = 74254.86
        brick = 74270.00   # brick was above stop
        ltp   = 74253.19   # 1.67pt wick below stop

        renko_df = _make_renko_df(brick, brick_col="Renko_Brick")
        engine   = self._make_engine(renko_df)
        engine._brick_sizes["SENSEX"] = 50.0
        tm = self._make_tm_with_stop("SENSEX", "SELST", stop, qty=20)
        tm.at[0, "exchange"] = "BSE_INDEX"
        tm.at[0, "brick_size_hint"] = 50.0

        tm_result, changed = self._run_stop_check(engine, tm, ltp)

        assert not engine._order_router.execute_order.called, (
            "Today's SENSEX CALL scenario: 1.67pt wick must NOT trigger exit. "
            "If this fails, Solution B is not implemented."
        )

    def test_selsp_no_renko_fallback_to_ltp(self):
        """SELSP: renko_df None → fallback to LTP. ltp > stop → exit."""
        stop = 23069.0
        ltp  = 23090.0   # above stop

        engine = self._make_engine(renko_df=None)
        tm     = self._make_tm_with_stop("NIFTY", "SELSP", stop)

        tm_result, changed = self._run_stop_check(engine, tm, ltp)

        assert engine._order_router.execute_order.called, (
            "PUT fallback: ltp > stop must trigger exit when renko is None"
        )
