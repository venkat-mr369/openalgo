"""
test_layer3_rr.py — Tests for Layer 3: RR threshold raised 1.5b → 2.5b.

Written BEFORE implementation. All tests must FAIL before config change
and PASS after.

Change: rr_min_room_bricks: 1.5 → 2.5

Audit findings:
  - April 7 winners all have room >> 2.5b → unaffected ✅
  - April 8 SENSEX 2.0b room → now BLOCKED (saves -69pt loss) ✅
  - April 8 BNF 5.0b room → still passes ✅
  - Brick-based threshold self-calibrates across instruments ✅
  - T13 in test_rr_gate.py needs updating (1.5b boundary → 2.5b)
"""
import pytest
from unittest.mock import patch


def _run_rr(signal, renko_df, brick_size=12.0, symbol="NIFTY"):
    """Run RR gate using actual config (not mocked threshold)."""
    from tcos_bot.filters.pipeline import FilterPipeline
    pipeline = FilterPipeline.__new__(FilterPipeline)
    return pipeline._check_rr_gate(symbol, signal, renko_df, brick_size)


def _make_renko(entry, bs, wall_above=None, floor_below=None, n_swings=6):
    """Build renko_df with controlled swing points."""
    import pandas as pd
    rows = []
    for i in range(10):
        price = entry - (10 - i) * bs
        rows.append({"Renko_Brick": price, "HH": False, "LH": False,
                     "HL": i % 2 == 0, "LL": i % 2 == 1,
                     "Last_High": entry + 3*bs, "Last_Low": entry - 10*bs,
                     "Colour_Brick_Count": 3, "zlema9": entry - 5*bs})
    extra = []
    if wall_above is not None:
        extra.append({"Renko_Brick": wall_above, "HH": False, "LH": True,
                      "HL": False, "LL": False, "Last_High": wall_above,
                      "Last_Low": entry - 3*bs, "Colour_Brick_Count": 3,
                      "zlema9": entry})
    if floor_below is not None:
        extra.append({"Renko_Brick": floor_below, "HH": False, "LH": False,
                      "HL": True, "LL": False, "Last_High": entry + 3*bs,
                      "Last_Low": floor_below, "Colour_Brick_Count": 3,
                      "zlema9": entry})
    entry_row = {"Renko_Brick": entry, "HH": False, "LH": False,
                 "HL": False, "LL": False, "Last_High": entry + 3*bs,
                 "Last_Low": entry - 3*bs, "Colour_Brick_Count": 3,
                 "zlema9": entry}
    import pandas as pd
    df = pd.DataFrame(rows + extra + [entry_row])
    return df.reset_index(drop=True)


# ═══════════════════════════════════════════════════════════════════════════
# T1: Config value must be 2.5 after Layer 3
# ═══════════════════════════════════════════════════════════════════════════
def test_t1_rr_min_room_config_is_2point5():
    """rr_min_room_bricks must be 2.5 after Layer 3."""
    from tcos_bot.config.settings import cfg
    assert cfg.signal_quality.rr_min_room_bricks == 2.5, (
        f"rr_min_room_bricks must be 2.5 after Layer 3. "
        f"Got: {cfg.signal_quality.rr_min_room_bricks}. "
        f"Was 1.5 — raised to filter marginal geometry."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T2: SENSEX 2.0b room → BLOCKED (was passing at 1.5b threshold)
# ═══════════════════════════════════════════════════════════════════════════
def test_t2_sensex_2b_room_now_blocked():
    """
    April 8 SENSEX: entry=77,250 wall=77,350 → room=2.0b.
    Was PASSING at old threshold=1.5b.
    Must be BLOCKED at new threshold=2.5b.
    This is the trade that lost -69pts today.
    """
    entry = 77250.0
    bs    = 50.0
    wall  = 77350.0   # 2.0b above entry

    renko = _make_renko(entry, bs, wall_above=wall)
    result = _run_rr("BUYEN", renko, brick_size=bs, symbol="SENSEX")

    assert not result.allowed, (
        f"SENSEX with room=2.0b must be BLOCKED at threshold=2.5b. "
        f"Today's -69pt loss had exactly this geometry. "
        f"Got: allowed={result.allowed}, reason={result.reason}"
    )


# ═══════════════════════════════════════════════════════════════════════════
# T3: SENSEX 3.0b room → PASSES
# ═══════════════════════════════════════════════════════════════════════════
def test_t3_sensex_3b_room_passes():
    """SENSEX with room=3.0b (150pts) must pass the raised threshold."""
    entry = 77250.0
    bs    = 50.0
    wall  = 77400.0   # 3.0b = 150pts

    renko = _make_renko(entry, bs, wall_above=wall)
    result = _run_rr("BUYEN", renko, brick_size=bs, symbol="SENSEX")

    assert result.allowed, (
        f"SENSEX with room=3.0b must PASS threshold=2.5b. "
        f"Got: {result.reason}"
    )


# ═══════════════════════════════════════════════════════════════════════════
# T4: BANKNIFTY 5.0b room → still passes (today's BNF unaffected)
# ═══════════════════════════════════════════════════════════════════════════
def test_t4_banknifty_5b_room_passes():
    """
    Today's BANKNIFTY had room=5.0b wall=55200 entry=55000.
    Must still pass at threshold=2.5b.
    """
    entry = 55000.0
    bs    = 40.0
    wall  = 55200.0   # 5.0b above entry

    renko = _make_renko(entry, bs, wall_above=wall)
    result = _run_rr("BUYEN", renko, brick_size=bs, symbol="BANKNIFTY")

    assert result.allowed, (
        f"BNF room=5.0b must PASS at threshold=2.5b. Got: {result.reason}"
    )


# ═══════════════════════════════════════════════════════════════════════════
# T5: April 7 SENSEX CALL +228pts (11b room) → still passes
# ═══════════════════════════════════════════════════════════════════════════
def test_t5_april7_sensex_call_winner_still_passes():
    """April 7 SENSEX CALL +228pts had room=11b. Must pass at 2.5b."""
    entry = 74052.0
    bs    = 50.0
    wall  = 74600.0   # 10.96b ≈ 11b

    renko = _make_renko(entry, bs, wall_above=wall)
    result = _run_rr("BUYEN", renko, brick_size=bs, symbol="SENSEX")

    assert result.allowed, (
        f"April 7 SENSEX CALL winner (room=11b) must still pass. Got: {result.reason}"
    )


# ═══════════════════════════════════════════════════════════════════════════
# T6: NIFTY 2.4b room → BLOCKED (just below new threshold)
# ═══════════════════════════════════════════════════════════════════════════
def test_t6_nifty_2point4b_room_blocked():
    """NIFTY with room=2.4b is below 2.5b threshold → BLOCKED."""
    entry = 23033.0
    bs    = 12.0
    wall  = entry + 2.4 * bs   # 28.8pts above entry

    renko = _make_renko(entry, bs, wall_above=wall)
    result = _run_rr("BUYEN", renko, brick_size=bs, symbol="NIFTY")

    assert not result.allowed, (
        f"NIFTY room=2.4b must be BLOCKED at threshold=2.5b."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T7: Exact threshold 2.5b → PASSES (boundary condition)
# ═══════════════════════════════════════════════════════════════════════════
def test_t7_exactly_2point5b_passes():
    """Wall at exactly 2.5b must PASS (>= comparison)."""
    entry = 23033.0
    bs    = 12.0
    wall  = entry + 2.5 * bs   # exactly 30pts

    renko = _make_renko(entry, bs, wall_above=wall)
    result = _run_rr("BUYEN", renko, brick_size=bs, symbol="NIFTY")

    assert result.allowed, (
        f"Room=2.5b (exactly threshold) must PASS. Got: {result.reason}"
    )
