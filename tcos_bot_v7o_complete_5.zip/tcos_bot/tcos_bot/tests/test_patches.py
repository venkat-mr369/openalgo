"""
test_patches.py — Self-contained regression tests for all four patches.
Run from repo root:  python tcos_bot_patches/test_patches.py

No external dependencies beyond the patched files.
Mocks are written inline so these tests work in CI without a broker connection.
"""
import sys, time, threading, types, unittest
from unittest.mock import MagicMock, patch, PropertyMock
import pandas as pd

# ─────────────────────────────────────────────────────────────────────────────
# HELPERS: minimal stubs so imports resolve without broker/DB
# ─────────────────────────────────────────────────────────────────────────────
def _stub_module(name):
    m = types.ModuleType(name)
    sys.modules[name] = m
    return m

# Stub ltp_store for ws_manager tests
_ltp_mod = _stub_module("tcos_bot.data.ltp_store")
class _FakeLTPStore:
    def update(self, *a, **k): pass
    def get(self, sym): return (100.0, 0.5)
    def stale_symbols(self, t=None): return []
    def health_report(self): return {"total": 1, "healthy": 1, "stale": 0}
_ltp_mod.ltp_store = _FakeLTPStore()

# Stub trade_store for chop_checker
_ts_mod = _stub_module("tcos_bot.data.trade_store")
_fake_tm = pd.DataFrame()
class _FakeTradeStore:
    def read_df(self): return _fake_tm.copy()
_ts_mod.trade_store = _FakeTradeStore()

# Real config import
sys.path.insert(0, "tcos_bot_patches")   # patches take priority
sys.path.insert(1, ".")

from tcos_bot.config.settings import cfg, WebSocketConfig, WhipsawConfig, ChopOscillationConfig

# ─────────────────────────────────────────────────────────────────────────────
# TEST SUITE A+B: WebSocketManager
# ─────────────────────────────────────────────────────────────────────────────
class TestWebSocketStaleDetection(unittest.TestCase):

    def _make_wsm(self):
        from tcos_bot.core.ws_manager import WebSocketManager
        client = MagicMock()
        client.connect.return_value = None
        client.disconnect.return_value = None
        wsm = WebSocketManager(client)
        # Seed last_tick as very old so feed is immediately stale
        wsm._last_tick_mono = time.monotonic() - 9999
        wsm._feed_healthy.clear()
        return wsm

    def test_feed_healthy_on_fresh_tick(self):
        """A tick must immediately restore feed health."""
        wsm = self._make_wsm()
        self.assertFalse(wsm.is_feed_healthy(), "should start unhealthy")
        wsm._on_quote({"symbol": "NIFTY", "data": {"ltp": 22000}})
        self.assertTrue(wsm.is_feed_healthy(), "should be healthy after tick")

    def test_feed_age_increases_without_ticks(self):
        """feed_age_secs must grow monotonically between ticks."""
        from tcos_bot.core.ws_manager import WebSocketManager
        client = MagicMock()
        wsm = WebSocketManager(client)
        wsm._on_quote({"symbol": "NIFTY", "data": {"ltp": 22000}})
        age1 = wsm.feed_age_secs()
        time.sleep(0.05)
        age2 = wsm.feed_age_secs()
        self.assertGreater(age2, age1)

    def test_reconnect_needed_breaks_connected_loop(self):
        """_ws_connected_loop must return when _reconnect_needed is set."""
        from tcos_bot.core.ws_manager import WebSocketManager
        client = MagicMock()
        wsm = WebSocketManager(client)

        loop_returned = threading.Event()
        def run_loop():
            wsm._ws_connected_loop()
            loop_returned.set()

        # Pre-set the flag so the loop sees it on its very first iteration.
        # (Setting it mid-sleep would need a 6s timeout to cover the 5s poll interval.)
        wsm._reconnect_needed.set()
        t = threading.Thread(target=run_loop, daemon=True)
        t.start()
        loop_returned.wait(timeout=2.0)   # pre-set flag → breaks immediately (<1s)
        self.assertTrue(loop_returned.is_set(),
                        "_ws_connected_loop did not break on reconnect_needed")

    def test_single_flight_reconnect(self):
        """Concurrent _trigger_reconnect calls must only produce 1 reconnect."""
        from tcos_bot.core.ws_manager import WebSocketManager
        client = MagicMock()
        wsm = WebSocketManager(client)
        wsm._last_tick_mono = time.monotonic() - 9999  # stale

        # Slow down disconnect so the second call arrives while first is running
        barrier = threading.Barrier(2)
        original_trigger = wsm._trigger_reconnect.__func__ if hasattr(wsm._trigger_reconnect, '__func__') else None

        disconnect_count = [0]
        def slow_disconnect():
            disconnect_count[0] += 1
            time.sleep(0.05)
        client.disconnect.side_effect = slow_disconnect

        symbols_df = pd.DataFrame([{"symbol": "NIFTY", "exchange": "NSE_INDEX"}])
        threads = [
            threading.Thread(target=wsm._trigger_reconnect, args=(symbols_df,))
            for _ in range(3)
        ]
        for t in threads: t.start()
        for t in threads: t.join(timeout=2.0)

        # At most 1 disconnect should have been called (single-flight)
        self.assertLessEqual(disconnect_count[0], 1,
                             f"disconnect called {disconnect_count[0]} times — single-flight violated")

    def test_stale_blocks_new_entries(self):
        """is_feed_healthy() must return False when feed is stale."""
        from tcos_bot.core.ws_manager import WebSocketManager
        client = MagicMock()
        wsm = WebSocketManager(client)
        wsm._feed_healthy.clear()   # simulate stale
        self.assertFalse(wsm.is_feed_healthy())

    def test_healthy_feed_allows_entries(self):
        """is_feed_healthy() must return True after ticks flow."""
        from tcos_bot.core.ws_manager import WebSocketManager
        client = MagicMock()
        wsm = WebSocketManager(client)
        wsm._feed_healthy.set()
        self.assertTrue(wsm.is_feed_healthy())


# ─────────────────────────────────────────────────────────────────────────────
# TEST SUITE C: AdaptiveWhipsawManager
# ─────────────────────────────────────────────────────────────────────────────
class TestAdaptiveWhipsawManager(unittest.TestCase):

    def setUp(self):
        from tcos_bot.risk.whipsaw_manager import AdaptiveWhipsawManager
        self.mgr = AdaptiveWhipsawManager()

    def test_no_cooldown_by_default(self):
        """Fresh symbol should have no cooldown."""
        allowed, reason = self.mgr.is_entry_allowed("NIFTY", "TRENDING")
        self.assertTrue(allowed)

    def test_false_chop_cooldown_is_short(self):
        """CHOP_OSCILLATION_EXIT in trending should produce short cooldown."""
        self.mgr.record_flip("NIFTY", "CHOP_OSCILLATION_EXIT", "TRENDING")
        # revenge_guard_secs=60 floors the duration
        # false_chop_cooldown × trending_mult = 90 × 0.5 = 45 → clamped to 60
        allowed, reason = self.mgr.is_entry_allowed("NIFTY", "TRENDING")
        self.assertFalse(allowed, "should be in cooldown immediately after flip")
        info = self.mgr.cooldown_info("NIFTY")
        self.assertIsNotNone(info)
        self.assertLessEqual(info["remaining_secs"], 60 + 1)   # ≤ revenge_guard

    def test_repeat_whipsaw_cooldown_is_long(self):
        """3rd flip in volatile regime should get maximum cooldown."""
        for _ in range(3):
            self.mgr.record_flip("BNIFTY", "STOPLOSS", "VOLATILE")
        info = self.mgr.cooldown_info("BNIFTY")
        self.assertIsNotNone(info)
        # repeat_whipsaw_cooldown(1800) × volatile(2.0) = 3600 → clamped to max(2700)
        self.assertAlmostEqual(info["remaining_secs"], 2700, delta=5)

    def test_momentum_auto_clear(self):
        """8 consecutive same-direction bricks should clear cooldown."""
        self.mgr.record_flip("GOLD", "STOPLOSS", "SIDEWAYS")
        allowed_before, _ = self.mgr.is_entry_allowed("GOLD", "SIDEWAYS")
        self.assertFalse(allowed_before)

        for _ in range(8):   # momentum_clear_bricks=8
            self.mgr.on_brick("GOLD", "UP")

        allowed_after, _ = self.mgr.is_entry_allowed("GOLD", "SIDEWAYS")
        self.assertTrue(allowed_after, "cooldown should be cleared after 8 bricks")

    def test_mixed_bricks_do_not_clear(self):
        """Alternating bricks should NOT trigger momentum clear."""
        self.mgr.record_flip("CRUDE", "STOPLOSS", "SIDEWAYS")
        for i in range(10):
            self.mgr.on_brick("CRUDE", "UP" if i % 2 == 0 else "DOWN")
        allowed, _ = self.mgr.is_entry_allowed("CRUDE", "SIDEWAYS")
        self.assertFalse(allowed, "alternating bricks should not clear cooldown")

    def test_manual_clear(self):
        """Manual clear must immediately allow entry."""
        self.mgr.record_flip("SENSEX", "STOPLOSS", "VOLATILE")
        self.mgr.clear("SENSEX")
        allowed, _ = self.mgr.is_entry_allowed("SENSEX", "VOLATILE")
        self.assertTrue(allowed)

    def test_trending_multiplier_halves_duration(self):
        """Trending regime should produce shorter cooldown than unknown regime."""
        from tcos_bot.risk.whipsaw_manager import AdaptiveWhipsawManager
        m1 = AdaptiveWhipsawManager()
        m2 = AdaptiveWhipsawManager()
        m1.record_flip("X", "STOPLOSS", "TRENDING")
        m2.record_flip("X", "STOPLOSS", "UNKNOWN")
        info1 = m1.cooldown_info("X")
        info2 = m2.cooldown_info("X")
        self.assertLess(info1["remaining_secs"], info2["remaining_secs"],
                        "trending cooldown should be shorter than unknown")

    def test_adaptive_disabled_uses_flat_cooldown(self):
        """When adaptive_enabled=False, legacy cooldown_mins should be used."""
        import dataclasses
        from tcos_bot.config import settings as _s
        old_cfg = _s.cfg.whipsaw
        new_wc = dataclasses.replace(old_cfg, adaptive_enabled=False, cooldown_mins=1)
        from tcos_bot.risk import whipsaw_manager as _wm
        old_wc = _wm._CFG
        _wm._CFG = new_wc
        try:
            from tcos_bot.risk.whipsaw_manager import AdaptiveWhipsawManager
            mgr = AdaptiveWhipsawManager()
            mgr._cfg = new_wc
            mgr.record_flip("FLAT", "STOPLOSS", "TRENDING")
            info = mgr.cooldown_info("FLAT")
            self.assertIsNotNone(info)
            # Should be ~60s (1 min × 60), clamped to revenge_guard=60
            self.assertAlmostEqual(info["remaining_secs"], 60, delta=5)
        finally:
            _wm._CFG = old_wc


# ─────────────────────────────────────────────────────────────────────────────
# TEST SUITE D: ChopOscillationChecker
# ─────────────────────────────────────────────────────────────────────────────
class TestChopOscillationChecker(unittest.TestCase):

    def _make_checker(self):
        from tcos_bot.risk.chop_checker import ChopOscillationChecker
        return ChopOscillationChecker()

    def _make_tm(self, symbol="NIFTY", action="BUYCL", regime="SIDEWAYS"):
        """Return a minimal trade_manager DataFrame with one INPOSITION row."""
        import datetime
        from tcos_bot.config.settings import IST
        fill_ts = (datetime.datetime.now(tz=IST)).isoformat()
        return pd.DataFrame([{
            "symbol":       symbol,
            "exchange":     "NSE_INDEX",
            "renko_signal": action,
            "order_status": "INPOSITION",
            "entry_price":  22000.0,
            "index_ltp":    22000.0,
            "fill_timestamp": fill_ts,
            "day_regime":   regime,
            "option_symbol": f"{symbol}APR22000CE",
            "quantity":     1,
            "brick_size_hint": 50.0,
        }])

    def test_no_exit_before_min_hold(self):
        """Chop exit must be blocked before min_hold_secs elapses."""
        chk = self._make_checker()
        tm  = self._make_tm()
        # Simulate 3 fast reversals
        ltp = 22000.0
        for _ in range(6):
            ltp = 22050.0 if ltp < 22050 else 21950.0
            tm, changed = chk.check_and_annotate(tm, "NIFTY", "NSE_INDEX", ltp, 50.0)
        self.assertFalse(changed, "should not exit before min_hold_secs=180s")
        # Position should still be INPOSITION
        self.assertEqual(tm.iloc[0]["order_status"], "INPOSITION")

    def test_no_exit_in_trending_regime(self):
        """Chop exit must be suppressed in TRENDING regime."""
        chk = self._make_checker()
        tm  = self._make_tm(regime="TRENDING")
        # Manually set entry time far in the past (so min_hold_secs passes)
        chk._state["NIFTY"] = chk._state.get("NIFTY") or __import__(
            'tcos_bot.risk.chop_checker', fromlist=['_ChopState']
        )._ChopState(
            entry_time=time.monotonic() - 300,
            entry_price=22000.0,
            entry_brick_count=0,
        )
        # Force bricks threshold satisfied
        renko_df = pd.DataFrame([{"close": 22000} for _ in range(5)])
        ltp = 22000.0
        for _ in range(8):
            ltp = 22050.0 if ltp < 22050 else 21950.0
            tm, changed = chk.check_and_annotate(
                tm, "NIFTY", "NSE_INDEX", ltp, 50.0, renko_df=renko_df
            )
        self.assertFalse(changed, "TRENDING regime should suppress chop exit")

    def test_momentum_decay_gate_blocks_exit(self):
        """Strong momentum should block chop exit."""
        chk = self._make_checker()
        tm  = self._make_tm(regime="SIDEWAYS")
        from tcos_bot.risk.chop_checker import _ChopState
        chk._state["NIFTY"] = _ChopState(
            entry_time=time.monotonic() - 300,
            entry_price=22000.0,
            entry_brick_count=0,
        )
        # Renko with strong bullish momentum (Colour_Brick_Count = +4)
        renko_df = pd.DataFrame(
            [{"close": 22000 + i*50, "Colour_Brick_Count": 4} for i in range(6)]
        )
        ltp = 22000.0
        for _ in range(8):
            ltp = 22050.0 if ltp < 22050 else 21950.0
            tm, changed = chk.check_and_annotate(
                tm, "NIFTY", "NSE_INDEX", ltp, 50.0, renko_df=renko_df
            )
        self.assertFalse(changed, "strong momentum should suppress chop exit")

    def test_clear_state_removes_symbol(self):
        """clear_state must remove symbol from internal dict."""
        chk = self._make_checker()
        from tcos_bot.risk.chop_checker import _ChopState
        chk._state["NIFTY"] = _ChopState(
            entry_time=time.monotonic(), entry_price=22000.0, entry_brick_count=0
        )
        chk.clear_state("NIFTY")
        self.assertNotIn("NIFTY", chk._state)

    def test_adverse_excursion_blocks_exit(self):
        """Large adverse move should block chop exit (use stop-loss instead)."""
        chk = self._make_checker()
        from tcos_bot.risk.chop_checker import _ChopState
        chk._state["NIFTY"] = _ChopState(
            entry_time=time.monotonic() - 300,
            entry_price=22000.0,
            entry_brick_count=0,
        )
        renko_df = pd.DataFrame([{"close": 22000 - i*50} for i in range(6)])
        # LTP has moved 3 bricks against CALL entry → stop-loss territory
        ltp = 22000.0 - 3 * 50 - 10   # > adverse_excursion_bricks=0.75 × bs=50
        tm = self._make_tm(regime="SIDEWAYS")
        for _ in range(8):
            tm, changed = chk.check_and_annotate(
                tm, "NIFTY", "NSE_INDEX", ltp, 50.0, renko_df=renko_df
            )
        self.assertFalse(changed, "large adverse excursion should block chop exit")


# ─────────────────────────────────────────────────────────────────────────────
# TEST SUITE CONFIG: new fields present and defaulted correctly
# ─────────────────────────────────────────────────────────────────────────────
class TestConfigNewFields(unittest.TestCase):

    def test_websocket_config_present(self):
        self.assertTrue(hasattr(cfg, "websocket"))
        self.assertIsInstance(cfg.websocket, WebSocketConfig)

    def test_websocket_defaults(self):
        wsc = cfg.websocket
        self.assertEqual(wsc.stale_threshold_secs, 30.0)
        self.assertEqual(wsc.reconnect_max_attempts, 20)
        self.assertEqual(wsc.watchdog_interval_secs, 5.0)
        self.assertEqual(wsc.in_position_stale_action, "LOG_ONLY")

    def test_whipsaw_new_fields(self):
        wc = cfg.whipsaw
        self.assertTrue(wc.adaptive_enabled)
        self.assertEqual(wc.base_cooldown_secs, 120)
        self.assertEqual(wc.false_chop_cooldown_secs, 90)
        self.assertEqual(wc.whipsaw_cooldown_secs, 600)
        self.assertEqual(wc.repeat_whipsaw_cooldown_secs, 1800)
        self.assertEqual(wc.max_cooldown_secs, 2700)
        self.assertEqual(wc.revenge_guard_secs, 60)
        self.assertEqual(wc.trending_multiplier, 0.5)
        self.assertEqual(wc.volatile_multiplier, 2.0)
        self.assertEqual(wc.sideways_multiplier, 1.5)

    def test_chop_oscillation_new_fields(self):
        cc = cfg.chop_oscillation
        self.assertEqual(cc.min_hold_secs, 180)
        self.assertEqual(cc.min_hold_bars, 3)
        self.assertEqual(cc.adverse_excursion_bricks, 0.75)
        self.assertTrue(cc.require_momentum_decay)
        self.assertTrue(cc.regime_filter_enabled)
        self.assertTrue(cc.two_stage_required)
        self.assertEqual(cc.confirmation_window_secs, 30)

    def test_original_chop_fields_unchanged(self):
        """Existing fields must retain their original values."""
        cc = cfg.chop_oscillation
        self.assertTrue(cc.enabled)
        self.assertEqual(cc.reversals_max, 3)
        self.assertEqual(cc.range_bricks, 1.0)
        self.assertEqual(cc.window_secs, 120)

    def test_original_whipsaw_fields_unchanged(self):
        wc = cfg.whipsaw
        self.assertTrue(wc.enabled)
        self.assertEqual(wc.max_flips, 2)
        self.assertEqual(wc.flip_window_mins, 30)
        self.assertEqual(wc.cooldown_mins, 45)   # legacy field preserved
        self.assertEqual(wc.momentum_clear_bricks, 8)

    def test_mcx_low_conf_exempt_exchanges_present(self):
        """MCX-BUG-1: low_conf_exempt_exchanges must be present with MCX."""
        sq = cfg.signal_quality
        self.assertTrue(
            hasattr(sq, "low_conf_exempt_exchanges"),
            "low_conf_exempt_exchanges field missing from SignalQualityConfig",
        )
        self.assertIn("MCX", sq.low_conf_exempt_exchanges)

    def test_mcx_low_conf_exempt_does_not_affect_nse(self):
        """MCX-BUG-1: NSE/NFO must NOT be in the exempt list."""
        sq = cfg.signal_quality
        exempt = getattr(sq, "low_conf_exempt_exchanges", ())
        for exch in ("NSE_INDEX", "BSE_INDEX", "NFO", "BFO"):
            self.assertNotIn(
                exch, exempt,
                f"{exch} must not be exempt — conf gate must apply to equity instruments",
            )


# ─────────────────────────────────────────────────────────────────────────────
# TEST SUITE MCX: option resolver MCX symtoken query (MCX-BUG-2)
# ─────────────────────────────────────────────────────────────────────────────

class TestMCXOptionResolver(unittest.TestCase):
    """MCX-BUG-2: _query_symtoken uses symbol suffix for MCX, not instrumenttype."""

    def _make_db(self, tmp_path: str) -> str:
        import sqlite3, os
        from datetime import datetime, timedelta
        db_dir = os.path.join(tmp_path, "db")
        os.makedirs(db_dir, exist_ok=True)
        db_path = os.path.join(db_dir, "openalgo.db")
        future = (datetime.now() + timedelta(days=45)).strftime("%d-%b-%y")
        con = sqlite3.connect(db_path)
        con.execute(
            """CREATE TABLE symtoken (
                symbol TEXT, exchange TEXT, instrumenttype TEXT,
                expiry TEXT, strike REAL, lotsize INTEGER
            )"""
        )
        con.executemany("INSERT INTO symtoken VALUES (?,?,?,?,?,?)", [
            # MCX-style: instrumenttype=OPTFUT, CE/PE in symbol name
            ("GOLDM26MAY57500CE",     "MCX", "OPTFUT", future, 57500,  10),
            ("GOLDM26MAY58000CE",     "MCX", "OPTFUT", future, 58000,  10),
            ("GOLDM26MAY57500PE",     "MCX", "OPTFUT", future, 57500,  10),
            ("SILVERM26MAY95000CE",   "MCX", "OPTFUT", future, 95000,   5),
            ("SILVERM26MAY95000PE",   "MCX", "OPTFUT", future, 95000,   5),
            ("NATURALGAS26MAY280CE",  "MCX", "OPTFUT", future,   280, 1250),
            ("NATURALGAS26MAY280PE",  "MCX", "OPTFUT", future,   280, 1250),
            # NSE-style: instrumenttype=CE/PE (must remain unchanged)
            ("NIFTY26MAY23200CE",     "NFO", "CE",     future, 23200,  75),
            ("NIFTY26MAY23200PE",     "NFO", "PE",     future, 23200,  75),
        ])
        con.commit()
        con.close()
        return db_path

    def setUp(self):
        import tempfile
        self._tmpdir = tempfile.mkdtemp()
        self._db_path = self._make_db(self._tmpdir)

    def _resolver(self):
        import tcos_bot.execution.option_resolver as orm
        original = orm._openalgo_db_path
        orm._openalgo_db_path = lambda: self._db_path
        r = orm.OptionResolver(client=None)
        orm._openalgo_db_path = original
        # Patch on the instance so all internal calls use the test DB
        r.__class__._db_path_override = self._db_path
        import tcos_bot.execution.option_resolver as orm2
        orm2._openalgo_db_path = lambda: self._db_path
        return r

    def test_mcx_call_resolved_by_symbol_suffix(self):
        """MCX-BUG-2: GOLDM CE resolves correctly via symbol suffix."""
        import tcos_bot.execution.option_resolver as orm
        orm._openalgo_db_path = lambda: self._db_path
        r = orm.OptionResolver(client=None)
        result = r._query_symtoken("MCX", "GOLDM", "CE", 57800)
        self.assertIsNotNone(result, "GOLDM CE must resolve on MCX")
        self.assertTrue(result.startswith("GOLDM"), f"Expected GOLDM*, got {result}")
        self.assertTrue(result.upper().endswith("CE"), f"Expected *CE, got {result}")

    def test_mcx_put_resolved_by_symbol_suffix(self):
        """MCX-BUG-2: GOLDM PE resolves correctly."""
        import tcos_bot.execution.option_resolver as orm
        orm._openalgo_db_path = lambda: self._db_path
        r = orm.OptionResolver(client=None)
        result = r._query_symtoken("MCX", "GOLDM", "PE", 57800)
        self.assertIsNotNone(result, "GOLDM PE must resolve on MCX")
        self.assertTrue(result.upper().endswith("PE"))

    def test_mcx_silverm_resolved(self):
        """MCX-BUG-2: SILVERM CE resolves correctly."""
        import tcos_bot.execution.option_resolver as orm
        orm._openalgo_db_path = lambda: self._db_path
        r = orm.OptionResolver(client=None)
        result = r._query_symtoken("MCX", "SILVERM", "CE", 95100)
        self.assertIsNotNone(result, "SILVERM CE must resolve on MCX")

    def test_mcx_naturalgas_resolved(self):
        """MCX-BUG-2: NATURALGAS CE and PE resolve correctly."""
        import tcos_bot.execution.option_resolver as orm
        orm._openalgo_db_path = lambda: self._db_path
        r = orm.OptionResolver(client=None)
        ce = r._query_symtoken("MCX", "NATURALGAS", "CE", 278)
        pe = r._query_symtoken("MCX", "NATURALGAS", "PE", 278)
        self.assertIsNotNone(ce, "NATURALGAS CE must resolve")
        self.assertIsNotNone(pe, "NATURALGAS PE must resolve")

    def test_nfo_nifty_unchanged(self):
        """MCX-BUG-2: NFO instruments still use instrumenttype='CE'/'PE' path."""
        import tcos_bot.execution.option_resolver as orm
        orm._openalgo_db_path = lambda: self._db_path
        r = orm.OptionResolver(client=None)
        ce = r._query_symtoken("NFO", "NIFTY", "CE", 23150)
        pe = r._query_symtoken("NFO", "NIFTY", "PE", 23150)
        self.assertIsNotNone(ce, "NIFTY CE on NFO must resolve via instrumenttype=CE")
        self.assertIsNotNone(pe, "NIFTY PE on NFO must resolve via instrumenttype=PE")

    def test_mcx_wrong_suffix_returns_none(self):
        """MCX-BUG-2: Symbol not in DB returns None (no cross-contamination)."""
        import tcos_bot.execution.option_resolver as orm
        orm._openalgo_db_path = lambda: self._db_path
        r = orm.OptionResolver(client=None)
        # COPPER is not in the test DB at all — must return None gracefully
        result = r._query_symtoken("MCX", "COPPER", "CE", 850)
        self.assertIsNone(result, "COPPER CE not in DB — must return None")


if __name__ == "__main__":
    loader  = unittest.TestLoader()
    suite   = unittest.TestSuite()
    for cls in [
        TestWebSocketStaleDetection,
        TestAdaptiveWhipsawManager,
        TestChopOscillationChecker,
        TestConfigNewFields,
        TestMCXOptionResolver,
    ]:
        suite.addTests(loader.loadTestsFromTestCase(cls))
    runner = unittest.TextTestRunner(verbosity=2)
    result = runner.run(suite)
    sys.exit(0 if result.wasSuccessful() else 1)



# ─────────────────────────────────────────────────────────────────────────────
# TEST SUITE MCX-BUGS: close confirm exempt, struct stop cap, drift override
# ─────────────────────────────────────────────────────────────────────────────

class TestMCXBugFixes(unittest.TestCase):
    """MCX-BUG-1,2,3: Close confirm exempt, struct stop cap, drift override."""

    # ── MCX-BUG-1: Close confirmation exemption ───────────────────────────────

    def test_mcx_close_confirm_exempt_in_config(self):
        """MCX-BUG-1: MCX must be in require_close_confirmation_exempt_exchanges."""
        e = cfg.entry
        self.assertTrue(
            hasattr(e, "require_close_confirmation_exempt_exchanges"),
            "require_close_confirmation_exempt_exchanges missing from EntryConfig",
        )
        self.assertIn("MCX", e.require_close_confirmation_exempt_exchanges)

    def test_nse_bse_not_exempt_from_close_confirm(self):
        """MCX-BUG-1: NSE/BSE must NOT be exempt — their close gate is unchanged."""
        exempt = getattr(cfg.entry, "require_close_confirmation_exempt_exchanges", ())
        for exch in ("NSE_INDEX", "BSE_INDEX", "NFO", "BFO"):
            self.assertNotIn(exch, exempt, f"{exch} must not be exempt")

    def test_has_close_signal_returns_true_for_mcx(self):
        """MCX-BUG-1: _extract_signal gate returns True (pass) for MCX exchange."""
        import pandas as pd
        from tcos_bot.signals.signal_generator import SignalGenerator
        sg = SignalGenerator()
        # DataFrame with Signal but NO Close_Signal → would suppress on NSE
        df = pd.DataFrame([{
            "timestamp": "2026-03-17 19:24:00",
            "Signal": "BUYEN", "Renko_Brick": 8700.0,
            "Close_Price": 8700.0, "zlema9": 8690.0,
            "Colour_Brick_Count": 3, "direction": 1,
            "HH": True, "LL": False, "LH": False, "HL": False,
            "Last_High": 8750.0, "Last_Low": 8680.0,
        }])
        # MCX exchange → gate exempt → signal passes through
        ts, sig, price = sg._extract_signal(df, "CRUDEOIL", 8.0, exchange="MCX")
        self.assertEqual(sig, "BUYEN", "MCX HL signal must not be suppressed")

    def test_has_close_signal_suppresses_on_nse(self):
        """MCX-BUG-1: NSE HL signal without Close_Signal IS suppressed (unchanged)."""
        import pandas as pd
        from tcos_bot.signals.signal_generator import SignalGenerator
        sg = SignalGenerator()
        df = pd.DataFrame([{
            "timestamp": "2026-03-17 09:30:00",
            "Signal": "BUYEN", "Renko_Brick": 23550.0,
            "Close_Price": 23550.0, "zlema9": 23540.0,
            "Colour_Brick_Count": 3, "direction": 1,
            "HH": True, "LL": False, "LH": False, "HL": False,
            "Last_High": 23600.0, "Last_Low": 23500.0,
        }] * 15)  # 15 rows, no Close_Signal column
        ts, sig, price = sg._extract_signal(df, "NIFTY", 12.0, exchange="NSE_INDEX")
        # Without Close_Signal column → gate transparent (returns True) — still passes
        # The gate only BLOCKS when Close_Signal column EXISTS but has no match
        # This test verifies NSE path still evaluates the gate (doesn't exempt)
        # A real NSE suppression needs Close_Signal column with wrong values
        df2 = df.copy()
        df2["Close_Signal"] = "NONE"   # column exists, no BUYRE → should suppress
        ts2, sig2, price2 = sg._extract_signal(df2, "NIFTY", 12.0, exchange="NSE_INDEX")
        self.assertIsNone(sig2, "NSE HL signal without Close_Signal match must be suppressed")

    # ── MCX-BUG-2: Struct stop cap ────────────────────────────────────────────

    def test_struct_stop_cap_config_present(self):
        """MCX-BUG-2: max_struct_stop_bricks and override must be in StopConfig."""
        s = cfg.stop
        self.assertTrue(hasattr(s, "max_struct_stop_bricks"))
        self.assertTrue(hasattr(s, "max_struct_stop_bricks_override"))
        self.assertEqual(s.max_struct_stop_bricks, 99.0)
        ov = s.max_struct_stop_bricks_override
        self.assertEqual(ov.get("GOLDM"), 4.0)
        self.assertEqual(ov.get("SILVERM"), 4.0)
        # FIX-4: CRUDEOIL cap reduced 4.0→3.5b to limit stop widening to ≤28pts
        self.assertLessEqual(ov.get("CRUDEOIL"), 3.5)

    def test_nse_bse_have_5b_struct_cap(self):
        """Fix #4: NIFTY/BANKNIFTY now have 5b cap to prevent morning crash lows
        anchoring afternoon stops. Previously uncapped (99b default)."""
        ov = dict(cfg.stop.max_struct_stop_bricks_override)
        self.assertIn("NIFTY", ov)
        self.assertEqual(ov["NIFTY"], 5.0)
        self.assertIn("BANKNIFTY", ov)
        self.assertEqual(ov["BANKNIFTY"], 5.0)

    def test_goldm_struct_stop_capped(self):
        """MCX-BUG-2: GOLDM PUT stop must be capped at 4b (600pts), not 8.6b."""
        from tcos_bot.risk.risk_manager import TrailingStopManager
        mgr = TrailingStopManager()
        stop = mgr.initialise(
            "GOLDM", "PUT", entry_price=156289.0, brick_size=150.0,
            struct_high=157500.0, reconciled=True,
        )
        width_b = (stop - 156289.0) / 150.0
        self.assertLessEqual(width_b, 4.01, f"GOLDM stop must be ≤4b, got {width_b:.2f}b")
        mgr.remove("GOLDM")

    def test_nifty_struct_stop_uncapped(self):
        """MCX-BUG-2: NIFTY PUT stop must NOT be capped — uses full struct_high."""
        from tcos_bot.risk.risk_manager import TrailingStopManager
        mgr = TrailingStopManager()
        stop = mgr.initialise(
            "NIFTY", "PUT", entry_price=23543.0, brick_size=12.0,
            struct_high=23592.0, reconciled=True,
        )
        self.assertGreater(stop, 23543.0, "NIFTY stop must be above entry for PUT")
        mgr.remove("NIFTY")

    # ── MCX-BUG-3: Drift override ─────────────────────────────────────────────

    def test_drift_override_config_present(self):
        """MCX-BUG-3: max_drift_bricks_override must be in EntryConfig."""
        e = cfg.entry
        self.assertTrue(hasattr(e, "max_drift_bricks_override"))
        ov = e.max_drift_bricks_override
        self.assertEqual(ov.get("CRUDEOIL"), 2.5)
        self.assertEqual(ov.get("NATURALGAS"), 2.5)

    def test_nse_bse_drift_unchanged(self):
        """MCX-BUG-3: NIFTY/BANKNIFTY not in drift override → default 1.5b."""
        ov = dict(cfg.entry.max_drift_bricks_override)
        self.assertNotIn("NIFTY", ov)
        self.assertNotIn("BANKNIFTY", ov)
        self.assertEqual(cfg.entry.max_drift_bricks, 1.5)

    def test_grade_a_drift_unchanged(self):
        """MCX-BUG-3: Grade-A drift limit 3.0b must not change."""
        self.assertEqual(cfg.entry.grade_a_max_drift_bricks, 3.0)
