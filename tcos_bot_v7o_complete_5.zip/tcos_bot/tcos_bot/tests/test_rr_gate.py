"""
test_rr_gate.py — Tests for the Reward/Risk Gate (Phase 2).

Written BEFORE implementation. All tests must FAIL before code is written
and PASS after implementation.

The RR gate blocks entry when the nearest structural obstacle (swing high
for CALL, swing low for PUT) is less than rr_min_room_bricks away.

Key design decisions confirmed in audit:
  - Uses Renko_Brick price as entry reference (not raw ltp)
  - Uses ALL swing highs/lows (HH|LH for CALL, LL|HL for PUT)
  - Finds NEAREST wall above entry (not just Last_High)
  - Falls back to allow() when: gate disabled, no renko, missing columns,
    or fewer than rr_min_swing_points swing points
  - VOLATILE half-size stays in Phase 2 (removed in Phase 3)
  - MCX instruments subject to same gate (reasonable with 1.5b threshold)
"""
import pandas as pd
import numpy as np
import pytest
from unittest.mock import MagicMock, patch


# ── Helpers ───────────────────────────────────────────────────────────────────

def _make_renko_df(
    entry_price: float,
    brick_size: float,
    wall_above: float = None,
    floor_below: float = None,
    n_swing_points: int = 6,
) -> pd.DataFrame:
    """
    Build a minimal Renko DataFrame with controlled swing points.

    wall_above:  if given, places a swing HIGH exactly at this price.
                 All base bricks are kept BELOW entry so no accidental
                 swing highs interfere with the wall_above test.
    floor_below: if given, places a swing LOW exactly at this price.
    n_swing_points: total swing flags (HL/LL placed below entry as history).
    """
    rows = []
    # Build bricks ONLY below entry to avoid polluting the above-entry space
    for i in range(20):
        price = entry_price - (20 - i) * brick_size  # all below entry
        rows.append({
            "Renko_Brick": price,
            "HH": False, "LH": False, "HL": False, "LL": False,
            "Last_High": entry_price + 3 * brick_size,
            "Last_Low":  entry_price - 10 * brick_size,
            "Colour_Brick_Count": 3,
            "zlema9": entry_price - 5 * brick_size,
        })
    # Add the entry brick itself (no swing flag)
    rows.append({
        "Renko_Brick": entry_price,
        "HH": False, "LH": False, "HL": False, "LL": False,
        "Last_High": entry_price + 3 * brick_size,
        "Last_Low":  entry_price - 3 * brick_size,
        "Colour_Brick_Count": 3,
        "zlema9": entry_price,
    })

    df = pd.DataFrame(rows)

    # Sprinkle LL/HL flags ONLY on rows below entry for swing history
    placed = 0
    below_idx = df[df["Renko_Brick"] < entry_price].index.tolist()
    step = max(1, len(below_idx) // max(n_swing_points, 1))
    for idx in below_idx[::step]:
        if placed >= n_swing_points:
            break
        df.at[idx, "LL"] = True
        placed += 1

    # Place wall/floor rows — these are HISTORICAL swing points, so they go
    # BEFORE the final entry brick. The entry brick must remain iloc[-1].
    extra_rows = []

    if wall_above is not None:
        extra_rows.append({
            "Renko_Brick": wall_above,
            "HH": False, "LH": True, "HL": False, "LL": False,
            "Last_High": wall_above,
            "Last_Low":  entry_price - 3 * brick_size,
            "Colour_Brick_Count": 3,
            "zlema9": entry_price,
        })

    if floor_below is not None:
        extra_rows.append({
            "Renko_Brick": floor_below,
            "HH": False, "LH": False, "HL": True, "LL": False,
            "Last_High": entry_price + 3 * brick_size,
            "Last_Low":  floor_below,
            "Colour_Brick_Count": 3,
            "zlema9": entry_price,
        })

    if extra_rows:
        # Remove the entry brick, insert extras, re-add entry brick last
        entry_brick = df.iloc[[-1]].copy()
        df = df.iloc[:-1]
        extras_df = pd.DataFrame(extra_rows)
        df = pd.concat([df, extras_df, entry_brick], ignore_index=True)

    return df.reset_index(drop=True)


def _run_rr_check(signal, renko_df, brick_size=12.0, symbol="NIFTY",
                  gate_enabled=True, min_room=1.5, min_swings=5):
    """
    Call the RR gate through the pipeline._check_rr_gate method.
    Returns FilterResult.
    """
    from tcos_bot.filters.pipeline import FilterPipeline

    pipeline = FilterPipeline.__new__(FilterPipeline)

    with patch("tcos_bot.filters.pipeline.cfg") as mock_cfg:
        mock_cfg.signal_quality.rr_gate_enabled    = gate_enabled
        mock_cfg.signal_quality.rr_min_room_bricks = min_room
        mock_cfg.signal_quality.rr_min_swing_points = min_swings

        return pipeline._check_rr_gate(
            symbol=symbol,
            signal=signal,
            renko_df=renko_df,
            brick_size=brick_size,
        )


# ═══════════════════════════════════════════════════════════════════════════
# T1: CALL, wall 8b away → PASS
# ═══════════════════════════════════════════════════════════════════════════
def test_t1_call_wall_far_away_passes():
    """
    CALL entry. Nearest swing high is 8 bricks above entry.
    8b >> 1.5b threshold → PASS.
    """
    entry = 22951.0
    bs    = 12.0
    wall  = entry + 8 * bs   # 23047

    renko = _make_renko_df(entry, bs, wall_above=wall)
    result = _run_rr_check("BUYEN", renko, brick_size=bs)

    assert result.allowed, (
        f"CALL with wall {8}b away must PASS. "
        f"Blocked with reason: {result.reason}"
    )


# ═══════════════════════════════════════════════════════════════════════════
# T2: CALL, wall 1.4b away → BLOCK (today's losing trade)
# ═══════════════════════════════════════════════════════════════════════════
def test_t2_call_wall_too_close_blocks():
    """
    TODAY'S LOSING TRADE REPRODUCED.
    NIFTY CALL 13:53 @ 23,033. Nearest swing high = 23,050.
    Distance = (23050 - 23033) / 12 = 1.4b < 1.5b threshold → BLOCK.
    """
    entry = 23033.0
    bs    = 12.0
    wall  = 23050.0   # 1.4b above entry

    renko = _make_renko_df(entry, bs, wall_above=wall)
    result = _run_rr_check("BUYEN", renko, brick_size=bs)

    assert not result.allowed, (
        "NIFTY CALL 13:53 scenario: wall only 1.4b away must be BLOCKED. "
        "This is the RR gate's primary purpose. If this fails, gate not implemented."
    )
    assert "RR" in result.reason.upper() or "room" in result.reason.lower(), (
        f"Block reason should mention RR/room. Got: {result.reason}"
    )


# ═══════════════════════════════════════════════════════════════════════════
# T3: PUT, floor 11b away → PASS (SENSEX CALL 13:17 scenario — as PUT mirror)
# ═══════════════════════════════════════════════════════════════════════════
def test_t3_put_floor_far_away_passes():
    """
    PUT entry. Nearest swing low is 11 bricks below entry.
    11b >> 1.5b threshold → PASS.
    """
    entry = 74209.0
    bs    = 50.0
    floor = entry - 11 * bs   # 73659

    renko = _make_renko_df(entry, bs, floor_below=floor)
    result = _run_rr_check("SELEX", renko, brick_size=bs)

    assert result.allowed, (
        f"PUT with floor {11}b away must PASS. Got: {result.reason}"
    )


# ═══════════════════════════════════════════════════════════════════════════
# T4: PUT, floor 1.2b away → BLOCK
# ═══════════════════════════════════════════════════════════════════════════
def test_t4_put_floor_too_close_blocks():
    """
    PUT entry. Floor is only 1.2b below entry.
    1.2b < 1.5b → BLOCK.
    """
    entry = 74209.0
    bs    = 50.0
    floor = entry - 1.2 * bs   # 74149

    renko = _make_renko_df(entry, bs, floor_below=floor)
    result = _run_rr_check("SELEX", renko, brick_size=bs)

    assert not result.allowed, (
        f"PUT with floor only 1.2b away must be BLOCKED. Got: {result.reason}"
    )


# ═══════════════════════════════════════════════════════════════════════════
# T5: No swing highs above CALL entry → open sky → PASS
# ═══════════════════════════════════════════════════════════════════════════
def test_t5_call_no_wall_above_passes():
    """
    CALL entry at all-time high. No swing high exists above entry.
    Open sky = unlimited room → PASS.
    This handles trending days where price is making new highs.
    """
    entry = 23350.0
    bs    = 12.0
    # All swing points are BELOW entry — no wall above
    renko = _make_renko_df(entry, bs, wall_above=None)
    # Manually set all HH/LH below entry to ensure no wall above
    renko.loc[renko['HH'] | renko['LH'], ['HH', 'LH']] = False

    result = _run_rr_check("BUYEN", renko, brick_size=bs)

    assert result.allowed, (
        "CALL with no swing high above entry = open sky = must PASS. "
        "Trending day with new highs should always allow entries."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T6: Fewer swing points than minimum → gate transparent → PASS
# ═══════════════════════════════════════════════════════════════════════════
def test_t6_insufficient_swing_history_transparent():
    """
    Early in session — only 3 swing points detected.
    rr_min_swing_points = 5 → gate is inactive → PASS even if wall is close.
    """
    entry = 23033.0
    bs    = 12.0
    wall  = entry + 1.0 * bs   # very close wall — would normally block

    renko = _make_renko_df(entry, bs, wall_above=wall, n_swing_points=2)
    result = _run_rr_check("BUYEN", renko, brick_size=bs, min_swings=5)

    assert result.allowed, (
        "When fewer than min_swing_points detected, gate must be transparent. "
        "Early morning session with little history should not block entries."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T7: Feature flag disabled → gate always passes
# ═══════════════════════════════════════════════════════════════════════════
def test_t7_gate_disabled_always_passes():
    """
    rr_gate_enabled = False → gate is completely inactive.
    Even with wall 0.1b away, nothing is blocked.
    This is the deployment state for Phase 2 validation.
    """
    entry = 23033.0
    bs    = 12.0
    wall  = entry + 0.1 * bs   # tiny room — would definitely block if enabled

    renko = _make_renko_df(entry, bs, wall_above=wall)
    result = _run_rr_check("BUYEN", renko, brick_size=bs, gate_enabled=False)

    assert result.allowed, (
        "Gate disabled → must pass regardless of room. "
        "Feature flag not working correctly."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T8: SENSEX CALL 13:17 today — room=11b → PASS
# ═══════════════════════════════════════════════════════════════════════════
def test_t8_todays_sensex_call_winner_passes():
    """
    TODAY'S BEST TRADE: SENSEX CALL 13:17 @ 74,052.
    Nearest resistance = 74,600 (pre-crash high).
    Room = (74600 - 74052) / 50 = 10.96b >> 1.5b → PASS.
    """
    entry = 74052.0
    bs    = 50.0
    wall  = 74600.0   # 10.96b above entry

    renko = _make_renko_df(entry, bs, wall_above=wall)
    result = _run_rr_check("BUYEN", renko, brick_size=bs, symbol="SENSEX")

    assert result.allowed, (
        "SENSEX CALL 13:17 (+228pts) must PASS RR gate. "
        "room=10.96b is far above 1.5b threshold."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T9: NIFTY CALL 13:53 today — room=1.4b → BLOCK
# ═══════════════════════════════════════════════════════════════════════════
def test_t9_todays_nifty_call_loser_blocked():
    """
    TODAY'S LOSING TRADE: NIFTY CALL 13:53 @ 23,033.
    Nearest resistance = 23,050 (afternoon chop zone high).
    Room = (23050 - 23033) / 12 = 1.4b < 1.5b → BLOCK.
    """
    entry = 23033.0
    bs    = 12.0
    wall  = 23050.0   # only 1.4b above entry

    renko = _make_renko_df(entry, bs, wall_above=wall)
    result = _run_rr_check("BUYEN", renko, brick_size=bs, symbol="NIFTY")

    assert not result.allowed, (
        "NIFTY CALL 13:53 (-42pts) must be BLOCKED by RR gate. "
        "room=1.4b is below 1.5b threshold. "
        "This is the primary test for the RR gate's purpose."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T10: BANKNIFTY rally scenario — room=20b → PASS
# ═══════════════════════════════════════════════════════════════════════════
def test_t10_banknifty_rally_passes():
    """
    BANKNIFTY April 2 afternoon: entry at 50,420, next resistance 800pts away.
    Room = 800 / 40 = 20b >> 1.5b → PASS.
    This is the trade the no_new_entries gate was blocking.
    """
    entry = 50420.0
    bs    = 40.0
    wall  = 51220.0   # 800pts = 20b away

    renko = _make_renko_df(entry, bs, wall_above=wall)
    result = _run_rr_check("BUYEN", renko, brick_size=bs, symbol="BANKNIFTY")

    assert result.allowed, (
        "BANKNIFTY rally scenario: room=20b must PASS. "
        "This is the afternoon trade the time gate was blocking incorrectly."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T11: renko_df is None → gate transparent → PASS
# ═══════════════════════════════════════════════════════════════════════════
def test_t11_no_renko_transparent():
    """
    renko_df is None (Renko not loaded yet at startup).
    Gate must be transparent — don't block due to missing data.
    """
    result = _run_rr_check("BUYEN", renko_df=None, brick_size=12.0)
    assert result.allowed, "None renko_df must always pass (transparent gate)"


# ═══════════════════════════════════════════════════════════════════════════
# T12: HH/LH/HL/LL columns missing → gate transparent → PASS
# ═══════════════════════════════════════════════════════════════════════════
def test_t12_missing_swing_columns_transparent():
    """
    Renko DataFrame exists but HH/LH/HL/LL columns are missing.
    (Old data format or pre-annotation renko.)
    Gate must be transparent — don't crash or block.
    """
    renko = pd.DataFrame([{
        "Renko_Brick": 23033.0,
        "Colour_Brick_Count": 3,
        "zlema9": 23000.0,
        # No HH/LH/HL/LL columns
    }])
    result = _run_rr_check("BUYEN", renko, brick_size=12.0)
    assert result.allowed, "Missing swing columns must be handled gracefully → pass"


# ═══════════════════════════════════════════════════════════════════════════
# T13: Nearest wall exactly at threshold (2.5b) → PASS (boundary)
# ═══════════════════════════════════════════════════════════════════════════
def test_t13_wall_exactly_at_threshold_passes():
    """
    Wall exactly at 2.5b = the threshold value (raised from 1.5b in Layer 3).
    At exactly threshold → PASS (>= comparison).
    """
    entry = 23033.0
    bs    = 12.0
    wall  = entry + 2.5 * bs   # exactly 2.5b

    renko = _make_renko_df(entry, bs, wall_above=wall)
    result = _run_rr_check("BUYEN", renko, brick_size=bs, min_room=2.5)

    assert result.allowed, (
        "Wall at exactly 2.5b (threshold) must PASS. "
        "Boundary condition: >= threshold. Layer 3 raised from 1.5b."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T14: Nearest wall just below threshold (2.49b) → BLOCK
# ═══════════════════════════════════════════════════════════════════════════
def test_t14_wall_just_below_threshold_blocks():
    """
    Wall at 2.49b — just under the 2.5b threshold (Layer 3).
    → BLOCK.
    """
    entry = 23033.0
    bs    = 12.0
    wall  = entry + 2.49 * bs   # 29.88pts above

    renko = _make_renko_df(entry, bs, wall_above=wall)
    result = _run_rr_check("BUYEN", renko, brick_size=bs, min_room=2.5)

    assert not result.allowed, (
        "Wall at 2.49b (just below threshold) must be BLOCKED."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T15: Multiple swing highs above entry — finds NEAREST, not farthest
# ═══════════════════════════════════════════════════════════════════════════
def test_t15_finds_nearest_wall_not_farthest():
    """
    Multiple swing highs above entry: [23,060, 23,150, 23,300].
    Nearest is 23,060 (2.25b away).
    Gate must use 23,060, not 23,300.
    2.25b > 1.5b → PASS using nearest.
    
    Also tests that a far wall alone wouldn't fool the gate.
    """
    entry = 23033.0
    bs    = 12.0

    # Build renko with multiple walls
    renko = _make_renko_df(entry, bs, wall_above=23060.0)
    # Add more distant walls
    extra_walls = pd.DataFrame([
        {"Renko_Brick": 23150.0, "HH": True, "LH": False, "HL": False, "LL": False,
         "Last_High": 23150.0, "Last_Low": 22900.0, "Colour_Brick_Count": 3, "zlema9": 23000.0},
        {"Renko_Brick": 23300.0, "HH": True, "LH": False, "HL": False, "LL": False,
         "Last_High": 23300.0, "Last_Low": 22900.0, "Colour_Brick_Count": 3, "zlema9": 23000.0},
    ])
    renko = pd.concat([renko, extra_walls], ignore_index=True)

    result = _run_rr_check("BUYEN", renko, brick_size=bs)

    room = (23060.0 - entry) / bs   # = 2.25b
    assert result.allowed, (
        f"Nearest wall at 23060 = {room:.2f}b > 1.5b → must PASS. "
        f"Gate should use nearest wall, not farthest. Got: {result.reason}"
    )
