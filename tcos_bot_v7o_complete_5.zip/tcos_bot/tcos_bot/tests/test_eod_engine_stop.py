"""
test_eod_engine_stop.py — Tests for engine stop guard fixes.

Written BEFORE implementation — all 8 tests must FAIL on the current
codebase and PASS after the fix is applied.

Two problems being fixed:
  1. NSE close check (15:30) fires for MCX-only sessions — wrong.
  2. Cold restart after 15:30 kills the bot immediately — wrong.

Fix design:
  Guard 1 (has_equity): only apply NSE stop if session has NSE/BSE symbols.
  Guard 2 (uptime):     only stop if bot has been running >= 60 seconds.
  MCX path:             MCX-only sessions stop at mcx_close (23:30) instead.
"""
import time
import threading
import pandas as pd
import pytest
from unittest.mock import MagicMock, patch


# ── Helpers ───────────────────────────────────────────────────────────────────

def _symbols_nse():
    """symbols_df with one NSE_INDEX symbol."""
    return pd.DataFrame([{
        "symbol":   "NIFTY",
        "exchange": "NSE_INDEX",
    }])


def _symbols_mcx():
    """symbols_df with MCX-only symbols."""
    return pd.DataFrame([
        {"symbol": "CRUDEOIL",   "exchange": "MCX"},
        {"symbol": "NATURALGAS", "exchange": "MCX"},
    ])


def _symbols_mixed():
    """symbols_df with both NSE and MCX symbols."""
    return pd.DataFrame([
        {"symbol": "NIFTY",    "exchange": "NSE_INDEX"},
        {"symbol": "CRUDEOIL", "exchange": "MCX"},
    ])


def _make_engine(started_secs_ago: float):
    """
    Build a minimal TradingEngine with:
      - _started_at set to `started_secs_ago` seconds in the past
      - _stop_event not set
      - all dependencies mocked
    """
    from tcos_bot.core.engine import TradingEngine
    engine = TradingEngine.__new__(TradingEngine)
    engine._stop_event      = threading.Event()
    engine._started_at      = time.monotonic() - started_secs_ago
    engine._last_cycle      = 0.0
    engine._tm_lock         = threading.Lock()
    engine._brick_sizes     = {}
    engine._renko_cache     = MagicMock()
    engine._ohlc_cache      = MagicMock()
    engine._signal_gen      = MagicMock()
    engine._position_tracker = MagicMock()
    engine._order_router    = MagicMock()
    engine._client          = MagicMock()
    engine._ws_manager      = MagicMock()
    engine._last_order_time = {}
    engine._close_hook_guard = set()
    engine._fire_close_hooks = MagicMock()
    return engine


def _run_stop_check(engine, symbols_df, fake_time_str: str):
    """
    Run only the EOD stop check portion of _cycle() by patching
    the current time to fake_time_str (e.g. "15:31").
    Returns True if engine.stop() was called.
    """
    from datetime import time as dtime

    h, m = map(int, fake_time_str.split(":"))
    fake_now_time = dtime(h, m, 0)

    # Patch _now() to return a datetime whose .time() is fake_now_time
    fake_dt = MagicMock()
    fake_dt.time.return_value = fake_now_time

    engine.stop = MagicMock()

    with patch("tcos_bot.core.engine._now", return_value=fake_dt), \
         patch("tcos_bot.core.engine.cfg") as mock_cfg, \
         patch("tcos_bot.core.engine.trade_store") as mock_ts, \
         patch("tcos_bot.core.engine.ltp_store") as mock_ltp, \
         patch("tcos_bot.core.engine.risk_engine") as mock_re:

        mock_cfg.market_hours.nse_close  = "15:30"
        mock_cfg.market_hours.mcx_close  = "23:30"
        mock_cfg.market_hours.eod_squareoff_time = "15:25"
        mock_cfg.market_hours.no_new_entries_nse = "14:30"
        mock_cfg.market_hours.nse_open   = "09:15"
        mock_cfg.trailing.breakeven_after    = 2.0
        mock_cfg.trailing.trail_start_after  = 3.0
        mock_cfg.trailing.trail_distance     = 1.0
        mock_cfg.trailing.adaptive_trail     = False
        mock_cfg.trailing.on_brick_confirm   = True
        mock_cfg.stop.confirmation_tighten   = False
        mock_cfg.broker.ltp_hard_block_secs  = 30.0
        mock_ts.read_df.return_value = pd.DataFrame()
        mock_ltp.get.return_value    = (None, 0)
        mock_re.is_entry_allowed.return_value = (True, "")

        # B-6 fix: _has_equity is now cached at startup in run(); the tests
        # bypass run() via __new__, so compute and inject it here so _cycle()
        # can read it without an AttributeError.
        _EQ = frozenset({"NSE_INDEX", "BSE_INDEX", "NSE", "BSE", "NFO", "BFO"})
        engine._has_equity = any(
            str(r.get("exchange", "")).upper() in _EQ
            for _, r in symbols_df.iterrows()
        )

        try:
            engine._cycle(symbols_df)
        except Exception:
            pass   # only care about whether stop() was called

    return engine.stop.called


# ═══════════════════════════════════════════════════════════════════════════
# T1: NSE session, >60s uptime, time=15:31 → MUST STOP
# ═══════════════════════════════════════════════════════════════════════════
def test_t1_nse_after_close_long_uptime_stops():
    """
    Normal NSE session that has been running all day.
    At 15:31 with >60s uptime → engine must stop.
    This preserves the existing correct behaviour.
    """
    engine = _make_engine(started_secs_ago=3600)  # started 1h ago
    stopped = _run_stop_check(engine, _symbols_nse(), "15:31")
    assert stopped, (
        "NSE session at 15:31 with >60s uptime must stop. "
        "Existing behaviour must be preserved."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T2: NSE session, <60s uptime, time=15:31 → must NOT stop (cold restart)
# ═══════════════════════════════════════════════════════════════════════════
def test_t2_nse_after_close_cold_restart_does_not_stop():
    """
    Bot restarted at e.g. 15:31 to check logs.
    Uptime = 10s < 60s → must NOT stop immediately.
    Without this fix: today's bug — bot dies on first cycle.
    """
    engine = _make_engine(started_secs_ago=10)  # cold restart
    stopped = _run_stop_check(engine, _symbols_nse(), "15:31")
    assert not stopped, (
        "Cold restart at 15:31 (uptime=10s) must NOT stop. "
        "Guard 2 (uptime >= 60s) must protect cold restarts."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T3: MCX-only, <60s uptime, time=20:55 → must NOT stop (TODAY'S BUG)
# ═══════════════════════════════════════════════════════════════════════════
def test_t3_mcx_only_evening_cold_restart_does_not_stop():
    """
    TODAY'S EXACT BUG.
    Bot started at 20:55 for CRUDEOIL MCX testing.
    Uptime = 5s, symbols = MCX only, time = 20:55.
    Must NOT stop — MCX trades until 23:30.
    """
    engine = _make_engine(started_secs_ago=5)
    stopped = _run_stop_check(engine, _symbols_mcx(), "20:55")
    assert not stopped, (
        "MCX-only session at 20:55 with 5s uptime must NOT stop. "
        "This is today's exact bug — Guard 1 (has_equity) must block NSE check."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T4: MCX-only, >60s uptime, time=23:31 → must stop at mcx_close
# ═══════════════════════════════════════════════════════════════════════════
def test_t4_mcx_only_after_mcx_close_stops():
    """
    MCX session that has been running all evening.
    At 23:31 (after mcx_close=23:30) with >60s uptime → must stop.
    """
    engine = _make_engine(started_secs_ago=3600)  # running for 1h
    stopped = _run_stop_check(engine, _symbols_mcx(), "23:31")
    assert stopped, (
        "MCX-only session at 23:31 with >60s uptime must stop. "
        "MCX close = 23:30. Engine must stop after MCX close."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T5: MCX-only, >60s uptime, time=15:31 → must NOT stop (MCX still trading)
# ═══════════════════════════════════════════════════════════════════════════
def test_t5_mcx_only_at_nse_close_does_not_stop():
    """
    MCX-only session running at 15:31 (NSE close time).
    MCX is still open (closes at 23:30) → must NOT stop.
    Guard 1 (has_equity=False) must skip the NSE close check entirely.
    """
    engine = _make_engine(started_secs_ago=3600)
    stopped = _run_stop_check(engine, _symbols_mcx(), "15:31")
    assert not stopped, (
        "MCX-only session at 15:31 must NOT stop — MCX trades until 23:30. "
        "Guard 1 must block NSE close check for MCX-only sessions."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T6: Mixed NSE+MCX, >60s uptime, time=15:31 → must stop (NSE rules)
# ═══════════════════════════════════════════════════════════════════════════
def test_t6_mixed_nse_mcx_at_nse_close_stops():
    """
    Mixed session with both NIFTY and CRUDEOIL.
    At 15:31 with >60s uptime → has_equity=True → NSE rules apply → stop.
    """
    engine = _make_engine(started_secs_ago=3600)
    stopped = _run_stop_check(engine, _symbols_mixed(), "15:31")
    assert stopped, (
        "Mixed NSE+MCX session at 15:31 must stop — NSE rules apply "
        "when any equity symbol is present."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T7: NSE session, >60s uptime, time=14:00 → must NOT stop (market open)
# ═══════════════════════════════════════════════════════════════════════════
def test_t7_nse_during_market_hours_does_not_stop():
    """
    Normal NSE session in the middle of the trading day.
    Time = 14:00, well before 15:30 → must NOT stop.
    Regression guard — ensure normal intraday operation is not broken.
    """
    engine = _make_engine(started_secs_ago=3600)
    stopped = _run_stop_check(engine, _symbols_nse(), "14:00")
    assert not stopped, (
        "NSE session at 14:00 must NOT stop — market is open."
    )


# ═══════════════════════════════════════════════════════════════════════════
# T8: NSE session, >60s uptime, time=20:55 → must stop (was running all day)
# ═══════════════════════════════════════════════════════════════════════════
def test_t8_nse_evening_long_uptime_stops():
    """
    NSE bot that started before 15:30 and is still running at 20:55.
    has_equity=True, time>15:30, uptime>60s → must stop.
    Ensures that a stale NSE bot running past close does get stopped.
    """
    engine = _make_engine(started_secs_ago=41700)  # ~11.6h, started ~09:10
    stopped = _run_stop_check(engine, _symbols_nse(), "20:55")
    assert stopped, (
        "NSE-only session at 20:55 with 11h uptime must stop. "
        "has_equity=True and time>>15:30."
    )
