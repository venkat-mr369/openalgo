"""
Position Reconciler — reconciler.py
=====================================
Makes broker positionbook the single source of truth.

Responsibilities
----------------
1. STARTUP RECONCILE (run once, immediately after broker client is ready):
   - Import any live broker positions that have no matching INPOSITION row
     in trade_manager  ("orphan recovery").
   - Close any trade_manager INPOSITION rows whose broker position is flat.

2. CYCLE RECONCILE (run every engine cycle, replaces old _reconcile_manual_closes):
   - Detect manual broker closes while bot is running.
   - Log prominently once; mark CLOSED; cancel sibling orders.
   - Guard: skip rows filled within GRACE_SECS to avoid false positives from
     broker positionbook lag.

3. PRE-FLIGHT CHECK (before any exit/SL order):
   - Re-verify broker position still exists with qty > 0.
   - Prevent phantom exit orders.

Idempotency
-----------
- Each reconcile-imported row is stamped with signal_source="RECONCILE_IMPORT"
  and a deterministic position_key = "<symbol>:<option_symbol>:<direction>".
- Before importing, the store is queried for that key; duplicates are blocked.
- CLOSED rows are never re-closed (close_reason already set).

Thread safety
-------------
- All reads/writes go through trade_store (which holds its own write lock).
- Callers must pass the trade_manager DataFrame read inside tm_lock; the
  reconciler returns the modified copy which the caller saves under tm_lock.
"""

from __future__ import annotations

import hashlib
import logging
import threading
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import pandas as pd

from tcos_bot.config.settings import IST, cfg
from tcos_bot.data.ltp_store import ltp_store
from tcos_bot.data.trade_store import trade_store
from tcos_bot.execution.position_tracker import (
    PositionTracker,
    _classify_option_type,
    _extract_root,
    _resolve_root,
)

log = logging.getLogger(__name__)

# ── Constants ──────────────────────────────────────────────────────────────────
_GRACE_SECS: int = 60          # skip reconciliation for fills <60s old
_LOG_ONCE:   Dict[str, bool] = {}   # dedup manual-close log messages


def _now_ist() -> datetime:
    return datetime.now(tz=IST)


def _now_str() -> str:
    return _now_ist().strftime("%Y-%m-%d %H:%M:%S")


def _position_key(symbol: str, option_symbol: str, direction: str) -> str:
    """Deterministic key for idempotent import dedup."""
    raw = f"{symbol.upper()}:{(option_symbol or '').upper()}:{direction.upper()}"
    return raw


def _log_once(key: str, level: int, msg: str, *args) -> None:
    """Log a message only the first time the key is seen."""
    if key not in _LOG_ONCE:
        _LOG_ONCE[key] = True
        log.log(level, msg, *args)


# ── Pre-flight position check ──────────────────────────────────────────────────

def preflight_position_check(
    client,
    symbol: str,
    option_symbol: str,
    direction: str,
    known_roots: List[str],
    cached_positions_df: Optional["pd.DataFrame"] = None,
) -> bool:
    """
    Re-verify that broker has a live position before placing an exit/SL order.

    Returns True (safe to proceed) or False (position gone — abort order).
    This is called inside _execute_open_orders() before every SELL action.

    C-16 FIX: accepts *cached_positions_df* so the main cycle can pass the
    positions DataFrame already fetched at the top of _cycle(), avoiding an
    extra synchronous positionbook() REST call per exit order while _tm_lock
    is held.  Falls back to a fresh fetch when no cache is supplied.
    """
    try:
        pt = PositionTracker(client)
        if cached_positions_df is not None:
            positions_df = cached_positions_df
        else:
            positions_df = pt.fetch()
        if positions_df is None:
            # API failed — assume position exists to avoid missing an exit
            log.warning("⚠️  preflight_position_check: API failure for %s — allowing order", symbol)
            return True
        if positions_df.empty:
            log.warning("🚫 preflight_position_check: broker is flat — blocking exit for %s %s",
                        direction, symbol)
            return False
        root_map = pt.build_root_map(positions_df, known_roots)
        qty = root_map.get(symbol, {}).get(direction, 0)
        if qty <= 0:
            log.warning("🚫 preflight_position_check: %s %s qty=%d — blocking exit",
                        direction, symbol, qty)
            return False
        return True
    except Exception:
        log.exception("preflight_position_check error for %s — allowing order to be safe", symbol)
        return True


# ── Startup reconciliation ────────────────────────────────────────────────────

def startup_reconcile(
    client,
    known_roots: List[str],
    brick_sizes: Dict[str, float],
) -> None:
    """
    Run ONCE at startup (after broker client confirmed valid).

    1. Pull broker positions.
    2. Import orphan broker positions into trade_manager.
    3. Close DB rows that the broker no longer holds.

    Thread-safe: does its own read/write under trade_store's write lock via
    dedicated helpers (import_position, mark_closed_row).
    """
    # B-03 FIX: Clear the log-once dedup dict at every startup so that
    # manual closes on the same symbols are re-logged each new session.
    # Without this, day-2 manual closes on previously-seen symbols are silently
    # skipped because the key was already inserted in day-1's session.
    _LOG_ONCE.clear()
    log.info("🔄 Startup reconciliation starting…")

    pt = PositionTracker(client)
    positions_df = pt.fetch()

    if positions_df is None:
        log.warning("⚠️  Startup reconcile: positions API unavailable — skipping import")
        return

    if positions_df.empty:
        log.info("📭 Startup reconcile: broker positionbook is empty")
        # Broker holds nothing — build an empty root_map so per-direction
        # check closes every INPOSITION row (C-7 fix: was passing a flat set).
        empty_root_map: Dict[str, Dict[str, int]] = {}
        _close_orphan_db_rows(empty_root_map, known_roots)
        return

    root_map = pt.build_root_map(positions_df, known_roots)
    log.info("📊 Startup reconcile: broker has %d live root position(s): %s",
             len(root_map), list(root_map.keys()))

    # Build a lookup: option_symbol → broker row
    opt_to_broker: Dict[str, pd.Series] = {}
    for _, pos in positions_df.iterrows():
        sym = str(pos.get("symbol", "")).upper()
        qty = int(pos.get("quantity", 0))
        if qty > 0:
            opt_to_broker[sym] = pos

    # ── 1. Import broker positions missing from DB ─────────────────────────
    tm = trade_store.read_df()
    live_opt_syms = set(
        str(r["option_symbol"]).upper()
        for _, r in tm.iterrows()
        if str(r.get("order_status", "")) == "INPOSITION"
        and r.get("option_symbol")
    )

    imported = 0
    for broker_sym, pos in opt_to_broker.items():
        if broker_sym in live_opt_syms:
            continue  # already tracked

        root      = _resolve_root(broker_sym, known_roots)
        opt_type  = _classify_option_type(broker_sym)
        if opt_type is None:
            log.debug("Startup reconcile: cannot classify %s — skipping import", broker_sym)
            continue

        direction = "CALL" if opt_type == "CALL" else "PUT"
        pkey      = _position_key(root, broker_sym, direction)

        # Check DB for existing row with this position_key (idempotency guard)
        if not tm.empty and "position_key" in tm.columns:
            match = tm[
                (tm["position_key"] == pkey) &
                (tm["order_status"] == "INPOSITION")
            ]
            if not match.empty:
                log.debug("Startup reconcile: %s already in DB (by pkey) — skipping", pkey)
                continue

        avg_price = float(pos.get("average_price", 0) or pos.get("buy_price", 0) or 0)
        qty       = int(pos.get("quantity", 0))
        exchange  = str(pos.get("exchange", "")).upper()
        bs        = brick_sizes.get(root, 50.0)

        entry_sig = "BUYCL" if direction == "CALL" else "BUYPT"
        stop_sig  = "SELST" if direction == "CALL" else "SELSP"

        ltp, _ = ltp_store.get(root)
        if not ltp:
            ltp = avg_price

        new_row = {
            "exchange":        exchange,
            "symbol":          root,
            "renko_signal":    entry_sig,
            "order_status":    "INPOSITION",
            "entry_price":     avg_price,
            "exec_price":      avg_price,
            "quantity":        qty,
            "option_symbol":   broker_sym,
            "fill_timestamp":  _now_str(),
            "timestamp":       _now_str(),
            "signal_source":   "RECONCILE_IMPORT",
            "position_key":    pkey,
            "brick_size_hint": bs,
        }
        trade_store.import_position(new_row)
        log.info(
            "📥 Startup reconcile IMPORT: %s %s qty=%d avg=%.2f (RECONCILE_IMPORT)",
            direction, broker_sym, qty, avg_price,
        )
        imported += 1

        # Create a paired stop row so the bot manages it
        stop_row = {
            "exchange":        exchange,
            "symbol":          root,
            "renko_signal":    stop_sig,
            "order_status":    "OPEN",
            "entry_price":     round(avg_price * 0.97, 2),  # conservative 3% initial stop
            "quantity":        qty,
            "option_symbol":   broker_sym,
            "timestamp":       _now_str(),
            "signal_source":   "RECONCILE_IMPORT_STOP",
            "brick_size_hint": bs,
        }
        trade_store.import_position(stop_row)

    if imported:
        log.info("📥 Startup reconcile: imported %d orphan position(s)", imported)

    # ── 2. Close DB rows broker no longer holds ────────────────────────────
    # C-7 FIX: old code built a set of "fully-flat roots" (CALL=0 AND PUT=0).
    # If the broker holds CALL=1 but PUT=0 for the same root, the stale PUT
    # INPOSITION row survived — the bot then placed a phantom SELPT exit.
    # Fix: pass the full root_map so _close_orphan_db_rows can check each
    # direction independently.
    _close_orphan_db_rows(root_map, known_roots)

    log.info("✅ Startup reconciliation complete")


def _close_orphan_db_rows(
    root_map: Dict[str, Dict[str, int]],
    known_roots: List[str],
) -> None:
    """
    Close trade_manager INPOSITION rows for positions broker no longer holds.
    Checks per-direction (CALL / PUT) so a stale PUT row is closed even when
    the broker still holds a CALL on the same root symbol.

    C-7 FIX: original received a flat set of "fully-flat roots" which missed
    cases where only one direction was closed at the broker.
    """
    tm = trade_store.read_df()
    if tm.empty:
        return

    in_pos_mask = (
        tm["order_status"] == "INPOSITION"
    ) & (
        tm["symbol"].isin(known_roots)
    )
    if not in_pos_mask.any():
        return

    changed = False
    for idx, row in tm[in_pos_mask].iterrows():
        sym    = str(row.get("symbol", ""))
        action = str(row.get("renko_signal", ""))
        # Map DB signal to broker direction key
        direction = "CALL" if action == "BUYCL" else "PUT"
        broker_qty = root_map.get(sym, {}).get(direction, 0)

        if broker_qty > 0:
            continue  # broker still holds this direction — leave it open

        ltp, _ = ltp_store.get(sym)
        tm.at[idx, "order_status"]    = "CLOSED"
        tm.at[idx, "close_reason"]    = "RECONCILE_BROKER_FLAT"
        tm.at[idx, "close_timestamp"] = _now_str()
        if ltp:
            tm.at[idx, "close_price"] = ltp
        stop_sig = "SELST" if action == "BUYCL" else "SELSP"
        exit_sig = "SELCL" if action == "BUYCL" else "SELPT"
        for cancel_sig in (stop_sig, exit_sig):
            cancel_mask = (
                (tm["symbol"] == sym) &
                (tm["renko_signal"] == cancel_sig) &
                (tm["order_status"].isin(("OPEN", "SENDING")))
            )
            if cancel_mask.any():
                tm.loc[cancel_mask, "order_status"] = "CANCELLED"
                tm.loc[cancel_mask, "close_reason"] = "RECONCILE_BROKER_FLAT_CANCEL"
        log.warning(
            "🔴 Startup reconcile CLOSED orphan DB row: %s %s "
            "(broker %s qty=0, was INPOSITION in DB)",
            action, sym, direction,
        )
        changed = True

    if changed:
        trade_store.save_df(tm)


# ── Cycle reconciliation (manual close detection) ─────────────────────────────

def cycle_reconcile(
    tm: pd.DataFrame,
    root_positions: Dict[str, Dict[str, int]],
    api_ok: bool,
) -> Tuple[pd.DataFrame, bool]:
    """
    Called every engine cycle (replaces _reconcile_manual_closes in engine.py).

    Compares trade_manager INPOSITION rows against root_positions (from broker).
    Detects manual closes and marks them CLOSED.

    Parameters
    ----------
    tm              : current trade_manager DataFrame (read inside tm_lock)
    root_positions  : {root: {"CALL": qty, "PUT": qty}} from broker
    api_ok          : False if positions API failed → skip to avoid false closes

    Returns
    -------
    (modified_tm, any_changed)
    """
    if not api_ok:
        return tm, False

    in_pos_mask = (
        tm["renko_signal"].isin(["BUYCL", "BUYPT"]) &
        (tm["order_status"] == "INPOSITION")
    )
    if not in_pos_mask.any():
        return tm, False

    now_ist = _now_ist()
    changed = False

    for idx, row in tm[in_pos_mask].iterrows():
        symbol    = str(row.get("symbol", ""))
        action    = str(row.get("renko_signal", ""))
        direction = "CALL" if action == "BUYCL" else "PUT"
        stop_sig  = "SELST" if action == "BUYCL" else "SELSP"
        exit_sig  = "SELCL" if action == "BUYCL" else "SELPT"

        # ── Grace period: broker book lags up to 60s after fill ───────────
        fill_ts_raw = row.get("fill_timestamp")
        if fill_ts_raw:
            try:
                fill_ts = pd.to_datetime(fill_ts_raw)
                if fill_ts.tzinfo is None:
                    fill_ts = fill_ts.tz_localize(IST)
                age_secs = (now_ist - fill_ts).total_seconds()
                if age_secs < _GRACE_SECS:
                    continue
            except Exception:
                pass  # unparseable → proceed

        # ── Already has a close_reason → skip ─────────────────────────────
        if row.get("close_reason"):
            continue

        broker_qty = root_positions.get(symbol, {}).get(direction, 0)
        if broker_qty > 0:
            continue  # position still live

        ltp, _ = ltp_store.get(symbol)
        log_key = f"manual_close:{symbol}:{direction}"

        _log_once(
            log_key, logging.WARNING,
            "🟠 Manual close detected: %s %s qty=0 in broker "
            "→ marking CLOSED (close_price=%.2f)",
            direction, symbol, ltp or 0,
        )

        tm.at[idx, "order_status"]     = "CLOSED"
        tm.at[idx, "close_reason"]     = "MANUAL_CLOSE_DETECTED"
        tm.at[idx, "close_timestamp"]  = _now_str()
        if ltp:
            tm.at[idx, "close_price"]  = ltp

        # Cancel sibling stop / exit orders
        for cancel_sig in (stop_sig, exit_sig):
            cancel_mask = (
                (tm["symbol"] == symbol) &
                (tm["renko_signal"] == cancel_sig) &
                (tm["order_status"].isin(("OPEN", "SENDING")))
            )
            if cancel_mask.any():
                tm.loc[cancel_mask, "order_status"] = "CANCELLED"
                tm.loc[cancel_mask, "close_reason"] = "MANUAL_CLOSE_DETECTED_CANCEL"

        # Remove trailing stop state
        try:
            from tcos_bot.risk.risk_manager import trailing_stop_mgr
            trailing_stop_mgr.remove(symbol)
        except Exception:
            pass

        changed = True

    return tm, changed
