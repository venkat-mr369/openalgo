"""
Option Resolver — option_resolver.py
======================================
PR-4 changes (BUG-6 FIX)
--------------------------
BUG-6 FIXED: _CACHE_TTL reduced from 300s → 60s.
             LTP-drift invalidation added: if |current_ltp - cached_ltp|
             exceeds the strike step for this root, the cache entry is
             immediately invalidated regardless of TTL.

             Old behaviour: a 5-minute cache during a fast move could let
             the bot buy a strike that had moved 200+ pts OTM.

             New fields per cache entry: (symbol, cached_at, cached_ltp)

Also FIXED:  _find_position_symbol() — if multiple expiries are open
             (rollover overlap), it now picks the one matching the stored
             option_symbol from the entry row in trade_manager, rather than
             the first CE/PE hit (which could be the wrong expiry).
             Caller passes expected_symbol hint when resolving exits.
"""

from __future__ import annotations

import logging
import os
import re
import sqlite3
from datetime import datetime, date
from typing import Optional, Tuple

import pandas as pd

from tcos_bot.config.settings import IST
from tcos_bot.data.ltp_store import ltp_store

log = logging.getLogger(__name__)

_STEP_MAP = {
    "NIFTY":      100,
    "BANKNIFTY":  100,
    "SENSEX":     100,
    "BANKEX":     100,
    "CRUDEOIL":    50,
    "GOLDM":      500,
    "SILVERM":   1000,
    "NATURALGAS":   5,
    "FINNIFTY":    50,
    "MIDCPNIFTY":  25,
}

_DERIV_MAP = {
    "NSE_INDEX": "NFO", "BSE_INDEX": "BFO",
    "NSE": "NFO",       "BSE": "BFO",
    "MCX": "MCX",       "NFO": "NFO", "BFO": "BFO",
}


def _derivative_exchange(exchange: str) -> str:
    return _DERIV_MAP.get(exchange.upper(), "NFO")


def _extract_root(symbol: str) -> str:
    m = re.match(r"^([A-Z]+)", symbol.upper())
    return m.group(1) if m else symbol


def _parse_expiry(raw) -> Optional[date]:
    try:
        if isinstance(raw, (int, float)):
            return datetime.fromtimestamp(int(raw) / 1000).date()
        if isinstance(raw, str):
            return datetime.strptime(raw, "%d-%b-%y").date()
    except Exception:
        pass
    return None


def _openalgo_db_path() -> str:
    return os.path.join(os.getcwd(), "db", "openalgo.db")


class OptionResolver:
    """
    BUG-6 FIX
    ----------
    Cache TTL: 300s → 60s.

    Cache entry: (symbol, cached_at, cached_ltp)
                   ↑ added cached_ltp for drift check.

    Invalidation logic (_is_cache_valid):
        1. Age > 60s → invalid
        2. |current_ltp - cached_ltp| > strike_step → invalid (LTP-drift)

    When drift invalidation fires, a WARNING is logged with the delta
    so it appears in the trade_events log for post-session analysis.
    """

    _CACHE_TTL = 60   # BUG-6: was 300s

    def __init__(self, client) -> None:
        self._client = client
        # (root, opt_type, exchange) → (symbol, cached_at, cached_ltp)
        self._cache: dict[tuple, tuple] = {}

    def resolve(
        self,
        action:        str,
        symbol:        str,
        exchange:      str,
        positions_df:  Optional[pd.DataFrame],
        trade_manager: Optional[pd.DataFrame] = None,   # for exit hint
    ) -> Tuple[Optional[str], str, Optional[float]]:
        deriv_ex = _derivative_exchange(exchange)
        root     = _extract_root(symbol)

        if action in ("BUYCL", "BUYPT"):
            opt_type   = "CE" if action == "BUYCL" else "PE"
            opt_symbol = self._resolve_entry_symbol(root, opt_type, exchange, symbol)
            if opt_symbol is None:
                log.warning("Could not resolve %s option for %s", opt_type, symbol)
                return None, deriv_ex, None
            opt_ltp, _ = ltp_store.get(opt_symbol)
            return opt_symbol, deriv_ex, opt_ltp

        elif action in ("SELCL", "SELST"):
            # BUG: pick the symbol stored in our entry row, not just first CE
            hint = self._get_position_hint(trade_manager, symbol, "BUYCL")
            opt_symbol = self._find_position_symbol(root, "CE", deriv_ex, positions_df, hint)
            if opt_symbol is None:
                log.warning("No CE position found for exit %s %s", action, symbol)
                return None, deriv_ex, None
            opt_ltp, _ = ltp_store.get(opt_symbol)
            return opt_symbol, deriv_ex, opt_ltp

        elif action in ("SELPT", "SELSP"):
            hint = self._get_position_hint(trade_manager, symbol, "BUYPT")
            opt_symbol = self._find_position_symbol(root, "PE", deriv_ex, positions_df, hint)
            if opt_symbol is None:
                log.warning("No PE position found for exit %s %s", action, symbol)
                return None, deriv_ex, None
            opt_ltp, _ = ltp_store.get(opt_symbol)
            return opt_symbol, deriv_ex, opt_ltp

        return None, deriv_ex, None

    # ── Entry resolution ──────────────────────────────────────────────────────

    def _resolve_entry_symbol(
        self, root: str, opt_type: str, exchange: str, index_sym: str
    ) -> Optional[str]:
        import time as _time

        ltp, _ = ltp_store.get(index_sym)
        if ltp is None:
            log.warning("No LTP for %s — cannot resolve option", index_sym)
            return None

        cache_key = (root, opt_type, exchange)
        cached    = self._cache.get(cache_key)
        step      = _STEP_MAP.get(root, 100)

        if cached and self._is_cache_valid(cached, ltp, step):
            log.debug("⚡ Cache hit %s %s: %s", root, opt_type, cached[0])
            return cached[0]

        # Cache miss or invalidated
        atm_strike = round(ltp / step) * step
        deriv_ex   = _derivative_exchange(exchange)

        # ATM-FOR-MCX FIX: MCX options have wide bid-ask spreads.
        # Going 1 step ITM on MCX means paying 50-500pts of extra premium
        # that you can never recover on a typical 24-32pt stop loss.
        # NSE/BSE keeps 1-step ITM for better delta (proven to work there).
        #
        # MCX  → ATM strike (no offset): tightest spread, best fills
        # NSE/BSE → 1 step ITM: higher delta, tracks index move better
        _MCX_EXCHANGES = {"MCX", "MCX_FUT", "MCX_OPT"}
        if _derivative_exchange(exchange).upper() in _MCX_EXCHANGES:
            target_strike = atm_strike          # ATM for MCX
            _strike_label = "ATM"
        else:
            target_strike = (atm_strike - step) if opt_type == "CE" else (atm_strike + step)
            _strike_label = "1-step-ITM"        # ITM for NSE/BSE

        log.info("🎯 %s LTP=%.2f ATM=%d %s_strike=%d (%s) → %s",
                 root, ltp, atm_strike, opt_type, target_strike, _strike_label, deriv_ex)

        opt_sym = self._query_symtoken(deriv_ex, root, opt_type, target_strike)
        if opt_sym:
            # Store (symbol, ts, ltp_at_cache_time)
            self._cache[cache_key] = (opt_sym, _time.time(), ltp)
            log.info("✅ Resolved %s %s → %s (ltp=%.2f)", root, opt_type, opt_sym, ltp)
        else:
            log.warning("❌ No %s option found for %s strike=%d in %s",
                        opt_type, root, target_strike, deriv_ex)
        return opt_sym

    def _is_cache_valid(self, cached: tuple, current_ltp: float, step: int) -> bool:
        """
        BUG-6 FIX: dual-criterion cache validation.
        cached = (symbol, cached_at, cached_ltp)
        """
        import time as _time
        if len(cached) < 3:
            # Old-format cache entry (no ltp) — always invalidate for safety
            return False

        sym, cached_at, cached_ltp = cached

        # Criterion 1: TTL
        if (_time.time() - cached_at) >= self._CACHE_TTL:
            log.debug("Cache TTL expired for %s", sym)
            return False

        # Criterion 2: LTP-drift
        ltp_drift = abs(current_ltp - cached_ltp)
        if ltp_drift > step:
            log.warning(
                "⚠️ OPTION CACHE DRIFT INVALIDATION: %s | "
                "cached_ltp=%.2f current_ltp=%.2f drift=%.2f > step=%d — "
                "re-resolving strike",
                sym, cached_ltp, current_ltp, ltp_drift, step,
            )
            return False

        return True

    def _query_symtoken(
        self, deriv_ex: str, root: str, opt_type: str, target_strike: float
    ) -> Optional[str]:
        db_path = _openalgo_db_path()
        if not os.path.exists(db_path):
            log.error("openalgo.db not found at %s", db_path)
            return None
        today = datetime.now(tz=IST).date()
        try:
            con = sqlite3.connect(db_path)
            con.row_factory = sqlite3.Row

            # MCX-BUG-2 FIX: MCX options in OpenAlgo/Flattrade store
            # instrumenttype='OPTFUT' (not 'CE'/'PE').  The call/put type is
            # embedded in the symbol name (e.g. GOLDM25APR8200CE).
            # Querying WHERE instrumenttype='CE' returns 0 rows for all MCX
            # instruments except CRUDEOIL if its broker maps it differently.
            # Fix: for MCX exchange, match by symbol suffix (ends with CE/PE)
            # instead of the instrumenttype column.
            # For NSE/BSE/NFO/BFO the original instrumenttype query is unchanged.
            if deriv_ex.upper() == "MCX":
                rows = con.execute(
                    """
                    SELECT symbol, expiry, strike
                    FROM symtoken
                    WHERE exchange = ?
                      AND UPPER(symbol) LIKE ?
                      AND UPPER(symbol) LIKE ?
                    ORDER BY strike ASC, expiry ASC
                    """,
                    (deriv_ex, root + "%", "%" + opt_type.upper()),
                ).fetchall()
            else:
                rows = con.execute(
                    """
                    SELECT symbol, expiry, strike
                    FROM symtoken
                    WHERE exchange = ?
                      AND UPPER(symbol) LIKE ?
                      AND UPPER(instrumenttype) = ?
                    ORDER BY strike ASC, expiry ASC
                    """,
                    (deriv_ex, root + "%", opt_type.upper()),
                ).fetchall()
            con.close()
        except Exception:
            log.exception("symtoken query failed for %s %s", root, opt_type)
            return None

        if not rows:
            log.warning("No symtoken rows for %s %s on %s", root, opt_type, deriv_ex)
            return None

        # FIX-2: Prefer exact-root matches over prefix matches.
        # For MCX, the query uses LIKE 'CRUDEOIL%' which returns both
        # CRUDEOIL and CRUDEOILM options.  If CRUDEOILM rows appear
        # first in the DB, they get selected for a CRUDEOIL root signal.
        # Fix: filter to rows whose symbol starts with EXACTLY root+expiry
        # pattern first; only fall back to all rows if no exact matches.
        # This keeps NSE/BSE unaffected (their roots are unambiguous).
        exact_rows = [
            r for r in rows
            if str(r["symbol"]).upper().startswith(root.upper())
            and not str(r["symbol"]).upper().startswith(root.upper() + "M")
            and not str(r["symbol"]).upper().startswith(root.upper() + "MINI")
        ]
        # Use exact matches if available, else fall back to all rows
        resolved_rows = exact_rows if exact_rows else rows

        if exact_rows and len(exact_rows) < len(rows):
            log.debug(
                "FIX-2 ROOT EXACT MATCH: %s — filtered %d→%d rows "
                "(excluded CRUDEOILM/mini variants for CRUDEOIL root)",
                root, len(rows), len(exact_rows),
            )

        valid_strikes: dict[float, list] = {}
        for r in resolved_rows:
            exp = _parse_expiry(r["expiry"])
            if exp and exp >= today:
                valid_strikes.setdefault(float(r["strike"]), []).append(r)

        if not valid_strikes:
            log.warning("No future-expiry rows for %s %s", root, opt_type)
            return None

        nearest_strike = min(valid_strikes, key=lambda s: abs(s - target_strike))
        if nearest_strike != target_strike:
            log.info("🔄 %s %s: strike adjusted %d → %d",
                     root, opt_type, int(target_strike), int(nearest_strike))

        candidates  = valid_strikes[nearest_strike]
        expiry_map: dict[date, str] = {}
        for r in candidates:
            exp = _parse_expiry(r["expiry"])
            if exp:
                expiry_map[exp] = str(r["symbol"])

        # BUG FIX v7m: apply minimum DTE floor before selecting expiry.
        # Old code picked nearest future expiry with no floor, causing
        # Apr 9 (1 DTE) to be selected on Apr 8 → extreme theta decay.
        # Winning trades made tiny real profits despite large index moves.
        from tcos_bot.config.settings import cfg as _cfg
        _min_dte = getattr(_cfg.option_quality, "min_dte_days", 5)

        selected = None
        for exp in sorted(expiry_map):
            dte = (exp - today).days
            if exp > today and dte >= _min_dte:
                selected = exp
                break
        # Fallback: if no expiry meets min_dte, pick nearest future (never fail).
        if selected is None:
            future_exps = [e for e in expiry_map if e > today]
            if future_exps:
                selected = min(future_exps)
                log.warning(
                    "⚠️  min_dte=%d: no expiry meets floor for %s %s — "
                    "falling back to nearest future expiry %s (%d DTE)",
                    _min_dte, root, opt_type, selected,
                    (selected - today).days,
                )
        if selected is None and expiry_map:
            selected = min(expiry_map)
        if selected is None:
            return None

        sym = expiry_map[selected]
        if not sym.upper().startswith(root.upper()):
            log.error("ROOT MISMATCH: expected %s, got %s", root, sym)
            return None
        return sym

    # ── Exit resolution ───────────────────────────────────────────────────────

    @staticmethod
    def _get_position_hint(
        tm: Optional[pd.DataFrame], symbol: str, entry_action: str
    ) -> Optional[str]:
        """Extract the option_symbol from the INPOSITION entry row."""
        if tm is None or tm.empty:
            return None
        mask = (
            (tm["symbol"] == symbol) &
            (tm["renko_signal"] == entry_action) &
            (tm["order_status"] == "INPOSITION")
        )
        rows = tm[mask]
        if rows.empty:
            return None
        opt_sym = rows.iloc[0].get("option_symbol")
        return str(opt_sym) if opt_sym and pd.notna(opt_sym) else None

    @staticmethod
    def _find_position_symbol(
        root:        str,
        opt_type:    str,
        deriv_ex:    str,
        positions_df: Optional[pd.DataFrame],
        hint:        Optional[str] = None,
    ) -> Optional[str]:
        """
        BUG FIX: Prefer hint symbol (from entry row) over first match.
        This prevents selecting the wrong expiry during rollover overlap.
        """
        if positions_df is None or positions_df.empty:
            return None

        # If hint is set and appears in positions with qty > 0, use it directly
        if hint:
            hint_upper = hint.upper()
            for _, pos in positions_df.iterrows():
                sym = str(pos.get("symbol", "")).upper()
                qty = int(pos.get("quantity", 0))
                ex  = str(pos.get("exchange", "")).upper()
                if sym == hint_upper and abs(qty) > 0 and ex == deriv_ex.upper():
                    log.debug("Exit resolve: using hint %s", hint)
                    return hint

        # Fallback: first matching root+opt_type
        for _, pos in positions_df.iterrows():
            sym = str(pos.get("symbol", "")).upper()
            qty = int(pos.get("quantity", 0))
            ex  = str(pos.get("exchange", "")).upper()
            if (
                abs(qty) > 0
                and sym.startswith(root.upper())
                and sym.endswith(opt_type.upper())
                and ex == deriv_ex.upper()
            ):
                if hint:
                    log.warning(
                        "Exit resolve: hint %s not found in positions — "
                        "falling back to %s (possible wrong expiry in rollover)",
                        hint, sym,
                    )
                return sym
        return None


# ── Front-month futures resolver (unchanged) ──────────────────────────────────

def resolve_front_month_futures(root: str, exchange: str) -> Optional[str]:
    import sqlite3 as _sq
    from datetime import date as _date

    db_path = _openalgo_db_path()
    if not os.path.exists(db_path):
        log.warning("resolve_front_month_futures: openalgo.db not found at %s", db_path)
        return None

    deriv_ex  = _DERIV_MAP.get(exchange.upper(), exchange.upper())
    today     = datetime.now(tz=IST).date()
    fut_types = ("FUTCOM", "FUTCUR", "FUTSTK", "FUTIDX", "FUTIVX", "FUT")
    placeholders = ",".join("?" * len(fut_types))

    try:
        con  = _sq.connect(db_path)
        con.row_factory = _sq.Row
        rows = con.execute(
            f"""
            SELECT symbol, expiry
            FROM symtoken
            WHERE exchange = ?
              AND UPPER(symbol) LIKE ?
              AND UPPER(instrumenttype) IN ({placeholders})
            ORDER BY expiry ASC
            """,
            (deriv_ex, root.upper() + "%", *fut_types),
        ).fetchall()
        con.close()
    except Exception:
        log.exception("resolve_front_month_futures DB error for %s", root)
        return None

    expiry_map: dict[_date, str] = {}
    for r in rows:
        exp = _parse_expiry(r["expiry"])
        if exp and exp >= today:
            expiry_map[exp] = str(r["symbol"])

    if not expiry_map:
        log.warning("No future futures contracts for %s on %s", root, deriv_ex)
        return None

    selected = min(expiry_map)
    sym      = expiry_map[selected]
    log.info("📅 Front-month futures: %s → %s (expiry=%s)", root, sym, selected)
    return sym
