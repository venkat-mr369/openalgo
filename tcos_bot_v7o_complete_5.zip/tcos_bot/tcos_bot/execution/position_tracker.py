"""
Execution Layer — position_tracker.py
======================================
PR-1 changes
------------
BUG-1 FIXED : _extract_root() defined at MODULE LEVEL (was dead-code inside
               _classify_option_type after a return None statement).
               Every call-site in this file now uses the module-level function.
DEAD CODE    : Removed the unreachable re.match block from _classify_option_type.
               Removed the duplicate `import re as _re` mid-function context.
"""

from __future__ import annotations

import logging
import os
import re
import time
from collections import defaultdict
from typing import Dict, Optional, Tuple

import pandas as pd

from tcos_bot.config.settings import LOT_SIZES, LOT_SIZE_OVERRIDES, cfg, IST
from tcos_bot.data.ltp_store import ltp_store
from tcos_bot.monitoring.logger import TradeLogger

log = logging.getLogger(__name__)


# ── MODULE-LEVEL _extract_root (BUG-1 FIX) ────────────────────────────────────
# Previously this logic was accidentally placed AFTER a `return None` inside
# _classify_option_type(), making it dead code.  Every caller raised NameError,
# which was swallowed by the blanket except in the main cycle — silently killing
# all position tracking.

def _resolve_root(broker_sym: str, known_roots: list[str]) -> str:
    """
    Map a broker option/futures symbol back to the bot's traded root.

    BUG-14 FIX: simple _extract_root (longest leading alpha sequence) fails
    for MCX mini-crude contracts where the option symbol is
    "CRUDEOILM17MAR267750CE" (root extracted = "CRUDEOILM") but the bot
    trades under root "CRUDEOIL".  The extra "M" in the contract ticker
    means every CRUDEOIL position has root="CRUDEOILM" in root_positions,
    so root_positions.get("CRUDEOIL") returns nothing → call_qty=0 →
    duplicate entries placed on same instrument.

    Fix: find the longest known_root that is a prefix of the broker symbol.
    Falls back to the raw alphabetic prefix if no known root matches.
    """
    sym_upper = broker_sym.upper()
    best = ""
    for root in known_roots:
        r = root.upper()
        if sym_upper.startswith(r) and len(r) > len(best):
            best = root
    if best:
        return best
    # fallback: original behaviour
    m = re.match(r"^([A-Z]+)", sym_upper)
    return m.group(1) if m else broker_sym


def _extract_root(symbol: str) -> str:
    """
    Extract the root ticker from any full symbol string.

    Examples
    --------
    _extract_root("NIFTY24MAY23500CE")  → "NIFTY"
    _extract_root("CRUDEOIL25MARFUT")   → "CRUDEOIL"
    _extract_root("NIFTY")             → "NIFTY"
    """
    m = re.match(r"^([A-Z]+)", symbol.upper())
    return m.group(1) if m else symbol


# ── Lot-size cache ────────────────────────────────────────────────────────────
# C-10 FIX: original was a bare dict with no TTL.  NSE lot sizes change
# periodically; a stale cache entry persists across sessions and causes wrong
# quantities.  We now store (lot_size, cached_at_monotonic) and re-query after
# _LOT_CACHE_TTL_SECS.
_LOT_CACHE_TTL_SECS: int = 3600          # re-verify every hour
_lot_cache: Dict[str, Tuple[int, float]] = {}   # {cache_key: (size, cached_at)}


def get_lot_size(symbol: str, exchange: str = "") -> int:
    """
    Return lot size for *symbol*.

    Priority
    --------
    0. LOT_SIZE_OVERRIDES config  (hard override, bypasses DB)
    1. In-memory cache (TTL = _LOT_CACHE_TTL_SECS, default 1 h)
    2. openalgo.db symtoken table  (always current)
    3. LOT_SIZES hardcoded map     (fallback)
    4. 1                           (last resort)

    LOT-FIX: LOT_SIZE_OVERRIDES added as priority 0.
    The openalgo.db symtoken table can contain wrong lotsize values for MCX
    instruments (e.g. GOLDM=100 instead of 10) because the CE/PE query picks
    up non-OPTFUT rows set incorrectly by the data vendor.
    LOT_SIZE_OVERRIDES bypasses the DB entirely for configured instruments.

    C-10 FIX: cache now stores (size, cached_at) and is invalidated after
    _LOT_CACHE_TTL_SECS so that exchange lot-size changes propagate without
    requiring a bot restart.
    """
    root = _extract_root(symbol)          # BUG-1: now calls the module-level function
    cache_key = root + (":" + exchange.upper() if exchange else "")
    now_mono = time.monotonic()

    # LOT-FIX Priority 0: hard config overrides always win over DB
    override = LOT_SIZE_OVERRIDES.get(root)
    if override:
        # Still cache it so logging doesn't repeat every call
        cached = _lot_cache.get(cache_key)
        if cached and (now_mono - cached[1]) < _LOT_CACHE_TTL_SECS:
            return cached[0]
        _lot_cache[cache_key] = (override, now_mono)
        log.info(
            "Lot size %s from LOT_SIZE_OVERRIDES: %d units/lot "
            "(overrides openalgo.db — DB value may be wrong for MCX instruments)",
            root, override,
        )
        return override

    # Check TTL-aware cache first
    cached = _lot_cache.get(cache_key)
    if cached is not None:
        size, cached_at = cached
        if (now_mono - cached_at) < _LOT_CACHE_TTL_SECS:
            return size
        # Cache expired — fall through to re-query
        log.debug("Lot cache TTL expired for %s — re-querying", root)

    deriv_map = {
        "NSE_INDEX": "NFO", "BSE_INDEX": "BFO",
        "NSE": "NFO", "BSE": "BFO", "MCX": "MCX",
        "NFO": "NFO", "BFO": "BFO",
    }
    db_path = os.path.join(os.getcwd(), "db", "openalgo.db")
    if os.path.exists(db_path):
        try:
            deriv_ex = deriv_map.get(exchange.upper(), "") if exchange else ""
            import sqlite3 as _sq
            con = _sq.connect(db_path)
            # LOT-FIX: MCX options use instrumenttype=OPTFUT (not CE/PE).
            # The old query only searched CE/PE and could pick up non-OPTFUT rows
            # with wrong lotsize values. Now includes OPTFUT for MCX exchanges.
            _mcx_exchanges = {"MCX"}
            _instr_types = "('CE','PE','OPTFUT')" if deriv_ex.upper() in _mcx_exchanges else "('CE','PE')"
            if deriv_ex:
                row = con.execute(
                    f"SELECT lotsize FROM symtoken "
                    f"WHERE exchange=? AND UPPER(symbol) LIKE ? "
                    f"AND UPPER(instrumenttype) IN {_instr_types} AND lotsize>0 "
                    f"ORDER BY CASE UPPER(instrumenttype) WHEN 'OPTFUT' THEN 0 ELSE 1 END LIMIT 1",
                    (deriv_ex, root + "%"),
                ).fetchone()
            else:
                row = con.execute(
                    "SELECT lotsize FROM symtoken "
                    "WHERE UPPER(symbol) LIKE ? "
                    "AND UPPER(instrumenttype) IN ('CE','PE','OPTFUT') AND lotsize>0 LIMIT 1",
                    (root + "%",),
                ).fetchone()
            con.close()
            if row and row[0]:
                size = int(row[0])
                _lot_cache[cache_key] = (size, now_mono)   # C-10: TTL tuple
                log.info("Lot size %s from openalgo.db: %d units/lot", root, size)
                return size
            log.warning(
                "No CE/PE rows found in symtoken for %s on %s — "
                "falling back to hardcoded map", root, deriv_ex or "any"
            )
        except Exception as exc:
            log.warning("openalgo.db lot size lookup failed for %s: %s", root, exc)

    size = LOT_SIZES.get(root)
    if size:
        _lot_cache[cache_key] = (size, now_mono)           # C-10: TTL tuple
        log.debug("Lot size %s from hardcoded map: %d", root, size)
        return size

    log.warning("Unknown lot size for %s (root=%s) — defaulting to 1", symbol, root)
    _lot_cache[cache_key] = (1, now_mono)                  # C-10: TTL tuple
    return 1


# ── Option-type classifier ────────────────────────────────────────────────────

def _classify_option_type(symbol: str) -> Optional[str]:
    """
    Determine whether a broker position symbol is a CALL or PUT.

    BUG-1 / DEAD-CODE FIX: Removed the unreachable `re.match` block that
    was placed after `return None`, and removed the duplicate `import re as _re`
    that was injected mid-function.
    """
    s = symbol.upper()

    if s.endswith("CE"):
        return "CALL"
    if s.endswith("PE"):
        return "PUT"

    # Embedded style: ...MAR26C8200 / ...MAR26P8200 (MCX Flattrade)
    m = re.search(r"(C|P)\d+$", s)
    if m:
        return "CALL" if m.group(1) == "C" else "PUT"

    if "CE" in s:
        return "CALL"
    if "PE" in s:
        return "PUT"

    return None


# ── Position Tracker ───────────────────────────────────────────────────────────

class PositionTracker:
    """Wraps broker positions API into structured per-root counts."""

    def __init__(self, client) -> None:
        self._client = client

    def fetch(self) -> Optional[pd.DataFrame]:
        try:
            resp = self._client.positionbook()
            if resp.get("status") == "error":
                log.warning("Positions API error: %s", resp.get("message"))
                return None
            data = resp.get("data", [])
            if not data:
                return pd.DataFrame()
            return pd.DataFrame(data)
        except Exception:
            log.exception("PositionTracker.fetch failed")
            return None

    def build_root_map(
        self,
        positions_df: Optional[pd.DataFrame],
        known_roots: Optional[list] = None,
    ) -> Dict[str, Dict[str, int]]:
        """
        Build {root: {"CALL": qty, "PUT": qty}} from broker positions.

        BUG-1 FIX: _extract_root() is now defined at module level.
        BUG-14 FIX: pass known_roots so that MCX mini contracts
            e.g. "CRUDEOILM17MAR267750CE" resolve to "CRUDEOIL" not
            "CRUDEOILM". Without this, root_positions["CRUDEOIL"] is
            always 0 → duplicate entries on same instrument.
        """
        result: Dict[str, Dict[str, int]] = defaultdict(lambda: {"CALL": 0, "PUT": 0})
        if positions_df is None or positions_df.empty:
            return result

        roots = list(known_roots) if known_roots else []

        for _, pos in positions_df.iterrows():
            sym     = str(pos.get("symbol", "")).upper()
            # BUG-14 FIX: use prefix-matched root not raw alphabetic prefix
            root    = _resolve_root(sym, roots)
            net_qty = int(pos.get("quantity", 0))
            if net_qty <= 0:
                continue
            opt_type = _classify_option_type(sym)
            if opt_type == "CALL":
                result[root]["CALL"] += net_qty
            elif opt_type == "PUT":
                result[root]["PUT"] += net_qty
        return result


# ── Order Router ───────────────────────────────────────────────────────────────

class OrderRouter:
    """
    Places and tracks orders via the broker client.

    Entry lifecycle
    ---------------
    1. Generate idempotency key (PR-6 stub — key stored in row)
    2. Set row to SENDING in DB (write-ahead log)
    3. Call client.placesmartorder()
    4. On success        → INPOSITION, store fill metadata
    5. On network error  → PENDING_VERIFY (not OPEN) — watchdog resolves
    6. On broker reject  → REJECTED + cancel sibling stop (BUG-9 FIX)

    Exit lifecycle
    --------------
    1. Verify position still exists (avoid double-sell)
    2. Set SENDING
    3. Place order
    4. On success → CLOSED + sibling stop CANCELLED
    5. On failure → OPEN (retry)
    """

    def __init__(self, client, strategy: str, product: str) -> None:
        self._client   = client
        self._strategy = strategy
        self._product  = product

    def execute_order(
        self,
        trade_manager:   pd.DataFrame,
        index:           int,
        row:             pd.Series,
        trading_symbol:  str,
        trading_exchange: str,
        index_ltp:       float,
        option_ltp:      float,
        quantity:        int,
    ) -> pd.DataFrame:
        action      = str(row.get("renko_signal", ""))
        symbol      = str(row.get("symbol", ""))
        entry_price = float(row.get("entry_price") or 0)
        order_action = "BUY" if action.startswith("BUY") else "SELL"

        # ── OpenAlgo smart order position_size semantics ───────────────────
        # position_size = TARGET net position after this order.
        # Entry  (BUY):  target = +quantity  → open/add to long
        # Exit (SELL):   target =  0         → close to flat
        # Passing position_size=quantity on a SELL tells OpenAlgo "keep qty=N
        # long", so the sell does NOTHING — position stays open. (BUG-11)
        target_position = quantity if order_action == "BUY" else 0

        log.info(
            "🎯 EXECUTE %s %s on %s | idx_ltp=%.2f opt_ltp=%.2f entry=%.2f qty=%d pos_target=%d",
            action, trading_symbol, trading_exchange,
            index_ltp, option_ltp, entry_price, quantity, target_position,
        )

        # Write-ahead: mark SENDING before broker call
        trade_manager.at[index, "order_status"] = "SENDING"
        from tcos_bot.data.trade_store import trade_store
        if hasattr(trade_store, "save_df"):
            trade_store.save_df(trade_manager)

        # Place order
        try:
            response = self._client.placesmartorder(
                strategy=self._strategy,
                symbol=trading_symbol,
                action=order_action,
                exchange=trading_exchange,
                price_type="MARKET",
                product=self._product,
                quantity=int(quantity),
                position_size=target_position,
            )
        except Exception as err:
            # Network/timeout: set PENDING_VERIFY — watchdog will query broker
            # for actual fill status on next tick rather than blindly reverting
            # to OPEN (which risked double-entry if broker had already filled).
            log.error("💀 Order network error %s %s: %s — marking PENDING_VERIFY",
                      action, trading_symbol, err)
            trade_manager.at[index, "order_status"]  = "PENDING_VERIFY"
            trade_manager.at[index, "close_reason"]  = f"network_err: {str(err)[:80]}"
            if hasattr(trade_store, "save_df"):
                trade_store.save_df(trade_manager)
            return trade_manager

        status = response.get("status", "")
        log.info("📋 Order response %s %s: %s", action, symbol, status)

        if status != "success":
            err_msg = response.get("message", str(response))[:120]
            log.warning("❌ Order REJECTED %s %s: %s", action, symbol, err_msg)
            trade_manager.at[index, "order_status"] = "REJECTED"
            trade_manager.at[index, "close_reason"] = f"broker_reject: {err_msg}"

            # BUG-9 FIX: cancel the sibling stop so it doesn't fire on
            # a position that never opened.
            if action in ("BUYCL", "BUYPT"):
                stop_sig = "SELST" if action == "BUYCL" else "SELSP"
                stop_mask = (
                    (trade_manager["symbol"] == symbol) &
                    (trade_manager["renko_signal"] == stop_sig) &
                    (trade_manager["order_status"] == "OPEN")
                )
                if stop_mask.any():
                    trade_manager.loc[stop_mask, "order_status"] = "CANCELLED"
                    trade_manager.loc[stop_mask, "close_reason"] = "ENTRY_REJECTED_CANCEL"
                    log.warning(
                        "🛑 Cancelled orphan stop %s for rejected entry %s %s",
                        stop_sig, action, symbol
                    )

            if hasattr(trade_store, "save_df"):
                trade_store.save_df(trade_manager)
            return trade_manager

        order_id = (
            response.get("orderid")
            or response.get("data", {}).get("orderid")
            or response.get("data", {}).get("order_id")
        )

        if action == "BUYCL":
            trade_manager = self._on_entry_fill(
                trade_manager, index, symbol, trading_symbol,
                order_id, index_ltp, entry_price, "BUYCL", "SELST",
            )
        elif action == "BUYPT":
            trade_manager = self._on_entry_fill(
                trade_manager, index, symbol, trading_symbol,
                order_id, index_ltp, entry_price, "BUYPT", "SELSP",
            )
        elif action in ("SELCL", "SELST"):
            trade_manager = self._on_exit_fill(
                trade_manager, index, symbol, action, order_id,
                index_ltp, "BUYCL", "SELST", "SELCL",
            )
        elif action in ("SELPT", "SELSP"):
            trade_manager = self._on_exit_fill(
                trade_manager, index, symbol, action, order_id,
                index_ltp, "BUYPT", "SELSP", "SELPT",
            )

        if hasattr(trade_store, "save_df"):
            trade_store.save_df(trade_manager)
        return trade_manager

    # ── Private helpers ─────────────────────────────────────────────────────────

    def _on_entry_fill(
        self,
        tm:             pd.DataFrame,
        index:          int,
        symbol:         str,
        option_symbol:  str,
        order_id:       Optional[str],
        index_ltp:      float,
        entry_price:    float,
        entry_action:   str,
        stop_action:    str,
    ) -> pd.DataFrame:
        from tcos_bot.config.settings import cfg
        from tcos_bot.risk.risk_manager import trailing_stop_mgr

        direction  = "CALL" if entry_action == "BUYCL" else "PUT"
        brick_size = float(tm.at[index, "brick_size_hint"]) if (
            "brick_size_hint" in tm.columns and pd.notna(tm.at[index, "brick_size_hint"])
        ) else 50.0

        now_str = pd.Timestamp.now(tz=IST).strftime("%Y-%m-%d %H:%M:%S")
        tm.at[index, "order_status"]          = "INPOSITION"
        tm.at[index, "orderid"]               = order_id
        tm.at[index, "index_ltp"]             = index_ltp
        tm.at[index, "fill_timestamp"]        = now_str
        tm.at[index, "option_symbol"]         = option_symbol
        tm.at[index, "peak_brick_since_entry"]= entry_price
        tm.at[index, "peak_ltp_since_entry"]  = index_ltp

        nft_ref = index_ltp
        nft_tgt = (
            nft_ref + cfg.nft.follow_through_bricks * brick_size
            if direction == "CALL"
            else nft_ref - cfg.nft.follow_through_bricks * brick_size
        )
        tm.at[index, "nft_validated"]  = 0
        tm.at[index, "nft_target"]     = nft_tgt
        tm.at[index, "chop_reversals"] = 0
        tm.at[index, "chop_last_ltp"]  = index_ltp
        # BUG-3: separate NFT state column (was sharing chop_last_ltp)
        tm.at[index, "nft_last_ltp"]   = index_ltp
        tm.at[index, "nft_rev_count"]  = 0

        # ── Drift stop override ───────────────────────────────────────────────
        # When exec price (index_ltp) has drifted significantly away from the
        # signal price (entry_price), anchoring the initial stop to signal_price
        # can leave the stop dangerously close to the fill price (because the
        # structural trail uses the fill as its peak reference).  If drift
        # exceeds cfg.entry.drift_stop_override_bricks, use exec price as the
        # anchor so the stop has the correct breathing room from the actual fill.
        _drift_override = cfg.entry.drift_stop_override_bricks
        _drift_b = abs(index_ltp - entry_price) / brick_size if brick_size > 0 else 0.0
        _stop_anchor = index_ltp if (_drift_override > 0 and _drift_b > _drift_override) else entry_price
        if _drift_b > _drift_override > 0:
            log.info(
                "🎯 STOP ANCHOR OVERRIDE %s %s: signal=%.2f exec=%.2f drift=%.2fb "
                "→ anchoring stop to exec price",
                symbol, direction, entry_price, index_ltp, _drift_b,
            )

        _day_regime = str(tm.at[index, "day_regime"] or "") if "day_regime" in tm.columns else ""
        stop_price = trailing_stop_mgr.initialise(
            symbol, direction, _stop_anchor, brick_size,
            # Structural swing levels stored by signal_generator._create_entry().
            # None-safe — initialise() falls back to fixed stop if missing.
            struct_high=float(tm.at[index, "struct_high"])
                        if "struct_high" in tm.columns and pd.notna(tm.at[index, "struct_high"])
                        else None,
            struct_low=float(tm.at[index, "struct_low"])
                       if "struct_low" in tm.columns and pd.notna(tm.at[index, "struct_low"])
                       else None,
            regime=_day_regime,   # VOLATILE regime gets longer confirm_mins
        )
        exchange = str(tm.at[index, "exchange"])
        qty      = int(tm.at[index, "quantity"] or 0)
        tm = self._replace_open_stop(tm, symbol, exchange, stop_price, qty, stop_action)

        TradeLogger.entry(
            symbol=symbol, action=entry_action, option_symbol=option_symbol,
            entry_price=entry_price, exec_price=index_ltp, quantity=qty,
            mode=str(tm.at[index, "entry_mode"] or "?"),
            grade=str(tm.at[index, "signal_grade"] or "?"),
            regime=str(tm.at[index, "day_regime"] or "?"),
        )
        log.info("✅ FILL %s %s | order_id=%s stop=%.2f",
                 entry_action, symbol, order_id, stop_price)
        # ── NFT ARMED — visible in main log (mirrors Lalaji bot) ─────────────
        if cfg.nft.enabled:
            _dyn_to_str = (
                f"dynamic {cfg.nft.timeout_min}–{cfg.nft.timeout_max}s"
                if cfg.nft.dynamic_timeout
                else f"{cfg.nft.base_timeout_secs}s (static)"
            )
            log.info(
                "⏱️📋 NFT ARMED %s %s: target=%.2f (entry %.2f %s %.0f×%.0f) "
                "| timeout=%s | smart_exit=%s | opt=%s",
                entry_action, symbol,
                nft_tgt, index_ltp,
                "+" if direction == "CALL" else "-",
                cfg.nft.follow_through_bricks, brick_size,
                _dyn_to_str, cfg.nft.smart_exit, option_symbol,
            )

        try:
            from tcos_bot.data.trade_store import symbol_store
            bs = float(tm.at[index, "brick_size_hint"]) if (
                "brick_size_hint" in tm.columns and pd.notna(tm.at[index, "brick_size_hint"])
            ) else 50.0
            symbol_store.upsert(exchange=exchange, symbol=symbol, brick_size=bs)
        except Exception:
            log.debug("symbol_store.upsert skipped for %s", symbol)

        self._try_subscribe(option_symbol, exchange)
        return tm

    def _on_exit_fill(
        self,
        tm:          pd.DataFrame,
        index:       int,
        symbol:      str,
        action:      str,
        order_id:    Optional[str],
        index_ltp:   float,
        entry_action: str,
        stop_signal:  str,
        exit_signal:  str,
    ) -> pd.DataFrame:
        from tcos_bot.risk.risk_manager import trailing_stop_mgr

        default_reason = (
            "STOP_EXIT"   if action in ("SELST", "SELSP") else
            "SIGNAL_EXIT" if action in ("SELCL", "SELPT") else
            "EXIT"
        )
        close_reason = str(tm.at[index, "close_reason"] or "") or default_reason
        tm.at[index, "order_status"] = "CLOSED"
        tm.at[index, "orderid"]      = order_id
        tm.at[index, "close_price"]  = index_ltp

        entry_mask = (
            (tm["symbol"] == symbol) &
            (tm["renko_signal"] == entry_action) &
            (tm["order_status"] == "INPOSITION")
        )
        entry_rows = tm[entry_mask]
        if not entry_rows.empty:
            entry_idx = entry_rows.index[0]
            entry_px  = float(tm.at[entry_idx, "entry_price"] or 0)
            pnl_pts   = (
                (index_ltp - entry_px) if entry_action == "BUYCL" else (entry_px - index_ltp)
            )
            tm.at[entry_idx, "order_status"] = "CLOSED"
            tm.at[entry_idx, "close_reason"] = close_reason
            tm.at[entry_idx, "close_price"]  = index_ltp
            opt_sym = str(tm.at[entry_idx, "option_symbol"] or symbol)
            TradeLogger.exit(
                symbol=symbol, action=action, option_symbol=opt_sym,
                entry_price=entry_px, close_price=index_ltp,
                pnl_pts=pnl_pts, reason=close_reason,
            )
            # B-01 FIX: Feed RiskEngine circuit breakers.
            # record_close() updates _session_pnl and _consec_losses so that:
            #   - daily max-loss halt fires correctly
            #   - consecutive-loss halt fires correctly
            #   - daily profit target lock fires correctly
            # Without this call all three circuit breakers read session_pnl=0 all day.
            try:
                from tcos_bot.risk.risk_manager import risk_engine
                from tcos_bot.execution.position_tracker import get_lot_size
                _lot_size = get_lot_size(symbol)
                _qty      = int(tm.at[entry_idx, "quantity"] or 0)
                _lots     = max(1, _qty // _lot_size) if _lot_size > 0 else 1
                risk_engine.record_close(symbol, pnl_pts, _lots, _lot_size)
            except Exception as _re_err:
                log.debug("risk_engine.record_close skipped: %s", _re_err)
        else:
            log.warning(
                "⚠️  _on_exit_fill: no INPOSITION entry row found for %s %s "
                "— position may already be closed.",
                entry_action, symbol,
            )

        trailing_stop_mgr.remove(symbol)

        # ── Fix 5: CHOP_EXIT resets flip counter ──────────────────────────────
        # A CHOP_OSCILLATION_EXIT is a structured bot-initiated exit, not a
        # genuine market direction flip.  Clear the whipsaw flip counter for
        # the exited direction so the next signal in that direction isn't
        # penalised for oscillation the bot itself recognised and acted on.
        if close_reason == "CHOP_OSCILLATION_EXIT":
            from tcos_bot.risk.risk_manager import whipsaw_tracker
            chop_direction = "CALL" if entry_action == "BUYCL" else "PUT"
            whipsaw_tracker.clear(symbol, direction=chop_direction,
                                  reason="CHOP_OSCILLATION_EXIT — flip counter reset")

        sibling = stop_signal if action == exit_signal else exit_signal
        sibling_mask = (
            (tm["symbol"] == symbol) &
            (tm["renko_signal"] == sibling) &
            (tm["order_status"] == "OPEN")
        )
        if sibling_mask.any():
            tm.loc[sibling_mask, "order_status"] = "CANCELLED"
            tm.loc[sibling_mask, "close_reason"] = "SIBLING_EXIT"

        log.info("✅ EXIT FILL %s %s @ %.2f | %s", action, symbol, index_ltp, close_reason)
        return tm

    def _replace_open_stop(
        self,
        tm:          pd.DataFrame,
        symbol:      str,
        exchange:    str,
        stop_price:  float,
        qty:         int,
        stop_signal: str,
    ) -> pd.DataFrame:
        existing_mask = (
            (tm["symbol"] == symbol) &
            (tm["exchange"] == exchange) &
            (tm["renko_signal"] == stop_signal) &
            (tm["order_status"] == "OPEN")
        )
        if existing_mask.any():
            tm.loc[existing_mask, "order_status"] = "CANCELLED"

        tm = pd.concat([tm, pd.DataFrame([{
            "exchange":     exchange,
            "timestamp":    pd.Timestamp.now(tz=IST).strftime("%Y-%m-%d %H:%M:%S"),
            "symbol":       symbol,
            "renko_signal": stop_signal,
            "entry_price":  stop_price,
            "quantity":     qty,
            "order_status": "OPEN",
        }])], ignore_index=True)
        return tm

    def _try_subscribe(self, option_symbol: str, exchange: str) -> None:
        try:
            from tcos_bot.core.ws_manager import ws_manager
            ws_manager.subscribe([{"exchange": exchange, "symbol": option_symbol}])
        except Exception as exc:
            log.debug("WS subscribe %s failed: %s", option_symbol, exc)
