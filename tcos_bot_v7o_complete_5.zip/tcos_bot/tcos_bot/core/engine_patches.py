"""
engine.py — TARGETED PATCHES (Issues A, B, C, D integration)
=============================================================
This file shows ONLY the two targeted change-blocks you need to apply to
engine.py.  The rest of the file is unchanged.

PATCH 1  (line ~280 in _execute_open_orders)
    Add WS-feed-health gate before BUY entries.
    Previously the stale check used cfg.broker.ltp_hard_block_secs (LTP age).
    Now ALSO checks ws_manager.is_feed_healthy() so the WS-level heartbeat
    blocks entries even if the REST fallback has injected a recent LTP.

PATCH 2  (line ~240 in _cycle, chop_checker call)
    Pass renko_df to chop_checker.check_and_annotate() so the new min_hold_bars
    and momentum_decay gates have access to Renko data.

PATCH 3  (engine import additions)
    Import whipsaw_manager for future integration (already wired in
    signal_generator.py by the user).

No other lines change.
"""

# ─────────────────────────────────────────────────────────────────────────────
# PATCH 1: _execute_open_orders — add WS-feed-health gate
# ─────────────────────────────────────────────────────────────────────────────
# FIND THIS BLOCK (approximately line 280 in original engine.py):
#
#     if action in ("BUYCL", "BUYPT") and ltp_age > cfg.broker.ltp_hard_block_secs:
#         log.warning("🚫 STALE LTP entry block %s: age=%.1fs", symbol, ltp_age)
#         continue
#
# REPLACE WITH:

def _execute_open_orders_patch_1():
    """
    The original stale LTP check only tests ltp_store age.
    Problem: REST fallback can inject a "fresh" LTP even when the WS is dead,
    making ltp_age appear healthy while the underlying feed is stale.
    The new WS heartbeat check catches this.

    IMPORTANT: Exits (SEL*) are NEVER blocked — we always allow closing
    a live position even on stale data.  The stale guard is BUY-entry only.
    """
    # ---- REPLACE THE EXISTING STALE CHECK (2 lines) WITH THIS BLOCK (5 lines) ----

    # Original (keep):
    #   if action in ("BUYCL", "BUYPT") and ltp_age > cfg.broker.ltp_hard_block_secs:
    #       log.warning("🚫 STALE LTP entry block %s: age=%.1fs", symbol, ltp_age)
    #       continue

    # Replacement:
    pass


PATCH_1_BEFORE = """\
            if action in ("BUYCL", "BUYPT") and ltp_age > cfg.broker.ltp_hard_block_secs:
                log.warning("🚫 STALE LTP entry block %s: age=%.1fs", symbol, ltp_age)
                continue\
"""

PATCH_1_AFTER = """\
            if action in ("BUYCL", "BUYPT"):
                # Gate 1: LTP age (REST-sourced freshness)
                if ltp_age > cfg.broker.ltp_hard_block_secs:
                    log.warning(
                        "🚫 STALE LTP entry block %s: age=%.1fs (hard_block=%.0fs)",
                        symbol, ltp_age, cfg.broker.ltp_hard_block_secs,
                    )
                    continue
                # Gate 2: WS heartbeat health (true feed-level freshness)
                # This catches cases where REST fallback injected a recent LTP
                # but the actual WS feed has been dead for > stale_threshold_secs.
                if self._ws_manager and not self._ws_manager.is_feed_healthy():
                    feed_age = self._ws_manager.feed_age_secs()
                    log.warning(
                        "🚫 WS FEED UNHEALTHY: blocking %s %s entry — "
                        "feed_age=%.1fs. Waiting for reconnect.",
                        action, symbol, feed_age,
                    )
                    continue\
"""

# ─────────────────────────────────────────────────────────────────────────────
# PATCH 2: _cycle — pass renko_df to chop_checker
# ─────────────────────────────────────────────────────────────────────────────
# FIND THIS LINE (approximately line 240 in original engine.py):
#
#     tm, chg = chop_checker.check_and_annotate(tm, symbol, exchange, ltp, bs)
#
# REPLACE WITH:

PATCH_2_BEFORE = """\
                    tm, chg = chop_checker.check_and_annotate(tm, symbol, exchange, ltp, bs)\
"""

PATCH_2_AFTER = """\
                    tm, chg = chop_checker.check_and_annotate(
                        tm, symbol, exchange, ltp, bs, renko_df=renko_df
                    )\
"""

# ─────────────────────────────────────────────────────────────────────────────
# PATCH 3: Import additions at top of engine.py
# ─────────────────────────────────────────────────────────────────────────────
# ADD to the existing imports block (after risk_manager imports):
#
#   from tcos_bot.risk.chop_checker import chop_checker
#   from tcos_bot.risk.whipsaw_manager import whipsaw_manager
#
# IMPORTANT: Only add these if your risk_manager.py currently re-exports
# chop_checker / whipsaw_manager as module-level objects.
# If risk_manager.py already contains these, no import change needed —
# just update the implementations in risk_manager.py.

PATCH_3_ADDITION = """\
# Add these after existing risk_manager imports (only if not already exported there):
# from tcos_bot.risk.chop_checker import chop_checker
# from tcos_bot.risk.whipsaw_manager import whipsaw_manager\
"""

# ─────────────────────────────────────────────────────────────────────────────
# HOW TO APPLY THESE PATCHES
# ─────────────────────────────────────────────────────────────────────────────
#
# Option A (sed / automated):
#   python apply_patches.py  (see apply_patches.py in this diff set)
#
# Option B (manual):
#   1. Open engine.py in your editor
#   2. Search for PATCH_1_BEFORE string → replace with PATCH_1_AFTER
#   3. Search for PATCH_2_BEFORE string → replace with PATCH_2_AFTER
#   4. Add PATCH_3_ADDITION imports where appropriate
#
# Option C (git patch):
#   git diff HEAD engine.py  — the changes above are the complete diff
#
# ─────────────────────────────────────────────────────────────────────────────
# VERIFICATION
# ─────────────────────────────────────────────────────────────────────────────
# After applying, search engine.py for:
#   self._ws_manager.is_feed_healthy()  → should appear once in _execute_open_orders
#   renko_df=renko_df                   → should appear in chop_checker call
