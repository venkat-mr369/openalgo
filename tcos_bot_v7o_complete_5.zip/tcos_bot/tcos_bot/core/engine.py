"""
Trading Engine — engine.py
===========================
PR-2 changes
------------
BUG-2 FIXED  : Watchdog acquires tm_lock BEFORE reading trade_store,
                re-reads INSIDE the lock, modifies, writes — all under
                one lock acquisition.  Eliminates stale-DF overwrite race.

BUG-7 FIXED  : _ohlc_cache and _renko_cache now protected by
                threading.RLock().  OHLC refresh thread holds the write
                (exclusive) side; main cycle holds the read side.
                Implemented via a simple _CacheLock helper that does
                read-under-same-RLock to keep it straightforward.

PENDING_VERIFY: Watchdog now resolves PENDING_VERIFY rows by querying
                the broker orders API — prevents double-entry after
                network timeout.
"""

from __future__ import annotations

import logging
import sys
import threading
import time
from collections import defaultdict
from datetime import datetime, time as dtime
from typing import Dict, List, Optional

import pandas as pd

from tcos_bot.config.settings import cfg, IST
from tcos_bot.core.ws_manager import WebSocketManager
from tcos_bot.data.ltp_store import ltp_store
from tcos_bot.data.trade_store import trade_store
from tcos_bot.execution.position_tracker import PositionTracker, get_lot_size
from tcos_bot.execution.reconciler import (
    cycle_reconcile,
    preflight_position_check,
    startup_reconcile,
)
from tcos_bot.monitoring.logger import TradeLogger
from tcos_bot.risk.risk_manager import (
    chop_checker,
    nft_checker,
    trailing_stop_mgr,
    risk_engine,            # C-1 FIX: circuit-breaker thread
    whipsaw_tracker,        # ISSUE-C FIX: wire exit_reason on position close
)
from tcos_bot.signals.renko_engine import HybridRenkoGenerator
from tcos_bot.signals.signal_generator import SignalGenerator

log = logging.getLogger(__name__)

_CYCLE_INTERVAL_SECS = 5.0
_ORDER_THROTTLE_SECS = cfg.broker.min_process_interval_secs
# Reduced from 60s to 30s to halve Renko lag on fast breakouts.
# At 60s, a brick forming at 14:11 was invisible until 14:19 (next refresh),
# producing 4b+ drift that cancelled Grade-A signals.  At 30s worst-case
# lag is ~35s, limiting drift to 1-2 bricks on a 12-pt brick size.
# Cost: doubles REST API calls (2/min per symbol — well within rate limits).
_OHLC_REFRESH_SECS   = 30
_STATUS_PRINT_SECS   = 30    # heartbeat for active-position status (matches Lalaji bot)


def _now() -> datetime:
    return datetime.now(tz=IST)


# ── BUG-7: Thread-safe cache wrapper ─────────────────────────────────────────
# We use a single RLock for both _ohlc_cache and _renko_cache.
# Because RLock is reentrant, the same thread can acquire it multiple times
# without deadlock (e.g., a method that calls another method that also reads).
# Both caches are updated atomically together during the OHLC refresh.

class _ProtectedCache:
    """
    Dict wrapper protected by a shared RLock.

    All read and write operations acquire the lock.  Because the lock is
    reentrant, a single thread can call get() inside a with _lock block
    without deadlocking.
    """

    def __init__(self, lock: threading.RLock) -> None:
        self._data: Dict = {}
        self._lock = lock

    def get(self, key: str, default=None):
        with self._lock:
            return self._data.get(key, default)

    def set(self, key: str, value) -> None:
        with self._lock:
            self._data[key] = value

    def keys(self):
        with self._lock:
            return list(self._data.keys())

    def items(self):
        with self._lock:
            return list(self._data.items())


class TradingEngine:
    """
    Single-entry-point orchestrator.
    All state lives in injected collaborators — engine itself is stateless.
    """

    def __init__(self, client, strategy: str, product: str) -> None:
        from tcos_bot.execution.position_tracker import OrderRouter
        self._client    = client
        self._strategy  = strategy
        self._product   = product

        self._position_tracker = PositionTracker(client)
        self._order_router     = OrderRouter(client, strategy, product)
        self._signal_gen       = SignalGenerator()
        self._renko_gen        = HybridRenkoGenerator(
            entry_offset_bricks=cfg.entry.offset_bricks
        )
        self._ws_manager: Optional[WebSocketManager] = None

        # BUG-7 FIX: shared RLock protecting both caches
        self._cache_lock   = threading.RLock()
        self._ohlc_cache   = _ProtectedCache(self._cache_lock)
        self._renko_cache  = _ProtectedCache(self._cache_lock)
        self._brick_sizes: Dict[str, float] = {}

        self._futures_symbol_cache: Dict[str, str] = {}
        self._fsc_lock = threading.RLock()   # protects _futures_symbol_cache

        # OHLC staleness monitor — mirrors Lalaji bot's last_ohlc_update dict
        self._last_ohlc_update: Dict[str, datetime] = {}
        self._ohlc_update_lock = threading.Lock()

        # Threading
        self._tm_lock    = threading.Lock()
        self._stop_event = threading.Event()
        self._last_cycle  = 0.0
        self._started_at = time.monotonic()   # EOD-MCX-FIX: uptime guard for cold-restart

        self._last_order_time: Dict[str, float] = defaultdict(float)

        # Tracks order-IDs of CLOSED rows whose close-hooks have already fired.
        # Pre-populated at startup with all pre-existing CLOSED rows so that
        # historical trades from prior sessions never re-trigger whipsaw
        # cooldowns or stop-removal on restart.
        self._closed_hooks_fired: set = set()

        # F-07: Per-position entry-snapshot state for momentum-failure detection.
        # Keyed by symbol. Populated when a row transitions OPEN→INPOSITION.
        # Cleared in _fire_close_hooks() on every position close.
        self._mf_entry_brick_count: Dict[str, int] = {}   # CBC at entry
        self._mf_entry_direction:   Dict[str, int] = {}   # +1 CALL, -1 PUT
        self._mf_bricks_since:      Dict[str, int] = {}   # brick count since entry

        # F-08: Per-position retest state for breakout-retest detection.
        # Keyed by symbol. Cleared in _fire_close_hooks() on every position close.
        # Structure: {"active": bool, "confirmed": bool, "retest_low"/"retest_high": float}
        self._retest_state: Dict[str, dict] = {}

        # Throttle for periodic position-status heartbeat (matches Lalaji bot's
        # TRAIL_PRINT_INTERVAL = 30s, but also prints immediately on any change)
        self._last_status_print:  float = 0.0      # monotonic timestamp
        self._last_status_hash:   str   = ""        # detect changes → force-print

        # B-6 PERF FIX: _has_equity cached once at startup.
        # The old code called symbols_df.iterrows() twice per 5s cycle (lines 374
        # and 412) to check if any symbol is NSE/BSE.  symbols_df never changes at
        # runtime, so computing this boolean once and storing it eliminates two
        # iterrows() calls per cycle.  Set False here; _cache_has_equity() populates
        # it during run() before the main loop starts.
        self._has_equity: bool = False

    # ── Public entry point ─────────────────────────────────────────────────────

    def run(self, symbols_df: pd.DataFrame) -> None:
        log.info("=" * 70)
        log.info("🚀 TCOS-L Trading Engine starting")
        log.info("=" * 70)

        self._init_brick_sizes(symbols_df)
        self._cache_has_equity(symbols_df)   # B-6: compute once, never re-iterate

        from tcos_bot.core.ws_manager import ws_manager as _wsm
        import tcos_bot.core.ws_manager as _wsmod
        self._ws_manager = WebSocketManager(self._client)
        _wsmod.ws_manager = self._ws_manager
        self._ws_manager.start(symbols_df, ltp_callback=None)

        # Wire feed-health gate: signal_generator._create_entry() checks
        # _ws_manager_instance.is_feed_healthy() before every new entry.
        # Setting it here activates the gate; None = gate transparent (test env).
        import tcos_bot.signals.signal_generator as _sg
        _sg._ws_manager_instance = self._ws_manager
        log.info("🔌 Feed-health entry gate wired to WebSocketManager")

        ohlc_thread = threading.Thread(
            target=self._ohlc_refresh_loop,
            args=(symbols_df,),
            daemon=True,
            name="ohlc-thread",
        )
        ohlc_thread.start()

        ohlc_monitor_thread = threading.Thread(
            target=self._ohlc_monitor_loop,
            args=(symbols_df,),
            daemon=True,
            name="ohlc-monitor",
        )
        ohlc_monitor_thread.start()

        watchdog = threading.Thread(
            target=self._watchdog_loop,
            daemon=True,
            name="watchdog",
        )
        watchdog.start()

        # C-1 FIX: start the RiskEngine circuit-breaker thread.
        # Without this call the thread never runs, so daily-max-loss,
        # consecutive-loss, and kill-switch guards are all dead code.
        log.info("⚡ Starting RiskEngine circuit-breaker thread…")
        risk_engine.start()

        log.info("🌐 Seeding LTP from REST quotes…")
        self._seed_ltp(symbols_df)

        # B-4b PERF FIX: initial OHLC seed also runs in parallel.
        # Same pattern as the 30s refresh loop: fetch all symbols concurrently.
        # Each symbol gets 3 retry attempts with 2s sleep between them.
        # If a symbol fails all 3 attempts, it will be picked up by the first
        # 30s refresh cycle — no data loss, just a slightly delayed first signal.
        # Saves 2-4s of startup time vs sequential fetch, critical for mid-session
        # crash recovery where every second of Renko lag costs signal quality.
        log.info("📊 Initial OHLC fetch (parallel)…")
        from concurrent.futures import ThreadPoolExecutor, as_completed as _as_completed

        def _seed_one(sym: str, ex: str) -> None:
            """Fetch OHLC + build Renko for one symbol with 3-attempt retry."""
            bs      = self._brick_sizes.get(sym, 50.0)
            ohlc_df = None
            for attempt in range(3):
                try:
                    ohlc_df = self._fetch_ohlc(sym, ex)
                    if ohlc_df is not None and not ohlc_df.empty:
                        break
                    if attempt < 2:
                        log.warning(
                            "⚠️ OHLC seed attempt %d/3 failed for %s — retrying in 2s",
                            attempt + 1, sym,
                        )
                        time.sleep(2)
                except Exception:
                    log.exception("Initial OHLC fetch failed for %s (attempt %d/3)", sym, attempt + 1)
                    if attempt < 2:
                        time.sleep(2)
            try:
                if ohlc_df is not None and not ohlc_df.empty:
                    # BUG-7 FIX: write through protected cache
                    self._ohlc_cache.set(sym, ohlc_df)
                    anchor   = self._compute_anchor(sym, bs, ohlc_df)
                    renko_df = self._renko_gen.generate(ohlc_df, bs, anchor)
                    if not renko_df.empty:
                        self._renko_cache.set(sym, renko_df)
                        log.info("✅ Initial Renko ready for %s: %d bricks", sym, len(renko_df))
                else:
                    log.warning(
                        "⚠️ OHLC seed gave up for %s after 3 attempts — "
                        "will retry at next refresh cycle", sym,
                    )
            except Exception:
                log.exception("Initial OHLC cache/renko build failed for %s", sym)

        _seed_pairs = [(str(r["symbol"]), str(r["exchange"])) for _, r in symbols_df.iterrows()]
        with ThreadPoolExecutor(max_workers=max(1, len(_seed_pairs)),
                                thread_name_prefix="ohlc-seed") as _pool:
            _futs = {_pool.submit(_seed_one, s, e): s for s, e in _seed_pairs}
            for _fut in _as_completed(_futs):
                _sym = _futs[_fut]
                try:
                    _fut.result()
                except Exception:
                    log.exception("Initial OHLC seed error for %s", _sym)

        if self._futures_symbol_cache and self._ws_manager:
            log.info(
                "📡 Re-subscribing WS with %d resolved futures contract(s)…",
                len(self._futures_symbol_cache),
            )
            with self._fsc_lock:
                fsc = dict(self._futures_symbol_cache)
            self._ws_manager.set_futures_symbol_map(fsc, symbols_df)

        log.info("♻️  Reseeding trailing stop state from DB…")
        self._reseed_trailing_stops()

        log.info("🔄 Running startup reconciliation…")
        startup_reconcile(
            client       = self._client,
            known_roots  = list(self._brick_sizes.keys()),
            brick_sizes  = self._brick_sizes,
        )

        # Bug fix: _reseed_trailing_stops() ran BEFORE startup_reconcile(),
        # so any position that startup_reconcile just imported was invisible
        # to the reseed — trailing_stop_mgr never initialised for it.
        # Those positions got a fixed 3% stop row but no trailing management:
        # breakeven never triggered, stop never advanced, peak never tracked.
        # Fix: reseed again after reconcile so imported positions are included.
        log.info("♻️  Re-seeding trailing stops after reconcile (picks up imports)…")
        self._reseed_trailing_stops()

        # Pre-populate the close-hook fired set with every CLOSED row already
        # in the DB.  This prevents historical trades from prior sessions from
        # re-triggering whipsaw cooldowns and stop-removal on each restart.
        try:
            _startup_tm = trade_store.read_df()
            _closed_mask = (
                _startup_tm["renko_signal"].isin(["BUYCL", "BUYPT"]) &
                (_startup_tm["order_status"] == "CLOSED")
            )
            for _, _row in _startup_tm[_closed_mask].iterrows():
                _oid = str(_row.get("orderid") or "")
                if _oid and _oid not in ("", "nan", "None"):
                    self._closed_hooks_fired.add(_oid)
                else:
                    _sym = str(_row.get("symbol", ""))
                    _act = str(_row.get("renko_signal", ""))
                    _dir = "CALL" if _act == "BUYCL" else "PUT"
                    _cr  = str(_row.get("close_reason") or "")
                    self._closed_hooks_fired.add(f"{_sym}:{_dir}:{_cr}")
            log.info(
                "🔒 Pre-seeded close-hook guard: %d historical CLOSED row(s) skipped on restart",
                _closed_mask.sum(),
            )
        except Exception:
            log.warning("Could not pre-seed close-hook guard — historical rows may re-fire once")

        log.info("Main loop started — cycling every %.0fs", _CYCLE_INTERVAL_SECS)
        while not self._stop_event.is_set():
            cycle_start = time.monotonic()
            try:
                self._cycle(symbols_df)
            except Exception:
                log.exception("Unhandled exception in main cycle — continuing")
                print(
                    f"\n{'='*60}\n"
                    f"CYCLE CRASH at {_now().strftime('%H:%M:%S')} — see log\n"
                    f"{'='*60}",
                    file=sys.stderr,
                )
            elapsed = time.monotonic() - cycle_start
            sleep_t = max(0.1, _CYCLE_INTERVAL_SECS - elapsed)
            time.sleep(sleep_t)

        log.info("Engine stopped.")

    def stop(self) -> None:
        self._stop_event.set()
        risk_engine.stop()   # C-1 FIX: signal the circuit-breaker thread to exit
        if self._ws_manager:
            self._ws_manager.stop()
        log.info("🛑 Engine stop requested")

    # ── Main cycle ─────────────────────────────────────────────────────────────

    def _cycle(self, symbols_df: pd.DataFrame) -> None:
        now = time.monotonic()
        if now - self._last_cycle < _ORDER_THROTTLE_SECS:
            return
        self._last_cycle = now

        # ── EOD engine stop ───────────────────────────────────────────────────
        # Check at the very top so no new work starts after market close.
        # self.stop() sets _stop_event; the while loop in run() exits after
        # this cycle completes — all threads are shut down cleanly.
        #
        # EOD-MCX-FIX — two guards added:
        #
        #   Guard 1 (has_equity): NSE close (15:30) only applies when the
        #   session includes at least one NSE/BSE symbol.  MCX-only sessions
        #   (CRUDEOIL, NATURALGAS) trade until 23:30 and must not be stopped
        #   by the NSE close check.  Uses the same _EQUITY_EXCHANGES set that
        #   already gates day-regime classification (line ~1300).
        #
        #   Guard 2 (uptime >= 60s): a cold restart after 15:30 must not
        #   immediately terminate.  A bot restarted at 20:55 for testing or
        #   log inspection should start normally.  Only stop if the bot has
        #   been running long enough to have been active during market hours.
        #   60s is safe: Renko loads in <30s; any genuine EOD bot will have
        #   been running for hours, not seconds.
        #
        #   MCX-only path: when no equity symbols are present, check mcx_close
        #   (23:30) instead so MCX sessions still get a clean shutdown.
        _now_t        = _now().time()
        _running_secs = time.monotonic() - self._started_at
        _uptime_ok    = _running_secs >= 60.0
        _has_equity   = self._has_equity   # B-6: read cached value, no iterrows

        if not self._stop_event.is_set():
            if _has_equity:
                # NSE/BSE session (or mixed) — stop at nse_close
                _nse_close_t = dtime(*map(int, cfg.market_hours.nse_close.split(":")))
                if _now_t >= _nse_close_t and _uptime_ok:
                    log.info(
                        "🛑 EOD: NSE market closed (%s) — stopping engine",
                        cfg.market_hours.nse_close,
                    )
                    self.stop()
                    return
            else:
                # MCX-only session — stop at mcx_close (23:30)
                _mcx_close_t = dtime(*map(int, cfg.market_hours.mcx_close.split(":")))
                if _now_t >= _mcx_close_t and _uptime_ok:
                    log.info(
                        "🛑 EOD: MCX market closed (%s) — stopping engine",
                        cfg.market_hours.mcx_close,
                    )
                    self.stop()
                    return
        # ─────────────────────────────────────────────────────────────────────

        pipeline = self._signal_gen.pipeline
        if pipeline.should_classify_today():
            now_t  = _now().time()
            cutoff = dtime(9, 30)
            if now_t >= cutoff:
                # Only attempt equity regime classification if at least one
                # equity-index symbol is in the instrument list.  For MCX-only
                # sessions (CRUDEOIL, GOLDM, SILVERM, NATURALGAS) there are no
                # equity instruments — _classify_day() would warn every 5s and
                # never set _classified_date, causing perpetual re-attempts.
                if self._has_equity:   # B-6: read cached value, no iterrows
                    self._classify_day(symbols_df)
                else:
                    # MCX-only: mark as classified with UNKNOWN regime so the
                    # half-size caution path applies and the warning stops.
                    pipeline._classified_date = _now().date()
                    log.info(
                        "📊 MCX-only session — skipping equity regime classification "
                        "(no NSE/BSE instruments). Pipeline will use UNKNOWN/half-size."
                    )

        # C-2 FIX: fetch broker positions BEFORE acquiring _tm_lock.
        # The old code fetched inside the lock, meaning a 30-second broker
        # timeout blocked the watchdog thread (timeout=20) for the entire
        # duration.  Positions change slowly enough that a pre-lock fetch
        # (a few milliseconds before lock acquisition) is always safe.
        positions_df = self._position_tracker.fetch()
        api_ok       = positions_df is not None
        if not api_ok:
            log.warning("⚠️ Positions API returned None")
            positions_df = pd.DataFrame()
        elif positions_df.empty:
            log.info("📭 Broker positionbook is empty (all positions flat).")

        if not self._tm_lock.acquire(timeout=10):
            log.error("tm_lock timeout — skipping cycle")
            return
        try:
            tm = trade_store.read_df()
            known_roots    = list(self._brick_sizes.keys())  # traded symbols
            root_positions = self._position_tracker.build_root_map(positions_df, known_roots)

            if api_ok:
                tm, reconciled = cycle_reconcile(tm, root_positions, api_ok=True)
                any_changed = reconciled
            else:
                log.warning("⚠️ Skipping cycle reconciler: positions API failed.")
                any_changed = False

            for _, sym_row in symbols_df.iterrows():
                symbol   = str(sym_row["symbol"])
                exchange = str(sym_row["exchange"])

                # BUG-7 FIX: read through protected cache
                renko_df = self._renko_cache.get(symbol)
                ohlc_df  = self._ohlc_cache.get(symbol)
                bs       = self._brick_sizes.get(symbol, 50.0)

                if renko_df is None or renko_df.empty:
                    log.debug("⏳ No Renko yet for %s", symbol)
                    continue

                root = symbol
                pos  = root_positions.get(root, {"CALL": 0, "PUT": 0})

                tm, changed = self._signal_gen.process(
                    trade_manager=tm, symbol=symbol, exchange=exchange,
                    renko_df=renko_df, ohlc_df=ohlc_df, brick_size=bs,
                    root_positions=pos,
                )
                any_changed = any_changed or changed

                ltp, ltp_age = ltp_store.get(symbol)
                if ltp:
                    # Degraded-mode guard: if WS is stale with open positions,
                    # freeze trailing-stop ADVANCES (peak updates) but keep hard
                    # stop-loss protection active.  Exits always proceed.
                    # FIX-3: Allow advance even in degraded mode when REST has
                    # refreshed LTP recently (age < ltp_hard_block_secs).
                    # Old code froze ALL advances the moment in_degraded_mode=True,
                    # even if the REST fallback loop had just polled a fresh price
                    # 2 seconds ago — meaning profits could not be locked during a
                    # brief WS glitch.
                    _degraded = (
                        self._ws_manager is not None and
                        self._ws_manager.in_degraded_mode
                    )
                    _ltp_fresh = ltp_age < cfg.broker.ltp_hard_block_secs
                    if _degraded and not _ltp_fresh:
                        log.debug(
                            "⚠️ DEGRADED MODE: trailing-stop advance frozen for %s (ltp_age=%.1fs)",
                            symbol, ltp_age,
                        )
                        new_stop = None   # no peak advance; hard stop still enforced below
                    else:
                        # Wire on_brick_confirm: pass the latest confirmed brick close
                        # so TrailingStopManager can gate peak updates to brick events,
                        # not every LTP tick.  Falls back gracefully to None if no Renko.
                        latest_brick = None
                        if renko_df is not None and not renko_df.empty:
                            brick_col = "Renko_Brick" if "Renko_Brick" in renko_df.columns else "close"
                            latest_brick = float(renko_df.iloc[-1][brick_col])
                        new_stop = trailing_stop_mgr.update(symbol, ltp, new_brick=latest_brick)
                    if new_stop is not None:
                        self._update_stop_in_tm(tm, symbol, exchange, new_stop)
                        any_changed = True

                    tm, chg = nft_checker.check_and_annotate(tm, symbol, exchange, ltp, bs, renko_df)
                    any_changed = any_changed or chg

                    # FIX I-10: pass live current_regime so Gate 4 uses current
                    # regime not stale entry-time regime from trade row.
                    _pipeline_regime = self._signal_gen.pipeline.current_regime
                    _live_regime_str = (
                        _pipeline_regime.value if _pipeline_regime else None
                    )
                    tm, chg = chop_checker.check_and_annotate(
                        tm, symbol, exchange, ltp, bs,
                        renko_df=renko_df,
                        current_regime=_live_regime_str,
                    )
                    any_changed = any_changed or chg

                    # ── F-07: Momentum-failure detection ──────────────────────
                    # Runs AFTER NFT/chop checks so it does not race them.
                    # Feature-flagged: cfg.stop.momentum_failure_enabled (default False).
                    _mf_enabled = getattr(cfg.stop, "momentum_failure_enabled", False)
                    if _mf_enabled and renko_df is not None and not renko_df.empty:
                        tm, chg = self._check_momentum_failure(
                            tm, symbol, exchange, ltp, bs, renko_df
                        )
                        any_changed = any_changed or chg
                    # ──────────────────────────────────────────────────────────

                    # ── F-08: Breakout retest detection ────────────────────────
                    # Feature-flagged: cfg.stop.retest_mode_enabled (default False).
                    _rt_enabled = getattr(cfg.stop, "retest_mode_enabled", False)
                    if _rt_enabled:
                        tm, chg = self._check_retest_state(
                            tm, symbol, exchange, ltp, bs
                        )
                        any_changed = any_changed or chg
                    # ──────────────────────────────────────────────────────────

            # ── ISSUE-C + ISSUE-D FIX: fire close hooks on every newly-CLOSED row ──
            # This wires two things that were missing:
            #   1. whipsaw_tracker.record_flip(exit_reason=...) so the adaptive
            #      cooldown knows WHY the trade closed (chop/NFT = short cooldown,
            #      stoploss = longer cooldown).  Without this, exit_reason was
            #      always "" and false_chop_cooldown_secs never fired.
            #   2. chop_checker.clear_pending(symbol) so two-stage pending state
            #      from a previous trade on the same symbol doesn't bleed into the
            #      next trade.
            #
            # We look for rows that JUST became CLOSED this cycle (close_price
            # was set but trailing_stop_mgr still has state = position just closed).
            # ── EOD squareoff at 15:25 ──────────────────────────────────
            tm, eod_changed = self._check_eod_squareoff(tm)
            any_changed = any_changed or eod_changed
            # ─────────────────────────────────────────────────────────────

            self._fire_close_hooks(tm)

            tm, exec_changed = self._execute_open_orders(tm, positions_df)
            any_changed = any_changed or exec_changed

            if any_changed:
                trade_store.save_df(tm)

            # Snapshot for status display — taken inside lock for consistent read,
            # but the actual logging happens after the lock is released below.
            tm_snapshot = tm

        finally:
            self._tm_lock.release()

        # ── Periodic position heartbeat (outside lock — read-only display) ──
        # Logging may call ltp_store.get() and _renko_cache.get() which have
        # their own fine-grained locks; no reason to hold _tm_lock here.
        self._log_position_status(tm_snapshot)

    # ── EOD squareoff ──────────────────────────────────────────────────────────

    def _check_eod_squareoff(self, tm: pd.DataFrame) -> tuple:
        """
        EOD squareoff: at eod_squareoff_time (15:25) create SELCL/SELPT exit
        rows for every NSE/BSE INPOSITION trade so the engine closes all open
        positions before market close at 15:30.

        Design decisions
        ----------------
        - Follows the exact same exit-row pattern as NFT and ChopOscillation
          (creates an OPEN SELCL/SELPT row; _execute_open_orders dispatches it).
        - Duplicate-guarded: if an exit row already exists (OPEN/SENDING), no
          second row is created.
        - MCX instruments are excluded — they trade until 23:30 and have their
          own session cutoff.
        - Idempotent: fires every 2-second cycle from 15:25 onward until all
          positions are closed (the 'already' guard prevents duplicate orders).
        - close_reason = "EOD_SQUAREOFF" so _fire_close_hooks and the whipsaw
          tracker see a clean reason string.
        """
        import pandas as _pd
        _now_t    = _now().time()
        _eod_str  = getattr(cfg.market_hours, "eod_squareoff_time", "15:25")
        _eod_t    = dtime(*map(int, _eod_str.split(":")))

        if _now_t < _eod_t:
            return tm, False

        _NSE_BSE = {"NSE_INDEX", "BSE_INDEX", "NFO", "BFO", "NSE", "BSE"}
        changed  = False

        inpos_mask = (
            tm["renko_signal"].isin(["BUYCL", "BUYPT"]) &
            (tm["order_status"] == "INPOSITION")
        )

        for _, row in tm[inpos_mask].iterrows():
            symbol   = str(row.get("symbol", ""))
            exchange = str(row.get("exchange", "")).upper()
            action   = str(row.get("renko_signal", ""))
            qty      = int(row.get("quantity") or 0)

            # MCX instruments: skip — they have a different session end
            if exchange not in _NSE_BSE:
                log.debug(
                    "🌅 EOD_SQUAREOFF skip %s %s: MCX exchange — not NSE/BSE",
                    symbol, action,
                )
                continue

            exit_sig = "SELCL" if action == "BUYCL" else "SELPT"

            # Duplicate guard — same pattern as NFT and ChopOscillation
            already = not tm[
                (tm["symbol"] == symbol) &
                (tm["renko_signal"] == exit_sig) &
                (tm["order_status"].isin(("OPEN", "SENDING")))
            ].empty
            if already:
                log.debug(
                    "🌅 EOD_SQUAREOFF %s: exit row already exists (%s) — skip",
                    symbol, exit_sig,
                )
                continue

            ltp, ltp_age = ltp_store.get(symbol)
            ltp = float(ltp or 0)

            new_row = _pd.DataFrame([{
                "exchange":     exchange,
                "timestamp":    _now().strftime("%Y-%m-%d %H:%M:%S"),
                "symbol":       symbol,
                "renko_signal": exit_sig,
                "entry_price":  ltp,
                "quantity":     qty,
                "order_status": "OPEN",
                "close_reason": "EOD_SQUAREOFF",
            }])
            tm = _pd.concat([tm, new_row], ignore_index=True)
            changed = True
            log.info(
                "🌅 EOD_SQUAREOFF %s %s: creating %s exit "
                "(time=%s >= eod=%s ltp=%.2f qty=%d)",
                symbol, action, exit_sig,
                _now_t.strftime("%H:%M"), _eod_str, ltp, qty,
            )

        return tm, changed

    # ── Position status heartbeat ──────────────────────────────────────────────

    def _log_position_status(self, tm: pd.DataFrame) -> None:
        """
        Logs a one-line status for every INPOSITION row every 30 s
        (or immediately whenever stop/P&L changes), matching the Lalaji bot's
        _trail_status_line + 📊 Position Check output.

        Format (entry):
          📍 CALL NIFTY | TRAILING | LTP P&L: +120pts (+2.4b) | brick P&L: +100pts (+2.0b)
             | entry=22300 ltp=22420 brick=22380 stop=22320 | trailing 1.5b behind price

        Format (summary):
          📊 NIFTY INPOSITION: CALL=1 PUT=0 | opt=NIFTY24JAN22400CE ltp=₹85.0→₹127.5 (+50.0%)
        """
        inpos_mask = tm["order_status"] == "INPOSITION"
        if not inpos_mask.any():
            return

        now_mono = time.monotonic()
        rows     = tm[inpos_mask]

        # Build a hash of key fields so we force-print on any change
        try:
            _hash_fields = rows[["symbol", "entry_price", "close_price"]].to_csv(index=False)
        except Exception:
            _hash_fields = str(len(rows))

        # ── Fetch stop prices from trailing_stop_mgr ─────────────────────────
        stop_map: Dict[str, float] = {}
        for sym in rows["symbol"].unique():
            sp = trailing_stop_mgr.get_stop_price(str(sym))
            if sp:
                stop_map[str(sym)] = sp

        _hash_fields += str(stop_map)
        changed = _hash_fields != self._last_status_hash

        if not changed and (now_mono - self._last_status_print) < _STATUS_PRINT_SECS:
            return

        self._last_status_print = now_mono
        self._last_status_hash  = _hash_fields

        for _, row in rows.iterrows():
            symbol     = str(row.get("symbol", "?"))
            action     = str(row.get("renko_signal", "?"))
            direction  = "CALL" if action == "BUYCL" else "PUT"
            entry_px   = float(row.get("index_ltp") or row.get("entry_price") or 0)
            opt_sym    = str(row.get("option_symbol") or symbol)
            bs         = float(row.get("brick_size_hint") or self._brick_sizes.get(symbol, 50.0))
            stop_px    = stop_map.get(symbol)
            nft_tgt    = float(row.get("nft_target") or 0)
            nft_val    = int(row.get("nft_validated") or 0)

            ltp, _ = ltp_store.get(symbol)
            opt_ltp, _ = ltp_store.get(opt_sym)

            # ── Brick-based P&L ───────────────────────────────────────────────
            if entry_px > 0 and bs > 0:
                renko_df = self._renko_cache.get(symbol)
                cur_brick = (
                    float(renko_df.iloc[-1]["close"]) if (
                        renko_df is not None and not renko_df.empty
                    ) else entry_px
                )
                brick_profit_pts   = (cur_brick - entry_px) if direction == "CALL" else (entry_px - cur_brick)
                brick_profit_bricks = brick_profit_pts / bs
            else:
                cur_brick = entry_px
                brick_profit_pts = brick_profit_bricks = 0.0

            # ── LTP-based P&L ─────────────────────────────────────────────────
            if ltp and entry_px > 0 and bs > 0:
                ltp_profit_pts    = (ltp - entry_px) if direction == "CALL" else (entry_px - ltp)
                ltp_profit_bricks = ltp_profit_pts / bs
                use_bricks        = ltp_profit_bricks
            else:
                ltp_profit_pts = ltp_profit_bricks = 0.0
                use_bricks     = brick_profit_bricks

            # ── Stage label — FIX I-05: based on actual stop price, not LTP ────
            # Old code used LTP bricks which showed "TRAILING" even when the
            # stop hadn't actually advanced yet (on_brick_confirm lag). This
            # caused the "10k on screen" confusion. Now derived from real stop.
            trail_dist   = cfg.trailing.trail_distance
            trail_be     = cfg.trailing.breakeven_after
            trail_start  = cfg.trailing.trail_start_after
            _be_buffer   = getattr(cfg.trailing, "breakeven_buffer", 0.25) * bs

            if stop_px is not None and entry_px > 0:
                _direction_ok = (direction == "CALL" and stop_px > entry_px + _be_buffer - 1) or                                 (direction == "PUT"  and stop_px < entry_px - _be_buffer + 1)
                _be_hit = (direction == "CALL" and stop_px >= entry_px + _be_buffer - 1) or                           (direction == "PUT"  and stop_px <= entry_px - _be_buffer + 1)
                # locked_pts = how much profit is actually secured by stop right now
                _locked = (stop_px - entry_px) if direction == "CALL" else (entry_px - stop_px)
                _locked_b = _locked / bs if bs > 0 else 0
                if _be_hit and _locked_b >= trail_start - 0.1:
                    stage     = "TRAILING"
                    next_info = f"trailing {trail_dist}b behind price"
                elif _be_hit:
                    need_pts  = (trail_start - _locked_b) * bs
                    stage     = "BREAKEVEN"
                    next_info = f"trail starts in +{need_pts:.0f}pts (+{trail_start - _locked_b:.1f}b)"
                elif use_bricks >= 0:
                    need_pts  = (trail_be - use_bricks) * bs
                    stage     = "WAITING"
                    next_info = f"breakeven in +{need_pts:.0f}pts (+{trail_be - use_bricks:.1f}b)"
                else:
                    stage     = "UNDERWATER"
                    next_info = f"need +{abs(use_bricks * bs):.0f}pts to get back to entry"
            elif use_bricks >= trail_start:
                stage     = "TRAILING"
                next_info = f"trailing {trail_dist}b behind price"
            elif use_bricks >= trail_be:
                need_pts  = (trail_start - use_bricks) * bs
                stage     = "BREAKEVEN"
                next_info = f"trail starts in +{need_pts:.0f}pts (+{trail_start - use_bricks:.1f}b)"
            elif use_bricks >= 0:
                need_pts  = (trail_be - use_bricks) * bs
                stage     = "WAITING"
                next_info = f"breakeven in +{need_pts:.0f}pts (+{trail_be - use_bricks:.1f}b)"
            else:
                stage     = "UNDERWATER"
                next_info = f"need +{abs(use_bricks * bs):.0f}pts to get back to entry"

            stop_str  = f"stop={stop_px:.0f}" if stop_px else "stop=INITIAL"
            ltp_str   = f" ltp={ltp:.0f}" if ltp else ""
            pnl_str   = (
                f"LTP P&L: {ltp_profit_pts:+.0f}pts ({ltp_profit_bricks:+.1f}b)"
                f" | brick P&L: {brick_profit_pts:+.0f}pts ({brick_profit_bricks:+.1f}b)"
                if ltp else
                f"P&L: {brick_profit_pts:+.0f}pts ({brick_profit_bricks:+.1f}b)"
            )
            nft_str   = (
                f" | NFT={'✅' if nft_val else f'⏳→{nft_tgt:.0f}'}"
                if cfg.nft.enabled and nft_tgt > 0 else ""
            )

            log.info(
                "📍 %s %s | %s | %s | entry=%d%s brick=%d %s | %s%s",
                direction, symbol, stage, pnl_str,
                int(entry_px), ltp_str, int(cur_brick), stop_str,
                next_info, nft_str,
            )

            # ── Option P&L summary line (matches old bot's 📊 Position Check) ─
            if opt_ltp and opt_sym != symbol:
                opt_entry = float(row.get("option_entry_price") or 0)
                if opt_entry > 0 and opt_ltp > 0:
                    opt_pnl_pct = (opt_ltp - opt_entry) / opt_entry * 100
                    opt_info = f"₹{opt_entry:.1f}→₹{opt_ltp:.1f} ({opt_pnl_pct:+.1f}%)"
                else:
                    opt_info = f"₹{opt_ltp:.1f}"
                log.info("📊 %s INPOSITION: %s=1 | opt=%s %s", symbol, direction, opt_sym, opt_info)

    # ── Order execution loop ───────────────────────────────────────────────────

    def _execute_open_orders(
        self,
        tm:           pd.DataFrame,
        positions_df: Optional[pd.DataFrame],
    ) -> tuple[pd.DataFrame, bool]:
        open_mask = tm["order_status"] == "OPEN"
        if not open_mask.any():
            return tm, False

        changed  = False
        now_mono = time.monotonic()
        _dispatched_exits: set[str] = set()

        for index, row in tm[open_mask].iterrows():
            action   = str(row.get("renko_signal", ""))
            symbol   = str(row.get("symbol", ""))
            exchange = str(row.get("exchange", ""))
            entry_price = float(row.get("entry_price") or 0)

            # C-1 FIX: check RiskEngine circuit-breaker before every new entry.
            # Exits (SEL*) always pass — we never block closing an open position.
            if action in ("BUYCL", "BUYPT"):
                allowed, halt_reason = risk_engine.is_entry_allowed()
                if not allowed:
                    log.warning(
                        "🚫 RISK_ENGINE HALT — blocking %s %s: %s",
                        action, symbol, halt_reason,
                    )
                    continue

            if action.startswith("SEL"):
                exit_key = f"{symbol}:{action}"
                if exit_key in _dispatched_exits:
                    log.warning("🚫 Double-exit blocked: %s %s", action, symbol)
                    continue
                _dispatched_exits.add(exit_key)

                # Pre-flight: re-verify broker position before any SELL.
                # C-16 FIX: pass the positions_df already fetched at cycle start
                # instead of triggering a new positionbook() REST call per exit
                # row while _tm_lock is held.
                direction = "CALL" if action in ("SELCL", "SELST") else "PUT"
                if not preflight_position_check(
                    self._client, symbol, str(row.get("option_symbol", "")),
                    direction, list(self._brick_sizes.keys()),
                    cached_positions_df=positions_df,
                ):
                    # Do NOT set to CANCELLED here.
                    #
                    # Bug: marking the row CANCELLED caused _create_exit to
                    # create a brand-new SELCL every 5-second cycle because
                    # its duplicate guard only checks (OPEN, SENDING, INPOSITION).
                    # A fresh OPEN row appeared each cycle → preflight blocked it
                    # → CANCELLED → repeat, producing 8+ duplicate exit rows per
                    # minute while the bot waited for cycle_reconcile (grace=60s)
                    # to detect the flat position and clean up.
                    #
                    # Fix: leave the row as OPEN. The duplicate guard finds it
                    # next cycle and suppresses new rows. cycle_reconcile will
                    # cancel it cleanly once it marks the parent INPOSITION
                    # CLOSED (via MANUAL_CLOSE_DETECTED or RECONCILE_BROKER_FLAT).
                    continue

            order_key = f"{symbol}:{action}"
            if now_mono - self._last_order_time[order_key] < _ORDER_THROTTLE_SECS:
                continue

            ltp, ltp_age = ltp_store.get(symbol)
            if ltp is None:
                continue

            if action in ("BUYCL", "BUYPT"):
                # Gate 1: LTP age (REST-sourced freshness)
                if ltp_age > cfg.broker.ltp_hard_block_secs:
                    log.warning(
                        "🚫 STALE LTP entry block %s: age=%.1fs (hard_block=%.0fs)",
                        symbol, ltp_age, cfg.broker.ltp_hard_block_secs,
                    )
                    continue
                # Gate 2: WS heartbeat health (true feed-level freshness)
                # REST fallback may inject a fresh LTP while WS is dead.
                # is_feed_healthy() tests the WS heartbeat timestamp directly.
                if self._ws_manager and not self._ws_manager.is_feed_healthy():
                    feed_age = self._ws_manager.feed_age_secs()
                    log.warning(
                        "🚫 WS FEED UNHEALTHY: blocking %s %s entry — "
                        "feed_age=%.1fs. Waiting for reconnect.",
                        action, symbol, feed_age,
                    )
                    continue

            # ── Drift cancel: abort entry if market has moved away from
            #    signal price beyond the allowed threshold.  Prevents chasing
            #    into a breakout that already ran; avoids the "3.75b drift →
            #    immediate stop" pattern seen on T8 / T10.
            #
            #    Grade-A signals use a wider limit (grade_a_max_drift_bricks,
            #    default 3.0b) because a large drift on a Grade-A signal means
            #    confirmed momentum — 5 consecutive bricks + ZLEMA + HH structure
            #    all aligned.  Grade-B and below use the tighter max_drift_bricks
            #    (default 1.5b) as before.
            #    MCX-BUG-3 FIX: per-symbol override for Grade-B drift limit.
            #    CRUDEOIL brick=8: Grade-B 1.5b=12pts. In a MCX momentum session
            #    the 5-second engine cycle means price moves 13-16pts between
            #    signal and execution → every CRUDEOIL Grade-B entry cancelled.
            #    Override raises CRUDEOIL to 2.5b=20pts. NSE/BSE unchanged.
            if action in ("BUYCL", "BUYPT") and entry_price > 0:
                signal_grade = str(row.get("signal_grade") or "B")
                _drift_overrides = getattr(cfg.entry, "max_drift_bricks_override", {})
                _grade_b_limit = _drift_overrides.get(
                    symbol, cfg.entry.max_drift_bricks
                )
                max_drift = (
                    cfg.entry.grade_a_max_drift_bricks
                    if signal_grade == "A"
                    else _grade_b_limit
                )
                if max_drift > 0:
                    bs = float(row.get("brick_size_hint") or 50.0)
                    drift_b = (ltp - entry_price) / bs if action == "BUYCL" else (entry_price - ltp) / bs
                    if drift_b > max_drift:
                        log.warning(
                            "🚫 DRIFT CANCEL %s %s: ltp=%.2f signal=%.2f drift=%.2fb > %.2fb limit (grade=%s)",
                            action, symbol, ltp, entry_price, drift_b, max_drift, signal_grade,
                        )
                        tm.at[index, "order_status"] = "CANCELLED"
                        tm.at[index, "close_reason"] = f"DRIFT_CANCEL:{drift_b:.2f}b"
                        # Also cancel the sibling stop so it doesn't orphan
                        stop_sig = "SELST" if action == "BUYCL" else "SELSP"
                        sib_mask = (
                            (tm["symbol"] == symbol) &
                            (tm["renko_signal"] == stop_sig) &
                            (tm["order_status"] == "OPEN")
                        )
                        if sib_mask.any():
                            tm.loc[sib_mask, "order_status"] = "CANCELLED"
                            tm.loc[sib_mask, "close_reason"] = "ENTRY_DRIFT_CANCEL"
                        changed = True
                        continue

            if action in ("SELST", "SELSP") and entry_price > 0:
                # ── SOLUTION B: brick-confirmed stop trigger ─────────────────
                # Stop fires only when the last COMPLETED Renko brick close
                # crosses the stop level — NOT on a raw LTP tick (wick).
                #
                # WHY: LTP is a raw tick updated every second. A wick touching
                # the stop price within a candle fires an immediate exit even
                # if the candle closes safely above the stop.  Today's proof:
                # SENSEX CALL stop=74254, LTP hit 74253 (1.67pts wick) → exit.
                # Candle closed above stop. Market went to 74,600 (+347pts lost).
                #
                # With brick-confirmed: stop only fires when the 1m candle
                # CLOSES beyond the stop, forming a completed Renko brick.
                # Wicks within a candle are absorbed. GAP-A FIX already strips
                # in-progress candles from the Renko, so latest_brick always
                # represents a COMPLETED 1-minute bar.
                #
                # FALLBACK: if renko_df is unavailable (startup, fetch failure)
                # → fall back to LTP check (existing behaviour). Safe.
                #
                # CATST (catastrophe stop) is NOT changed — it fires on raw LTP
                # inside trailing_stop_mgr.update() and must stay that way for
                # emergency gap-down protection.
                _renko_for_stop = self._renko_cache.get(symbol)
                if _renko_for_stop is not None and not _renko_for_stop.empty:
                    _brick_col   = ("Renko_Brick" if "Renko_Brick" in _renko_for_stop.columns
                                    else "close")
                    _latest_brick = float(_renko_for_stop.iloc[-1][_brick_col])
                    _check_price  = _latest_brick
                    _price_label  = "brick"
                else:
                    # Renko not loaded yet → fall back to LTP
                    _check_price  = ltp
                    _latest_brick = None
                    _price_label  = "ltp(fallback)"

                # FIX v7n: direction guard — stop only fires on confirmed OPPOSITE brick.
                # A PUT stop must only fire on an UP brick (genuine reversal).
                # A CALL stop must only fire on a DOWN brick (genuine reversal).
                # Prevents race condition where trailing stop (LTP-based) slips
                # below the confirmed brick level, causing a same-direction brick
                # to falsely trigger the stop.
                # Evidence: April 9 NIFTY PUT — DOWN brick at 23,880 with stop
                # at 23,866 fired the exit. No reverse brick on 1-min Renko chart.
                # LTP=23,854 had trailed stop below the confirmed DOWN brick.
                # Direction = None (unknown/renko fallback) → safe default → allow.
                if _renko_for_stop is not None and not _renko_for_stop.empty:
                    _brick_direction = int(
                        _renko_for_stop.iloc[-1].get("direction", 0) or 0
                    )
                else:
                    _brick_direction = None  # LTP fallback — skip direction guard

                if action == "SELST":
                    # Exit CALL: only a DOWN brick (-1) confirms reversal.
                    # UP brick (+1) = market still going in CALL's favour → skip.
                    if _brick_direction == 1:
                        continue   # UP brick — CALL's direction, not a reversal
                    if _check_price > entry_price:
                        continue   # brick has not closed below stop — no exit
                    log.info(
                        "🔴 STOP TRIGGERED %s SELST: %s=%.2f ≤ stop=%.2f (ltp=%.2f)",
                        symbol, _price_label, _check_price, entry_price, ltp,
                    )
                else:  # SELSP
                    # Exit PUT: only an UP brick (+1) confirms reversal.
                    # DOWN brick (-1) = market still going in PUT's favour → skip.
                    if _brick_direction == -1:
                        continue   # DOWN brick — PUT's direction, not a reversal
                    if _check_price < entry_price:
                        continue   # brick has not closed above stop — no exit
                    log.info(
                        "🔴 STOP TRIGGERED %s SELSP: %s=%.2f ≥ stop=%.2f (ltp=%.2f)",
                        symbol, _price_label, _check_price, entry_price, ltp,
                    )
                # ─────────────────────────────────────────────────────────────

            trading_symbol, trading_exchange, option_ltp = self._resolve_option(
                action, symbol, exchange, positions_df, tm=tm
            )
            if trading_symbol is None:
                continue

            quantity = int(row.get("quantity") or get_lot_size(symbol))

            self._last_order_time[order_key] = now_mono
            tm = self._order_router.execute_order(
                trade_manager    = tm,
                index            = index,
                row              = row,
                trading_symbol   = trading_symbol,
                trading_exchange = trading_exchange,
                index_ltp        = ltp,
                option_ltp       = option_ltp or 0.0,
                quantity         = quantity,
            )
            changed = True

        return tm, changed

    # ── Option resolution ──────────────────────────────────────────────────────

    def _resolve_option(self, action, symbol, exchange, positions_df, tm=None):
        """Resolve the option trading symbol for *action*.

        C-4 FIX: *tm* (trade_manager DataFrame) is now forwarded to
        OptionResolver.resolve() so the hint-based exit resolver can read the
        stored option_symbol from the INPOSITION entry row and pick the correct
        expiry during rollover overlap.  Previously tm was never passed and
        the hint was always None.
        """
        if not hasattr(self, "_option_resolver"):
            from tcos_bot.execution.option_resolver import OptionResolver
            self._option_resolver = OptionResolver(self._client)
        return self._option_resolver.resolve(action, symbol, exchange, positions_df,
                                             trade_manager=tm)

    # ── OHLC refresh (BUG-7: writes through protected cache) ──────────────────

    def _ohlc_refresh_loop(self, symbols_df: pd.DataFrame) -> None:
        """B-4 PERF FIX: parallel OHLC fetch via ThreadPoolExecutor.

        OLD: symbols fetched sequentially — NIFTY then BNF then SENSEX.
             If each HTTP call takes 1-2s, total = 3-6s before sleep(30).
        NEW: all symbols fetched concurrently.  Total = max(individual calls)
             ≈ 1-2s regardless of symbol count.

        Correctness: fetches are fully independent (no shared mutable state
        during fetch).  Cache writes remain protected by cache_lock exactly
        as before — ThreadPoolExecutor workers call _ohlc_refresh_one() which
        acquires the lock internally before writing.
        """
        from concurrent.futures import ThreadPoolExecutor, as_completed

        symbols_list = [
            (str(row["symbol"]), str(row["exchange"]))
            for _, row in symbols_df.iterrows()
        ]
        n_workers = max(1, len(symbols_list))

        log.info("📊 OHLC refresh thread started — fetching every %ds (parallel, %d workers)",
                 _OHLC_REFRESH_SECS, n_workers)

        while not self._stop_event.is_set():
            log.info("📊 OHLC refresh cycle starting… (%d symbols in parallel)", len(symbols_list))
            with ThreadPoolExecutor(max_workers=n_workers, thread_name_prefix="ohlc") as pool:
                futures = {
                    pool.submit(self._ohlc_refresh_one, symbol, exchange): symbol
                    for symbol, exchange in symbols_list
                }
                for fut in as_completed(futures):
                    symbol = futures[fut]
                    try:
                        fut.result()   # re-raises any exception from the worker
                    except Exception:
                        log.exception("OHLC refresh error for %s", symbol)
            time.sleep(_OHLC_REFRESH_SECS)

    def _ohlc_refresh_one(self, symbol: str, exchange: str) -> None:
        """Fetch OHLC + rebuild Renko for ONE symbol.  Called from thread pool."""
        bs = self._brick_sizes.get(symbol, 50.0)
        try:
            ohlc_df = self._fetch_ohlc(symbol, exchange)
            if ohlc_df is not None and not ohlc_df.empty:
                # BUG-7 FIX: both cache writes are protected by cache_lock
                anchor   = self._compute_anchor(symbol, bs, ohlc_df)
                renko_df = self._renko_gen.generate(ohlc_df, bs, anchor)
                with self._cache_lock:
                    self._ohlc_cache.set(symbol, ohlc_df)
                    if not renko_df.empty:
                        self._renko_cache.set(symbol, renko_df)
                        log.info("✅ Renko updated for %s: %d bricks", symbol, len(renko_df))
                    else:
                        log.warning("⚠️ Renko empty for %s", symbol)
                # Stamp successful update time for staleness monitor
                with self._ohlc_update_lock:
                    self._last_ohlc_update[symbol.upper()] = _now()
            else:
                log.warning("⚠️ OHLC fetch returned no data for %s", symbol)
        except Exception:
            log.exception("OHLC refresh error for %s", symbol)
            raise

    # ── OHLC staleness monitor (mirrors Lalaji bot's OHLC_UPDATE_TIMEOUT) ────

    # Per-symbol alert thresholds (seconds) matching old bot's thresholds
    _OHLC_STALE_THRESHOLDS: Dict[str, int] = {}  # filled lazily per-symbol

    @staticmethod
    def _ohlc_stale_threshold(symbol: str) -> int:
        """Return per-symbol staleness alert threshold in seconds.

        Rule of thumb: threshold = refresh_cycle (60s) × 2 + buffer.
        BSE_INDEX (SENSEX/BANKEX) get extra headroom because Flattrade
        occasionally takes longer on BFO data.
        """
        u = symbol.upper()
        if u.startswith(("NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY")):
            return 310    # 5 min 10 sec — NSE index (unchanged, already generous)
        if u.startswith(("SENSEX", "BANKEX")):
            return 180    # 3 min — BSE index: slower feed, needs headroom
        if u.endswith("FUT") or any(u.startswith(r) for r in ("CRUDE", "GOLD", "SILVER", "NATURALGAS")):
            return 150    # 2 min 30 sec — MCX / futures
        return 150        # 2 min 30 sec — default (was 70s, too tight vs 60s cycle)

    def _ohlc_monitor_loop(self, symbols_df: pd.DataFrame) -> None:
        """
        Periodically checks every tracked symbol for OHLC staleness and
        logs a 🚨 ALERT if no successful fetch has occurred within the
        per-symbol threshold.  Runs every 60 s, same cadence as Lalaji bot.
        Also prunes symbols that have been removed from symbols_df.
        """
        log.info("🔍 OHLC staleness monitor started")
        # Seed update timestamps so we don't false-alarm on cold start
        now = _now()
        tracked = set(symbols_df["symbol"].astype(str).str.upper())
        with self._ohlc_update_lock:
            for sym in tracked:
                self._last_ohlc_update.setdefault(sym, now)

        while not self._stop_event.is_set():
            time.sleep(_OHLC_REFRESH_SECS)
            now = _now()

            # Prune symbols no longer in active list
            with self._ohlc_update_lock:
                stale_map = dict(self._last_ohlc_update)
            for sym in list(stale_map.keys()):
                if sym.upper() not in tracked:
                    with self._ohlc_update_lock:
                        self._last_ohlc_update.pop(sym, None)

            # Alert on any symbol whose last update is overdue
            with self._ohlc_update_lock:
                stale_map = dict(self._last_ohlc_update)
            for symbol, last_update in stale_map.items():
                age_secs = (now - last_update).total_seconds()
                threshold = self._ohlc_stale_threshold(symbol)
                if age_secs > threshold:
                    log.warning(
                        "🚨 OHLC STALE: No successful update for %s in %ds (threshold: %ds)",
                        symbol, int(age_secs), threshold,
                    )

    # ── Deterministic Renko anchor (matches Lalaji bot's _deterministic_anchor) ─

    @staticmethod
    def _compute_anchor(symbol: str, brick_size: float, ohlc_df: pd.DataFrame) -> Optional[float]:
        """
        Compute a deterministic Renko grid anchor from the previous trading
        day's closing price (same logic as Lalaji bot's _deterministic_anchor).

        All bot instances starting on the same calendar day produce identical
        Renko grids, eliminating signal divergence between restarts.
        Uses round() not int() to avoid systematic directional bias.
        Returns None if ohlc_df has no prior-day data (caller falls back to
        the renko engine's default first-bar anchor).
        """
        if ohlc_df is None or ohlc_df.empty or brick_size <= 0:
            return None
        # B-5 PERF FIX: drop df.copy() — _compute_anchor never mutates the
        # input DataFrame (it only reads it), so copying 5,760 rows just to
        # call pd.to_datetime() on the timestamp column is wasteful.
        # Work directly on the input; parse timestamps into a local Series.
        ts_series = pd.to_datetime(ohlc_df["timestamp"])
        today     = pd.Timestamp.now(tz=IST).normalize().tz_localize(None)
        prev_mask = ts_series.dt.normalize() < today
        if not prev_mask.any():
            anchor_price = float(ohlc_df.iloc[0]["close"])
            # ANCHOR ALERT: no prev-day bars in OHLC window — using today's first bar
            # as anchor instead of yesterday's close.  This shifts the Renko grid by
            # up to 1 brick vs a normal day.  Causes: 5+ day holiday gap, API returning
            # today-only data, or bot started before any bars have closed.
            # Impact: brick boundaries shift up to brick_size pts; swing levels, RR gate,
            # and signal prices differ by up to 1 brick from expected values.
            log.warning(
                "⚠️ ANCHOR_FALLBACK %s: no prev-day OHLC bars found — using today's "
                "first bar close=%.2f as anchor (may shift Renko grid up to 1 brick). "
                "Normal cause: 5+ day holiday, API gap, or pre-09:15 start.",
                symbol, anchor_price,
            )
        else:
            anchor_price = float(ohlc_df.loc[prev_mask].iloc[-1]["close"])
            log.debug("⚓ Prev-day close for %s: %.2f (last bar before today)", symbol, anchor_price)
        import math as _math
        # Bug fix: round() uses banker's rounding (round-half-to-even) which
        # shifts the anchor one brick lower or higher on exact half-brick prices.
        # Use floor-to-grid for deterministic, consistent anchoring (same fix
        # applied to RenkoHLWick and RenkoCloseTraditional in renko_engine.py).
        anchor = _math.floor(anchor_price / brick_size) * brick_size
        log.info("⚓ Deterministic anchor for %s: prev_close=%.2f → anchor=%.2f (brick=%s)",
                 symbol, anchor_price, anchor, brick_size)
        return anchor

    def _watchdog_loop(self) -> None:
        """
        BUG-2 FIX
        ---------
        Old code: read trade_store (no lock) → modify → acquire lock → write
        Race: main cycle could process fills between the read and lock+write,
              those fills were silently overwritten by the watchdog's stale snapshot.

        Fix: acquire tm_lock FIRST, then read, modify, and write — all under
             the same lock acquisition.  The main cycle also holds tm_lock for its
             entire read-modify-write, so the two are now mutually exclusive.

        PENDING_VERIFY resolution
        -------------------------
        Rows in PENDING_VERIFY were placed by execute_order() when a network
        timeout occurred.  The broker may or may not have filled the order.
        We query the broker orders API here to determine the true state and
        avoid re-submitting an already-filled order (double-entry risk).
        """
        while not self._stop_event.is_set():
            time.sleep(60)
            try:
                # BUG-2 FIX: acquire tm_lock before ANY read
                if not self._tm_lock.acquire(timeout=20):
                    log.error("Watchdog: could not acquire tm_lock (timeout) — skipping cycle")
                    continue
                try:
                    # Read inside the lock — snapshot is coherent with current state
                    tm = trade_store.read_df()

                    changed = False

                    # ── Resolve PENDING_VERIFY rows ───────────────────────────
                    pv_mask = tm["order_status"] == "PENDING_VERIFY"
                    if pv_mask.any():
                        log.warning("🔧 Watchdog: %d PENDING_VERIFY row(s) — resolving",
                                    pv_mask.sum())
                        positions_df   = self._position_tracker.fetch()
                        root_positions = self._position_tracker.build_root_map(positions_df, list(self._brick_sizes.keys()))

                        for idx, row in tm[pv_mask].iterrows():
                            action = str(row.get("renko_signal", ""))
                            symbol = str(row.get("symbol", ""))
                            pos    = root_positions.get(symbol, {})

                            if action == "BUYCL" and pos.get("CALL", 0) > 0:
                                tm.at[idx, "order_status"] = "INPOSITION"
                                log.info("✅ Watchdog PV→INPOSITION: BUYCL %s (broker confirms fill)", symbol)
                                changed = True
                                # Initialise trailing stop if not already set
                                if trailing_stop_mgr.get_stop_price(symbol) is None:
                                    bs = float(row.get("brick_size_hint") or self._brick_sizes.get(symbol, 50.0))
                                    ep = float(row.get("entry_price") or 0)
                                    if ep > 0:
                                        trailing_stop_mgr.initialise(symbol, "CALL", ep, bs, reconciled=True)
                                        log.info("🛡️  Watchdog PV stop init: CALL %s entry=%.2f", symbol, ep)
                            elif action == "BUYPT" and pos.get("PUT", 0) > 0:
                                tm.at[idx, "order_status"] = "INPOSITION"
                                log.info("✅ Watchdog PV→INPOSITION: BUYPT %s", symbol)
                                changed = True
                                # Initialise trailing stop if not already set
                                if trailing_stop_mgr.get_stop_price(symbol) is None:
                                    bs = float(row.get("brick_size_hint") or self._brick_sizes.get(symbol, 50.0))
                                    ep = float(row.get("entry_price") or 0)
                                    if ep > 0:
                                        trailing_stop_mgr.initialise(symbol, "PUT", ep, bs, reconciled=True)
                                        log.info("🛡️  Watchdog PV stop init: PUT %s entry=%.2f", symbol, ep)
                            elif action.startswith("SEL"):
                                opt_type = "CE" if action in ("SELCL", "SELST") else "PE"
                                qty_key  = "CALL" if opt_type == "CE" else "PUT"
                                if pos[qty_key] == 0:
                                    tm.at[idx, "order_status"] = "CLOSED"
                                    tm.at[idx, "close_reason"] = "WATCHDOG_PV_RESOLVE"
                                    log.info("✅ Watchdog PV→CLOSED: %s %s", action, symbol)
                                    changed = True
                                else:
                                    # Position still open — exit didn't fill, retry
                                    tm.at[idx, "order_status"] = "OPEN"
                                    log.info("↩️ Watchdog PV→OPEN (retry): %s %s", action, symbol)
                                    changed = True
                            else:
                                # Cannot determine — safe fallback: retry as OPEN
                                tm.at[idx, "order_status"] = "OPEN"
                                log.warning("↩️ Watchdog PV→OPEN (fallback): %s %s", action, symbol)
                                changed = True

                    # ── Resolve stale SENDING rows ────────────────────────────
                    sending = tm[tm["order_status"] == "SENDING"]
                    if not sending.empty:
                        log.warning("🔧 Watchdog: %d SENDING row(s)", len(sending))
                        if not pv_mask.any():
                            # Only fetch positions if not already fetched above
                            positions_df   = self._position_tracker.fetch()
                            root_positions = self._position_tracker.build_root_map(positions_df, list(self._brick_sizes.keys()))

                        for idx, row in sending.iterrows():
                            action = str(row.get("renko_signal", ""))
                            symbol = str(row.get("symbol", ""))
                            pos    = root_positions.get(symbol, {"CALL": 0, "PUT": 0})

                            if action == "BUYCL" and pos["CALL"] > 0:
                                tm.at[idx, "order_status"] = "INPOSITION"
                                log.info("✅ Watchdog SENDING→INPOSITION: BUYCL %s", symbol)
                                if trailing_stop_mgr.get_stop_price(symbol) is None:
                                    bs = float(row.get("brick_size_hint") or self._brick_sizes.get(symbol, 50.0))
                                    ep = float(row.get("entry_price") or 0)
                                    if ep > 0:
                                        trailing_stop_mgr.initialise(symbol, "CALL", ep, bs, reconciled=True)
                                        log.info("🛡️  Watchdog SENDING stop init: CALL %s entry=%.2f", symbol, ep)
                            elif action == "BUYPT" and pos["PUT"] > 0:
                                tm.at[idx, "order_status"] = "INPOSITION"
                                log.info("✅ Watchdog SENDING→INPOSITION: BUYPT %s", symbol)
                                if trailing_stop_mgr.get_stop_price(symbol) is None:
                                    bs = float(row.get("brick_size_hint") or self._brick_sizes.get(symbol, 50.0))
                                    ep = float(row.get("entry_price") or 0)
                                    if ep > 0:
                                        trailing_stop_mgr.initialise(symbol, "PUT", ep, bs, reconciled=True)
                                        log.info("🛡️  Watchdog SENDING stop init: PUT %s entry=%.2f", symbol, ep)
                            elif action.startswith("SEL"):
                                opt_type = "CE" if action in ("SELCL", "SELST") else "PE"
                                qty_key  = "CALL" if opt_type == "CE" else "PUT"
                                if pos[qty_key] == 0:
                                    tm.at[idx, "order_status"] = "CLOSED"
                                    tm.at[idx, "close_reason"] = "WATCHDOG_RECONCILE"
                                else:
                                    tm.at[idx, "order_status"] = "OPEN"
                            else:
                                tm.at[idx, "order_status"] = "OPEN"
                                log.warning("↩️ Watchdog SENDING→OPEN (fallback): %s %s", action, symbol)
                            changed = True

                    if changed:
                        # Write still inside the same lock — coherent with any reads
                        trade_store.save_df(tm)

                finally:
                    self._tm_lock.release()

            except Exception:
                log.exception("Watchdog error")

    # ── Helpers (unchanged from original, abbreviated for clarity) ─────────────

    # Exchanges treated as equity-index for day-regime classification.
    # MCX instruments have completely different session hours and volatility
    # profiles — they must never supply the OHLC used to classify the equity
    # market regime (C-9 fix).
    _EQUITY_EXCHANGES = frozenset({"NSE_INDEX", "BSE_INDEX", "NSE", "BSE", "NFO", "BFO"})

    def _classify_day(self, symbols_df: pd.DataFrame) -> None:
        """Classify today's market regime.

        C-9 FIX: the old code used `return` after the first symbol with OHLC
        data regardless of exchange.  If CRUDEOIL (MCX) loaded before NIFTY,
        the equity regime was classified from MCX opening range data — a
        completely different market.

        Fix: only consider equity-index exchanges for classification.  MCX
        instruments are excluded.  The pipeline's single DayRegimeClassifier
        is shared; VIX is always fetched once and reused.
        """
        vix = self._fetch_vix()
        for _, row in symbols_df.iterrows():
            sym = str(row["symbol"])
            ex  = str(row.get("exchange", "")).upper()
            if ex not in self._EQUITY_EXCHANGES:
                continue                      # skip MCX — not relevant to equity regime
            ohlc = self._ohlc_cache.get(sym)
            if ohlc is not None and not ohlc.empty:
                bs = self._brick_sizes.get(sym, 50.0)
                self._signal_gen.pipeline.classify_day(ohlc, vix, bs)
                return
        log.warning("Cannot classify day regime: no equity OHLC data available yet")

    def _fetch_vix(self) -> Optional[float]:
        _VIX_CACHE_TTL = 300
        _VIX_SYMBOL    = "INDIAVIX"
        _VIX_EXCHANGE  = "NSE_INDEX"
        cached, age = ltp_store.get(_VIX_SYMBOL)
        if cached and age < _VIX_CACHE_TTL:
            return cached
        try:
            resp = self._client.quotes(symbol=_VIX_SYMBOL, exchange=_VIX_EXCHANGE)
            if isinstance(resp, dict) and resp.get("status") == "success":
                data = resp.get("data", {})
                vix  = float(data.get("ltp") or data.get("close") or 0)
                if vix > 0:
                    ltp_store.update(_VIX_SYMBOL, vix, source="REST")
                    return vix
        except Exception:
            pass
        cached, age = ltp_store.get(_VIX_SYMBOL)
        return cached if cached and age < 600 else None

    def _seed_ltp(self, symbols_df: pd.DataFrame) -> None:
        seeded = 0
        for _, row in symbols_df.iterrows():
            sym = str(row["symbol"])
            ex  = str(row["exchange"])
            try:
                trading_sym, quotes_exchange = self._resolve_ohlc_symbol(sym, ex)
                resp = self._client.quotes(symbol=trading_sym, exchange=quotes_exchange)
                if isinstance(resp, dict) and resp.get("status") == "success":
                    data = resp.get("data", {})
                    ltp  = data.get("ltp") or data.get("close")
                    if ltp:
                        ltp_store.update(sym, float(ltp), source="REST_SEED")
                        seeded += 1
            except Exception as exc:
                log.warning("LTP seed failed for %s: %s", sym, exc)
            time.sleep(0.2)
        log.info("🌐 LTP seeding complete: %d/%d symbols", seeded, len(symbols_df))

    def _init_brick_sizes(self, symbols_df: pd.DataFrame) -> None:
        """Populate both the engine-local brick size dict and the module-level
        settings.BRICK_SIZES so any module that does
            ``from tcos_bot.config.settings import BRICK_SIZES``
        receives live values rather than the empty dict defined at import time.

        C-14 FIX: the old code only wrote to self._brick_sizes; settings.BRICK_SIZES
        remained an empty dict for the entire session.
        """
        import tcos_bot.config.settings as _settings
        for _, row in symbols_df.iterrows():
            sym = str(row["symbol"])
            bs  = float(row.get("brick_size", 50))
            self._brick_sizes[sym]      = bs
            _settings.BRICK_SIZES[sym]  = bs   # C-14: keep module-level dict in sync

    def _cache_has_equity(self, symbols_df: pd.DataFrame) -> None:
        """B-6 PERF FIX: pre-compute and cache whether any symbol is equity.

        Called once in run() after _init_brick_sizes().  The result is stored
        in self._has_equity and read in _cycle() without re-iterating symbols_df.

        Why: symbols_df never changes at runtime — computing this boolean per
        cycle (2× iterrows per 5s cycle = 144+ iterrows per trading session)
        for a value that never changes is pure waste.
        """
        self._has_equity = any(
            str(row.get("exchange", "")).upper() in self._EQUITY_EXCHANGES
            for _, row in symbols_df.iterrows()
        )
        log.info(
            "📊 _has_equity cached at startup: %s "
            "(NSE/BSE=%s, MCX-only=%s)",
            self._has_equity, self._has_equity, not self._has_equity,
        )

    def _resolve_ohlc_symbol(self, symbol: str, exchange: str) -> tuple[str, str]:
        from tcos_bot.execution.option_resolver import resolve_front_month_futures
        # NSE_INDEX / BSE_INDEX: OpenAlgo's /history endpoint accepts these
        # exchanges directly (passes them to Flattrade as spot-index OHLC).
        # Do NOT remap to NFO/BFO — doing so causes a fallback to e.g.
        # SENSEX on BFO which Flattrade rejects with "no data".
        # Only MCX / NFO / BFO instruments need futures-contract resolution.
        _FUTURES_EXCHANGES = {"MCX", "NFO", "BFO", "NFO_FUT", "BFO_FUT"}
        ex_upper = exchange.upper()
        if ex_upper in _FUTURES_EXCHANGES:
            with self._fsc_lock:
                cached = self._futures_symbol_cache.get(symbol)
            if cached:
                return cached, ex_upper
            resolved = resolve_front_month_futures(symbol, exchange)
            if resolved:
                with self._fsc_lock:
                    self._futures_symbol_cache[symbol] = resolved
                log.info("📅 Futures symbol cached: %s → %s", symbol, resolved)
                return resolved, ex_upper
            # Resolution failed — do NOT fall back to raw symbol on a futures
            # exchange (it would always 404).  Return None sentinel so
            # _fetch_ohlc can skip gracefully.
            log.warning(
                "⚠️ Could not resolve front-month futures for %s on %s — skipping OHLC fetch",
                symbol, exchange,
            )
            return symbol, "__UNRESOLVED__"
        # NSE_INDEX, BSE_INDEX, NSE, BSE → pass through as-is
        return symbol, ex_upper

    def _fetch_ohlc(self, symbol: str, exchange: str) -> Optional[pd.DataFrame]:
        trading_symbol, hist_exchange = self._resolve_ohlc_symbol(symbol, exchange)
        # Guard: futures resolution failed — do not issue a doomed API call.
        if hist_exchange == "__UNRESOLVED__":
            return None
        try:
            now        = pd.Timestamp.now(tz=IST)
            today      = now.floor("D")
            # Use a 4-day lookback (same as Lalaji bot) so Renko has enough
            # bars at startup and there is always data even early in the session.
            start_day  = (today - pd.Timedelta(days=4)).strftime("%Y-%m-%d")
            end_day    = today.strftime("%Y-%m-%d")
            df    = self._client.history(
                symbol     = trading_symbol,
                exchange   = hist_exchange,
                interval   = "1m",
                start_date = start_day,
                end_date   = end_day,
            )
            if not isinstance(df, pd.DataFrame):
                if isinstance(df, dict):
                    msg = df.get("message", str(df)[:200])
                    if "not found" in msg.lower() and trading_symbol != symbol:
                        with self._fsc_lock:
                            self._futures_symbol_cache.pop(symbol, None)
                    log.warning("⚠️ OHLC API non-DataFrame for %s: %s", symbol, msg)
                return None
            if df.empty:
                return None
            df = df.copy()
            if "timestamp" not in df.columns:
                df = df.reset_index().rename(columns={df.index.name or "index": "timestamp"})
            df.columns = [c.lower() for c in df.columns]
            df["timestamp"] = pd.to_datetime(df["timestamp"]).dt.tz_localize(None)
            for col in ("open", "high", "low", "close", "volume"):
                if col in df.columns:
                    df[col] = pd.to_numeric(df[col], errors="coerce")
            # True Range = max(H-L, |H-prev_close|, |L-prev_close|).
            # The old formula used only H-L, which understates ATR on gap days
            # (the overnight gap is real price movement but H-L misses it).
            # A gapped day appears to have a tight range → lower range_ratio →
            # DayRegimeClassifier is more likely to call it SIDEWAYS when it is
            # actually TRENDING post-gap.
            prev_close  = df["close"].shift(1)
            df["tr"]  = pd.concat([
                df["high"] - df["low"],
                (df["high"] - prev_close).abs(),
                (df["low"]  - prev_close).abs(),
            ], axis=1).max(axis=1)
            df["atr"] = df["tr"].rolling(14, min_periods=1).mean()
            df = df.dropna(subset=["close"]).reset_index(drop=True)

            # GAP-A FIX: Strip the last OHLC bar if it belongs to the current
            # in-progress minute.  Without this, the Renko engine processes an
            # incomplete candle whose H/L will change before the minute closes,
            # producing intrabar signals that can reverse 30 seconds later when
            # the next OHLC refresh sees the finished candle.
            # Safe guard: only strip if df has at least 2 rows (never leave empty).
            if len(df) >= 2:
                try:
                    last_bar_ts = pd.to_datetime(df.iloc[-1]["timestamp"])
                    now_ist     = pd.Timestamp.now(tz=IST).tz_localize(None)
                    # Strip if the last bar started within the current minute
                    if (now_ist - last_bar_ts).total_seconds() < 60:
                        df = df.iloc[:-1].reset_index(drop=True)
                        log.debug("⏳ Stripped incomplete current-bar for %s (age<60s)", symbol)
                except Exception:
                    pass   # timestamp parse failure → keep df unchanged (safe)

            return df
        except Exception:
            log.exception("OHLC fetch error %s", symbol)
            return None

    def _reseed_trailing_stops(self) -> None:
        try:
            tm = trade_store.read_df()
        except Exception:
            log.exception("_reseed_trailing_stops: could not read trade_store")
            return
        entry_mask = (
            tm["renko_signal"].isin(["BUYCL", "BUYPT"]) &
            (tm["order_status"] == "INPOSITION")
        )
        reseeded = 0
        for _, row in tm[entry_mask].iterrows():
            symbol    = str(row.get("symbol", ""))
            exchange  = str(row.get("exchange", ""))
            action    = str(row.get("renko_signal", ""))
            direction = "CALL" if action == "BUYCL" else "PUT"
            stop_sig  = "SELST" if action == "BUYCL" else "SELSP"
            entry_price = float(row.get("entry_price") or 0)
            bs          = float(row.get("brick_size_hint") or self._brick_sizes.get(symbol, 50.0))
            if entry_price <= 0:
                continue

            # FIX-2: Skip re-initialisation if a stop is already active for this
            # symbol. _reseed_trailing_stops() is called TWICE at startup (before
            # and after startup_reconcile). On the second call the Renko cache has
            # refreshed, producing a different struct_high/struct_low. This silently
            # overwrites the correctly-computed stop from the first call, widening it
            # by up to 1 brick. Guard: if stop already active, leave it alone.
            if trailing_stop_mgr.get_stop_price(symbol) is not None:
                log.debug("⚓ Reseed skip %s — stop already active (%.2f), not overwriting",
                          symbol, trailing_stop_mgr.get_stop_price(symbol))
                reseeded += 1
                continue

            # Prefer struct levels stored in DB (set at entry time).
            # For positions entered before the structural-stop fix, those columns
            # are NULL — fall back to the live renko_df from cache so reseeded
            # positions also benefit from structural stop placement.
            struct_high: Optional[float] = None
            struct_low:  Optional[float] = None
            if "struct_high" in row.index and pd.notna(row.get("struct_high")):
                struct_high = float(row["struct_high"])
            if "struct_low" in row.index and pd.notna(row.get("struct_low")):
                struct_low = float(row["struct_low"])

            if struct_high is None or struct_low is None:
                renko_df = self._renko_cache.get(symbol)
                if renko_df is not None and not renko_df.empty:
                    last = renko_df.iloc[-1]
                    if struct_high is None and "Last_High" in renko_df.columns and pd.notna(last.get("Last_High")):
                        struct_high = float(last["Last_High"])
                    if struct_low is None and "Last_Low" in renko_df.columns and pd.notna(last.get("Last_Low")):
                        struct_low = float(last["Last_Low"])

            trailing_stop_mgr.initialise(
                symbol, direction, entry_price, bs,
                struct_high=struct_high,
                struct_low=struct_low,
                reconciled=True,   # skip confirmation tighten for imported positions
            )
            stop_mask = (
                (tm["symbol"] == symbol) &
                (tm["exchange"] == exchange) &
                (tm["renko_signal"] == stop_sig) &
                (tm["order_status"] == "OPEN")
            )
            stop_rows = tm[stop_mask]
            if not stop_rows.empty:
                saved_stop = float(stop_rows.iloc[0]["entry_price"])
                if saved_stop > 0:
                    with trailing_stop_mgr._lock:
                        state = trailing_stop_mgr._stops.get(symbol)
                        if state:
                            state["stop_price"] = round(saved_stop, 2)
                            trail_dist = trailing_stop_mgr._cfg.trail_distance * bs
                            if direction == "CALL":
                                state["peak_price"] = max(entry_price, saved_stop + trail_dist)
                            else:
                                state["peak_price"] = min(entry_price, saved_stop - trail_dist)
            reseeded += 1
        log.info("♻️  Trailing stop reseed complete: %d position(s)", reseeded)

    def _update_stop_in_tm(self, tm, symbol, exchange, new_stop) -> None:
        for stop_sig in ("SELST", "SELSP"):
            mask = (
                (tm["symbol"] == symbol) &
                (tm["exchange"] == exchange) &
                (tm["renko_signal"] == stop_sig) &
                (tm["order_status"] == "OPEN")
            )
            if mask.any():
                old_stop = float(tm.loc[mask, "entry_price"].iloc[0])
                tm.loc[mask, "entry_price"] = new_stop
                TradeLogger.stop_update(symbol, old_stop, new_stop, "TRAIL_UPDATE")

    # Grace period after a fill before the reconciler trusts a qty=0 response.
    # Broker position books can lag 10–60s after a fill — without this guard
    # a positionbook call that arrives before the position propagates produces
    # a false MANUAL_CLOSE that closes a live trade immediately after entry.
    _RECONCILE_GRACE_SECS: int = 60

    # ── ISSUE-C + ISSUE-D: close-event hook ──────────────────────────────────

    def _fire_close_hooks(self, tm: pd.DataFrame) -> None:
        """
        Called every cycle BEFORE _execute_open_orders.

        Scans for INPOSITION rows whose trailing stop state has been cleaned up
        (i.e., position is CLOSED this cycle) and fires:

          1. whipsaw_tracker.record_flip(symbol, direction, exit_reason, regime)
             ISSUE-C FIX: exit_reason carries CHOP_OSCILLATION_EXIT / NFT /
             STOPLOSS etc. so adaptive cooldown picks the right base duration.
             Without this, exit_reason was always "" → false_chop_cooldown
             never triggered.

          2. chop_checker.clear_pending(symbol)
             ISSUE-D FIX: clears two-stage pending state so a new position on
             the same symbol starts fresh.

          3. trailing_stop_mgr.remove(symbol)
             Already called elsewhere but idempotent — safe to call again.

        We detect "just closed" by looking at CLOSED rows where trailing_stop_mgr
        still holds state (i.e., the close happened THIS cycle before we cleaned up).
        """
        closed_mask = (
            tm["renko_signal"].isin(["BUYCL", "BUYPT"]) &
            (tm["order_status"] == "CLOSED")
        )
        if not closed_mask.any():
            return

        # Build set of symbols that already have a NEW live position this cycle
        # so remove() is not called when a new position owns the stop slot.
        live_inposition_symbols: set[str] = set(
            tm.loc[
                tm["renko_signal"].isin(["BUYCL", "BUYPT"]) &
                (tm["order_status"] == "INPOSITION"),
                "symbol",
            ].astype(str)
        )

        for _, row in tm[closed_mask].iterrows():
            symbol       = str(row.get("symbol", ""))
            action       = str(row.get("renko_signal", ""))
            direction    = "CALL" if action == "BUYCL" else "PUT"
            close_reason = str(row.get("close_reason") or "")
            regime       = str(row.get("day_regime") or "UNKNOWN")
            order_id     = str(row.get("orderid") or "")

            # Dedup key: prefer orderid when the broker assigned one.
            # Bug fix: reconcile-imported rows have no orderid so str(orderid)
            # collapses to "" for every imported position — the first close
            # fires hooks, every subsequent one is silently skipped because
            # "" is already in the set (no whipsaw flip, no chop clear).
            # Fix: fall back to a composite key that is always unique.
            if order_id and order_id not in ("", "nan", "None"):
                hook_key = order_id
            else:
                hook_key = f"{symbol}:{direction}:{close_reason}"

            # Skip rows whose hooks have already fired (covers both same-session
            # rows processed in prior cycles AND all pre-existing CLOSED rows
            # from prior sessions that were pre-seeded at startup).
            if hook_key in self._closed_hooks_fired:
                continue

            log.info(
                "🔔 CLOSE HOOK: %s %s | reason=%s regime=%s",
                direction, symbol, close_reason, regime,
            )

            # Mark this row as processed before doing anything so a crash mid-hook
            # does not leave a partially-fired state on the next cycle.
            self._closed_hooks_fired.add(hook_key)

            # 1. Adaptive whipsaw cooldown with exit_reason
            whipsaw_tracker.record_flip(
                symbol,
                direction,
                exit_reason=close_reason,
                regime=regime,
            )

            # 1a. If this was a SIGNAL_EXIT, record it so the signal_exit guard
            # blocks the opposite direction for a duration-weighted cooldown.
            # DURATION-WEIGHTED FIX: pass how long the trade was held so that
            # short-lived reversals (< 5 min) get a longer 300s block.
            # This prevents immediate re-entry into the same oscillating range.
            if "SIGNAL_EXIT" in close_reason.upper():
                _entry_time_val = None
                try:
                    # Read entry timestamp from trade_manager row
                    _entry_ts_str = str(row.get("timestamp") or "")
                    if _entry_ts_str:
                        import pandas as _pd
                        _entry_dt = _pd.to_datetime(_entry_ts_str)
                        if _entry_dt.tzinfo is None:
                            _entry_dt = _entry_dt.tz_localize(IST)
                        _held = (datetime.now(tz=IST) - _entry_dt).total_seconds()
                        _entry_time_val = max(0.0, _held)
                except Exception:
                    pass
                whipsaw_tracker.record_signal_exit(
                    symbol, direction,
                    trade_held_secs=_entry_time_val or 0.0,
                )

            # 1b. FIX NEW — profitable trailing stop exit protection.
            # If trade exited via STOP_EXIT (trailing stop), check if it was
            # profitable. If yes, arm profit-exit reversal block so bot cannot
            # immediately enter the opposite direction and give back morning profits.
            if "STOP_EXIT" in close_reason.upper():
                # Read P&L from trade row's close_price and entry_price
                try:
                    _close_px = float(row.get("close_price") or 0)
                    _entry_px = float(row.get("entry_price") or 0)
                    if _close_px > 0 and _entry_px > 0:
                        _pnl = (_close_px - _entry_px) if direction == "CALL" else (_entry_px - _close_px)
                        if _pnl > 0:
                            # PROPORTIONAL-BLOCK FIX: pass pnl_pts so block
                            # duration scales with profit size — small profits
                            # (e.g. +29pts CRUDEOIL) get a short 60-180s block
                            # instead of the full 600s, preventing missed reversals.
                            whipsaw_tracker.record_profit_exit(symbol, direction, pnl_pts=_pnl)
                            log.info(
                                "🛡️  Profitable STOP_EXIT %s %s: pnl=+%.1fpts → "
                                "reversal block armed",
                                symbol, direction, _pnl,
                            )
                except Exception:
                    pass

            # 2. Clear two-stage chop pending state
            chop_checker.clear_pending(symbol)

            # 3. Clean up trailing stop — skip if a new INPOSITION already owns
            #    this symbol's stop slot (same-cycle exit+entry race condition).
            if symbol in live_inposition_symbols:
                log.debug(
                    "🔔 CLOSE HOOK: skipping remove(%s) — new INPOSITION owns stop",
                    symbol,
                )
            else:
                trailing_stop_mgr.remove(symbol)

            # 4. F-07: Clear momentum-failure entry state for this symbol.
            #    Must run regardless of whether a new INPOSITION replaced it —
            #    the new position will repopulate on its first cycle.
            self._mf_entry_brick_count.pop(symbol, None)
            self._mf_entry_direction.pop(symbol, None)
            self._mf_bricks_since.pop(symbol, None)
            log.debug("🧹 CLOSE HOOK F-07: cleared momentum-failure state for %s", symbol)

            # 5. F-08: Clear retest state for this symbol.
            self._retest_state.pop(symbol, None)
            log.debug("🧹 CLOSE HOOK F-08: cleared retest state for %s", symbol)

    # ── F-07: Momentum-failure exit ────────────────────────────────────────────

    def _check_momentum_failure(
        self,
        tm:        "pd.DataFrame",
        symbol:    str,
        exchange:  str,
        ltp:       float,
        bs:        float,
        renko_df:  "pd.DataFrame",
    ) -> tuple["pd.DataFrame", bool]:
        """
        F-07: Detects the 'entry brick formed then immediately reversed' pattern.

        Algorithm:
        1. On the first cycle an INPOSITION row is seen: snapshot CBC + direction.
        2. Every subsequent cycle: count bricks formed since entry.
        3. If within momentum_failure_window_bricks AND current direction is
           OPPOSITE to entry direction AND peak profit < threshold: fire exit.

        Returns (updated_tm, changed).
        Feature-flagged by cfg.stop.momentum_failure_enabled (default False).
        """
        import pandas as _pd
        changed = False

        _mf_window  = getattr(cfg.stop, "momentum_failure_window_bricks", 2)
        _mf_pbricks = getattr(cfg.stop, "momentum_failure_profit_bricks", 0.5)

        # Find all INPOSITION entry rows for this symbol
        inpos_mask = (
            (tm["symbol"] == symbol) &
            (tm["exchange"] == exchange) &
            (tm["renko_signal"].isin(["BUYCL", "BUYPT"])) &
            (tm["order_status"] == "INPOSITION")
        )
        if not inpos_mask.any():
            return tm, False

        last_row_renko = renko_df.iloc[-1]
        cur_dir = int(last_row_renko.get("direction", 0) or 0)
        cur_cbc = int(last_row_renko.get("Colour_Brick_Count", 0) or 0)

        for idx, row in tm[inpos_mask].iterrows():
            action    = str(row.get("renko_signal", ""))
            entry_dir = 1 if action == "BUYCL" else -1   # CALL=up, PUT=down
            entry_px  = float(row.get("entry_price") or 0)
            fill_ts   = row.get("fill_timestamp")

            # ── Snapshot state on first sight ──────────────────────────────
            if symbol not in self._mf_entry_direction:
                self._mf_entry_direction[symbol]   = entry_dir
                self._mf_entry_brick_count[symbol] = cur_cbc
                self._mf_bricks_since[symbol]      = 0
                log.debug(
                    "📌 F-07 SNAPSHOT %s %s: entry_dir=%+d cbc=%d",
                    symbol, action, entry_dir, cur_cbc,
                )
                continue   # wait for next cycle to evaluate

            # ── Count bricks since entry using fill timestamp ───────────────
            if fill_ts is not None and "timestamp" in renko_df.columns:
                try:
                    from tcos_bot.config.settings import IST
                    _fts = _pd.to_datetime(fill_ts)
                    if _fts.tzinfo is None:
                        _fts = _fts.tz_localize(IST)
                    _ts_col = _pd.to_datetime(renko_df["timestamp"])
                    if _ts_col.dt.tz is None:
                        _ts_col = _ts_col.dt.tz_localize(IST)
                    bricks_since = int((_ts_col > _fts).sum())
                    self._mf_bricks_since[symbol] = bricks_since
                except Exception:
                    bricks_since = self._mf_bricks_since.get(symbol, 0)
            else:
                bricks_since = self._mf_bricks_since.get(symbol, 0)

            # ── Gate: only within the window ───────────────────────────────
            if bricks_since > _mf_window:
                continue   # outside window — stop checking this trade

            # ── Gate: opposite brick direction formed ───────────────────────
            if cur_dir == 0 or cur_dir == entry_dir:
                continue   # no opposite brick yet

            # ── Gate: position not profitable ──────────────────────────────
            if entry_px > 0 and bs > 0:
                _profit_b = (
                    (ltp - entry_px) / bs if entry_dir == 1
                    else (entry_px - ltp) / bs
                )
                if _profit_b >= _mf_pbricks:
                    log.debug(
                        "F-07 SKIP %s: profit=%.2fb >= %.2fb — trade confirmed",
                        symbol, _profit_b, _mf_pbricks,
                    )
                    continue   # already profitable — don't exit

            # ── All gates passed: fire momentum-failure exit ────────────────
            exit_sig = "SELCL" if action == "BUYCL" else "SELPT"
            already_exits = not tm[
                (tm["symbol"] == symbol) &
                (tm["renko_signal"] == exit_sig) &
                (tm["order_status"].isin(("OPEN", "SENDING")))
            ].empty
            if already_exits:
                continue

            qty = int(row.get("quantity") or 0)
            new_exit_row = _pd.DataFrame([{
                "exchange":     exchange,
                "timestamp":    _now().strftime("%Y-%m-%d %H:%M:%S"),
                "symbol":       symbol,
                "renko_signal": exit_sig,
                "entry_price":  float(ltp),
                "quantity":     qty,
                "order_status": "OPEN",
                "close_reason": "MOMENTUM_FAILURE_EXIT",
            }])
            tm = _pd.concat([tm, new_exit_row], ignore_index=True)
            changed = True
            log.warning(
                "🔴 MOMENTUM_FAILURE_EXIT %s %s: opp brick dir=%+d within %d bricks, "
                "no profit — immediate exit",
                symbol, action, cur_dir, bricks_since,
            )

        return tm, changed

    # _reconcile_manual_closes() removed — replaced by cycle_reconcile() in
    # tcos_bot/execution/reconciler.py which is called from _cycle() directly.
    # The old method was never called and used a slightly different close_reason
    # ("MANUAL_CLOSE" vs "MANUAL_CLOSE_DETECTED") which could confuse log analysis.

    # ── F-08: Breakout retest detection ────────────────────────────────────────

    def _check_retest_state(
        self,
        tm:       "pd.DataFrame",
        symbol:   str,
        exchange: str,
        ltp:      float,
        bs:       float,
    ) -> tuple["pd.DataFrame", bool]:
        """
        F-08: Detects breakout retest and fires an exit on a failed retest.

        State machine (per symbol):
          INACTIVE  → price returns within proximity_bricks of entry → ACTIVE
          ACTIVE    → price recovers above entry+confirm_bricks       → CONFIRMED (hold)
          ACTIVE    → price breaks below entry-fail_bricks            → EXIT

        CONFIRMED positions are never exited by this method.
        State is cleared in _fire_close_hooks() on every position close.

        Feature-flagged: cfg.stop.retest_mode_enabled (default False).
        """
        import pandas as _pd
        changed = False

        _prox_b = getattr(cfg.stop, "retest_proximity_bricks", 0.5)
        _fail_b = getattr(cfg.stop, "retest_fail_bricks",      0.5)
        _conf_b = getattr(cfg.stop, "retest_confirm_bricks",   0.5)

        inpos_mask = (
            (tm["symbol"] == symbol) &
            (tm["exchange"] == exchange) &
            (tm["renko_signal"].isin(["BUYCL", "BUYPT"])) &
            (tm["order_status"] == "INPOSITION")
        )
        if not inpos_mask.any():
            return tm, False

        for idx, row in tm[inpos_mask].iterrows():
            action   = str(row.get("renko_signal", ""))
            entry_px = float(row.get("entry_price") or 0)
            if entry_px <= 0 or bs <= 0:
                continue

            direction = "CALL" if action == "BUYCL" else "PUT"
            rt        = self._retest_state.setdefault(symbol, {
                "active":    False,
                "confirmed": False,
                "retest_extreme": entry_px,   # tracks lowest (CALL) or highest (PUT) during retest
            })

            if rt["confirmed"]:
                continue   # confirmed — never exit from this method

            # ── Activation: price returns within proximity of entry ─────────
            if not rt["active"]:
                _near_entry = (
                    (direction == "CALL" and ltp <= entry_px + _prox_b * bs) or
                    (direction == "PUT"  and ltp >= entry_px - _prox_b * bs)
                )
                if _near_entry:
                    rt["active"]        = True
                    rt["retest_extreme"] = ltp
                    log.info(
                        "🔄 RETEST_MODE ACTIVE %s %s: ltp=%.2f within %.1fb of entry=%.2f",
                        symbol, direction, ltp, _prox_b, entry_px,
                    )
                continue   # nothing more to do until active

            # ── Update retest extreme ──────────────────────────────────────
            if direction == "CALL":
                rt["retest_extreme"] = min(rt["retest_extreme"], ltp)
            else:
                rt["retest_extreme"] = max(rt["retest_extreme"], ltp)

            # ── Confirmation: price recovered above entry + confirm ─────────
            _recovered = (
                (direction == "CALL" and ltp > entry_px + _conf_b * bs) or
                (direction == "PUT"  and ltp < entry_px - _conf_b * bs)
            )
            if _recovered:
                rt["confirmed"] = True
                log.info(
                    "✅ RETEST_CONFIRMED %s %s: ltp=%.2f > entry+%.1fb=%.2f — holding",
                    symbol, direction, ltp, _conf_b,
                    entry_px + _conf_b * bs if direction == "CALL" else entry_px - _conf_b * bs,
                )
                continue

            # ── Failed retest: price broke below entry - fail_bricks ────────
            _failed = (
                (direction == "CALL" and ltp < entry_px - _fail_b * bs) or
                (direction == "PUT"  and ltp > entry_px + _fail_b * bs)
            )
            if not _failed:
                continue

            # Fire exit
            exit_sig = "SELCL" if action == "BUYCL" else "SELPT"
            already  = not tm[
                (tm["symbol"] == symbol) &
                (tm["renko_signal"] == exit_sig) &
                (tm["order_status"].isin(("OPEN", "SENDING")))
            ].empty
            if already:
                continue

            qty = int(row.get("quantity") or 0)
            new_exit = _pd.DataFrame([{
                "exchange":     exchange,
                "timestamp":    _now().strftime("%Y-%m-%d %H:%M:%S"),
                "symbol":       symbol,
                "renko_signal": exit_sig,
                "entry_price":  float(ltp),
                "quantity":     qty,
                "order_status": "OPEN",
                "close_reason": "FAILED_RETEST_EXIT",
            }])
            tm = _pd.concat([tm, new_exit], ignore_index=True)
            changed = True
            log.warning(
                "🔴 FAILED_RETEST_EXIT %s %s: ltp=%.2f broke entry-%.1fb=%.2f "
                "(retest_extreme=%.2f)",
                symbol, direction, ltp, _fail_b,
                entry_px - _fail_b * bs if direction == "CALL" else entry_px + _fail_b * bs,
                rt["retest_extreme"],
            )

        return tm, changed
