"""
WebSocket Manager  (PATCHED — Issues A + B, event-conflict bug fixed)
======================================================================
Root-cause fix summary
-----------------------
ORIGINAL BUG (78-min stale, no reconnect):
  Old inner loop had no exit path when WS died silently. Stale was detected
  but had no way to break to the outer reconnect loop.

FIRST-PATCH BUG (event conflict):
  _reconnect_needed was used for two contradictory purposes:
    1. Wake the watchdog from its timed sleep (watchdog cleared it at start)
    2. Signal _ws_connected_loop to break (loop checked if it was set)
  The watchdog's .clear() at the top of each iteration erased the signal
  before the connected loop ever polled it → reconnect never triggered.

THIS VERSION separates the two uses with two distinct events:
  _watchdog_wake    : ONLY used to wake watchdog sleep early (e.g. on stop())
  _reconnect_needed : ONLY used to signal _ws_connected_loop to break

Complete reconnect flow (verified by test):
  1. Watchdog detects feed_age > stale_threshold_secs
  2. Clears _feed_healthy (blocks BUY entries in engine)
  3. Calls _trigger_reconnect() under _reconnect_lock (single-flight)
  4. _trigger_reconnect: sets _reconnect_needed + calls client.disconnect()
  5. _ws_connected_loop: polls _reconnect_needed every 5s → breaks and returns
  6. _websocket_loop: applies backoff sleep, calls client.connect()
  7. Subscribes all instruments, clears _reconnect_needed, marks feed healthy

Thread model:
  ws-thread        : _websocket_loop → _ws_connected_loop (restarts on break)
  watchdog-thread  : polls feed age, calls _trigger_reconnect when stale
  rest-fallback    : REST polling of stale LTP symbols (unchanged safety net)
"""

from __future__ import annotations

import logging
import threading
import time
from typing import Callable, Dict, List, Optional, Set

import pandas as pd

from tcos_bot.config.settings import cfg
from tcos_bot.data.ltp_store import ltp_store

log = logging.getLogger(__name__)

# ── Config (falls back to BrokerConfig defaults if WebSocketConfig absent) ────
def _wscfg(attr, default):
    ws = getattr(cfg, "websocket", None)
    return getattr(ws, attr, default) if ws else default

_STALE_THRESHOLD_SECS    = _wscfg("stale_threshold_secs",     15.0)
_HARD_BLOCK_SECS         = _wscfg("hard_block_secs",           30.0)
_RECONNECT_INITIAL_DELAY = _wscfg("reconnect_initial_delay",    2.0)
_RECONNECT_MAX_DELAY     = _wscfg("reconnect_max_delay",        60.0)
_RECONNECT_MAX_ATTEMPTS  = _wscfg("reconnect_max_attempts",     20)
_WATCHDOG_INTERVAL       = _wscfg("watchdog_interval_secs",     5.0)
_IN_POS_STALE_ACTION     = _wscfg("in_position_stale_action",   "LOG_ONLY")
_HEALTH_LOG_INTERVAL     = _wscfg("health_log_interval_secs",   60)


class WebSocketManager:
    """
    Manages the OpenAlgo WebSocket with:
      - Heartbeat watchdog daemon (detects stale in <= watchdog_interval_secs)
      - Single-flight reconnect with exponential backoff
      - Feed-health gate for entry blocking (is_feed_healthy())
      - REST fallback for LTP while WS reconnects
    """

    def __init__(self, client) -> None:
        self._client   = client
        self._subscribed: Set[str] = set()
        self._sub_lock  = threading.Lock()

        self._active    = threading.Event()
        self._active.set()

        self._ltp_callbacks: List[Callable[[str, float], None]] = []

        self._ws_thread:       Optional[threading.Thread] = None
        self._rest_thread:     Optional[threading.Thread] = None
        self._watchdog_thread: Optional[threading.Thread] = None

        # Futures symbol maps
        self._trading_to_root: Dict[str, str] = {}
        self._root_to_trading: Dict[str, Dict[str, str]] = {}
        self._sym_map_lock = threading.Lock()

        # ── Heartbeat ─────────────────────────────────────────────────────────
        self._last_tick_mono: float = time.monotonic()
        self._tick_lock = threading.Lock()

        # ── Feed health ───────────────────────────────────────────────────────
        # Set = live ticks flowing.  Cleared = stale/reconnecting.
        # Engine reads is_feed_healthy() before every BUY entry.
        self._feed_healthy = threading.Event()
        self._feed_healthy.set()

        # ── Reconnect signalling (TWO SEPARATE EVENTS — the core fix) ─────────
        #
        # _reconnect_needed : set by _trigger_reconnect() to tell
        #                     _ws_connected_loop to break and return.
        #                     Cleared by _websocket_loop after connect() succeeds.
        #                     NEVER touched by the watchdog directly.
        #
        # _watchdog_wake    : set by stop() to unblock the watchdog's timed sleep.
        #                     Has no meaning to _ws_connected_loop.
        #
        # WHY TWO: if one event serves both purposes, the watchdog's
        # self._reconnect_needed.clear() at the top of its loop erases the
        # "please break" signal before _ws_connected_loop ever polls it.
        self._reconnect_needed = threading.Event()
        self._watchdog_wake    = threading.Event()

        # ── Reconnect state ───────────────────────────────────────────────────
        self._reconnect_lock     = threading.Lock()
        self._reconnect_attempts = 0
        self._reconnect_delay    = _RECONNECT_INITIAL_DELAY
        self._last_reconnect_at: float = 0.0
        self._reconnect_total    = 0
        self._stale_detected_at: Optional[float] = None
        self._in_degraded_mode: bool = False  # True when stale feed + open positions

        # Operational counters for observability
        self._sub_failures: int = 0          # subscription failure count

    # ── Public API ─────────────────────────────────────────────────────────────

    def is_feed_healthy(self) -> bool:
        """True if WS has delivered a tick within stale_threshold_secs."""
        return self._feed_healthy.is_set()

    def feed_age_secs(self) -> float:
        """Seconds since the last WS tick."""
        with self._tick_lock:
            return time.monotonic() - self._last_tick_mono

    # ── Startup / shutdown ─────────────────────────────────────────────────────

    def start(
        self,
        symbols_df: pd.DataFrame,
        ltp_callback: Optional[Callable[[str, float], None]] = None,
    ) -> None:
        if ltp_callback:
            self._ltp_callbacks.append(ltp_callback)

        self._ws_thread = threading.Thread(
            target=self._websocket_loop, args=(symbols_df,),
            daemon=True, name="ws-thread",
        )
        self._rest_thread = threading.Thread(
            target=self._rest_fallback_loop, args=(symbols_df,),
            daemon=True, name="rest-fallback",
        )
        self._watchdog_thread = threading.Thread(
            target=self._heartbeat_watchdog, args=(symbols_df,),
            daemon=True, name="ws-watchdog",
        )
        self._ws_thread.start()
        self._rest_thread.start()
        self._watchdog_thread.start()
        log.info(
            "🔌 WebSocketManager started | stale=%.0fs hard_block=%.0fs "
            "watchdog=%.0fs max_attempts=%d",
            _STALE_THRESHOLD_SECS, _HARD_BLOCK_SECS,
            _WATCHDOG_INTERVAL, _RECONNECT_MAX_ATTEMPTS,
        )

    def stop(self) -> None:
        self._active.clear()
        self._watchdog_wake.set()       # wake watchdog so it exits cleanly
        self._reconnect_needed.set()    # wake connected_loop if sleeping
        log.info("🛑 WebSocketManager stopping")

    # ── Futures symbol map ─────────────────────────────────────────────────────

    def set_futures_symbol_map(
        self,
        futures_cache: Dict[str, str],
        symbols_df:    "pd.DataFrame",
    ) -> None:
        if not futures_cache:
            return
        with self._sym_map_lock:
            self._trading_to_root.clear()
            self._root_to_trading.clear()
            for root, trading_sym in futures_cache.items():
                self._trading_to_root[trading_sym.upper()] = root
                match    = symbols_df[symbols_df["symbol"] == root]
                exchange = str(match.iloc[0]["exchange"]) if not match.empty else "MCX"
                self._root_to_trading[root] = {"symbol": trading_sym, "exchange": exchange}

        new_instruments = []
        for root, info in self._root_to_trading.items():
            trading_sym = info["symbol"]
            with self._sub_lock:
                already = trading_sym in self._subscribed
            if not already:
                new_instruments.append({"symbol": trading_sym, "exchange": info["exchange"]})

        if new_instruments:
            try:
                self._client.subscribe_quote(new_instruments, on_data_received=self._on_quote)
                with self._sub_lock:
                    for i in new_instruments:
                        self._subscribed.add(i["symbol"])
                log.info("📡 WS re-subscribed futures: %s",
                         [i["symbol"] for i in new_instruments])
            except Exception as e:
                log.warning("WS futures re-subscribe failed: %s", e)

    # ── Subscription ───────────────────────────────────────────────────────────

    def subscribe(self, instruments: List[Dict[str, str]]) -> None:
        with self._sub_lock:
            new = [i for i in instruments if i["symbol"] not in self._subscribed]
        if not new:
            return
        try:
            self._client.subscribe_quote(new, on_data_received=self._on_quote)
            with self._sub_lock:
                for i in new:
                    self._subscribed.add(i["symbol"])
            log.info("📡 WS subscribed: %s", [i["symbol"] for i in new])
        except Exception as e:
            self._sub_failures += 1
            # Escalate severity after repeated failures — a missing subscription
            # means we may be managing a position blind.
            log_fn = log.critical if self._sub_failures >= 3 else log.warning
            log_fn(
                "📡 WS subscribe FAILED (attempt #%d): %s | symbols=%s",
                self._sub_failures,
                e,
                [i["symbol"] for i in new],
            )

    # ── Quote callback ─────────────────────────────────────────────────────────

    def _on_quote(self, msg: dict) -> None:
        """Stamp heartbeat FIRST (even on malformed ticks — connection is alive)."""
        now_mono = time.monotonic()
        with self._tick_lock:
            self._last_tick_mono = now_mono

        if not self._feed_healthy.is_set():
            self._feed_healthy.set()
            log.info("✅ WS FEED RESTORED: ticks flowing after stale period")

        symbol = msg.get("symbol")
        if not symbol:
            return

        with self._sym_map_lock:
            root = self._trading_to_root.get(symbol.upper())
        store_key = root if root else symbol

        data = msg.get("data", {})
        ltp  = data.get("ltp") or data.get("close")
        if ltp is None:
            ltp = msg.get("ltp") or msg.get("close")
        if ltp is None:
            ltp = data.get("last_price") or msg.get("last_price")
        if ltp is None:
            return

        try:
            ltp = float(ltp)
        except (ValueError, TypeError):
            return

        ltp_store.update(store_key, ltp, source="WEBSOCKET")
        for cb in self._ltp_callbacks:
            try:
                cb(store_key, ltp)
            except Exception:
                log.exception("LTP callback error for %s", store_key)

    # ── Heartbeat watchdog ─────────────────────────────────────────────────────

    def _heartbeat_watchdog(self, symbols_df: pd.DataFrame) -> None:
        """
        Dedicated daemon. Checks feed_age_secs() every _WATCHDOG_INTERVAL seconds.
        When stale is detected:
          1. Clears _feed_healthy (entry blocking)
          2. Calls _trigger_reconnect() which:
               - Sets _reconnect_needed (signals _ws_connected_loop to break)
               - Calls client.disconnect()

        Uses _watchdog_wake (NOT _reconnect_needed) for its timed sleep so it
        never accidentally clears the signal that _ws_connected_loop is waiting on.
        """
        log.info("🔍 WS watchdog started (interval=%.0fs stale=%.0fs)",
                 _WATCHDOG_INTERVAL, _STALE_THRESHOLD_SECS)
        last_health_log = time.monotonic()

        while self._active.is_set():
            # Use _watchdog_wake for sleep — never clears _reconnect_needed
            self._watchdog_wake.wait(timeout=_WATCHDOG_INTERVAL)
            self._watchdog_wake.clear()
            if not self._active.is_set():
                break

            age = self.feed_age_secs()
            now = time.monotonic()

            # Periodic health log
            if now - last_health_log >= _HEALTH_LOG_INTERVAL:
                last_health_log = now
                report = ltp_store.health_report()
                log.info(
                    "📡 WS HEALTH: feed_age=%.1fs | ltp_total=%d healthy=%d stale=%d"
                    " | reconnects=%d feed=%s",
                    age, report["total"], report["healthy"], report["stale"],
                    self._reconnect_total,
                    "✅" if self._feed_healthy.is_set() else "❌",
                )
                stale_syms = [s for s in ltp_store.stale_symbols() if s != "INDIAVIX"]
                if stale_syms:
                    log.warning("⚠️ STALE LTP SYMBOLS: %s", stale_syms[:10])

            # Stale detection
            if age > _STALE_THRESHOLD_SECS:
                if self._feed_healthy.is_set():
                    self._stale_detected_at = now
                    self._feed_healthy.clear()
                    log.error(
                        "🚨 WS STALE DETECTED: no tick for %.1fs (threshold=%.0fs)"
                        " — feed UNHEALTHY, new entries blocked",
                        age, _STALE_THRESHOLD_SECS,
                    )
                    self._check_in_position_stale()
                else:
                    stale_for = now - (self._stale_detected_at or now)
                    log.warning("⏳ WS still stale: age=%.1fs stale_for=%.1fs",
                                age, stale_for)

                self._trigger_reconnect(symbols_df)

        log.info("🔍 WS watchdog exited")

    def _check_in_position_stale(self) -> None:
        """
        Called by the watchdog when the feed goes stale with open positions.

        Degraded-mode policy (Part 6):
          - _feed_healthy is already CLEAR → no new entries accepted by signal_generator
          - We additionally freeze trailing-stop updates by setting _in_degraded_mode=True
            (engine.py reads this flag before advancing trailing stops)
          - Exits (SELCL/SELPT/SELST/SELSP) are never gated — they must always proceed
          - Log at CRITICAL so operator is alerted immediately
        """
        try:
            from tcos_bot.data.trade_store import trade_store
            tm     = trade_store.read_df()
            in_pos = tm[tm["order_status"] == "INPOSITION"]
            if in_pos.empty:
                self._in_degraded_mode = False
                return
            syms = in_pos["symbol"].unique().tolist()
            self._in_degraded_mode = True
            log.critical(
                "🚨 WS STALE with %d ACTIVE POSITION(S): %s — "
                "entries frozen, exits still active. Reconnect in progress.",
                len(in_pos), syms,
            )
        except Exception:
            log.exception("_check_in_position_stale: trade_store read failed")

    @property
    def in_degraded_mode(self) -> bool:
        """True when feed is stale with open positions — trailing logic should pause."""
        return getattr(self, "_in_degraded_mode", False)

    # ── Single-flight reconnect ────────────────────────────────────────────────

    def _trigger_reconnect(self, symbols_df: pd.DataFrame) -> None:
        """
        Acquire reconnect lock (single-flight) and:
          1. SET _reconnect_needed so _ws_connected_loop breaks on next poll
          2. Call client.disconnect() so broker-side socket is cleaned up
          3. Apply exponential backoff

        Both steps are required. Setting _reconnect_needed alone makes the
        connected loop break but leaves the broker socket open. Calling
        disconnect() alone closes the socket but without the event signal,
        _ws_connected_loop keeps sleeping and never breaks.
        """
        if not self._reconnect_lock.acquire(blocking=False):
            log.debug("WS reconnect already in progress — skipping")
            return

        try:
            if self._reconnect_attempts >= _RECONNECT_MAX_ATTEMPTS:
                log.critical(
                    "💀 WS MAX RECONNECT ATTEMPTS (%d/%d) — manual restart required",
                    self._reconnect_attempts, _RECONNECT_MAX_ATTEMPTS,
                )
                return

            # Apply backoff
            now_mono    = time.monotonic()
            since_last  = now_mono - self._last_reconnect_at
            if since_last < self._reconnect_delay:
                wait = self._reconnect_delay - since_last
                log.info("⏳ WS reconnect backoff: %.1fs (attempt %d/%d)",
                         wait, self._reconnect_attempts + 1, _RECONNECT_MAX_ATTEMPTS)
                time.sleep(wait)

            log.warning("🔄 WS RECONNECT TRIGGERED (attempt %d/%d, delay=%.0fs)",
                        self._reconnect_attempts + 1, _RECONNECT_MAX_ATTEMPTS,
                        self._reconnect_delay)

            # Step 1: signal _ws_connected_loop to break
            self._reconnect_needed.set()
            log.debug("🔌 _reconnect_needed SET — connected_loop will break")

            # Step 2: disconnect so broker cleans up its side
            try:
                self._client.disconnect()
                log.info("🔌 WS disconnected for reconnect")
            except Exception as e:
                log.warning("WS disconnect error: %s", e)

            self._last_reconnect_at  = time.monotonic()
            self._reconnect_attempts += 1
            self._reconnect_total    += 1
            self._reconnect_delay     = min(self._reconnect_delay * 2, _RECONNECT_MAX_DELAY)

        finally:
            self._reconnect_lock.release()

    # ── WebSocket outer loop ───────────────────────────────────────────────────

    def _websocket_loop(self, symbols_df: pd.DataFrame) -> None:
        """
        Outer reconnect loop. Runs for the lifetime of the manager.

        After each successful connect+subscribe:
          - Clears _reconnect_needed (fresh start for connected_loop)
          - Runs _ws_connected_loop() until it returns (reconnect requested)
          - Applies outer_delay before next connect attempt
        """
        outer_delay = _RECONNECT_INITIAL_DELAY

        while self._active.is_set():
            try:
                log.info("🔌 WS connecting… (lifetime reconnects: %d)",
                         self._reconnect_total)
                self._client.connect()

                # Successful connect — reset counters
                self._reconnect_attempts = 0
                self._reconnect_delay    = _RECONNECT_INITIAL_DELAY
                outer_delay              = _RECONNECT_INITIAL_DELAY

                # Clear the flag so the connected loop starts clean
                # (must happen BEFORE entering _ws_connected_loop)
                self._reconnect_needed.clear()

                log.info("✅ WS CONNECTED")
                self._last_tick_mono = time.monotonic()  # reset heartbeat on connect

                # Re-subscribe (clear subscribed set first so we resend all)
                with self._sub_lock:
                    self._subscribed.clear()

                instruments = self._build_instrument_list(symbols_df)
                self.subscribe(instruments)

                # Re-subscribe futures contracts if map is populated
                with self._sym_map_lock:
                    fsc = [{"symbol": v["symbol"], "exchange": v["exchange"]}
                           for v in self._root_to_trading.values()]
                for i in fsc:
                    with self._sub_lock:
                        if i["symbol"] not in self._subscribed:
                            self.subscribe([i])
                if fsc:
                    log.info("📡 WS futures resubscribed: %s",
                             [i["symbol"] for i in fsc])

                self._feed_healthy.set()
                log.info("✅ WS RESUBSCRIBE COMPLETE — feed healthy")

                # Run until reconnect is needed
                self._ws_connected_loop()

                # _ws_connected_loop returned — reconnect requested or stopping
                if self._active.is_set():
                    log.info("🔄 Reconnect needed — waiting %.1fs", outer_delay)
                    time.sleep(outer_delay)
                    outer_delay = min(outer_delay * 2, _RECONNECT_MAX_DELAY)

            except Exception as e:
                log.error("💀 WS connection error: %s — retry in %.0fs", e, outer_delay)
                self._feed_healthy.clear()
                try:
                    self._client.disconnect()
                except Exception:
                    pass
                time.sleep(outer_delay)
                outer_delay = min(outer_delay * 2, _RECONNECT_MAX_DELAY)

        log.info("🔌 WS thread exited")

    def _ws_connected_loop(self) -> None:
        """
        Runs while connected. Returns when _reconnect_needed is set.
        Polls every 5 seconds — breaks within 5s of _trigger_reconnect() firing.
        No stale detection here — that is the watchdog's job.
        """
        while self._active.is_set():
            if self._reconnect_needed.is_set():
                log.warning("🔄 WS connected_loop: reconnect_needed set — breaking")
                return
            time.sleep(5)

    def _build_instrument_list(self, symbols_df: pd.DataFrame) -> List[Dict[str, str]]:
        with self._sym_map_lock:
            futures_roots = set(self._root_to_trading.keys())
        return [
            {"symbol": r["symbol"], "exchange": r["exchange"]}
            for r in symbols_df.to_dict("records")
            if r.get("symbol") not in futures_roots
        ]

    # ── REST fallback ──────────────────────────────────────────────────────────

    def _rest_fallback_loop(
        self,
        symbols_df:    pd.DataFrame,
        poll_interval: float = 5.0,
    ) -> None:
        """
        Polls REST quotes() for symbols with stale LTP.
        Safety net during WS outages — does NOT restore _feed_healthy.
        Only real WS ticks restore feed health.
        """
        stale_threshold = cfg.broker.ltp_stale_threshold_secs

        while self._active.is_set():
            try:
                stale = ltp_store.stale_symbols(stale_threshold)
                if stale:
                    log.debug("REST polling %d stale symbols", len(stale))
                    for sym in stale:
                        with self._sym_map_lock:
                            info = self._root_to_trading.get(sym)
                        if info:
                            trading_sym = info["symbol"]
                            exchange    = info["exchange"]
                        else:
                            match       = symbols_df[symbols_df["symbol"] == sym]
                            exchange    = str(match.iloc[0]["exchange"]) if not match.empty else "NSE_INDEX"
                            trading_sym = sym
                        try:
                            resp = self._client.quotes(symbol=trading_sym, exchange=exchange)
                            ltp_val = None
                            if isinstance(resp, dict) and resp.get("status") == "success":
                                d = resp.get("data", {})
                                if isinstance(d, dict):
                                    ltp_val = d.get("ltp") or d.get("close")
                            if ltp_val:
                                old_ltp, _ = ltp_store.get(sym)
                                ltp_store.update(sym, float(ltp_val), source="REST")
                                if old_ltp and abs(float(ltp_val) - old_ltp) > 0.01:
                                    log.debug("REST LTP %s (%s): %.2f → %.2f",
                                              sym, trading_sym, old_ltp, float(ltp_val))
                        except Exception as e:
                            log.debug("REST poll error %s: %s", sym, e)
                        time.sleep(0.1)
            except Exception:
                log.exception("REST fallback loop error")
            time.sleep(poll_interval)


# Module-level singleton (set in engine.py)
ws_manager: Optional[WebSocketManager] = None
