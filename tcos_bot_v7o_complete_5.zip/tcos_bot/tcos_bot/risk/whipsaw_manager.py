"""
Adaptive Whipsaw Cooldown Manager  (PATCHED — Issue C)
=======================================================
Root cause of missed re-entries
---------------------------------
Original: flat `cooldown_mins=45` — every trade exit, regardless of reason,
imposed a 45-minute block on new entries for the same symbol.

Problems:
  1. A false chop exit (market was right, we bailed too soon) imposed the same
     45-min penalty as a genuine double-whipsaw.  The next valid signal arrived
     during the penalty period and was missed.

  2. No market regime awareness.  In a strong trending market with brief
     consolidation, a 45-min block is extremely expensive (trend usually
     resumes well within that window).

  3. Same cooldown for first-time flip and third repeated flip.  The second
     whipsaw in 30 minutes is much more dangerous than the first — but the
     original code penalised both equally.

  4. No distinction between CHOP_OSCILLATION_EXIT (strategy chose to exit) and
     STOPLOSS (market hit our stop) when computing cooldown.

Adaptive cooldown logic
------------------------
Cooldown duration is calculated per-symbol at the time of a cooldown trigger:

  base = select_base_duration(exit_reason, recent_flip_count)
  regime_mult = multiplier_for(current_regime)
  cooldown = clamp(max(revenge_guard_secs, base × regime_mult), max_cooldown)

Duration selection table (defaults from WhipsawConfig):

  exit_reason               flips_in_window   base_secs
  -------------------------------------------------
  CHOP_OSCILLATION_EXIT     any               90   (false_chop_cooldown_secs)
  STOPLOSS / SIGNAL_EXIT    == 1              120  (base_cooldown_secs)
  STOPLOSS / SIGNAL_EXIT    == 2              600  (whipsaw_cooldown_secs)
  STOPLOSS / SIGNAL_EXIT    >= 3              1800 (repeat_whipsaw_cooldown_secs)

Regime multipliers:
  TRENDING   × 0.5   (allow faster re-entry in strong trend)
  SIDEWAYS   × 1.5   (more dangerous for breakout entries)
  VOLATILE   × 2.0   (much more dangerous)
  UNKNOWN    × 1.0   (neutral)

Hard limits:
  Always >= revenge_guard_secs (60s)  — no same-second revenge trades
  Always <= max_cooldown_secs (2700s) — never longer than original 45 min

Momentum auto-clear
--------------------
If momentum_clear_bricks consecutive same-direction bricks are observed,
the cooldown is cancelled early (same as original behaviour).

API
---
  from tcos_bot.risk.whipsaw_manager import whipsaw_manager

  # Record a flip / position close (call from signal_generator or engine):
  whipsaw_manager.record_flip(symbol, exit_reason, regime)

  # Check if entry is allowed (call from signal_generator before any entry):
  allowed, reason_str = whipsaw_manager.is_entry_allowed(symbol, regime)

  # Notify of new Renko brick (call from signal_generator on brick confirm):
  whipsaw_manager.on_brick(symbol, direction)

  # Clear cooldown explicitly (e.g. manual override):
  whipsaw_manager.clear(symbol)
"""

from __future__ import annotations

import logging
import threading
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from tcos_bot.config.settings import cfg

log = logging.getLogger(__name__)

_CFG = cfg.whipsaw


# ── Regime string constants (must match MarketRegime enum values in types.py) ──
_TRENDING  = "TRENDING"
_SIDEWAYS  = "SIDEWAYS"
_VOLATILE  = "VOLATILE"
_UNKNOWN   = "UNKNOWN"

# ── Exit reasons (must match CloseReason enum values in types.py) ─────────────
_CHOP_EXIT     = "CHOP_OSCILLATION_EXIT"
_STOP_LOSS     = "STOPLOSS"
_SIGNAL_EXIT   = "SIGNAL_EXIT"
_NFT_EXIT      = "NFT_NO_FOLLOW_THROUGH"


@dataclass
class _FlipEvent:
    """Records a single position close / flip event."""
    mono_time:   float        # time.monotonic()
    exit_reason: str
    regime:      str


@dataclass
class _CooldownState:
    """Tracks cooldown for one symbol."""
    cooldown_until: float           # time.monotonic()
    cooldown_reason: str            # human-readable explanation
    flip_events: List[_FlipEvent] = field(default_factory=list)
    # Brick momentum tracker for auto-clear
    consecutive_same_dir_bricks: int   = 0
    last_brick_dir: Optional[str]      = None


class AdaptiveWhipsawManager:
    """
    Adaptive per-symbol whipsaw cooldown with regime awareness.

    Drop-in replacement for the original cooldown logic in signal_generator.py.

    Thread safety: all public methods are protected by a per-symbol RLock
    drawn from a pool of 16 buckets (same pattern as LTPStore).
    """

    _BUCKET_COUNT = 16

    def __init__(self) -> None:
        self._state: Dict[str, _CooldownState] = {}
        self._locks: List[threading.RLock] = [
            threading.RLock() for _ in range(self._BUCKET_COUNT)
        ]
        self._cfg = _CFG

    # ────────────────────────────────────────────────────────────────────────────
    # Public API
    # ────────────────────────────────────────────────────────────────────────────

    def record_flip(
        self,
        symbol:      str,
        exit_reason: str,
        regime:      str = _UNKNOWN,
    ) -> None:
        """
        Record a position close event and set the adaptive cooldown.

        Call this whenever a BUYCL / BUYPT position closes, regardless of reason.
        The cooldown duration depends on exit_reason and recent flip history.

        Parameters
        ----------
        symbol      : root symbol (e.g. "NIFTY", "CRUDEOIL")
        exit_reason : CloseReason string (from trade row's close_reason field)
        regime      : current day regime string ("TRENDING" | "SIDEWAYS" | ...)
        """
        if not self._cfg.enabled:
            return

        now_mono = time.monotonic()
        with self._lock_for(symbol):
            state = self._get_or_create(symbol)

            # Record this flip event
            event = _FlipEvent(
                mono_time=now_mono,
                exit_reason=exit_reason,
                regime=regime,
            )
            state.flip_events.append(event)

            # Prune events outside the lookback window
            self._prune_old_flips(state, now_mono)

            # Compute adaptive cooldown
            flip_count      = len(state.flip_events)
            duration_secs   = self._compute_duration(exit_reason, flip_count)
            regime_mult     = self._regime_multiplier(regime)
            raw_duration    = duration_secs * regime_mult
            final_duration  = self._clamp(raw_duration)

            state.cooldown_until  = now_mono + final_duration
            state.cooldown_reason = (
                f"exit={exit_reason} flips={flip_count} "
                f"regime={regime} base={duration_secs}s "
                f"×{regime_mult:.1f}={final_duration:.0f}s"
            )
            # Reset momentum tracker on new cooldown
            state.consecutive_same_dir_bricks = 0
            state.last_brick_dir = None

        log.info(
            "⏸️ WHIPSAW COOLDOWN SET: %s for %.0fs | %s",
            symbol, final_duration, state.cooldown_reason,
        )

    def is_entry_allowed(
        self,
        symbol: str,
        regime: str = _UNKNOWN,
    ) -> Tuple[bool, str]:
        """
        Return (allowed, reason_string).

        Call this from signal_generator before every new BUYCL/BUYPT signal.
        If allowed=False, the entry should be suppressed.
        """
        if not self._cfg.enabled:
            return True, "whipsaw_disabled"

        now_mono = time.monotonic()
        with self._lock_for(symbol):
            state = self._state.get(symbol)
            if state is None:
                return True, "no_cooldown"

            if now_mono < state.cooldown_until:
                remaining = state.cooldown_until - now_mono
                reason = (
                    f"WHIPSAW_COOLDOWN: {remaining:.0f}s remaining "
                    f"({state.cooldown_reason})"
                )
                log.debug("🚫 Entry blocked: %s %s", symbol, reason)
                return False, reason

        return True, "cooldown_expired"

    def on_brick(self, symbol: str, brick_direction: str) -> None:
        """
        Notify the manager of a new confirmed Renko brick.
        If momentum_clear_bricks consecutive same-direction bricks are
        observed during cooldown, the cooldown is auto-cleared.

        Call this from signal_generator on each new confirmed brick.

        Parameters
        ----------
        brick_direction : "UP" | "DOWN"
        """
        if not self._cfg.enabled:
            return

        now_mono = time.monotonic()
        with self._lock_for(symbol):
            state = self._state.get(symbol)
            if state is None:
                return

            # No cooldown active — nothing to auto-clear
            if now_mono >= state.cooldown_until:
                return

            if brick_direction == state.last_brick_dir:
                state.consecutive_same_dir_bricks += 1
            else:
                state.consecutive_same_dir_bricks = 1
                state.last_brick_dir = brick_direction

            if state.consecutive_same_dir_bricks >= self._cfg.momentum_clear_bricks:
                remaining = state.cooldown_until - now_mono
                log.info(
                    "✅ WHIPSAW COOLDOWN AUTO-CLEARED: %s — "
                    "%d consecutive %s bricks (momentum restored), "
                    "%.0fs remaining waived",
                    symbol,
                    state.consecutive_same_dir_bricks,
                    brick_direction,
                    remaining,
                )
                state.cooldown_until = now_mono - 1   # expire immediately
                state.consecutive_same_dir_bricks = 0

    def clear(self, symbol: str) -> None:
        """Manually clear cooldown for *symbol* (e.g. operator override)."""
        with self._lock_for(symbol):
            if symbol in self._state:
                self._state[symbol].cooldown_until = 0.0
                log.info("🔓 WHIPSAW COOLDOWN MANUALLY CLEARED: %s", symbol)

    def cooldown_info(self, symbol: str) -> Optional[dict]:
        """Return current cooldown info dict, or None if no active cooldown."""
        now_mono = time.monotonic()
        with self._lock_for(symbol):
            state = self._state.get(symbol)
            if state is None:
                return None
            if now_mono >= state.cooldown_until:
                return None
            return {
                "symbol":            symbol,
                "remaining_secs":    state.cooldown_until - now_mono,
                "reason":            state.cooldown_reason,
                "flip_count":        len(state.flip_events),
                "momentum_bricks":   state.consecutive_same_dir_bricks,
            }

    # ────────────────────────────────────────────────────────────────────────────
    # Private helpers
    # ────────────────────────────────────────────────────────────────────────────

    def _get_or_create(self, symbol: str) -> _CooldownState:
        """Return existing state or create a fresh one (lock must be held)."""
        if symbol not in self._state:
            self._state[symbol] = _CooldownState(cooldown_until=0.0, cooldown_reason="")
        return self._state[symbol]

    def _prune_old_flips(self, state: _CooldownState, now_mono: float) -> None:
        """Remove flip events older than recent_flip_lookback_secs."""
        cutoff = now_mono - self._cfg.recent_flip_lookback_secs
        state.flip_events = [e for e in state.flip_events if e.mono_time >= cutoff]

    def _compute_duration(self, exit_reason: str, flip_count: int) -> float:
        """
        Select base cooldown duration in seconds.

        Logic:
          - CHOP_OSCILLATION_EXIT → short cooldown (false exit most of the time)
          - NFT exit → treated like chop (also an early exit by strategy logic)
          - First flip → base_cooldown_secs (mild signal of trouble)
          - Second flip → whipsaw_cooldown_secs (real whipsaw pattern)
          - Third+ flip → repeat_whipsaw_cooldown_secs (persistently choppy)
        """
        if not self._cfg.adaptive_enabled:
            # Legacy fallback: flat cooldown_mins
            return float(self._cfg.cooldown_mins * 60)

        reason_upper = exit_reason.upper()

        # False/early exits — shorter cooldown since the market likely continued
        if _CHOP_EXIT in reason_upper or _NFT_EXIT in reason_upper:
            return float(self._cfg.false_chop_cooldown_secs)

        # Genuine flip / stop / signal exit
        if flip_count <= 1:
            return float(self._cfg.base_cooldown_secs)
        elif flip_count == 2:
            return float(self._cfg.whipsaw_cooldown_secs)
        else:  # flip_count >= 3
            return float(self._cfg.repeat_whipsaw_cooldown_secs)

    def _regime_multiplier(self, regime: str) -> float:
        """Return the duration multiplier for the given regime."""
        r = regime.upper()
        if r == _TRENDING:
            return self._cfg.trending_multiplier
        if r == _SIDEWAYS:
            return self._cfg.sideways_multiplier
        if r == _VOLATILE:
            return self._cfg.volatile_multiplier
        return 1.0   # UNKNOWN

    def _clamp(self, duration_secs: float) -> float:
        """Clamp duration to [revenge_guard_secs, max_cooldown_secs]."""
        lo = float(self._cfg.revenge_guard_secs)
        hi = float(self._cfg.max_cooldown_secs)
        return max(lo, min(duration_secs, hi))

    def _lock_for(self, symbol: str) -> threading.RLock:
        bucket = hash(symbol) % self._BUCKET_COUNT
        return self._locks[bucket]

    # ── Logging helper for status display ──────────────────────────────────────

    def log_all_cooldowns(self) -> None:
        """Log all active cooldowns. Useful for heartbeat logging."""
        now_mono = time.monotonic()
        active = []
        for sym, state in list(self._state.items()):
            if now_mono < state.cooldown_until:
                active.append(
                    f"{sym}:{state.cooldown_until - now_mono:.0f}s"
                )
        if active:
            log.info("⏸️ ACTIVE WHIPSAW COOLDOWNS: %s", ", ".join(active))


# Module-level singleton
# Usage in signal_generator.py:
#   from tcos_bot.risk.whipsaw_manager import whipsaw_manager
#
#   # On every position close (wherever CloseReason is set):
#   whipsaw_manager.record_flip(symbol, close_reason, current_regime)
#
#   # Before every new entry signal:
#   allowed, reason = whipsaw_manager.is_entry_allowed(symbol, current_regime)
#   if not allowed:
#       log.info("Entry blocked: %s", reason)
#       return
#
#   # On every confirmed Renko brick (for momentum auto-clear):
#   whipsaw_manager.on_brick(symbol, "UP" if brick_is_bullish else "DOWN")
whipsaw_manager = AdaptiveWhipsawManager()
