"""
Risk Manager — risk_manager.py
================================
PR-3 changes (original)
------------------------
BUG-3 FIXED : NFTChecker._track_reversals() was writing to "chop_last_ltp"
               (shared with ChopOscillationChecker), producing delta≈0 in the
               chop checker.  NFT now uses its own "nft_last_ltp" column.

BUG-4 FIXED : NFTChecker._dynamic_timeout() was computing:
                   timeout = (elapsed/target) * target * 2 = elapsed * 2
               So `elapsed < timeout` was always True (≡ "never timeout").
               Correct formula: derive expected secs-per-brick from the actual
               Renko brick timestamps passed in (or fall back to config).

BUG-5 FIXED : Catastrophe check fired BEFORE normal trailing stop was
               persisted.  Fix: compute normal trail stop first.  Only apply
               catastrophe if and only if the catastrophe level is worse than
               the trailing stop.

ISSUE-C FIX (adaptive whipsaw cooldown)
-----------------------------------------
WhipsawCooldownTracker now uses adaptive duration instead of a flat
cooldown_mins=45 for every flip.

Root cause of missed re-entries:
  Old: every position close imposed a flat 45-minute block on new entries,
  regardless of exit reason or market regime.  A false chop exit in a
  trending market blocked the next valid re-entry for 45 minutes.

Adaptive cooldown table (all values configurable in WhipsawConfig):
  exit_reason                  regime     duration
  ─────────────────────────────────────────────────
  CHOP_OSCILLATION_EXIT        any        false_chop_cooldown_secs (default 90s)
  NFT_NO_FOLLOW_THROUGH        any        false_chop_cooldown_secs (default 90s)
  STOPLOSS / SIGNAL_EXIT       TRENDING   base_cooldown x trending_mult  (= 60s)
  STOPLOSS / SIGNAL_EXIT       UNKNOWN    base_cooldown_secs             (= 120s)
  STOPLOSS / SIGNAL_EXIT       SIDEWAYS   base_cooldown x sideways_mult  (= 180s)
  STOPLOSS / SIGNAL_EXIT       VOLATILE   base_cooldown x volatile_mult  (= 240s)
  Any, 2nd flip in window      any        whipsaw_cooldown_secs          (= 600s)
  Any, 3rd+ flip in window     any        repeat_whipsaw x regime_mult   (<=2700s)

Hard limits:
  Always >= revenge_guard_secs (60s) — no same-second revenge trades
  Always <= max_cooldown_secs (2700s) — never longer than original worst case

record_flip() gains optional `regime` and `exit_reason` params (default "").
Existing callers pass only symbol+direction — fully backward compatible.

ISSUE-D FIX (chop exit firing at ~73 seconds)
-----------------------------------------------
ChopOscillationChecker now has 6 gates before any exit fires.

Root cause:
  No minimum hold time — reversal counting started at T=0.
  With 5s cycle: rev-1 at ~10s, rev-2 at ~40s, rev-3 at ~73s = EXIT.

Six gates added:
  1. min_hold_secs (default 180s) — THE PRIMARY FIX. No evaluation before
     3 minutes. 73-second exits are structurally impossible.
  2. min_hold_bars (default 3) — at least 3 new Renko bricks since entry.
  3. adverse_excursion_bricks (default 0.75) — if price moved >0.75b against
     us, that is a stop-loss scenario, not chop. Let stop-loss handle it.
  4. regime_filter_enabled (default True) — TRENDING regime suppresses chop
     exit entirely.
  5. require_momentum_decay (default True) — Colour_Brick_Count must show
     decaying momentum before exit is allowed.
  6. two_stage_required (default True) — first breach of reversals_max enters
     a PENDING state. A second confirmation within confirmation_window_secs
     is required. Prevents exit from a single brief oscillation.

check_and_annotate() signature unchanged except new optional renko_df=None.
engine.py already patched to pass renko_df=renko_df.
"""

from __future__ import annotations

import logging
import os
import threading
import time
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import pandas as pd

from tcos_bot.config.settings import cfg, IST
from tcos_bot.data.ltp_store import ltp_store
from tcos_bot.monitoring.logger import TradeLogger

log = logging.getLogger(__name__)

_KILL_SWITCH_FILE = os.path.join(os.getcwd(), "KILL_SWITCH")


def _now() -> datetime:
    return datetime.now(tz=IST)


# ─────────────────────────────────────────────────────────────────────────────
# ISSUE-C: Adaptive Whipsaw Cooldown Tracker
# ─────────────────────────────────────────────────────────────────────────────

class WhipsawCooldownTracker:
    """
    Direction-specific whipsaw cooldown tracker with ADAPTIVE duration.

    ISSUE-C FIX: Duration is now a function of (exit_reason, flip_count, regime)
    instead of a flat cooldown_mins=45 for every flip.

    All original fixes preserved:
      FIX-1: Direction-specific (CALL vs PUT locked independently)
      FIX-2: Startup grace (120s) prevents reseed-triggered false cooldowns
      FIX-3: Brick-momentum auto-clear
      FIX-4: Grade-A bypass (enforced in signal_generator, not here)

    Backward-compatible API:
      record_flip(symbol, direction)                      old callers safe
      record_flip(symbol, direction, exit_reason, regime) new callers richer
    """

    _STARTUP_GRACE_SECS = 120
    _CHOP_EXIT = "CHOP_OSCILLATION_EXIT"
    _NFT_EXIT  = "NFT_NO_FOLLOW_THROUGH"
    _TRENDING  = "TRENDING"
    _SIDEWAYS  = "SIDEWAYS"
    _VOLATILE  = "VOLATILE"

    def __init__(self) -> None:
        self._flips:           Dict[tuple, List[float]] = {}
        self._cooldown_until:  Dict[tuple, float]       = {}
        self._cooldown_reason: Dict[tuple, str]         = {}
        self._last_signal_exit: Dict[tuple, float]      = {}
        self._signal_exit_windows: Dict[tuple, int]        = {}  # duration-weighted block per exit
        # Tracks the exit_reason for the most recent flip per (symbol, direction).
        # Used by is_stop_exit_recent() to prevent Grade-A bypass after stop losses.
        self._last_exit_reason: Dict[tuple, str]        = {}
        # FIX NEW: tracks timestamp of profitable trailing-stop exits per (symbol, direction)
        # Key = (symbol, OPPOSITE direction) so we can block the reversal
        self._profit_exits:    Dict[tuple, float]       = {}
        self._profit_exit_windows: Dict[tuple, int]        = {}  # per-block duration
        self._lock       = threading.Lock()
        self._cfg        = cfg.whipsaw
        self._start_time = time.monotonic()

    def record_flip(
        self,
        symbol:      str,
        direction:   str,
        exit_reason: str = "",
        regime:      str = "",
    ) -> None:
        """
        Record a direction flip. Computes adaptive cooldown duration from
        exit_reason, flip_count, and regime.

        SIGNAL_EXIT is NOT counted as a flip.

        A SIGNAL_EXIT means Renko confirmed a new direction — that is normal
        trading, not a whipsaw. Only adverse exits (stop loss, NFT timeout,
        chop oscillation) indicate the market reversed against you and warrant
        an extended cooldown. Counting SIGNAL_EXIT as a flip was causing 300s
        blocks after clean profitable-or-breakeven trades that exited on a
        signal, preventing re-entry on the very next valid setup.

        Adverse exits (counted as flips):
          STOPLOSS / STOP_EXIT / TRAIL_EXIT — market went against you
          NFT_NO_FOLLOW_THROUGH            — no momentum after entry
          CHOP_OSCILLATION_EXIT            — choppy oscillation detected

        Non-adverse exits (NOT counted as flips, cooldown still set to base):
          SIGNAL_EXIT — market changed direction cleanly via Renko signal
        """
        if not self._cfg.enabled:
            return
        now_t = time.monotonic()
        if (now_t - self._start_time) < self._STARTUP_GRACE_SECS:
            log.debug("⏳ WHIPSAW grace — ignoring flip for %s %s", symbol, direction)
            return

        reason_upper = exit_reason.upper()
        is_signal_exit = "SIGNAL_EXIT" in reason_upper and                          self._CHOP_EXIT  not in reason_upper and                          self._NFT_EXIT   not in reason_upper

        key = (symbol, direction)
        with self._lock:
            window = self._cfg.flip_window_mins * 60
            flips  = [t for t in self._flips.get(key, []) if now_t - t <= window]

            if not is_signal_exit:
                # Adverse exit — counts as a flip, extends cooldown
                flips.append(now_t)
                self._flips[key] = flips

            flip_count = len(flips)
            duration   = self._compute_duration(exit_reason, flip_count, regime)
            self._cooldown_until[key]  = now_t + duration
            # Track last exit reason so Grade-A bypass can check it
            self._last_exit_reason[key] = exit_reason.upper()
            reason_str = (
                f"exit={exit_reason or 'unknown'} flips={flip_count} "
                f"regime={regime or 'unknown'} duration={duration:.0f}s"
                + (" [signal_exit:no_flip]" if is_signal_exit else "")
            )
            self._cooldown_reason[key] = reason_str

        log.info(
            "⏸️  WHIPSAW COOLDOWN %s %s: %d flip(s) -> %.0fs | %s",
            symbol, direction, flip_count, duration, reason_str,
        )

    def is_blocked(self, symbol: str, direction: str) -> Tuple[bool, str]:
        if not self._cfg.enabled:
            return False, ""
        now_t = time.monotonic()
        key   = (symbol, direction)
        with self._lock:
            until  = self._cooldown_until.get(key, 0)
            reason = self._cooldown_reason.get(key, "")
        if now_t < until:
            remaining = int(until - now_t)
            return True, f"WHIPSAW_COOLDOWN({symbol} {direction}: {remaining}s — {reason})"
        return False, ""

    def last_exit_was_stop(self, symbol: str, direction: str, window_s: float = 300.0) -> bool:
        """
        STOP-REENTRY-FIX: Return True if the most recent exit for (symbol, direction)
        was a STOP_EXIT or TRAIL_EXIT within the last window_s seconds.

        Used to prevent Grade-A bypass from allowing immediate re-entry after a
        stop-loss. A STOP_EXIT means the market literally reversed against us —
        Grade-A bypass should NOT override the cooldown in that case.

        Grade-A bypass remains active after SIGNAL_EXIT and NFT exits (clean exits)
        because those represent genuine directional changes worth re-entering on.
        After a stop, we need the full cooldown to prevent whipsaw both directions.
        """
        key = (symbol, direction)
        with self._lock:
            reason = self._last_exit_reason.get(key, "")
            until  = self._cooldown_until.get(key, 0)
        if not reason:
            return False
        # Any stop-type exit: stop-loss, trailing stop, or catastrophe
        _stop_exits = ("STOP_EXIT", "STOP", "STOPLOSS", "TRAIL_EXIT", "CATA")
        is_stop = any(s in reason.upper() for s in _stop_exits)
        if not is_stop:
            return False
        # Only relevant if the cooldown is still active (within window)
        return time.monotonic() < until + window_s

    def record_signal_exit(
        self, symbol: str, direction: str, trade_held_secs: float = 0.0
    ) -> None:
        """
        Record that a SIGNAL_EXIT occurred for (symbol, direction).

        DURATION-WEIGHTED COOLDOWN FIX:
        How long the trade was held tells us how meaningful the reversal is.

        A trade held < 5 min that exits via SIGNAL_EXIT means the market
        barely moved in our direction before flipping back — pure oscillation.
        A trade held > 15 min that SIGNAL_EXITs means a genuine trend that
        ran its course and changed direction — worth following immediately.

        We store the actual block window alongside the timestamp so that
        signal_exit_too_recent() can apply the right duration per trade:

          F-10 FIX: held < 5 min  → 120s block (was 300s)
          The old 300s block was too long — a trade that SIGNAL_EXITs
          after only 2 min has already confirmed a directional change via
          Renko (2-box reversal). Blocking the OPPOSITE direction for 5
          minutes means missing the first 2-3 bricks of a genuine reversal.
          120s is the same as the base_cooldown_secs for a SIGNAL_EXIT —
          consistent with how other SIGNAL_EXIT durations are calculated.

          held < 5 min  → 120s block (F-10: was 300s)
          held 5–15 min → 180s block (short trend — modest cooldown)
          held > 15 min → 120s block (genuine trend change — fast re-entry)

        Grade-A bypass still applies after 30s regardless of this window.
        Grade-B must wait the full duration-weighted window.
        """
        if trade_held_secs < 300:       # < 5 min held
            block_secs = 120            # F-10: was 300s — reduced to 120s
        elif trade_held_secs < 900:     # 5–15 min held
            block_secs = 180
        else:                           # > 15 min held
            block_secs = getattr(self._cfg, "signal_exit_block_secs", 120)

        key = (symbol, direction)
        with self._lock:
            self._last_signal_exit[key] = time.monotonic()
            self._signal_exit_windows[key] = block_secs
        log.debug(
            "📝 SIGNAL_EXIT recorded %s %s: held=%.0fs → block=%ds",
            symbol, direction, trade_held_secs, block_secs,
        )

    def is_stop_exit_recent(self, symbol: str, direction: str) -> bool:
        """
        Return True if ANY active cooldown on this symbol was triggered by a
        STOP_EXIT or TRAIL_EXIT (market moved against us).

        Direction convention: record_flip stores under the EXITED direction.
        When BUYEN fires (direction="CALL") after a PUT stop, the cooldown is
        stored under ("CRUDEOIL","PUT") — so we check BOTH own and opposite key.

        Used to block the Grade-A whipsaw bypass after stop losses.
        Proven bug: PUT stop at 17:57 → CALL Grade-A bypass 11s later → CALL stop.
        -₹5,100 in 6 minutes from a 51-point chop range.

        Returns False once all cooldowns expire — Grade-A can bypass normally.
        """
        opposite = "PUT" if direction == "CALL" else "CALL"
        now_t = time.monotonic()
        with self._lock:
            for key in [(symbol, direction), (symbol, opposite)]:
                if now_t < self._cooldown_until.get(key, 0):
                    last = self._last_exit_reason.get(key, "")
                    if any(x in last for x in ("STOP_EXIT", "TRAIL_EXIT", "STOPLOSS")):
                        return True
        return False

    def signal_exit_too_recent(
        self,
        symbol:    str,
        direction: str,
        window_s:  float = 120.0,
    ) -> bool:
        """
        Return True if the last SIGNAL_EXIT for (symbol, direction) is within
        the duration-weighted block window.

        window_s is the CALLER's default (Grade-B=120s, Grade-A=30s).
        The actual window used is max(window_s, stored per-trade window) so
        that a short oscillation trade always gets at least 300s cooldown
        even if the caller passes a smaller Grade-A window of 30s.

        Wait — Grade-A bypass should still work after 30s for genuine reversals.
        The duration weighting only applies to Grade-B (the non-bypass path).
        Grade-A explicitly bypasses the whipsaw cooldown in signal_generator.

        So this method is only called for Grade-B entries. Use stored window.
        """
        key = (symbol, direction)
        with self._lock:
            t = self._last_signal_exit.get(key)
            # Use the stored per-trade window if available, else fall back to caller's
            stored_window = self._signal_exit_windows.get(key, window_s)
            effective_window = max(window_s, stored_window)
        if t is None:
            return False
        return (time.monotonic() - t) < effective_window


    def record_profit_exit(self, symbol: str, direction: str, pnl_pts: float = 0.0) -> None:
        """
        FIX NEW — afternoon giveback prevention.
        Called when a profitable STOP_EXIT (trailing stop) closes a position.
        Blocks the OPPOSITE direction for a duration proportional to profit size.

        PROPORTIONAL-BLOCK FIX: block duration now scales with profit magnitude.
        A small +29pt trailing exit should not block reversal for 10 minutes —
        that causes missed genuine reversals on the same move.

        Scaling tiers (based on brick multiples of base profit):
          profit < 2b  → 60s  (tiny profit, barely a confirmed move)
          profit 2–4b  → 180s (small confirmed move — 3 min cooldown)
          profit 4–8b  → 300s (medium move — 5 min cooldown)
          profit > 8b  → full no_reversal_after_profit_exit_secs (big trend day)

        For CRUDEOIL (brick=8):  2b=16pts, 4b=32pts, 8b=64pts
        For NIFTY    (brick=12): 2b=24pts, 4b=48pts, 8b=96pts
        For BANKNIFTY(brick=40): 2b=80pts, 4b=160pts, 8b=320pts
        """
        base_window = getattr(self._cfg, "no_reversal_after_profit_exit_secs", 600)
        if base_window <= 0:
            return

        from tcos_bot.config.settings import BRICK_SIZES
        import re as _re
        _root = (_re.match(r"^([A-Z]+)", symbol.upper()) or _re.match(r"^([A-Z]+)", "X")).group(1)
        _bs   = BRICK_SIZES.get(_root, 10.0)

        # Scale block duration by profit size in bricks:
        #   < 2b  →  60s  (tiny gain — barely moved, allow fast reversal)
        #   2–4b  → 180s  (small confirmed move)
        #   4–8b  → 300s  (medium move)
        #   > 8b  → full base_window (big trending day — protect it)
        if pnl_pts > 0:
            _profit_bricks = pnl_pts / _bs
            if _profit_bricks < 2.0:
                window = 60
            elif _profit_bricks < 4.0:
                window = 180
            elif _profit_bricks < 8.0:
                window = 300
            else:
                window = base_window
        else:
            window = base_window

        opposite = "PUT" if direction == "CALL" else "CALL"
        key = (symbol, opposite)
        with self._lock:
            self._profit_exits[key] = time.monotonic()
            self._profit_exit_windows[key] = window
        log.info(
            "🛡️  PROFIT_EXIT_BLOCK armed: %s %s blocked for %ds "
            "— profitable %s exit +%.0fpts (%.1fb) prevents immediate reversal",
            symbol, opposite, window, direction, pnl_pts, pnl_pts / _bs,
        )

    def is_reversal_blocked_after_profit(
        self, symbol: str, direction: str
    ) -> bool:
        """
        Return True if this direction is blocked due to a recent profitable exit
        in the opposite direction. Used in signal_generator._create_entry().
        """
        base_window = getattr(self._cfg, "no_reversal_after_profit_exit_secs", 600)
        if base_window <= 0:
            return False
        key = (symbol, direction)
        with self._lock:
            t = self._profit_exits.get(key)
            window = self._profit_exit_windows.get(key, base_window)
        if t is None:
            return False
        elapsed = time.monotonic() - t
        if elapsed < window:
            remaining = int(window - elapsed)
            log.info(
                "🚫 PROFIT_EXIT_REVERSAL_BLOCK %s %s: %ds remaining "
                "— protecting morning profits from reversal entry",
                symbol, direction, remaining,
            )
            return True
        return False

    def on_brick_formed(
        self, symbol: str, direction: str, consecutive_count: int
    ) -> None:
        """Momentum auto-clear: lift cooldown after N consecutive same-direction bricks."""
        if not self._cfg.enabled:
            return
        threshold = getattr(self._cfg, "momentum_clear_bricks", 8)
        if consecutive_count < threshold:
            return
        key = (symbol, direction)
        with self._lock:
            until = self._cooldown_until.get(key, 0)
            if until <= time.monotonic():
                return
            remaining = until - time.monotonic()
            del self._cooldown_until[key]
            self._flips.pop(key, None)
            self._cooldown_reason.pop(key, None)
        log.info(
            "🧹 WHIPSAW MOMENTUM CLEAR %s %s: %d consecutive bricks >= %d — "
            "%.0fs cooldown waived",
            symbol, direction, consecutive_count, threshold, remaining,
        )

    def clear(
        self, symbol: str, direction: Optional[str] = None, reason: str = ""
    ) -> None:
        with self._lock:
            if direction is None:
                for d in ("CALL", "PUT"):
                    k = (symbol, d)
                    self._flips.pop(k, None)
                    self._cooldown_until.pop(k, None)
                    self._cooldown_reason.pop(k, None)
            else:
                k = (symbol, direction)
                self._flips.pop(k, None)
                self._cooldown_until.pop(k, None)
                self._cooldown_reason.pop(k, None)
        if reason:
            log.debug("Whipsaw cleared %s %s: %s", symbol, direction or "ALL", reason)

    # ── ISSUE-C: adaptive duration computation ────────────────────────────────

    def _compute_duration(
        self, exit_reason: str, flip_count: int, regime: str
    ) -> float:
        """
        Adaptive cooldown duration in seconds.

        Table:
          false exits (CHOP/NFT)    -> false_chop_cooldown_secs (90s) x regime_mult
          1st flip                  -> base_cooldown_secs (120s) x regime_mult
          2nd flip                  -> whipsaw_cooldown_secs (600s) x regime_mult
          3rd+ flip                 -> repeat_whipsaw_cooldown_secs (1800s) x regime_mult

        Regime multipliers:
          TRENDING  x 0.5   (halve — trending markets allow fast re-entry)
          SIDEWAYS  x 1.5   (extend — dangerous for breakout entries)
          VOLATILE  x 2.0   (double — high penalty for repeated entries)
          UNKNOWN   x 1.0   (neutral)

        Hard clamps: [revenge_guard_secs=60, max_cooldown_secs=2700]
        """
        _cfg = self._cfg

        if not getattr(_cfg, "adaptive_enabled", True):
            return float(_cfg.cooldown_mins * 60)

        reason_upper = exit_reason.upper()
        regime_upper = regime.upper()

        # False / early exits
        if self._CHOP_EXIT in reason_upper or self._NFT_EXIT in reason_upper:
            base = float(getattr(_cfg, "false_chop_cooldown_secs", 90))
        elif flip_count <= 1:
            base = float(getattr(_cfg, "base_cooldown_secs", 120))
        elif flip_count == 2:
            base = float(getattr(_cfg, "whipsaw_cooldown_secs", 600))
        else:
            base = float(getattr(_cfg, "repeat_whipsaw_cooldown_secs", 1800))

        if regime_upper == self._TRENDING:
            mult = float(getattr(_cfg, "trending_multiplier", 0.5))
        elif regime_upper == self._SIDEWAYS:
            mult = float(getattr(_cfg, "sideways_multiplier", 1.5))
        elif regime_upper == self._VOLATILE:
            mult = float(getattr(_cfg, "volatile_multiplier", 2.0))
        else:
            mult = 1.0

        raw = base * mult
        lo  = float(getattr(_cfg, "revenge_guard_secs",  60))
        hi  = float(getattr(_cfg, "max_cooldown_secs", 2700))
        return max(lo, min(raw, hi))


# ─────────────────────────────────────────────────────────────────────────────
# Trailing Stop Manager (BUG-5 fix)
# ─────────────────────────────────────────────────────────────────────────────

class TrailingStopManager:
    """
    BUG-5 FIX: Catastrophe check now runs AFTER trailing stop logic.
    Catastrophe only applied if strictly WORSE than the trailing stop.
    """

    def __init__(self) -> None:
        self._cfg   = cfg.trailing
        self._stops: Dict[str, dict] = {}
        self._lock  = threading.Lock()

    def initialise(
        self,
        symbol:            str,
        direction:         str,
        entry_price:       float,
        brick_size:        float,
        catastrophe_extra: Optional[float] = None,
        struct_high:       Optional[float] = None,
        struct_low:        Optional[float] = None,
        reconciled:        bool = False,
        regime:            str  = "",
    ) -> float:
        """
        reconciled=True: position was imported from a previous session.
        Skip the confirmation tighten window — the trade has already been
        running for an unknown duration and we cannot apply a 3-minute window
        retroactively. Mark as confirmed immediately.

        regime: day regime string. VOLATILE gets extra confirm_mins (+2min)
        since price moves slower on VOLATILE days.
        """
        bs             = brick_size
        # Use per-symbol override if configured, else global default
        _overrides     = getattr(cfg.stop, "symbol_overrides", {})
        initial_bricks = _overrides.get(symbol, cfg.stop.initial_stop_bricks)
        use_struct     = getattr(cfg.stop, "use_structural_stop", True)
        if catastrophe_extra is None:
            catastrophe_extra = getattr(cfg.stop, "catastrophe_extra_bricks", 1.5)

        # MCX-BUG-2 FIX: per-symbol cap on structural stop width.
        # For coarse-brick MCX instruments (GOLDM=150, SILVERM=500) the swing
        # high/low can be 5-8 bricks from entry, making the structural stop
        # unreachably wide and preventing the trailing stop from ever advancing.
        # Today: GOLDM struct_high=157500 (825pts above fill 156289) → stop 8.6b wide
        # → breakeven needed +450pt move → never triggered in 80 minutes.
        # NSE/BSE symbols not in the override dict → global default 99b = no cap.
        _struct_cap_overrides = getattr(cfg.stop, "max_struct_stop_bricks_override", {})
        _max_struct_b = _struct_cap_overrides.get(
            symbol, getattr(cfg.stop, "max_struct_stop_bricks", 99.0)
        )

        if direction == "CALL":
            fixed_stop = entry_price - initial_bricks * bs
            catst      = entry_price - (initial_bricks + catastrophe_extra) * bs
            if use_struct and struct_low and 0 < struct_low < entry_price:
                struct_stop = struct_low - 0.5 * bs
                # MCX-BUG-2 FIX: cap struct_stop so it cannot be more than
                # _max_struct_b bricks below entry (for CALL: price floor).
                _capped_floor = entry_price - _max_struct_b * bs
                struct_stop = max(struct_stop, _capped_floor)
                # FIX: was min() which picked the WIDER (lower) stop for CALL.
                # max() picks the HIGHER value = closer to entry = tighter risk.
                # Struct stop only tightens (when swing low is nearby).
                # Fixed stop wins when swing low is far (morning crash etc).
                stop = max(fixed_stop, struct_stop)
            else:
                stop = fixed_stop
            # catst relative to final stop so it is always strictly worse
            catst = stop - catastrophe_extra * bs
        else:
            fixed_stop = entry_price + initial_bricks * bs
            catst      = entry_price + (initial_bricks + catastrophe_extra) * bs
            if use_struct and struct_high and struct_high > entry_price:
                struct_stop = struct_high + 0.5 * bs
                # MCX-BUG-2 FIX: cap struct_stop so it cannot be more than
                # _max_struct_b bricks above entry (for PUT: price ceiling).
                _capped_ceil = entry_price + _max_struct_b * bs
                struct_stop = min(struct_stop, _capped_ceil)
                stop = max(fixed_stop, struct_stop)
            else:
                stop = fixed_stop
            # BUG-2 FIX: catst relative to final stop so it is always strictly
            # worse (mirrors CALL branch). Without this, when struct_stop >
            # fixed_stop the catst stays at entry+(initial+extra)*bs which can
            # land INSIDE the structural stop range. The BUG-5 guard in
            # update() then prevents catst from ever firing because
            # catst <= new_stop, defeating the last-resort circuit breaker.
            catst = stop + catastrophe_extra * bs

        struct_note = ""
        if use_struct:
            if direction == "CALL" and struct_low and 0 < struct_low < entry_price:
                struct_note = f" struct_low={struct_low:.2f}"
            elif direction == "PUT" and struct_high and struct_high > entry_price:
                struct_note = f" struct_high={struct_high:.2f}"

        # Confirmation tighten state
        _conf_cfg      = cfg.stop
        _use_tighten   = getattr(_conf_cfg, "confirmation_tighten", True)
        # F-04 FIX: read per-instrument confirm_mins override (GOLDM/SILVERM
        # have slow brick velocity and need more time before tightening).
        import re as _cm_re
        _cm_root = (
            _cm_re.match(r"^([A-Z]+)", symbol.upper()) or
            _cm_re.match(r"^([A-Z]+)", "X")
        ).group(1)
        _cm_overrides  = getattr(_conf_cfg, "confirm_mins_override", {})
        _confirm_mins  = _cm_overrides.get(
            _cm_root, getattr(_conf_cfg, "confirm_mins", 1.5)
        )

        # ── Opening session grace period ──────────────────────────────────────
        # Trades entered before opening_confirm_cutoff (default 09:40 IST) get
        # a wider confirm window. Opening range volatility means the first 5min
        # are too noisy for the standard 1.5min tighten.
        # Effective: max(opening_confirm_mins, instrument_override).
        # April 8: BNF 09:31 tightened at 1.6min killing a +691pt trend trade.
        _opening_grace   = getattr(_conf_cfg, "opening_confirm_mins", 5.0)
        _opening_cutoff  = getattr(_conf_cfg, "opening_confirm_cutoff", "09:40")
        try:
            _cut_h, _cut_m = map(int, _opening_cutoff.split(":"))
            _now_ist       = datetime.now(tz=IST)
            _in_opening    = (
                _now_ist.hour < _cut_h or
                (_now_ist.hour == _cut_h and _now_ist.minute < _cut_m)
            )
            if _in_opening and _opening_grace > _confirm_mins:
                _confirm_mins = _opening_grace
                log.debug(
                    "🌅 OPENING_GRACE %s %s: confirm_mins raised to %.1fmin "
                    "(entry before %s IST)",
                    symbol, direction, _confirm_mins, _opening_cutoff,
                )
        except Exception:
            pass  # malformed cutoff — fall through to normal confirm_mins
        _confirm_bricks= getattr(_conf_cfg, "confirm_bricks", 1.5)   # fallback matches config default
        # Note: actual confirm_mins used in update() is stored in state dict
        # and may be adjusted for regime (VOLATILE gets +2min).
        _tight_bricks  = getattr(_conf_cfg, "tight_bricks", 1.5)
        if direction == "CALL":
            tight_stop = entry_price - _tight_bricks * brick_size
        else:
            tight_stop = entry_price + _tight_bricks * brick_size

        with self._lock:
            self._stops[symbol] = {
                "direction":         direction,
                "entry_price":       entry_price,
                "stop_price":        round(stop, 2),
                "catastrophe":       round(catst, 2),
                "peak_price":        entry_price,
                "brick_size":        brick_size,
                "trail_active":      False,
                "breakeven_reached": False,
                "updated_at":        time.monotonic(),
                # Confirmation tighten
                "confirm_tighten":   _use_tighten,
                # FIX I-06: single confirm_mins assignment. Previously appeared twice
                # (lines 453 + 461) — Python silently takes the last value, making the
                # first assignment dead code. Consolidated to one line with VOLATILE adj.
                "confirm_mins":      _confirm_mins + (2.0 if "VOLATILE" in regime.upper() else 0.0),
                "confirm_bricks":    _confirm_bricks,
                "tight_stop":        round(tight_stop, 2),
                "confirmed":         reconciled,   # skip tighten for reconciled
                "tightened":         False,
                "entry_time":        time.monotonic(),
            }
        log.info(
            "🛡️  STOP INIT %s %s | entry=%.2f stop=%.2f cata=%.2f%s",
            symbol, direction, entry_price, stop, catst, struct_note,
        )
        return round(stop, 2)

    def update(
        self,
        symbol:    str,
        ltp:       float,
        new_brick: Optional[float] = None,
    ) -> Optional[float]:
        if not self._cfg.enabled:
            return None

        with self._lock:
            state = self._stops.get(symbol)
            if state is None:
                return None

            direction  = state["direction"]
            entry      = state["entry_price"]
            stop       = state["stop_price"]
            peak       = state["peak_price"]
            bs         = state["brick_size"]
            trail_on   = state["trail_active"]
            be_reached = state["breakeven_reached"]
            catst      = state.get("catastrophe")
            new_stop   = stop

            profit_bricks = (
                (ltp - entry) / bs if direction == "CALL"
                else (entry - ltp) / bs
            )

            # ── F-06: Fast-fail gate (90-second post-entry check) ────────────
            # Fires BEFORE the confirmation-tighten block so it can catch
            # failed entries in the first 90s — before the 1.5-min tighten.
            # Conditions (ALL must be true to trigger):
            #   1. fast_fail_enabled = True (feature flag, default False)
            #   2. elapsed < fast_fail_secs (within 90s of fill)
            #   3. peak profit < fast_fail_profit_bricks (never reached 0.5b)
            #   4. new_brick moved against entry direction
            # Action: tighten stop to entry - fast_fail_tight_bricks.
            _ff_enabled = getattr(self._cfg, "fast_fail_enabled", False)
            _confirmed_ff = state.get("confirmed", True)
            _tightened_ff = state.get("tightened", False)
            if (
                _ff_enabled
                and not _confirmed_ff
                and not _tightened_ff
                and not be_reached
                and new_brick is not None
            ):
                _ff_secs    = getattr(self._cfg, "fast_fail_secs", 90.0)
                _ff_pbricks = getattr(self._cfg, "fast_fail_profit_bricks", 0.5)
                _ff_tbricks = getattr(self._cfg, "fast_fail_tight_bricks", 1.0)
                _elapsed_s  = time.monotonic() - state.get("entry_time", time.monotonic())
                _peak_profit_b = (
                    (peak - entry) / bs if direction == "CALL"
                    else (entry - peak) / bs
                )
                _brick_against = (
                    (direction == "CALL" and new_brick < entry)
                    or (direction == "PUT"  and new_brick > entry)
                )
                if (
                    _elapsed_s <= _ff_secs
                    and _peak_profit_b < _ff_pbricks
                    and _brick_against
                ):
                    _ff_stop = (
                        round(entry - _ff_tbricks * bs, 2) if direction == "CALL"
                        else round(entry + _ff_tbricks * bs, 2)
                    )
                    _should_apply = (
                        (direction == "CALL" and _ff_stop > new_stop)
                        or (direction == "PUT"  and _ff_stop < new_stop)
                    )
                    if _should_apply:
                        new_stop = _ff_stop
                        state["tightened"] = True
                        log.info(
                            "⚡ FAST_FAIL_90S %s %s: %.0fs elapsed, "
                            "peak=%.2fb < %.2fb, brick %.2f against entry %.2f "
                            "-> stop tightened to %.2f (%.1fb)",
                            symbol, direction, _elapsed_s,
                            _peak_profit_b, _ff_pbricks,
                            new_brick, entry, _ff_stop, _ff_tbricks,
                        )
                        TradeLogger.stop_update(symbol, stop, new_stop, "FAST_FAIL_90S")
            # ─────────────────────────────────────────────────────────────────

            # ── Confirmation tighten ─────────────────────────────────────────
            # If price has not moved confirm_bricks in profit within confirm_mins,
            # tighten the stop to tight_stop. This cuts unconfirmed trades early
            # (avg -14pts) vs letting them run to the full stop (-60pts).
            # Confirmed trades are never affected.
            _use_tighten  = state.get("confirm_tighten", False)
            _confirmed    = state.get("confirmed", True)
            _tightened    = state.get("tightened", False)
            if _use_tighten and not _confirmed and not _tightened and not be_reached:
                _confirm_bricks = state.get("confirm_bricks", 1.5)   # fallback matches config default
                # confirm_mins is stored per-position at initialise() time,
                # already adjusted for regime (VOLATILE gets +2min).
                _confirm_mins   = state.get("confirm_mins", 3.0)
                _elapsed_mins   = (time.monotonic() - state.get("entry_time", time.monotonic())) / 60

                # Has trade confirmed? (peak profit >= confirm_bricks)
                peak_profit_bricks = (
                    (peak - entry) / bs if direction == "CALL"
                    else (entry - peak) / bs
                )
                if peak_profit_bricks >= _confirm_bricks:
                    state["confirmed"] = True
                    _confirmed = True
                    log.info(
                        "✅ CONFIRMED %s %s: +%.2fb in %.1fmin — full stop maintained",
                        symbol, direction, peak_profit_bricks, _elapsed_mins,
                    )
                elif _elapsed_mins >= _confirm_mins and not _tightened:
                    # Time expired without confirmation — tighten the stop
                    tight_stop = state.get("tight_stop", stop)
                    # BUG-2 FIX: _tight_bricks was used here but never defined in update().
                    # It is defined in initialise() and stored in tight_stop but not
                    # as a separate key. Read from config directly for the log line.
                    _tight_bricks_log = getattr(cfg.stop, "tight_bricks", 2.5)
                    if (direction == "CALL" and tight_stop > new_stop) or                        (direction == "PUT"  and tight_stop < new_stop):
                        new_stop = tight_stop
                        state["tightened"] = True
                        log.info(
                            "⚡ TIGHTEN %s %s: %.1fmin unconfirmed (<%.2fb) "
                            "→ stop %.2f→%.2f (tight=%.2fb)",
                            symbol, direction, _elapsed_mins, _confirm_bricks,
                            stop, new_stop, _tight_bricks_log,
                        )

            on_confirm = getattr(self._cfg, "on_brick_confirm", True)
            if on_confirm and new_brick is not None:
                if direction == "CALL" and new_brick > peak:
                    state["peak_price"] = new_brick; peak = new_brick
                elif direction == "PUT" and new_brick < peak:
                    state["peak_price"] = new_brick; peak = new_brick
            else:
                if direction == "CALL" and ltp > peak:
                    state["peak_price"] = ltp; peak = ltp
                elif direction == "PUT" and ltp < peak:
                    state["peak_price"] = ltp; peak = ltp

            if not be_reached and profit_bricks >= self._cfg.breakeven_after:
                buf = getattr(self._cfg, "breakeven_buffer", 0.25) * bs
                if direction == "CALL":
                    new_stop = max(stop, entry + buf)
                else:
                    new_stop = min(stop, entry - buf)
                state["breakeven_reached"] = True
                log.info(
                    "🟢 BREAKEVEN %s %s | stop %.2f -> %.2f | P&L: +%.1fb (+%.0fpts)",
                    symbol, direction, stop, new_stop, profit_bricks, profit_bricks * bs,
                )
                TradeLogger.stop_update(symbol, stop, new_stop, "BREAKEVEN")

            if profit_bricks >= self._cfg.trail_start_after:
                state["trail_active"] = True
                trail_on = True

            if trail_on:
                if getattr(self._cfg, "adaptive_trail", True):
                    # FIX I-15: thresholds now read from config (were hardcoded 3.0/6.0)
                    _tier1 = getattr(self._cfg, "adaptive_trail_tier1_bricks", 3.0)
                    _tier2 = getattr(self._cfg, "adaptive_trail_tier2_bricks", 6.0)
                    _add1  = getattr(self._cfg, "adaptive_trail_tier1_add",    0.5)
                    _add2  = getattr(self._cfg, "adaptive_trail_tier2_add",    1.0)
                    if profit_bricks < _tier1:
                        trail_dist_bricks = self._cfg.trail_distance
                    elif profit_bricks < _tier2:
                        trail_dist_bricks = self._cfg.trail_distance + _add1
                    else:
                        trail_dist_bricks = self._cfg.trail_distance + _add2
                else:
                    trail_dist_bricks = self._cfg.trail_distance
                trail_dist = trail_dist_bricks * bs
                if direction == "CALL":
                    candidate = round(peak - trail_dist, 2)
                    # Safety cap: never advance the stop above current LTP.
                    # on_brick_confirm=True updates peak to the brick CLOSE price,
                    # which can be 1-2 bricks above LTP if price retraced after
                    # forming the brick.  Without this cap, trail=brick-1b can
                    # exceed LTP and trigger an immediate stop the same cycle
                    # the trail advances (confirmed from 14:53 log: brick@23496,
                    # trail→23484, LTP=23478 → instant stop).
                    candidate = min(candidate, round(ltp - trail_dist, 2))
                    if candidate > new_stop:
                        new_stop = candidate
                else:
                    candidate = round(peak + trail_dist, 2)
                    # Same cap for PUT: stop must not go below current LTP.
                    candidate = max(candidate, round(ltp + trail_dist, 2))
                    if candidate < new_stop:
                        new_stop = candidate

            # BUG-5 FIX: catastrophe only if WORSE than trailing stop
            if catst is not None:
                if direction == "CALL" and ltp <= catst:
                    if catst < new_stop:
                        log.info(
                            "💥 CATA %s: ltp=%.2f <= cata=%.2f but trail=%.2f is better",
                            symbol, ltp, catst, new_stop,
                        )
                    else:
                        log.warning(
                            "💥 CATASTROPHE STOP %s: ltp=%.2f <= cata=%.2f "
                            "(trail=%.2f) — applying cata", symbol, ltp, catst, new_stop,
                        )
                        new_stop = catst
                elif direction == "PUT" and ltp >= catst:
                    if catst > new_stop:
                        log.info(
                            "💥 CATA %s: ltp=%.2f >= cata=%.2f but trail=%.2f is better",
                            symbol, ltp, catst, new_stop,
                        )
                    else:
                        log.warning(
                            "💥 CATASTROPHE STOP %s: ltp=%.2f >= cata=%.2f "
                            "(trail=%.2f) — applying cata", symbol, ltp, catst, new_stop,
                        )
                        new_stop = catst

            if abs(new_stop - stop) > 0.01:
                old_stop = state["stop_price"]
                state["stop_price"] = new_stop
                state["updated_at"] = time.monotonic()
                log.info(
                    "🔼 TRAIL %s %s | stop %.2f -> %.2f | P&L: +%.1fb (+%.0fpts)",
                    symbol, direction, old_stop, new_stop, profit_bricks, profit_bricks * bs,
                )
                TradeLogger.stop_update(symbol, old_stop, new_stop, "TRAIL")
                return new_stop

        return None

    def get_stop_price(self, symbol: str) -> Optional[float]:
        with self._lock:
            state = self._stops.get(symbol)
        return state["stop_price"] if state else None

    def remove(self, symbol: str) -> None:
        with self._lock:
            self._stops.pop(symbol, None)


# ─────────────────────────────────────────────────────────────────────────────
# NFT Checker (BUG-3 + BUG-4)
# ─────────────────────────────────────────────────────────────────────────────

class NFTChecker:
    """
    BUG-3 FIX: Uses nft_last_ltp (not chop_last_ltp).
    BUG-4 FIX: _dynamic_timeout measures actual brick velocity from renko_df.
    """

    def __init__(self) -> None:
        self._cfg = cfg.nft

    def check_and_annotate(
        self,
        trade_manager: pd.DataFrame,
        symbol:        str,
        exchange:      str,
        ltp:           float,
        brick_size:    float,
        renko_df:      Optional[pd.DataFrame] = None,
    ) -> Tuple[pd.DataFrame, bool]:
        if not self._cfg.enabled:
            return trade_manager, False

        changed = False
        mask = (
            (trade_manager["symbol"] == symbol) &
            (trade_manager["exchange"] == exchange) &
            (trade_manager["renko_signal"].isin(["BUYCL", "BUYPT"])) &
            (trade_manager["order_status"] == "INPOSITION") &
            (trade_manager["nft_validated"] == 0)
        )
        rows = trade_manager[mask]

        for idx, row in rows.iterrows():
            entry_sig  = str(row.get("renko_signal", ""))
            fill_ts    = row.get("fill_timestamp")
            entry_ref  = float(row.get("index_ltp") or row.get("entry_price") or 0)
            nft_target = float(row.get("nft_target") or 0)

            if fill_ts is None or entry_ref <= 0:
                continue

            try:
                _fill_dt = pd.to_datetime(fill_ts)
                if _fill_dt.tzinfo is None:
                    _fill_dt = _fill_dt.tz_localize(IST)
                else:
                    _fill_dt = _fill_dt.tz_convert(IST)
                elapsed = (_now() - _fill_dt).total_seconds()
            except Exception:
                elapsed = 9999

            timeout = self._dynamic_timeout(elapsed, brick_size, renko_df, fill_ts, symbol=symbol)

            validated, val_src = self._check_validation(
                entry_sig, ltp, nft_target, entry_ref, row
            )
            if validated:
                trade_manager.at[idx, "nft_validated"] = 1
                changed = True
                log.info("✅ NFT VALIDATED %s %s: %s", symbol, entry_sig, val_src)
                continue

            trade_manager, changed_rev = self._track_reversals(
                trade_manager, idx, row, ltp, brick_size, entry_ref, entry_sig
            )
            if changed_rev:
                changed = True

            if elapsed < timeout:
                continue

            nft_rev  = int(row.get("nft_rev_count") or 0)
            net_move = abs(ltp - entry_ref) / brick_size

            # PROFIT GUARD: if position is already profitable by ≥ 1b
            # (measured from the original entry_price, not from a
            # potentially stale quote), never NFT-exit.
            # This prevents the race condition where:
            #   (a) NFT check fires using a stale LTP (near entry),
            #   (b) 3 seconds later execution sees LTP already 3b+ in profit.
            # Using entry_price from the trade row is always accurate —
            # it is the actual fill price, not a quote snapshot.
            entry_price = float(row.get("entry_price") or entry_ref)
            if entry_sig == "BUYCL":
                actual_profit_bricks = (ltp - entry_price) / brick_size
            else:
                actual_profit_bricks = (entry_price - ltp) / brick_size
            profit_guard = getattr(self._cfg, "profit_guard_bricks", 1.0)
            if actual_profit_bricks >= profit_guard:
                trade_manager.at[idx, "nft_validated"] = 1
                changed = True
                log.info(
                    "✅ NFT PROFIT GUARD %s %s: position is +%.2fb — "
                    "not exiting a profitable trade",
                    symbol, entry_sig, actual_profit_bricks,
                )
                continue

            is_choppy  = nft_rev >= self._cfg.reversal_min
            is_stalled = net_move < self._cfg.net_move_min_bricks

            if not (is_choppy and is_stalled):
                trade_manager.at[idx, "nft_validated"] = 1
                changed = True
                log.info("⏱️  NFT ALLOW %s: timeout but not (choppy+stalled)", symbol)
                continue

            exit_sig = "SELCL" if entry_sig == "BUYCL" else "SELPT"
            already  = not trade_manager[
                (trade_manager["symbol"] == symbol) &
                (trade_manager["renko_signal"] == exit_sig) &
                (trade_manager["order_status"].isin(("OPEN", "SENDING")))
            ].empty

            if not already:
                qty = int(row.get("quantity") or 0)
                trade_manager = pd.concat([trade_manager, pd.DataFrame([{
                    "exchange":     exchange,
                    "timestamp":    _now().strftime("%Y-%m-%d %H:%M:%S"),
                    "symbol":       symbol,
                    "renko_signal": exit_sig,
                    "entry_price":  float(ltp),
                    "quantity":     int(qty),
                    "order_status": "OPEN",
                    "close_reason": "NFT_NO_FOLLOW_THROUGH",
                }])], ignore_index=True)
                changed = True
                log.info(
                    "⏱️ 🚫 NFT EXIT %s: created %s after %.0fs "
                    "(rev=%d net=%.2fb timeout=%.0fs)",
                    symbol, exit_sig, elapsed, nft_rev, net_move, timeout,
                )

        return trade_manager, changed

    def _check_validation(
        self, entry_sig, ltp, nft_target, entry_ref, row
    ) -> Tuple[bool, str]:
        if nft_target > 0:
            if entry_sig == "BUYCL" and ltp >= nft_target:
                return True, f"INDEX({ltp:.2f}>={nft_target:.2f})"
            if entry_sig == "BUYPT" and ltp <= nft_target:
                return True, f"INDEX({ltp:.2f}<={nft_target:.2f})"
        opt_sym   = row.get("option_symbol")
        opt_entry = row.get("exec_price")
        if opt_sym and opt_entry and pd.notna(opt_entry) and float(opt_entry) > 0:
            opt_ltp, _ = ltp_store.get(str(opt_sym))
            if opt_ltp and float(opt_ltp) > 0:
                pct = (float(opt_ltp) - float(opt_entry)) / float(opt_entry) * 100
                if pct >= self._cfg.option_profit_pct:
                    return True, f"OPTION({pct:+.1f}%)"
        return False, ""

    def _dynamic_timeout(
        self,
        elapsed:    float,
        brick_size: float,
        renko_df:   Optional[pd.DataFrame],
        fill_ts,
        symbol:     str = "",
    ) -> float:
        """BUG-4 FIX: measures actual brick velocity from renko_df.
        FIX-3: per-instrument timeout bounds override global timeout_min/max
        for coarse-brick MCX instruments (GOLDM, SILVERM) that move slowly."""
        target_secs = self._cfg.target_sec_per_brick
        nft_bricks  = getattr(self._cfg, "follow_through_bricks", 2)

        # FIX-3: resolve per-instrument timeout bounds
        _min_override = getattr(self._cfg, "timeout_min_override", {})
        _max_override = getattr(self._cfg, "timeout_max_override", {})
        # Match on root symbol (strip digits/expiry suffix)
        import re as _re
        _root = (_re.match(r"^([A-Z]+)", symbol.upper()) or
                 _re.match(r"^([A-Z]+)", "X")).group(1)
        _t_min = _min_override.get(_root, self._cfg.timeout_min)
        _t_max = _max_override.get(_root, self._cfg.timeout_max)
        if _root in _min_override:
            log.debug(
                "NFT timeout override for %s: min=%ds max=%ds (global: %d/%d)",
                _root, _t_min, _t_max, self._cfg.timeout_min, self._cfg.timeout_max,
            )

        if renko_df is not None and "timestamp" in renko_df.columns and fill_ts is not None:
            try:
                fill_dt = pd.to_datetime(fill_ts)
                if fill_dt.tzinfo is None:
                    fill_dt = fill_dt.tz_localize(IST)

                ts_series = pd.to_datetime(renko_df["timestamp"])
                if ts_series.dt.tz is None:
                    ts_series = ts_series.dt.tz_localize(IST)

                bricks_after_fill = renko_df[ts_series > fill_dt]
                n = len(bricks_after_fill)

                if n >= 2:
                    first_ts = ts_series[bricks_after_fill.index[0]]
                    last_ts  = ts_series[bricks_after_fill.index[-1]]
                    span     = (last_ts - first_ts).total_seconds()
                    if span > 0:
                        secs_per_brick = span / (n - 1)
                        timeout        = secs_per_brick * nft_bricks
                        return max(_t_min, min(_t_max, timeout))
            except Exception:
                log.debug("NFT dynamic timeout: renko parse failed", exc_info=True)

        timeout = target_secs * nft_bricks
        return max(_t_min, min(_t_max, timeout))

    @staticmethod
    def _track_reversals(
        df:         pd.DataFrame,
        idx,
        row:        pd.Series,
        ltp:        float,
        brick_size: float,
        entry_ref:  float,
        entry_sig:  str,
    ) -> Tuple[pd.DataFrame, bool]:
        """BUG-3 FIX: uses nft_last_ltp (not chop_last_ltp)."""
        changed   = False
        last_ltp  = row.get("nft_last_ltp")
        last_dir  = row.get("nft_last_dir")
        rev_count = int(row.get("nft_rev_count") or 0)

        if last_ltp and pd.notna(last_ltp) and float(last_ltp) > 0:
            delta = ltp - float(last_ltp)
            if abs(delta) >= 0.25 * brick_size:
                cur_dir = "UP" if delta > 0 else "DOWN"
                if last_dir and str(last_dir) != cur_dir:
                    rev_count += 1
                    df.at[idx, "nft_rev_count"] = rev_count
                    changed = True
                df.at[idx, "nft_last_dir"] = cur_dir
                df.at[idx, "nft_last_ltp"] = ltp
                changed = True
        elif pd.isna(row.get("nft_last_ltp")) or row.get("nft_last_ltp") is None:
            df.at[idx, "nft_last_ltp"] = ltp
            changed = True
        return df, changed


# ─────────────────────────────────────────────────────────────────────────────
# ISSUE-D: Improved Chop Oscillation Checker
# ─────────────────────────────────────────────────────────────────────────────

class ChopOscillationChecker:
    """
    ISSUE-D FIX: 6-gate chop exit replaces the original single-trigger logic
    that caused exits at ~73 seconds.

    Uses chop_last_ltp and chop_last_dir exclusively (BUG-3 preserved).

    Gate sequence (ALL must pass):
      1. min_hold_secs      no eval before 180s (default)
      2. min_hold_bars      min 3 new bricks since entry (default)
      3. adverse_excursion  stop-loss territory guard (default 0.75b)
      4. regime_filter      suppress in TRENDING (default True)
      5. momentum_decay     require decaying Colour_Brick_Count (default True)
      6. two_stage confirm  2 confirmations in window (default True)
    """

    def __init__(self) -> None:
        self._cfg = cfg.chop_oscillation
        # Two-stage confirmation state per symbol
        self._pending: Dict[str, dict] = {}
        self._pending_lock = threading.Lock()

    def check_and_annotate(
        self,
        trade_manager: pd.DataFrame,
        symbol:        str,
        exchange:      str,
        ltp:           float,
        brick_size:    float,
        renko_df:       Optional[pd.DataFrame] = None,
        current_regime: Optional[str]          = None,   # FIX I-10: live regime
    ) -> Tuple[pd.DataFrame, bool]:
        if not self._cfg.enabled:
            return trade_manager, False

        changed = False
        mask = (
            (trade_manager["symbol"] == symbol) &
            (trade_manager["exchange"] == exchange) &
            (trade_manager["renko_signal"].isin(["BUYCL", "BUYPT"])) &
            (trade_manager["order_status"] == "INPOSITION")
        )
        rows = trade_manager[mask]

        for idx, row in rows.iterrows():
            entry_sig = str(row.get("renko_signal", ""))
            entry_ref = float(row.get("index_ltp") or row.get("entry_price") or 0)
            fill_ts   = row.get("fill_timestamp")
            if entry_ref <= 0 or fill_ts is None:
                continue

            try:
                _fill_dt = pd.to_datetime(fill_ts)
                if _fill_dt.tzinfo is None:
                    _fill_dt = _fill_dt.tz_localize(IST)
                else:
                    _fill_dt = _fill_dt.tz_convert(IST)
                elapsed = (_now() - _fill_dt).total_seconds()
            except Exception:
                elapsed = 0

            # ── Gate 1: minimum hold time ─────────────────────────────────
            min_hold = getattr(self._cfg, "min_hold_secs", 180)
            if elapsed < min_hold:
                log.debug(
                    "⏳ CHOP GATE(hold_secs): %s hold=%.0fs < min=%.0fs",
                    symbol, elapsed, min_hold,
                )
                continue

            # ── Gate 2: minimum brick count since entry ───────────────────
            min_bars = getattr(self._cfg, "min_hold_bars", 3)
            if renko_df is not None and not renko_df.empty:
                try:
                    ts_col = pd.to_datetime(renko_df.get(
                        "timestamp", pd.Series(dtype="object")
                    ))
                    if ts_col.dt.tz is None:
                        ts_col = ts_col.dt.tz_localize(IST)
                    _fts = pd.to_datetime(fill_ts)
                    if _fts.tzinfo is None:
                        _fts = _fts.tz_localize(IST)
                    bricks_since = int((ts_col > _fts).sum())
                except Exception:
                    bricks_since = len(renko_df)
                if bricks_since < min_bars:
                    log.debug(
                        "⏳ CHOP GATE(min_bars): %s bricks_since=%d < %d",
                        symbol, bricks_since, min_bars,
                    )
                    continue

            # ── Gate 3: adverse excursion guard ──────────────────────────
            # FIX-1 (LIVE): apply per-symbol override before computing threshold.
            # Global default 0.75b × 12 = 9pts fires on every NIFTY tick noise.
            # NIFTY override 1.25b × 12 = 15pts matches real intraday noise floor.
            _ae_overrides = getattr(self._cfg, "adverse_excursion_bricks_override", {})
            ae_bricks = _ae_overrides.get(symbol, getattr(self._cfg, "adverse_excursion_bricks", 0.75))
            if brick_size > 0:
                direction = "CALL" if entry_sig == "BUYCL" else "PUT"
                adverse_pts = (
                    (entry_ref - ltp) if direction == "CALL" else (ltp - entry_ref)
                )
                if adverse_pts > ae_bricks * brick_size:
                    log.debug(
                        "🚫 CHOP GATE(adverse_exc): %s %.1fpts > %.1fpts threshold",
                        symbol, adverse_pts, ae_bricks * brick_size,
                    )
                    continue

            # ── Gate 4: regime filter ─────────────────────────────────────
            if getattr(self._cfg, "regime_filter_enabled", True):
                # FIX I-10: use live current_regime param instead of stale row value.
                # row.get("day_regime") is written at ENTRY time and stays stale
                # after the 45-min reclassify. Live regime is passed from engine.
                if current_regime is not None:
                    regime = str(current_regime).upper()
                else:
                    regime = str(row.get("day_regime") or "UNKNOWN").upper()
                if regime == "TRENDING":
                    log.debug(
                        "🚫 CHOP GATE(regime): %s TRENDING — suppressed", symbol,
                    )
                    continue

            # ── Gate 5: momentum decay ────────────────────────────────────
            if getattr(self._cfg, "require_momentum_decay", True):
                if renko_df is not None and not renko_df.empty:
                    if "Colour_Brick_Count" in renko_df.columns:
                        try:
                            last_row   = renko_df.iloc[-1]
                            last_cbc   = int(last_row["Colour_Brick_Count"])
                            last_dir   = int(last_row.get("direction", 0))
                            _direction = "CALL" if entry_sig == "BUYCL" else "PUT"
                            # Colour_Brick_Count is always a positive integer — it
                            # counts consecutive same-direction bricks regardless of
                            # direction.  The old PUT check (cbc <= -2) could never
                            # fire because the column is never negative.
                            # Fix: gate on brick count AND the direction column
                            # (1=up=bullish, -1=down=bearish) so both CALL and PUT
                            # suppression work symmetrically.
                            if _direction == "CALL" and last_dir == 1 and last_cbc >= 2:
                                log.debug(
                                    "🚫 CHOP GATE(momentum): %s CALL cbc=%d dir=UP — suppressed",
                                    symbol, last_cbc,
                                )
                                continue
                            if _direction == "PUT" and last_dir == -1 and last_cbc >= 2:
                                log.debug(
                                    "🚫 CHOP GATE(momentum): %s PUT cbc=%d dir=DOWN — suppressed",
                                    symbol, last_cbc,
                                )
                                continue
                        except (ValueError, TypeError, IndexError):
                            pass

            # ── Core oscillation counting (BUG-3: own columns) ────────────
            dist      = abs(ltp - entry_ref) / brick_size
            reversals = int(row.get("chop_reversals") or 0)
            last_ltp  = row.get("chop_last_ltp")
            last_dir  = row.get("chop_last_dir")

            if last_ltp and pd.notna(last_ltp) and float(last_ltp) > 0:
                delta = ltp - float(last_ltp)
                if abs(delta) >= 0.5 * brick_size:
                    cur_dir = "UP" if delta > 0 else "DOWN"
                    if last_dir and str(last_dir) != cur_dir:
                        reversals += 1
                        trade_manager.at[idx, "chop_reversals"] = reversals
                        changed = True
                    trade_manager.at[idx, "chop_last_dir"] = cur_dir
                    trade_manager.at[idx, "chop_last_ltp"] = ltp
                    changed = True
            elif pd.isna(row.get("chop_last_ltp")) or row.get("chop_last_ltp") is None:
                trade_manager.at[idx, "chop_last_ltp"] = ltp
                changed = True

            threshold_met = (
                reversals >= self._cfg.reversals_max
                and dist   <= self._cfg.range_bricks
                and elapsed <= self._cfg.window_secs
            )
            if not threshold_met:
                continue

            # ── Gate 6: two-stage confirmation ────────────────────────────
            if getattr(self._cfg, "two_stage_required", True):
                now_mono        = time.monotonic()
                confirm_window  = getattr(self._cfg, "confirmation_window_secs", 30)
                confirms_needed = getattr(self._cfg, "confirmations_required", 2)

                with self._pending_lock:
                    pstate = self._pending.get(symbol)

                    if pstate is None or not pstate.get("pending"):
                        self._pending[symbol] = {
                            "pending":       True,
                            "pending_since": now_mono,
                            "confirm_count": 1,
                        }
                        log.info(
                            "🔶 CHOP STAGE-1 PENDING: %s | hold=%.0fs rev=%d "
                            "— awaiting confirmation within %ds",
                            symbol, elapsed, reversals, confirm_window,
                        )
                        continue

                    age = now_mono - pstate["pending_since"]
                    if age > confirm_window:
                        self._pending[symbol] = {
                            "pending": False, "pending_since": 0, "confirm_count": 0,
                        }
                        log.info(
                            "⏳ CHOP STAGE-1 EXPIRED: %s — %.0fs window elapsed, resetting",
                            symbol, age,
                        )
                        continue

                    pstate["confirm_count"] += 1
                    if pstate["confirm_count"] < confirms_needed:
                        log.debug(
                            "🔶 CHOP STAGE-2 PARTIAL: %s confirms=%d/%d",
                            symbol, pstate["confirm_count"], confirms_needed,
                        )
                        continue

                    # All confirmations received
                    self._pending.pop(symbol, None)

            # ── All gates passed — fire chop exit ─────────────────────────
            exit_sig = "SELCL" if entry_sig == "BUYCL" else "SELPT"
            already  = not trade_manager[
                (trade_manager["symbol"] == symbol) &
                (trade_manager["renko_signal"] == exit_sig) &
                (trade_manager["order_status"].isin(("OPEN", "SENDING")))
            ].empty
            if not already:
                qty = int(row.get("quantity") or 0)
                trade_manager = pd.concat([trade_manager, pd.DataFrame([{
                    "exchange":     exchange,
                    "timestamp":    _now().strftime("%Y-%m-%d %H:%M:%S"),
                    "symbol":       symbol,
                    "renko_signal": exit_sig,
                    "entry_price":  float(ltp),
                    "quantity":     int(qty),
                    "order_status": "OPEN",
                    "close_reason": "CHOP_OSCILLATION_EXIT",
                }])], ignore_index=True)
                changed = True
                log.warning(
                    "🌀 CHOP EXIT CONFIRMED: %s %s | hold=%.0fs rev=%d "
                    "(all 6 gates passed)",
                    exit_sig, symbol, elapsed, reversals,
                )

        return trade_manager, changed

    def clear_pending(self, symbol: str) -> None:
        """Clear two-stage pending state on any position close."""
        with self._pending_lock:
            self._pending.pop(symbol, None)


# ─────────────────────────────────────────────────────────────────────────────
# RiskEngine — dedicated circuit-breaker thread
# ─────────────────────────────────────────────────────────────────────────────

class RiskEngine:
    """
    Standalone 500ms risk thread:
    - Daily max-loss circuit breaker
    - Consecutive-loss circuit breaker
    - Kill-switch file watcher
    """

    def __init__(self) -> None:
        self._cfg             = cfg.risk_engine if hasattr(cfg, "risk_engine") else None
        self.trading_halted   = False
        self.halt_reason      = ""
        self._session_pnl:   float = 0.0
        self._closed_trades: list  = []
        self._consec_losses: int   = 0
        self._target_locked: bool  = False   # FIX NEW: daily profit target lock
        self._lock           = threading.Lock()
        self._stop_event     = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self) -> None:
        self._thread = threading.Thread(
            target=self._loop, daemon=True, name="risk-engine"
        )
        self._thread.start()
        log.info("⚡ RiskEngine thread started")

    def stop(self) -> None:
        self._stop_event.set()

    def record_close(self, symbol: str, pnl_pts: float, lots: int, lot_size: int) -> None:
        from tcos_bot.config.settings import PNL_RUPEE_PER_PT
        rps    = PNL_RUPEE_PER_PT.get(symbol, 1)
        pnl_rs = pnl_pts * lots * lot_size * rps
        with self._lock:
            self._session_pnl += pnl_rs
            self._closed_trades.append({"symbol": symbol, "pnl_rs": pnl_rs, "ts": _now()})
            if pnl_rs < 0:
                self._consec_losses += 1
            else:
                self._consec_losses = 0
            # F-11 FIX: trigger target check with time gate.
            # Only lock after target_lock_after_time (default 13:30 IST).
            if self._cfg and self._is_past_target_lock_time():
                _target = getattr(self._cfg, "daily_target_rs", 0.0)
                if _target > 0 and self._session_pnl >= _target and not self._target_locked:
                    self._target_locked = True
                    self.trading_halted = True
                    self.halt_reason    = (
                        f"DAILY_TARGET_REACHED: session_pnl=₹{self._session_pnl:.0f} "
                        f">= target=₹{_target:.0f} — all new entries blocked"
                    )
                    log.info("🎯 %s", self.halt_reason)
        log.info(
            "💰 TRADE CLOSE %s: pnl_pts=%.2f pnl_rs=%.0f "
            "session_pnl=%.0f consec_losses=%d",
            symbol, pnl_pts, pnl_rs, self._session_pnl, self._consec_losses,
        )

    def is_entry_allowed(self, symbol: str = "") -> Tuple[bool, str]:
        if self.trading_halted:
            return False, self.halt_reason
        if os.path.exists(_KILL_SWITCH_FILE):
            self._halt("KILL_SWITCH_FILE")
            return False, self.halt_reason

        # GAP-B FIX: Include unrealized P&L from open positions in the
        # daily-max-loss check.  Without this, a bot holding a -₹40k floating
        # loss can still open new trades even with max_daily_loss_rs=50000,
        # because _session_pnl (realized only) shows 0.
        # We add a lightweight open-position P&L estimate using ltp_store.
        # This only fires when the realized session_pnl is already positive or
        # near the threshold — otherwise the check is skipped for performance.
        if self._cfg is not None and not self.trading_halted:
            max_loss = getattr(self._cfg, "max_daily_loss_rs", 0.0)
            if max_loss > 0:
                try:
                    unrealized = self._compute_unrealized_pnl()
                    with self._lock:
                        combined = self._session_pnl + unrealized
                    if combined < -abs(max_loss):
                        self._halt(
                            f"DAILY_MAX_LOSS (incl. unrealized): "
                            f"realized={self._session_pnl:.0f} + "
                            f"unrealized={unrealized:.0f} = {combined:.0f} < "
                            f"-{max_loss:.0f}"
                        )
                        return False, self.halt_reason
                except Exception:
                    pass   # unrealized calc failure → do not block entries

        return True, ""

    def _compute_unrealized_pnl(self) -> float:
        """
        GAP-B: Estimate unrealized P&L for all currently-INPOSITION rows
        by reading underlying LTP from ltp_store.

        Uses the same pnl_pts * lots * lot_size * rps formula as record_close.
        Returns 0.0 if trade_store or ltp_store is unavailable (fail-safe).
        This is a best-effort estimate — option P&L is not read directly
        because option feeds can be stale.  Underlying-based P&L is reliable
        since it is the same source used for stop and trail decisions.
        """
        try:
            from tcos_bot.data.trade_store import trade_store
            from tcos_bot.data.ltp_store import ltp_store
            from tcos_bot.config.settings import PNL_RUPEE_PER_PT
            tm = trade_store.read_df()
            if tm.empty:
                return 0.0
            mask = (
                tm["renko_signal"].isin(["BUYCL", "BUYPT"]) &
                (tm["order_status"] == "INPOSITION")
            )
            if not mask.any():
                return 0.0
            total = 0.0
            for _, row in tm[mask].iterrows():
                sym      = str(row.get("symbol", ""))
                action   = str(row.get("renko_signal", ""))
                entry_px = float(row.get("entry_price") or 0)
                qty      = int(row.get("quantity") or 0)
                if entry_px <= 0 or qty <= 0:
                    continue
                ltp, age = ltp_store.get(sym)
                if ltp is None or age > 60:
                    continue   # stale or missing → skip this position
                pnl_pts = (ltp - entry_px) if action == "BUYCL" else (entry_px - ltp)
                rps     = PNL_RUPEE_PER_PT.get(sym, 1.0)
                # Approximate lots from quantity (lot_size from ltp_store not available here,
                # use quantity directly since pnl_pts * qty * rps is the correct formula
                # when lot_size is already baked into qty).
                # qty = lots * lot_size, so pnl_rs = pnl_pts * qty * rps
                total += pnl_pts * qty * rps
            return total
        except Exception:
            return 0.0

    def _loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                self._check_all()
            except Exception:
                log.exception("RiskEngine loop error")
            time.sleep(0.5)

    def _check_all(self) -> None:
        if os.path.exists(_KILL_SWITCH_FILE):
            self._halt("KILL_SWITCH_FILE")
            return
        # FIX I-11: self._cfg was always None before (BotConfig had no risk_engine field).
        # Now that RiskEngineConfig is wired in, these checks are finally live.
        if self.trading_halted or self._cfg is None:
            return
        with self._lock:
            session_pnl   = self._session_pnl
            consec_losses = self._consec_losses
        if (
            hasattr(self._cfg, "max_daily_loss_rs")
            and session_pnl < -abs(self._cfg.max_daily_loss_rs)
        ):
            self._halt(
                f"DAILY_MAX_LOSS: session_pnl={session_pnl:.0f} < "
                f"-{self._cfg.max_daily_loss_rs}"
            )
            return
        if (
            hasattr(self._cfg, "max_consecutive_losses")
            and consec_losses >= self._cfg.max_consecutive_losses
        ):
            self._halt(
                f"CONSECUTIVE_LOSSES: {consec_losses} >= "
                f"{self._cfg.max_consecutive_losses}"
            )
            return
        # F-11 FIX: daily profit target lock with time gate.
        # Only activates after target_lock_after_time (default 13:30 IST).
        # Morning trades (09:30-13:30) proceed normally even after target is hit.
        target = getattr(self._cfg, "daily_target_rs", 0.0)
        if target > 0 and session_pnl >= target and not self.trading_halted:
            if not getattr(self, "_target_locked", False) and self._is_past_target_lock_time():
                self._target_locked = True
                self.trading_halted  = True
                self.halt_reason     = (
                    f"DAILY_TARGET_REACHED: session_pnl=₹{session_pnl:.0f} "
                    f">= target=₹{target:.0f} — all new entries blocked"
                )
                log.info("🎯 %s", self.halt_reason)
                try:
                    with open("TCOS_TARGET.flag", "w") as _f:
                        _f.write(f"{_now().isoformat()}|{self.halt_reason}\n")
                except Exception:
                    pass

    def _is_past_target_lock_time(self) -> bool:
        """
        F-11 FIX: Return True if the current IST time is at or after
        target_lock_after_time (default "13:30").

        Empty string → always return True (original immediate-lock behaviour).
        Invalid format → return True (fail-safe: lock as before).
        """
        lock_time_str = getattr(self._cfg, "target_lock_after_time", "") if self._cfg else ""
        if not lock_time_str:
            return True   # empty = lock immediately (old behaviour)
        try:
            h, m  = map(int, lock_time_str.split(":"))
            now_t = _now().time()
            from datetime import time as _dtime
            return now_t >= _dtime(h, m)
        except Exception:
            return True   # parse failure → fail-safe, lock as before

    def _halt(self, reason: str) -> None:
        if self.trading_halted:
            return
        self.trading_halted = True
        self.halt_reason    = reason
        log.critical("🚨 TRADING HALTED: %s", reason)
        try:
            with open("TCOS_HALT.flag", "w") as f:
                f.write(f"{_now().isoformat()}|{reason}\n")
        except Exception:
            pass


# ── Module-level singletons ────────────────────────────────────────────────────

whipsaw_tracker   = WhipsawCooldownTracker()
trailing_stop_mgr = TrailingStopManager()
nft_checker       = NFTChecker()
chop_checker      = ChopOscillationChecker()
risk_engine       = RiskEngine()
