"""
Risk Controls — tcos_bot/risk/controls.py
==========================================
PR-5: New module implementing the missing risk controls from audit section 3.x

Contents
--------
MarginGuard           — validates available margin before every entry order
SlippageModel         — estimates realistic fill price and P&L impact
PartialFillReconciler — reconciles broker fills vs internal state, handles splits
ExposureGuard         — prevents stacking correlated positions across symbols
TradeLedger           — structured P&L, fees, slippage, realized/unrealized
KillSwitch            — file-based + programmatic kill switch for safe shutdown
"""

from __future__ import annotations

import logging
import os
import threading
import time
from datetime import datetime
from typing import Dict, List, Optional, Tuple

import pandas as pd

from tcos_bot.config.settings import IST, cfg

log = logging.getLogger(__name__)

_KILL_SWITCH_FILE = os.path.join(os.getcwd(), "KILL_SWITCH")
_HALT_FLAG_FILE   = os.path.join(os.getcwd(), "TCOS_HALT.flag")


def _now() -> datetime:
    return datetime.now(tz=IST)


# ── Kill Switch ────────────────────────────────────────────────────────────────

class KillSwitch:
    """
    File-based + programmatic kill switch.

    Activation methods:
        1. Create file: `touch KILL_SWITCH` in cwd
        2. Call: kill_switch.activate("reason")
        3. Hotkey: Ctrl+C → main() catches KeyboardInterrupt and calls activate()

    Safe shutdown procedure:
        1. Halt all new entry creation (is_active returns True)
        2. Cancel all OPEN entry rows in trade_manager
        3. Close all INPOSITION via market SELL orders
        4. Wait for fills, then exit process

    Engine checks is_active() at the top of _execute_open_orders().
    """

    def __init__(self) -> None:
        self._active  = False
        self._reason  = ""
        # RLock (re-entrant): is_active() holds the lock while calling
        # activate(), which also acquires it — an RLock prevents the
        # resulting deadlock that threading.Lock() would cause.
        self._lock    = threading.RLock()

    def is_active(self) -> bool:
        if self._active:
            return True
        # Check file
        if os.path.exists(_KILL_SWITCH_FILE):
            with self._lock:
                if not self._active:
                    self.activate("KILL_SWITCH_FILE")
            return True
        return False

    def activate(self, reason: str) -> None:
        with self._lock:
            if self._active:
                return
            self._active = True
            self._reason = reason
        log.critical("🛑 KILL SWITCH ACTIVATED: %s", reason)
        try:
            with open(_HALT_FLAG_FILE, "w") as f:
                f.write(f"{_now().isoformat()}|{reason}\n")
        except Exception:
            pass

    def deactivate(self) -> None:
        """Manual deactivation (requires delete of KILL_SWITCH file first)."""
        if os.path.exists(_KILL_SWITCH_FILE):
            log.error("Cannot deactivate: KILL_SWITCH file still exists. "
                      "Run: rm KILL_SWITCH")
            return
        with self._lock:
            self._active = False
            self._reason = ""
        if os.path.exists(_HALT_FLAG_FILE):
            try:
                os.remove(_HALT_FLAG_FILE)
            except Exception:
                pass
        log.info("✅ Kill switch deactivated")

    @property
    def reason(self) -> str:
        return self._reason


kill_switch = KillSwitch()


# ── Margin Guard ───────────────────────────────────────────────────────────────

class MarginGuard:
    """
    Validates available margin before placing an entry order.

    Conservative fallback: if the broker API fails or returns an
    ambiguous response, BLOCK the trade (safe side is no trade).
    This can be overridden per-symbol with an emergency override flag.

    Usage
    -----
    ok, reason = margin_guard.check(symbol, estimated_premium, quantity)
    if not ok:
        return  # skip order
    """

    _MARGIN_TTL_SECS = 30   # re-query margin at most every 30s
    _MIN_SAFETY_BUFFER = 1.2   # require 20% buffer above required margin

    def __init__(self, client) -> None:
        self._client       = client
        self._cached_funds: Optional[float] = None
        self._cached_at:    float           = 0.0
        self._lock         = threading.Lock()

    def check(
        self,
        symbol:    str,
        premium:   float,  # current option LTP
        quantity:  int,
        lot_size:  int,
    ) -> Tuple[bool, str]:
        """
        Returns (allowed, reason).
        Blocks if available funds < premium * qty * safety_buffer.
        """
        cfg_obj = getattr(cfg, "margin_guard", None)
        if cfg_obj is not None and not getattr(cfg_obj, "enabled", True):
            return True, "MARGIN_CHECK_DISABLED"

        available = self._get_available_funds()
        if available is None:
            msg = "MARGIN_API_FAILED — blocking new entry (safe fallback)"
            log.error("🚫 %s", msg)
            return False, msg

        required = premium * quantity * self._MIN_SAFETY_BUFFER
        if available < required:
            msg = (f"INSUFFICIENT_MARGIN: available={available:.0f} < "
                   f"required={required:.0f} (premium={premium:.2f} qty={quantity})")
            log.warning("🚫 %s", msg)
            return False, msg

        log.debug("✅ Margin OK for %s: available=%.0f required=%.0f",
                  symbol, available, required)
        return True, ""

    def _get_available_funds(self) -> Optional[float]:
        with self._lock:
            if (time.time() - self._cached_at) < self._MARGIN_TTL_SECS and \
               self._cached_funds is not None:
                return self._cached_funds

        try:
            resp = self._client.funds()
            if not isinstance(resp, dict) or resp.get("status") != "success":
                log.warning("Margin API returned: %s", str(resp)[:200])
                return None
            data = resp.get("data", {})
            # OpenAlgo response structure
            avail = (
                data.get("availablecash")
                or data.get("available_cash")
                or data.get("net")
                or data.get("available_balance")
            )
            if avail is None:
                log.warning("Cannot parse available funds from: %s", data)
                return None
            funds = float(avail)
            with self._lock:
                self._cached_funds = funds
                self._cached_at    = time.time()
            log.debug("💰 Available funds: %.0f", funds)
            return funds
        except Exception:
            log.exception("MarginGuard._get_available_funds failed")
            return None


# ── Slippage Model ─────────────────────────────────────────────────────────────

class SlippageModel:
    """
    Estimates realistic fill price and P&L impact from slippage.

    Model (simple): MARKET order on NSE/BSE options.
        - Bid-ask spread: typically 0.5–2% of premium
        - Market impact: ~0.1% for standard lot sizes
        - Total slippage = spread_pct + impact_pct (asymmetric: entry vs exit)

    Usage
    -----
    adjusted_entry = slippage.adjust_entry(ltp=150.0, symbol="NIFTY")
    adjusted_exit  = slippage.adjust_exit(ltp=120.0, symbol="NIFTY")
    pnl_after_slip = slippage.net_pnl(entry=150.0, exit=120.0, qty=50, symbol="NIFTY")
    """

    # Slippage rates as fraction of premium (empirical NSE options)
    _ENTRY_SLIP_PCT = 0.005   # 0.5% — we buy at ask
    _EXIT_SLIP_PCT  = 0.005   # 0.5% — we sell at bid

    def adjust_entry(self, ltp: float, symbol: str = "") -> float:
        """Return realistic entry fill price (LTP + slippage)."""
        slip = ltp * self._ENTRY_SLIP_PCT
        return round(ltp + slip, 2)

    def adjust_exit(self, ltp: float, symbol: str = "") -> float:
        """Return realistic exit fill price (LTP - slippage)."""
        slip = ltp * self._EXIT_SLIP_PCT
        return round(ltp - slip, 2)

    def net_pnl(
        self,
        entry_ltp:  float,
        exit_ltp:   float,
        quantity:   int,
        symbol:     str = "",
        brokerage:  float = 40.0,   # flat ₹40/order (Zerodha-style)
        taxes_pct:  float = 0.0018, # STT + GST + stamps (≈0.18%)
    ) -> dict:
        """
        Return a P&L breakdown dict after slippage, brokerage, and taxes.
        quantities are in number of shares (lots × lot_size).
        """
        adj_entry  = self.adjust_entry(entry_ltp, symbol)
        adj_exit   = self.adjust_exit(exit_ltp, symbol)
        gross_pnl  = (adj_exit - adj_entry) * quantity
        turnover   = (adj_entry + adj_exit) * quantity
        tax_charge = turnover * taxes_pct
        brokerage_total = brokerage * 2   # entry + exit order
        net_pnl    = gross_pnl - tax_charge - brokerage_total
        slip_cost  = (adj_entry - entry_ltp + exit_ltp - adj_exit) * quantity
        return {
            "adj_entry":  adj_entry,
            "adj_exit":   adj_exit,
            "gross_pnl":  round(gross_pnl, 2),
            "slip_cost":  round(-abs(slip_cost), 2),
            "brokerage":  round(-brokerage_total, 2),
            "taxes":      round(-tax_charge, 2),
            "net_pnl":    round(net_pnl, 2),
        }


slippage_model = SlippageModel()


# ── Partial Fill Reconciler ────────────────────────────────────────────────────

class PartialFillReconciler:
    """
    Reconciles broker fill quantity vs intended quantity.
    Handles split fills and updates the trade_manager row accordingly.

    Problem: broker fills 40 of 50 → bot marks INPOSITION with qty=50
             → at exit it sends SELL 50, but only 40 exist → rejection or naked short.

    Fix:
        1. After order placement, query broker order status for filled_qty.
        2. Update trade_manager row quantity to actual filled_qty.
        3. If filled_qty=0 → revert to OPEN or REJECTED.
        4. If partial → mark PARTIAL_FILL + log.

    Usage (called from OrderRouter._on_entry_fill after success response)
    """

    def __init__(self, client) -> None:
        self._client = client

    def verify_fill(
        self,
        order_id:  str,
        intended:  int,
    ) -> Tuple[int, str]:
        """
        Returns (actual_filled_qty, status_str).
        Falls back to intended qty if API fails (conservative: assume full fill).
        """
        if not order_id:
            return intended, "NO_ORDERID"
        try:
            resp = self._client.order_status(order_id=order_id)
            if not isinstance(resp, dict) or resp.get("status") != "success":
                log.warning("order_status API error for %s: %s", order_id, resp)
                return intended, "API_ERROR_ASSUME_FULL"
            data      = resp.get("data", {})
            filled    = int(data.get("filledshares") or data.get("filled_qty") or 0)
            qty       = int(data.get("quantity") or intended)
            st        = str(data.get("orderstatus") or data.get("status") or "")

            if filled == 0 and "reject" in st.lower():
                return 0, "REJECTED"
            if filled == 0 and "cancel" in st.lower():
                return 0, "CANCELLED"
            if filled == 0:
                log.warning("⚠️ order %s: filled=0 status=%s — treating as full fill", order_id, st)
                return intended, f"ZERO_FILL_ASSUME_{st}"
            if filled < qty:
                log.warning("⚠️ PARTIAL FILL order %s: filled=%d / %d", order_id, filled, qty)
                return filled, f"PARTIAL_{filled}of{qty}"
            return filled, "FULL"
        except Exception:
            log.exception("PartialFillReconciler.verify_fill error for %s", order_id)
            return intended, "EXCEPTION_ASSUME_FULL"


# ── Exposure Guard ─────────────────────────────────────────────────────────────

class ExposureGuard:
    """
    Prevents stacking correlated positions across multiple symbols.

    Rules (configurable):
        max_concurrent_positions: int     — total open positions across all symbols
        max_same_direction:       int     — max CALL or PUT positions simultaneously
        correlated_symbols:       list    — treat these as same underlying

    Example: NIFTY + BANKNIFTY are highly correlated — buying CALL on both
             doubles effective delta exposure.  Guard limits this to 1
             unless explicitly configured.
    """

    def __init__(self) -> None:
        cfg_obj = getattr(cfg, "exposure_guard", None)
        self._max_concurrent = getattr(cfg_obj, "max_concurrent_positions", 2)
        self._max_direction  = getattr(cfg_obj, "max_same_direction", 1)
        self._corr_groups: list[list[str]] = getattr(
            cfg_obj, "correlated_groups",
            [["NIFTY", "BANKNIFTY", "FINNIFTY", "MIDCPNIFTY"],
             ["SENSEX", "BANKEX"]],
        )

    def check(
        self,
        symbol:       str,
        direction:    str,   # "CALL" | "PUT"
        root_positions: Dict[str, Dict[str, int]],  # {root: {"CALL": qty, "PUT": qty}}
    ) -> Tuple[bool, str]:
        """
        Returns (allowed, reason).
        """
        total_open = sum(
            1 for pos in root_positions.values()
            if pos.get("CALL", 0) > 0 or pos.get("PUT", 0) > 0
        )
        if total_open >= self._max_concurrent:
            return False, (f"EXPOSURE_MAX_CONCURRENT: {total_open} positions ≥ "
                           f"{self._max_concurrent}")

        # Check direction stacking
        same_dir_count = sum(
            1 for pos in root_positions.values()
            if pos.get(direction, 0) > 0
        )
        if same_dir_count >= self._max_direction:
            return False, (f"EXPOSURE_MAX_{direction}: {same_dir_count} positions ≥ "
                           f"{self._max_direction}")

        # Correlated group check
        group = self._find_group(symbol)
        if group:
            group_open = sum(
                1 for s in group
                if root_positions.get(s, {}).get(direction, 0) > 0
            )
            if group_open >= self._max_direction:
                return False, (f"EXPOSURE_CORR_GROUP {group}: {group_open} {direction} "
                               f"positions in correlated group")

        return True, ""

    def _find_group(self, symbol: str) -> Optional[List[str]]:
        for grp in self._corr_groups:
            if symbol in grp:
                return grp
        return None


exposure_guard = ExposureGuard()


# ── Trade Ledger ───────────────────────────────────────────────────────────────

class TradeLedger:
    """
    Structured P&L ledger with real reconciliation.

    Replaces the dual-purpose entry_price field with explicit columns:
        intended_entry_price  — what we targeted at signal time
        avg_fill_price        — actual broker fill (from order_status API)
        close_price           — actual broker exit fill

    Persisted to a separate ledger table in the same SQLite DB,
    not mixed with trade_manager rows (prevents schema conflicts).

    Usage
    -----
    On entry fill:
        ledger.record_entry(trade_id, symbol, ...)
    On exit fill:
        ledger.record_exit(trade_id, close_price, close_qty)
    Query:
        ledger.session_summary()  → dict with realized P&L, fees, slippage
    """

    _LOCK = threading.Lock()

    def record_entry(
        self,
        trade_id:             str,
        symbol:               str,
        direction:            str,
        intended_entry_price: float,
        avg_fill_price:       float,
        quantity:             int,
        option_symbol:        str,
        signal_grade:         str,
        regime:               str,
    ) -> None:
        row = {
            "trade_id":             trade_id,
            "symbol":               symbol,
            "direction":            direction,
            "intended_entry_price": intended_entry_price,
            "avg_fill_price":       avg_fill_price,
            "quantity":             quantity,
            "option_symbol":        option_symbol,
            "signal_grade":         signal_grade,
            "regime":               regime,
            "entry_ts":             _now().isoformat(),
            "status":               "OPEN",
            "close_price":          None,
            "close_qty":            None,
            "close_ts":             None,
            "slip_rs":              round((avg_fill_price - intended_entry_price) * quantity, 2),
            "gross_pnl_rs":         None,
            "net_pnl_rs":           None,
        }
        self._upsert(row)

    def record_exit(
        self,
        trade_id:    str,
        close_price: float,
        close_qty:   int,
        reason:      str = "",
    ) -> Optional[dict]:
        """Update ledger row with exit data. Returns P&L breakdown."""
        from tcos_bot.data.trade_store import _engine
        from sqlalchemy import text
        try:
            with _engine.begin() as cn:
                result = cn.execute(
                    text("SELECT * FROM trade_ledger WHERE trade_id=:tid"),
                    {"tid": trade_id}
                ).fetchone()
            if result is None:
                log.warning("TradeLedger: trade_id %s not found", trade_id)
                return None

            row        = dict(result._mapping)
            avg_fill   = float(row.get("avg_fill_price") or 0)
            direction  = str(row.get("direction") or "CALL")
            qty        = int(row.get("quantity") or close_qty)
            opt_sym    = str(row.get("option_symbol") or "")

            pnl_breakdown = slippage_model.net_pnl(
                entry_ltp  = avg_fill,
                exit_ltp   = close_price,
                quantity   = qty,
                symbol     = opt_sym,
            )
            gross_pnl = pnl_breakdown["gross_pnl"]
            net_pnl   = pnl_breakdown["net_pnl"]

            with _engine.begin() as cn:
                cn.execute(text("""
                    UPDATE trade_ledger SET
                        close_price = :cp,
                        close_qty   = :cq,
                        close_ts    = :cts,
                        gross_pnl_rs= :gp,
                        net_pnl_rs  = :np,
                        close_reason= :cr,
                        status      = 'CLOSED'
                    WHERE trade_id = :tid
                """), {
                    "cp": close_price, "cq": close_qty,
                    "cts": _now().isoformat(),
                    "gp": gross_pnl, "np": net_pnl,
                    "cr": reason, "tid": trade_id,
                })
            return pnl_breakdown
        except Exception:
            log.exception("TradeLedger.record_exit failed for %s", trade_id)
            return None

    def session_summary(self) -> dict:
        from tcos_bot.data.trade_store import _engine
        from sqlalchemy import text
        try:
            with _engine.connect() as cn:
                df = pd.read_sql("SELECT * FROM trade_ledger", cn)
            if df.empty:
                return {"trades": 0}
            closed = df[df["status"] == "CLOSED"]
            wins   = closed[closed["net_pnl_rs"] > 0]
            losses = closed[closed["net_pnl_rs"] <= 0]
            return {
                "trades":          len(closed),
                "wins":            len(wins),
                "losses":          len(losses),
                "win_rate":        round(len(wins) / max(1, len(closed)) * 100, 1),
                "gross_pnl_rs":    round(closed["gross_pnl_rs"].sum(), 2),
                "net_pnl_rs":      round(closed["net_pnl_rs"].sum(), 2),
                "avg_net_pnl":     round(closed["net_pnl_rs"].mean(), 2) if len(closed) else 0,
                "open_positions":  len(df[df["status"] == "OPEN"]),
            }
        except Exception:
            log.exception("TradeLedger.session_summary failed")
            return {}

    def _upsert(self, row: dict) -> None:
        from tcos_bot.data.trade_store import _engine
        from sqlalchemy import text

        self._ensure_ledger_table()
        cols   = ", ".join(row.keys())
        placeholders = ", ".join(f":{k}" for k in row.keys())
        with self._LOCK:
            try:
                with _engine.begin() as cn:
                    cn.execute(text(
                        f"INSERT OR REPLACE INTO trade_ledger ({cols}) VALUES ({placeholders})"
                    ), row)
            except Exception:
                log.exception("TradeLedger._upsert failed for trade_id=%s",
                              row.get("trade_id"))

    def _ensure_ledger_table(self) -> None:
        from tcos_bot.data.trade_store import _engine
        from sqlalchemy import text
        ddl = """
        CREATE TABLE IF NOT EXISTS trade_ledger (
            trade_id             TEXT PRIMARY KEY,
            symbol               TEXT,
            direction            TEXT,
            intended_entry_price REAL,
            avg_fill_price       REAL,
            close_price          REAL,
            close_qty            INTEGER,
            quantity             INTEGER,
            option_symbol        TEXT,
            signal_grade         TEXT,
            regime               TEXT,
            entry_ts             TEXT,
            close_ts             TEXT,
            close_reason         TEXT,
            status               TEXT DEFAULT 'OPEN',
            slip_rs              REAL,
            gross_pnl_rs         REAL,
            net_pnl_rs           REAL
        );
        """
        try:
            with _engine.begin() as cn:
                cn.execute(text(ddl))
        except Exception:
            log.exception("TradeLedger._ensure_ledger_table failed")


trade_ledger = TradeLedger()
